.class public Landroidx/activity/EdgeToEdgeApi29;
.super Landroidx/activity/EdgeToEdgeApi28;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# virtual methods
.method public setUp(Landroidx/activity/SystemBarStyle;Landroidx/activity/SystemBarStyle;Landroid/view/Window;Landroid/view/View;ZZ)V
    .registers 7

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    const/4 p0, 0x0

    .line 14
    invoke-static {p3, p0}, Landroidx/core/os/BundleKt;->setDecorFitsSystemWindows(Landroid/view/Window;Z)V

    .line 17
    invoke-virtual {p3, p0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 20
    invoke-virtual {p3, p0}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 23
    invoke-virtual {p3, p0}, Landroid/view/Window;->setStatusBarContrastEnforced(Z)V

    .line 26
    const/4 p0, 0x1

    .line 27
    invoke-virtual {p3, p0}, Landroid/view/Window;->setNavigationBarContrastEnforced(Z)V

    .line 30
    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 32
    const/16 p2, 0x23

    .line 34
    if-lt p1, p2, :cond_29

    .line 36
    new-instance p1, Landroidx/core/view/WindowInsetsControllerCompat$Impl35;

    .line 38
    invoke-direct {p1, p3}, Landroidx/core/view/WindowInsetsControllerCompat$Impl30;-><init>(Landroid/view/Window;)V

    .line 41
    goto :goto_38

    .line 42
    :cond_29
    const/16 p2, 0x1e

    .line 44
    if-lt p1, p2, :cond_33

    .line 46
    new-instance p1, Landroidx/core/view/WindowInsetsControllerCompat$Impl30;

    .line 48
    invoke-direct {p1, p3}, Landroidx/core/view/WindowInsetsControllerCompat$Impl30;-><init>(Landroid/view/Window;)V

    .line 51
    goto :goto_38

    .line 52
    :cond_33
    new-instance p1, Landroidx/core/view/WindowInsetsControllerCompat$Impl26;

    .line 54
    invoke-direct {p1, p3}, Landroidx/core/view/WindowInsetsControllerCompat$Impl26;-><init>(Landroid/view/Window;)V

    .line 57
    :goto_38
    xor-int/lit8 p2, p5, 0x1

    .line 59
    invoke-virtual {p1, p2}, Landroidx/core/os/BundleKt;->setAppearanceLightStatusBars(Z)V

    .line 62
    xor-int/2addr p0, p6

    .line 63
    invoke-virtual {p1, p0}, Landroidx/core/os/BundleKt;->setAppearanceLightNavigationBars(Z)V

    .line 66
    return-void
.end method
