.class public final Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput;
.super Landroidx/navigationevent/NavigationEventInput;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public final dispatcher:Lkotlin/text/MatcherMatchResult;


# direct methods
.method public constructor <init>(Landroidx/activity/OnBackPressedDispatcher;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    new-instance v0, Lkotlin/text/MatcherMatchResult;

    .line 6
    new-instance v1, Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput$$ExternalSyntheticLambda0;

    .line 8
    invoke-direct {v1, p1}, Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;)V

    .line 11
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 14
    iput-object v1, v0, Lkotlin/text/MatcherMatchResult;->matcher:Ljava/lang/Object;

    .line 16
    new-instance p1, Landroidx/navigationevent/NavigationEventProcessor;

    .line 18
    invoke-direct {p1}, Landroidx/navigationevent/NavigationEventProcessor;-><init>()V

    .line 21
    iput-object p1, v0, Lkotlin/text/MatcherMatchResult;->input:Ljava/lang/Object;

    .line 23
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 25
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 28
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 30
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 33
    iput-object p1, v0, Lkotlin/text/MatcherMatchResult;->groups:Ljava/lang/Object;

    .line 35
    new-instance p1, Ljava/util/LinkedHashSet;

    .line 37
    invoke-direct {p1}, Ljava/util/LinkedHashSet;-><init>()V

    .line 40
    iput-object p1, v0, Lkotlin/text/MatcherMatchResult;->groupValues_:Ljava/lang/Object;

    .line 42
    invoke-virtual {v0, p0}, Lkotlin/text/MatcherMatchResult;->addInput(Landroidx/navigationevent/NavigationEventInput;)V

    .line 45
    iput-object v0, p0, Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput;->dispatcher:Lkotlin/text/MatcherMatchResult;

    .line 47
    return-void
.end method


# virtual methods
.method public final onHasEnabledHandlersChanged(Z)V
    .registers 2

    .line 1
    return-void
.end method
