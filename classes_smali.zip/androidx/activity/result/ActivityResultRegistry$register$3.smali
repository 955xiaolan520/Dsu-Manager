.class public final Landroidx/activity/result/ActivityResultRegistry$register$3;
.super Lkotlin/math/MathKt;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public final synthetic $contract:Landroidx/collection/internal/Lock;

.field public final synthetic $key:Ljava/lang/String;

.field public final synthetic this$0:Landroidx/activity/ComponentActivity$activityResultRegistry$1;


# direct methods
.method public constructor <init>(Landroidx/activity/ComponentActivity$activityResultRegistry$1;Ljava/lang/String;Landroidx/collection/internal/Lock;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/activity/result/ActivityResultRegistry$register$3;->this$0:Landroidx/activity/ComponentActivity$activityResultRegistry$1;

    .line 6
    iput-object p2, p0, Landroidx/activity/result/ActivityResultRegistry$register$3;->$key:Ljava/lang/String;

    .line 8
    iput-object p3, p0, Landroidx/activity/result/ActivityResultRegistry$register$3;->$contract:Landroidx/collection/internal/Lock;

    .line 10
    return-void
.end method
