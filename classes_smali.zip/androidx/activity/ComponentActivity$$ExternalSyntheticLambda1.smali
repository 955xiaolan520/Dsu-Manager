.class public final synthetic Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic f$0:Lyangfentuozi/dsusideloaderplus/MainActivity;


# direct methods
.method public synthetic constructor <init>(Lyangfentuozi/dsusideloaderplus/MainActivity;I)V
    .registers 3

    .line 1
    iput p2, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;->$r8$classId:I

    .line 3
    iput-object p1, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;->f$0:Lyangfentuozi/dsusideloaderplus/MainActivity;

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;->$r8$classId:I

    .line 3
    const/4 v1, 0x1

    .line 4
    iget-object p0, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;->f$0:Lyangfentuozi/dsusideloaderplus/MainActivity;

    .line 6
    packed-switch v0, :pswitch_data_7e

    .line 9
    new-instance v0, Landroidx/activity/OnBackPressedDispatcher;

    .line 11
    new-instance v2, Lrikka/shizuku/Shizuku$$ExternalSyntheticLambda1;

    .line 13
    invoke-direct {v2, v1, p0}, Lrikka/shizuku/Shizuku$$ExternalSyntheticLambda1;-><init>(ILjava/lang/Object;)V

    .line 16
    invoke-direct {v0, v2}, Landroidx/activity/OnBackPressedDispatcher;-><init>(Ljava/lang/Runnable;)V

    .line 19
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 21
    const/16 v2, 0x21

    .line 23
    if-lt v1, v2, :cond_43

    .line 25
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 28
    move-result-object v1

    .line 29
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 32
    move-result-object v2

    .line 33
    invoke-static {v1, v2}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 36
    move-result v1

    .line 37
    if-nez v1, :cond_39

    .line 39
    new-instance v1, Landroid/os/Handler;

    .line 41
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 44
    move-result-object v2

    .line 45
    invoke-direct {v1, v2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    .line 48
    new-instance v2, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 50
    const/4 v3, 0x0

    .line 51
    invoke-direct {v2, v3, p0, v0}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 54
    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 57
    goto :goto_43

    .line 58
    :cond_39
    iget-object v1, p0, Landroidx/core/app/ComponentActivity;->lifecycleRegistry:Landroidx/lifecycle/LifecycleRegistry;

    .line 60
    new-instance v2, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda12;

    .line 62
    invoke-direct {v2, v0, p0}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda12;-><init>(Landroidx/activity/OnBackPressedDispatcher;Landroidx/activity/ComponentActivity;)V

    .line 65
    invoke-virtual {v1, v2}, Landroidx/lifecycle/LifecycleRegistry;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 68
    :cond_43
    :goto_43
    return-object v0

    .line 69
    :pswitch_44  #0x3
    new-instance v0, Landroidx/lifecycle/SavedStateViewModelFactory;

    .line 71
    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    .line 74
    move-result-object v1

    .line 75
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 78
    move-result-object v2

    .line 79
    if-eqz v2, :cond_59

    .line 81
    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    .line 84
    move-result-object v2

    .line 85
    invoke-virtual {v2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    .line 88
    move-result-object v2

    .line 89
    goto :goto_5a

    .line 90
    :cond_59
    const/4 v2, 0x0

    .line 91
    :goto_5a
    invoke-direct {v0, v1, p0, v2}, Landroidx/lifecycle/SavedStateViewModelFactory;-><init>(Landroid/app/Application;Lyangfentuozi/dsusideloaderplus/MainActivity;Landroid/os/Bundle;)V

    .line 94
    return-object v0

    .line 95
    :pswitch_5e  #0x2
    new-instance v0, Landroidx/navigationevent/DirectNavigationEventInput;

    .line 97
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 100
    invoke-virtual {p0}, Landroidx/activity/ComponentActivity;->getNavigationEventDispatcher()Lkotlin/text/MatcherMatchResult;

    .line 103
    move-result-object p0

    .line 104
    invoke-virtual {p0, v0}, Lkotlin/text/MatcherMatchResult;->addInput(Landroidx/navigationevent/NavigationEventInput;)V

    .line 107
    return-object v0

    .line 108
    :pswitch_6b  #0x1
    invoke-virtual {p0}, Landroidx/activity/ComponentActivity;->reportFullyDrawn()V

    .line 111
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 113
    return-object p0

    .line 114
    :pswitch_71  #0x0
    new-instance v0, Landroidx/activity/FullyDrawnReporter;

    .line 116
    iget-object v2, p0, Landroidx/activity/ComponentActivity;->reportFullyDrawnExecutor:Landroidx/activity/ComponentActivity$ReportFullyDrawnExecutorImpl;

    .line 118
    new-instance v3, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;

    .line 120
    invoke-direct {v3, p0, v1}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;-><init>(Lyangfentuozi/dsusideloaderplus/MainActivity;I)V

    .line 123
    invoke-direct {v0, v2, v3}, Landroidx/activity/FullyDrawnReporter;-><init>(Ljava/util/concurrent/Executor;Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda1;)V

    .line 126
    return-object v0

    .line 127
    :pswitch_data_7e
    .packed-switch 0x0
        :pswitch_71  #00000000
        :pswitch_6b  #00000001
        :pswitch_5e  #00000002
        :pswitch_44  #00000003
    .end packed-switch
.end method
