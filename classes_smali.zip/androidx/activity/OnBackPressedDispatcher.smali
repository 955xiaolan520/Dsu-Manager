.class public final Landroidx/activity/OnBackPressedDispatcher;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public final eventInput$delegate:Lkotlin/SynchronizedLazyImpl;

.field public final fallbackOnBackPressed:Ljava/lang/Runnable;


# direct methods
.method public constructor <init>(Ljava/lang/Runnable;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/activity/OnBackPressedDispatcher;->fallbackOnBackPressed:Ljava/lang/Runnable;

    .line 6
    new-instance p1, Landroidx/datastore/core/FileStorage$$ExternalSyntheticLambda1;

    .line 8
    const/4 v0, 0x1

    .line 9
    invoke-direct {p1, v0, p0}, Landroidx/datastore/core/FileStorage$$ExternalSyntheticLambda1;-><init>(ILjava/lang/Object;)V

    .line 12
    new-instance v0, Lkotlin/SynchronizedLazyImpl;

    .line 14
    invoke-direct {v0, p1}, Lkotlin/SynchronizedLazyImpl;-><init>(Lkotlin/jvm/functions/Function0;)V

    .line 17
    iput-object v0, p0, Landroidx/activity/OnBackPressedDispatcher;->eventInput$delegate:Lkotlin/SynchronizedLazyImpl;

    .line 19
    return-void
.end method


# virtual methods
.method public final addCallback(Landroidx/activity/OnBackPressedCallback;Landroidx/lifecycle/LifecycleOwner;)V
    .registers 6

    .line 1
    invoke-interface {p2}, Landroidx/lifecycle/LifecycleOwner;->getLifecycle()Landroidx/lifecycle/LifecycleRegistry;

    .line 4
    move-result-object v0

    .line 5
    iget-object v1, v0, Landroidx/lifecycle/LifecycleRegistry;->state:Landroidx/lifecycle/Lifecycle$State;

    .line 7
    sget-object v2, Landroidx/lifecycle/Lifecycle$State;->DESTROYED:Landroidx/lifecycle/Lifecycle$State;

    .line 9
    if-ne v1, v2, :cond_b

    .line 11
    return-void

    .line 12
    :cond_b
    new-instance v1, Landroidx/activity/OnBackPressedCallbackInfo;

    .line 14
    invoke-direct {v1, p1, p2}, Landroidx/activity/OnBackPressedCallbackInfo;-><init>(Landroidx/activity/OnBackPressedCallback;Landroidx/lifecycle/LifecycleOwner;)V

    .line 17
    new-instance p2, Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;

    .line 19
    invoke-direct {p2, p1, v1}, Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;-><init>(Landroidx/activity/OnBackPressedCallback;Landroidx/activity/OnBackPressedCallbackInfo;)V

    .line 22
    iget-object v1, p1, Landroidx/activity/OnBackPressedCallback;->eventHandlers:Ljava/util/ArrayList;

    .line 24
    invoke-virtual {v1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 27
    const/4 v1, 0x0

    .line 28
    invoke-virtual {p2, v1}, Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;->setLifecycleActive(Z)V

    .line 31
    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher;->getEventDispatcher$activity()Lkotlin/text/MatcherMatchResult;

    .line 34
    move-result-object v1

    .line 35
    invoke-static {v1, p2}, Lkotlin/text/MatcherMatchResult;->addHandler$default(Lkotlin/text/MatcherMatchResult;Landroidx/navigationevent/NavigationEventHandler;)V

    .line 38
    new-instance v1, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;

    .line 40
    invoke-direct {v1, p2, p0, v0}, Landroidx/lifecycle/DefaultLifecycleObserverAdapter;-><init>(Landroidx/activity/OnBackPressedCallback$OnBackPressedEventHandler;Landroidx/activity/OnBackPressedDispatcher;Landroidx/lifecycle/LifecycleRegistry;)V

    .line 43
    invoke-virtual {v0, v1}, Landroidx/lifecycle/LifecycleRegistry;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 46
    new-instance p0, Landroidx/activity/OnBackPressedDispatcher$$ExternalSyntheticLambda1;

    .line 48
    invoke-direct {p0, v0, v1}, Landroidx/activity/OnBackPressedDispatcher$$ExternalSyntheticLambda1;-><init>(Landroidx/lifecycle/LifecycleRegistry;Landroidx/lifecycle/DefaultLifecycleObserverAdapter;)V

    .line 51
    iget-object p1, p1, Landroidx/activity/OnBackPressedCallback;->closeables:Ljava/util/concurrent/CopyOnWriteArrayList;

    .line 53
    invoke-virtual {p1, p0}, Ljava/util/concurrent/CopyOnWriteArrayList;->add(Ljava/lang/Object;)Z

    .line 56
    return-void
.end method

.method public final getEventDispatcher$activity()Lkotlin/text/MatcherMatchResult;
    .registers 1

    .line 1
    iget-object p0, p0, Landroidx/activity/OnBackPressedDispatcher;->eventInput$delegate:Lkotlin/SynchronizedLazyImpl;

    .line 3
    invoke-virtual {p0}, Lkotlin/SynchronizedLazyImpl;->getValue()Ljava/lang/Object;

    .line 6
    move-result-object p0

    .line 7
    check-cast p0, Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput;

    .line 9
    iget-object p0, p0, Landroidx/activity/OnBackPressedDispatcher$OnBackPressedEventInput;->dispatcher:Lkotlin/text/MatcherMatchResult;

    .line 11
    return-object p0
.end method

.method public final setOnBackInvokedDispatcher(Landroid/window/OnBackInvokedDispatcher;)V
    .registers 6

    .line 1
    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher;->getEventDispatcher$activity()Lkotlin/text/MatcherMatchResult;

    .line 4
    move-result-object v0

    .line 5
    new-instance v1, Landroidx/navigationevent/OnBackInvokedDefaultInput;

    .line 7
    const/4 v2, 0x0

    .line 8
    invoke-direct {v1, p1, v2}, Landroidx/navigationevent/OnBackInvokedDefaultInput;-><init>(Landroid/window/OnBackInvokedDispatcher;I)V

    .line 11
    const/4 v3, 0x1

    .line 12
    invoke-virtual {v0, v1, v3}, Lkotlin/text/MatcherMatchResult;->addInput(Landroidx/navigationevent/OnBackInvokedDefaultInput;I)V

    .line 15
    invoke-virtual {p0}, Landroidx/activity/OnBackPressedDispatcher;->getEventDispatcher$activity()Lkotlin/text/MatcherMatchResult;

    .line 18
    move-result-object p0

    .line 19
    new-instance v0, Landroidx/navigationevent/OnBackInvokedDefaultInput;

    .line 21
    const v1, 0xf4240

    .line 24
    invoke-direct {v0, p1, v1}, Landroidx/navigationevent/OnBackInvokedDefaultInput;-><init>(Landroid/window/OnBackInvokedDispatcher;I)V

    .line 27
    invoke-virtual {p0, v0, v2}, Lkotlin/text/MatcherMatchResult;->addInput(Landroidx/navigationevent/OnBackInvokedDefaultInput;I)V

    .line 30
    return-void
.end method
