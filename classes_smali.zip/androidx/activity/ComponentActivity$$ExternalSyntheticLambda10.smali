.class public final synthetic Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 1
    iput p1, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;->$r8$classId:I

    .line 3
    iput-object p2, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;->f$0:Ljava/lang/Object;

    .line 5
    iput-object p3, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;->f$1:Ljava/lang/Object;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 5

    .line 1
    iget v0, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;->$r8$classId:I

    .line 3
    iget-object v1, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;->f$1:Ljava/lang/Object;

    .line 5
    iget-object p0, p0, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;->f$0:Ljava/lang/Object;

    .line 7
    packed-switch v0, :pswitch_data_a8

    .line 10
    check-cast p0, Lrikka/shizuku/ShizukuServiceConnection;

    .line 12
    check-cast v1, Landroid/os/IBinder;

    .line 14
    iget-object v0, p0, Lrikka/shizuku/ShizukuServiceConnection;->connections:Ljava/util/HashSet;

    .line 16
    invoke-virtual {v0}, Ljava/util/HashSet;->iterator()Ljava/util/Iterator;

    .line 19
    move-result-object v0

    .line 20
    :goto_13
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 23
    move-result v2

    .line 24
    if-eqz v2, :cond_25

    .line 26
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 29
    move-result-object v2

    .line 30
    check-cast v2, Landroid/content/ServiceConnection;

    .line 32
    iget-object v3, p0, Lrikka/shizuku/ShizukuServiceConnection;->componentName:Landroid/content/ComponentName;

    .line 34
    invoke-interface {v2, v3, v1}, Landroid/content/ServiceConnection;->onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V

    .line 37
    goto :goto_13

    .line 38
    :cond_25
    return-void

    .line 39
    :pswitch_26  #0x9
    check-cast p0, Lcom/topjohnwu/superuser/internal/RootServiceManager$ConnectionRecord;

    .line 41
    check-cast v1, Landroid/content/ServiceConnection;

    .line 43
    iget-object p0, p0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 45
    check-cast p0, Lcom/topjohnwu/superuser/internal/RootServiceManager$RemoteServiceRecord;

    .line 47
    iget-object p0, p0, Lcom/topjohnwu/superuser/internal/RootServiceManager$RemoteServiceRecord;->key:Lcom/topjohnwu/superuser/internal/RootServiceManager$ServiceKey;

    .line 49
    iget-object p0, p0, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 51
    check-cast p0, Landroid/content/ComponentName;

    .line 53
    invoke-interface {v1, p0}, Landroid/content/ServiceConnection;->onServiceDisconnected(Landroid/content/ComponentName;)V

    .line 56
    return-void

    .line 57
    :pswitch_38  #0x8
    check-cast p0, Landroid/content/ServiceConnection;

    .line 59
    check-cast v1, Lcom/topjohnwu/superuser/internal/RootServiceManager$ServiceKey;

    .line 61
    iget-object v0, v1, Landroid/util/Pair;->first:Ljava/lang/Object;

    .line 63
    check-cast v0, Landroid/content/ComponentName;

    .line 65
    invoke-interface {p0, v0}, Landroid/content/ServiceConnection;->onNullBinding(Landroid/content/ComponentName;)V

    .line 68
    return-void

    .line 69
    :pswitch_44  #0x7
    check-cast p0, Lcom/topjohnwu/superuser/Shell$GetShellCallback;

    .line 71
    check-cast v1, Lcom/topjohnwu/superuser/internal/ShellImpl;

    .line 73
    invoke-interface {p0, v1}, Lcom/topjohnwu/superuser/Shell$GetShellCallback;->onShell(Lcom/topjohnwu/superuser/internal/ShellImpl;)V

    .line 76
    return-void

    .line 77
    :pswitch_4c  #0x6
    check-cast p0, Ljava/util/concurrent/Executor;

    .line 79
    check-cast v1, Lcom/topjohnwu/superuser/Shell$GetShellCallback;

    .line 81
    :try_start_50
    invoke-static {}, Lcom/topjohnwu/superuser/internal/MainShell;->get()Lcom/topjohnwu/superuser/internal/ShellImpl;

    .line 84
    move-result-object v0

    .line 85
    if-nez p0, :cond_5a

    .line 87
    invoke-interface {v1, v0}, Lcom/topjohnwu/superuser/Shell$GetShellCallback;->onShell(Lcom/topjohnwu/superuser/internal/ShellImpl;)V

    .line 90
    goto :goto_63

    .line 91
    :cond_5a
    new-instance v2, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;

    .line 93
    const/4 v3, 0x7

    .line 94
    invoke-direct {v2, v3, v1, v0}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda10;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 97
    invoke-interface {p0, v2}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V
    :try_end_63
    .catch Lcom/topjohnwu/superuser/NoShellException; {:try_start_50 .. :try_end_63} :catch_63

    .line 100
    :catch_63
    :goto_63
    return-void

    .line 101
    :pswitch_64  #0x5
    check-cast p0, Lcom/topjohnwu/superuser/internal/PendingJob;

    .line 103
    check-cast v1, Landroidx/core/view/MenuHostHelper;

    .line 105
    iget-object p0, p0, Lcom/topjohnwu/superuser/internal/PendingJob;->callback:Landroidx/core/view/MenuHostHelper;

    .line 107
    iput-object v1, p0, Landroidx/core/view/MenuHostHelper;->mMenuProviders:Ljava/lang/Object;

    .line 109
    return-void

    .line 110
    :pswitch_6d  #0x4
    check-cast p0, Lyangfentuozi/dsusideloaderplus/util/CmdRunner$runReadEachLine$callbackList$1;

    .line 112
    check-cast v1, Ljava/lang/String;

    .line 114
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 117
    iget-object p0, p0, Lyangfentuozi/dsusideloaderplus/util/CmdRunner$runReadEachLine$callbackList$1;->$onReceive:Landroidx/navigation/NavController$$ExternalSyntheticLambda3;

    .line 119
    invoke-virtual {p0, v1}, Landroidx/navigation/NavController$$ExternalSyntheticLambda3;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 122
    return-void

    .line 123
    :pswitch_7a  #0x3
    check-cast p0, Lorg/tukaani/xz/lzma/LZMADecoder$LiteralDecoder;

    .line 125
    check-cast v1, Landroid/graphics/Typeface;

    .line 127
    invoke-virtual {p0, v1}, Lorg/tukaani/xz/lzma/LZMADecoder$LiteralDecoder;->onFontRetrieved(Landroid/graphics/Typeface;)V

    .line 130
    return-void

    .line 131
    :pswitch_82  #0x2
    check-cast p0, Landroidx/compose/ui/platform/WrappedComposition;

    .line 133
    check-cast v1, Landroidx/lifecycle/LifecycleRegistry;

    .line 135
    iget-boolean v0, p0, Landroidx/compose/ui/platform/WrappedComposition;->disposed:Z

    .line 137
    if-nez v0, :cond_8f

    .line 139
    iput-object v1, p0, Landroidx/compose/ui/platform/WrappedComposition;->addedToLifecycle:Landroidx/lifecycle/LifecycleRegistry;

    .line 141
    invoke-virtual {v1, p0}, Landroidx/lifecycle/LifecycleRegistry;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 144
    :cond_8f
    return-void

    .line 145
    :pswitch_90  #0x1
    check-cast p0, Landroidx/compose/ui/contentcapture/AndroidContentCaptureManager;

    .line 147
    check-cast v1, Landroid/util/LongSparseArray;

    .line 149
    invoke-static {p0, v1}, Landroidx/compose/ui/geometry/RectKt;->doTranslation(Landroidx/compose/ui/contentcapture/AndroidContentCaptureManager;Landroid/util/LongSparseArray;)V

    .line 152
    return-void

    .line 153
    :pswitch_98  #0x0
    check-cast p0, Lyangfentuozi/dsusideloaderplus/MainActivity;

    .line 155
    check-cast v1, Landroidx/activity/OnBackPressedDispatcher;

    .line 157
    iget-object v0, p0, Landroidx/core/app/ComponentActivity;->lifecycleRegistry:Landroidx/lifecycle/LifecycleRegistry;

    .line 159
    new-instance v2, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda12;

    .line 161
    invoke-direct {v2, v1, p0}, Landroidx/activity/ComponentActivity$$ExternalSyntheticLambda12;-><init>(Landroidx/activity/OnBackPressedDispatcher;Landroidx/activity/ComponentActivity;)V

    .line 164
    invoke-virtual {v0, v2}, Landroidx/lifecycle/LifecycleRegistry;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 167
    return-void

    nop

    .line 169
    :pswitch_data_a8
    .packed-switch 0x0
        :pswitch_98  #00000000
        :pswitch_90  #00000001
        :pswitch_82  #00000002
        :pswitch_7a  #00000003
        :pswitch_6d  #00000004
        :pswitch_64  #00000005
        :pswitch_4c  #00000006
        :pswitch_44  #00000007
        :pswitch_38  #00000008
        :pswitch_26  #00000009
    .end packed-switch
.end method
