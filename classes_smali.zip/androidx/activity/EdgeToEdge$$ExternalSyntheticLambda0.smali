.class public final synthetic Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Ljava/lang/Object;

.field public final synthetic f$2:Ljava/lang/Object;

.field public final synthetic f$3:Ljava/lang/Object;

.field public final synthetic f$4:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V
    .registers 7

    .line 1
    iput p6, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 3
    iput-object p1, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 5
    iput-object p2, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 7
    iput-object p3, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$2:Ljava/lang/Object;

    .line 9
    iput-object p4, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$3:Ljava/lang/Object;

    .line 11
    iput-object p5, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$4:Ljava/lang/Object;

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 16
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 13

    .line 1
    iget v0, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 3
    iget-object v1, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$4:Ljava/lang/Object;

    .line 5
    iget-object v2, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$3:Ljava/lang/Object;

    .line 7
    iget-object v3, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$2:Ljava/lang/Object;

    .line 9
    iget-object v4, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 11
    iget-object p0, p0, Landroidx/activity/EdgeToEdge$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 13
    packed-switch v0, :pswitch_data_ba

    .line 16
    check-cast p0, Landroidx/compose/ui/text/TextStyle;

    .line 18
    check-cast v4, Landroidx/compose/ui/unit/LayoutDirection;

    .line 20
    move-object v6, v3

    .line 21
    check-cast v6, Ljava/lang/String;

    .line 23
    move-object v11, v2

    .line 24
    check-cast v11, Landroidx/compose/ui/unit/Density;

    .line 26
    move-object v10, v1

    .line 27
    check-cast v10, Landroidx/compose/ui/text/font/FontFamily$Resolver;

    .line 29
    const-string v0, "BackgroundTextMeasurement"

    .line 31
    invoke-static {v0}, Landroid/os/Trace;->beginSection(Ljava/lang/String;)V

    .line 34
    :try_start_21
    invoke-static {}, Landroidx/compose/runtime/snapshots/SnapshotKt;->currentSnapshot()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 37
    move-result-object v0

    .line 38
    instance-of v1, v0, Landroidx/compose/runtime/snapshots/MutableSnapshot;

    .line 40
    const/4 v2, 0x0

    .line 41
    if-eqz v1, :cond_2d

    .line 43
    check-cast v0, Landroidx/compose/runtime/snapshots/MutableSnapshot;

    .line 45
    goto :goto_2e

    .line 46
    :cond_2d
    move-object v0, v2

    .line 47
    :goto_2e
    if-eqz v0, :cond_6d

    .line 49
    invoke-virtual {v0, v2, v2}, Landroidx/compose/runtime/snapshots/MutableSnapshot;->takeNestedMutableSnapshot(Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function1;)Landroidx/compose/runtime/snapshots/MutableSnapshot;

    .line 52
    move-result-object v1
    :try_end_34
    .catchall {:try_start_21 .. :try_end_34} :catchall_6a

    .line 53
    if-eqz v1, :cond_6d

    .line 55
    :try_start_36
    invoke-virtual {v1}, Landroidx/compose/runtime/snapshots/Snapshot;->makeCurrent()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 58
    move-result-object v2
    :try_end_3a
    .catchall {:try_start_36 .. :try_end_3a} :catchall_5a

    .line 59
    :try_start_3a
    invoke-static {p0, v4}, Landroidx/compose/ui/text/ParagraphKt;->resolveDefaults(Landroidx/compose/ui/text/TextStyle;Landroidx/compose/ui/unit/LayoutDirection;)Landroidx/compose/ui/text/TextStyle;

    .line 62
    move-result-object v7

    .line 63
    sget-object v8, Lkotlin/collections/EmptyList;->INSTANCE:Lkotlin/collections/EmptyList;

    .line 65
    new-instance v5, Landroidx/compose/ui/text/platform/AndroidParagraphIntrinsics;

    .line 67
    move-object v9, v8

    .line 68
    invoke-direct/range {v5 .. v11}, Landroidx/compose/ui/text/platform/AndroidParagraphIntrinsics;-><init>(Ljava/lang/String;Landroidx/compose/ui/text/TextStyle;Ljava/util/List;Ljava/util/List;Landroidx/compose/ui/text/font/FontFamily$Resolver;Landroidx/compose/ui/unit/Density;)V

    .line 71
    invoke-virtual {v5}, Landroidx/compose/ui/text/platform/AndroidParagraphIntrinsics;->getMaxIntrinsicWidth()F
    :try_end_49
    .catchall {:try_start_3a .. :try_end_49} :catchall_5d

    .line 74
    :try_start_49
    invoke-static {v2}, Landroidx/compose/runtime/snapshots/Snapshot;->restoreCurrent(Landroidx/compose/runtime/snapshots/Snapshot;)V
    :try_end_4c
    .catchall {:try_start_49 .. :try_end_4c} :catchall_5a

    .line 77
    :try_start_4c
    invoke-virtual {v1}, Landroidx/compose/runtime/snapshots/MutableSnapshot;->apply()Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;

    .line 80
    move-result-object p0

    .line 81
    invoke-virtual {p0}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->check()V

    .line 84
    invoke-virtual {v1}, Landroidx/compose/runtime/snapshots/MutableSnapshot;->dispose()V
    :try_end_56
    .catchall {:try_start_4c .. :try_end_56} :catchall_6a

    .line 87
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 90
    return-void

    .line 91
    :catchall_5a
    move-exception v0

    .line 92
    move-object p0, v0

    .line 93
    goto :goto_63

    .line 94
    :catchall_5d
    move-exception v0

    .line 95
    move-object p0, v0

    .line 96
    :try_start_5f
    invoke-static {v2}, Landroidx/compose/runtime/snapshots/Snapshot;->restoreCurrent(Landroidx/compose/runtime/snapshots/Snapshot;)V

    .line 99
    throw p0
    :try_end_63
    .catchall {:try_start_5f .. :try_end_63} :catchall_5a

    .line 100
    :goto_63
    :try_start_63
    throw p0
    :try_end_64
    .catchall {:try_start_63 .. :try_end_64} :catchall_64

    .line 101
    :catchall_64
    move-exception v0

    .line 102
    move-object p0, v0

    .line 103
    :try_start_66
    invoke-virtual {v1}, Landroidx/compose/runtime/snapshots/MutableSnapshot;->dispose()V

    .line 106
    throw p0

    .line 107
    :catchall_6a
    move-exception v0

    .line 108
    move-object p0, v0

    .line 109
    goto :goto_75

    .line 110
    :cond_6d
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 112
    const-string v0, "Cannot create a mutable snapshot of an read-only snapshot"

    .line 114
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 117
    throw p0
    :try_end_75
    .catchall {:try_start_66 .. :try_end_75} :catchall_6a

    .line 118
    :goto_75
    invoke-static {}, Landroid/os/Trace;->endSection()V

    .line 121
    throw p0

    .line 122
    :pswitch_79  #0x0
    move-object v0, p0

    .line 123
    check-cast v0, Landroidx/activity/EdgeToEdgeApi26;

    .line 125
    check-cast v4, Landroidx/activity/SystemBarStyle;

    .line 127
    check-cast v3, Landroidx/activity/SystemBarStyle;

    .line 129
    check-cast v2, Lyangfentuozi/dsusideloaderplus/MainActivity;

    .line 131
    check-cast v1, Landroid/view/View;

    .line 133
    invoke-virtual {v2}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    .line 136
    move-result-object p0

    .line 137
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 140
    iget-object v2, v4, Landroidx/activity/SystemBarStyle;->detectDarkMode:Lkotlin/jvm/functions/Function1;

    .line 142
    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 145
    move-result-object v5

    .line 146
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 149
    invoke-interface {v2, v5}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 152
    move-result-object v2

    .line 153
    check-cast v2, Ljava/lang/Boolean;

    .line 155
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 158
    move-result v5

    .line 159
    iget-object v2, v3, Landroidx/activity/SystemBarStyle;->detectDarkMode:Lkotlin/jvm/functions/Function1;

    .line 161
    invoke-virtual {v1}, Landroid/view/View;->getResources()Landroid/content/res/Resources;

    .line 164
    move-result-object v6

    .line 165
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 168
    invoke-interface {v2, v6}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 171
    move-result-object v2

    .line 172
    check-cast v2, Ljava/lang/Boolean;

    .line 174
    invoke-virtual {v2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 177
    move-result v6

    .line 178
    move-object v2, v4

    .line 179
    move-object v4, v1

    .line 180
    move-object v1, v2

    .line 181
    move-object v2, v3

    .line 182
    move-object v3, p0

    .line 183
    invoke-virtual/range {v0 .. v6}, Landroidx/activity/EdgeToEdgeApi26;->setUp(Landroidx/activity/SystemBarStyle;Landroidx/activity/SystemBarStyle;Landroid/view/Window;Landroid/view/View;ZZ)V

    .line 186
    return-void

    .line 187
    :pswitch_data_ba
    .packed-switch 0x0
        :pswitch_79  #00000000
    .end packed-switch
.end method
