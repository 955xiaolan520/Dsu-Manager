.class public abstract Landroidx/activity/EdgeToEdgeApi26;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# virtual methods
.method public abstract adjustLayoutInDisplayCutoutMode(Landroid/view/Window;)V
.end method

.method public setUp(Landroidx/activity/SystemBarStyle;Landroidx/activity/SystemBarStyle;Landroid/view/Window;Landroid/view/View;ZZ)V
    .registers 7

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 7
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 10
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 13
    const/4 p0, 0x0

    .line 14
    invoke-static {p3, p0}, Landroidx/core/os/BundleKt;->setDecorFitsSystemWindows(Landroid/view/Window;Z)V

    .line 17
    if-eqz p5, :cond_15

    .line 19
    iget p0, p1, Landroidx/activity/SystemBarStyle;->darkScrim:I

    .line 21
    goto :goto_17

    .line 22
    :cond_15
    iget p0, p1, Landroidx/activity/SystemBarStyle;->lightScrim:I

    .line 24
    :goto_17
    invoke-virtual {p3, p0}, Landroid/view/Window;->setStatusBarColor(I)V

    .line 27
    if-eqz p6, :cond_1f

    .line 29
    iget p0, p2, Landroidx/activity/SystemBarStyle;->darkScrim:I

    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    iget p0, p2, Landroidx/activity/SystemBarStyle;->lightScrim:I

    .line 34
    :goto_21
    invoke-virtual {p3, p0}, Landroid/view/Window;->setNavigationBarColor(I)V

    .line 37
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 39
    const/16 p1, 0x23

    .line 41
    if-lt p0, p1, :cond_30

    .line 43
    new-instance p0, Landroidx/core/view/WindowInsetsControllerCompat$Impl35;

    .line 45
    invoke-direct {p0, p3}, Landroidx/core/view/WindowInsetsControllerCompat$Impl30;-><init>(Landroid/view/Window;)V

    .line 48
    goto :goto_3f

    .line 49
    :cond_30
    const/16 p1, 0x1e

    .line 51
    if-lt p0, p1, :cond_3a

    .line 53
    new-instance p0, Landroidx/core/view/WindowInsetsControllerCompat$Impl30;

    .line 55
    invoke-direct {p0, p3}, Landroidx/core/view/WindowInsetsControllerCompat$Impl30;-><init>(Landroid/view/Window;)V

    .line 58
    goto :goto_3f

    .line 59
    :cond_3a
    new-instance p0, Landroidx/core/view/WindowInsetsControllerCompat$Impl26;

    .line 61
    invoke-direct {p0, p3}, Landroidx/core/view/WindowInsetsControllerCompat$Impl26;-><init>(Landroid/view/Window;)V

    .line 64
    :goto_3f
    xor-int/lit8 p1, p5, 0x1

    .line 66
    invoke-virtual {p0, p1}, Landroidx/core/os/BundleKt;->setAppearanceLightStatusBars(Z)V

    .line 69
    xor-int/lit8 p1, p6, 0x1

    .line 71
    invoke-virtual {p0, p1}, Landroidx/core/os/BundleKt;->setAppearanceLightNavigationBars(Z)V

    .line 74
    return-void
.end method
