.class public interface abstract Landroidx/activity/contextaware/OnContextAvailableListener;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# virtual methods
.method public abstract onContextAvailable(Landroidx/activity/ComponentActivity;)V
.end method
