.class public final Landroidx/collection/MutableObjectIntMap;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public _capacity:I

.field public _size:I

.field public growthLimit:I

.field public keys:[Ljava/lang/Object;

.field public metadata:[J

.field public values:[I


# direct methods
.method public synthetic constructor <init>()V
    .registers 2

    const/4 v0, 0x6

    .line 38
    invoke-direct {p0, v0}, Landroidx/collection/MutableObjectIntMap;-><init>(I)V

    return-void
.end method

.method public constructor <init>(I)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    sget-object v0, Landroidx/collection/ScatterMapKt;->EmptyGroup:[J

    .line 6
    iput-object v0, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 8
    sget-object v0, Landroidx/collection/internal/ContainerHelpersKt;->EMPTY_OBJECTS:[Ljava/lang/Object;

    .line 10
    iput-object v0, p0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 12
    sget-object v0, Landroidx/collection/IntSetKt;->EmptyIntArray:[I

    .line 14
    iput-object v0, p0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 16
    if-ltz p1, :cond_13

    .line 18
    const/4 v0, 0x1

    .line 19
    goto :goto_14

    .line 20
    :cond_13
    const/4 v0, 0x0

    .line 21
    :goto_14
    if-eqz v0, :cond_1e

    .line 23
    invoke-static {p1}, Landroidx/collection/ScatterMapKt;->unloadedCapacity(I)I

    .line 26
    move-result p1

    .line 27
    invoke-virtual {p0, p1}, Landroidx/collection/MutableObjectIntMap;->initializeStorage(I)V

    .line 30
    return-void

    .line 31
    :cond_1e
    const-string p0, "Capacity must be a positive value."

    .line 33
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 36
    const/4 p0, 0x0

    .line 37
    throw p0
.end method


# virtual methods
.method public final clear()V
    .registers 11

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 4
    iget-object v1, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 6
    sget-object v2, Landroidx/collection/ScatterMapKt;->EmptyGroup:[J

    .line 8
    if-eq v1, v2, :cond_25

    .line 10
    const-wide v2, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 15
    invoke-static {v1, v2, v3}, Lkotlin/collections/ArraysKt;->fill$default([JJ)V

    .line 18
    iget-object v1, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 20
    iget v2, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 22
    shr-int/lit8 v3, v2, 0x3

    .line 24
    and-int/lit8 v2, v2, 0x7

    .line 26
    shl-int/lit8 v2, v2, 0x3

    .line 28
    aget-wide v4, v1, v3

    .line 30
    const-wide/16 v6, 0xff

    .line 32
    shl-long/2addr v6, v2

    .line 33
    not-long v8, v6

    .line 34
    and-long/2addr v4, v8

    .line 35
    or-long/2addr v4, v6

    .line 36
    aput-wide v4, v1, v3

    .line 38
    :cond_25
    iget-object v1, p0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 40
    iget v2, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 42
    invoke-static {v1, v0, v2}, Lkotlin/collections/ArraysKt;->fill([Ljava/lang/Object;II)V

    .line 45
    iget v0, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 47
    invoke-static {v0}, Landroidx/collection/ScatterMapKt;->loadedCapacity(I)I

    .line 50
    move-result v0

    .line 51
    iget v1, p0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 53
    sub-int/2addr v0, v1

    .line 54
    iput v0, p0, Landroidx/collection/MutableObjectIntMap;->growthLimit:I

    .line 56
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    const/4 v2, 0x1

    .line 6
    if-ne v1, v0, :cond_8

    .line 8
    return v2

    .line 9
    :cond_8
    instance-of v3, v1, Landroidx/collection/MutableObjectIntMap;

    .line 11
    const/4 v4, 0x0

    .line 12
    if-nez v3, :cond_e

    .line 14
    return v4

    .line 15
    :cond_e
    check-cast v1, Landroidx/collection/MutableObjectIntMap;

    .line 17
    iget v3, v1, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 19
    iget v5, v0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 21
    if-eq v3, v5, :cond_17

    .line 23
    return v4

    .line 24
    :cond_17
    iget-object v3, v0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 26
    iget-object v5, v0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 28
    iget-object v0, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 30
    array-length v6, v0

    .line 31
    add-int/lit8 v6, v6, -0x2

    .line 33
    if-ltz v6, :cond_67

    .line 35
    move v7, v4

    .line 36
    :goto_23
    aget-wide v8, v0, v7

    .line 38
    not-long v10, v8

    .line 39
    const/4 v12, 0x7

    .line 40
    shl-long/2addr v10, v12

    .line 41
    and-long/2addr v10, v8

    .line 42
    const-wide v12, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 47
    and-long/2addr v10, v12

    .line 48
    cmp-long v10, v10, v12

    .line 50
    if-eqz v10, :cond_62

    .line 52
    sub-int v10, v7, v6

    .line 54
    not-int v10, v10

    .line 55
    ushr-int/lit8 v10, v10, 0x1f

    .line 57
    const/16 v11, 0x8

    .line 59
    rsub-int/lit8 v10, v10, 0x8

    .line 61
    move v12, v4

    .line 62
    :goto_3d
    if-ge v12, v10, :cond_60

    .line 64
    const-wide/16 v13, 0xff

    .line 66
    and-long/2addr v13, v8

    .line 67
    const-wide/16 v15, 0x80

    .line 69
    cmp-long v13, v13, v15

    .line 71
    if-gez v13, :cond_5c

    .line 73
    shl-int/lit8 v13, v7, 0x3

    .line 75
    add-int/2addr v13, v12

    .line 76
    aget-object v14, v3, v13

    .line 78
    aget v13, v5, v13

    .line 80
    invoke-virtual {v1, v14}, Landroidx/collection/MutableObjectIntMap;->findKeyIndex(Ljava/lang/Object;)I

    .line 83
    move-result v14

    .line 84
    if-ltz v14, :cond_5b

    .line 86
    iget-object v15, v1, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 88
    aget v14, v15, v14

    .line 90
    if-eq v13, v14, :cond_5c

    .line 92
    :cond_5b
    return v4

    .line 93
    :cond_5c
    shr-long/2addr v8, v11

    .line 94
    add-int/lit8 v12, v12, 0x1

    .line 96
    goto :goto_3d

    .line 97
    :cond_60
    if-ne v10, v11, :cond_67

    .line 99
    :cond_62
    if-eq v7, v6, :cond_67

    .line 101
    add-int/lit8 v7, v7, 0x1

    .line 103
    goto :goto_23

    .line 104
    :cond_67
    return v2
.end method

.method public final findFirstAvailableSlot(I)I
    .registers 11

    .line 1
    iget v0, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 3
    and-int/2addr p1, v0

    .line 4
    const/4 v1, 0x0

    .line 5
    :goto_4
    iget-object v2, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 7
    shr-int/lit8 v3, p1, 0x3

    .line 9
    and-int/lit8 v4, p1, 0x7

    .line 11
    shl-int/lit8 v4, v4, 0x3

    .line 13
    aget-wide v5, v2, v3

    .line 15
    ushr-long/2addr v5, v4

    .line 16
    add-int/lit8 v3, v3, 0x1

    .line 18
    aget-wide v2, v2, v3

    .line 20
    rsub-int/lit8 v7, v4, 0x40

    .line 22
    shl-long/2addr v2, v7

    .line 23
    int-to-long v7, v4

    .line 24
    neg-long v7, v7

    .line 25
    const/16 v4, 0x3f

    .line 27
    shr-long/2addr v7, v4

    .line 28
    and-long/2addr v2, v7

    .line 29
    or-long/2addr v2, v5

    .line 30
    not-long v4, v2

    .line 31
    const/4 v6, 0x7

    .line 32
    shl-long/2addr v4, v6

    .line 33
    and-long/2addr v2, v4

    .line 34
    const-wide v4, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 39
    and-long/2addr v2, v4

    .line 40
    const-wide/16 v4, 0x0

    .line 42
    cmp-long v4, v2, v4

    .line 44
    if-eqz v4, :cond_37

    .line 46
    invoke-static {v2, v3}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 49
    move-result p0

    .line 50
    shr-int/lit8 p0, p0, 0x3

    .line 52
    add-int/2addr p1, p0

    .line 53
    and-int p0, p1, v0

    .line 55
    return p0

    .line 56
    :cond_37
    add-int/lit8 v1, v1, 0x8

    .line 58
    add-int/2addr p1, v1

    .line 59
    and-int/2addr p1, v0

    .line 60
    goto :goto_4
.end method

.method public final findIndex(Ljava/lang/Object;)I
    .registers 37

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    if-eqz v1, :cond_b

    .line 7
    invoke-virtual {v1}, Ljava/lang/Object;->hashCode()I

    .line 10
    move-result v3

    .line 11
    goto :goto_c

    .line 12
    :cond_b
    const/4 v3, 0x0

    .line 13
    :goto_c
    const v4, -0x3361d2af  # -8.293031E7f

    .line 16
    mul-int/2addr v3, v4

    .line 17
    shl-int/lit8 v5, v3, 0x10

    .line 19
    xor-int/2addr v3, v5

    .line 20
    ushr-int/lit8 v5, v3, 0x7

    .line 22
    and-int/lit8 v3, v3, 0x7f

    .line 24
    iget v6, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 26
    and-int v7, v5, v6

    .line 28
    const/4 v8, 0x0

    .line 29
    :goto_1c
    iget-object v9, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 31
    shr-int/lit8 v10, v7, 0x3

    .line 33
    and-int/lit8 v11, v7, 0x7

    .line 35
    shl-int/lit8 v11, v11, 0x3

    .line 37
    aget-wide v12, v9, v10

    .line 39
    ushr-long/2addr v12, v11

    .line 40
    const/4 v14, 0x1

    .line 41
    add-int/2addr v10, v14

    .line 42
    aget-wide v9, v9, v10

    .line 44
    rsub-int/lit8 v15, v11, 0x40

    .line 46
    shl-long/2addr v9, v15

    .line 47
    move/from16 v16, v14

    .line 49
    int-to-long v14, v11

    .line 50
    neg-long v14, v14

    .line 51
    const/16 v11, 0x3f

    .line 53
    shr-long/2addr v14, v11

    .line 54
    and-long/2addr v9, v14

    .line 55
    or-long/2addr v9, v12

    .line 56
    int-to-long v11, v3

    .line 57
    const-wide v13, 0x101010101010101L

    .line 62
    mul-long v17, v11, v13

    .line 64
    move/from16 v19, v3

    .line 66
    const/4 v15, 0x0

    .line 67
    xor-long v2, v9, v17

    .line 69
    sub-long v13, v2, v13

    .line 71
    not-long v2, v2

    .line 72
    and-long/2addr v2, v13

    .line 73
    const-wide v13, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 78
    and-long/2addr v2, v13

    .line 79
    :goto_4e
    const-wide/16 v17, 0x0

    .line 81
    cmp-long v20, v2, v17

    .line 83
    if-eqz v20, :cond_74

    .line 85
    invoke-static {v2, v3}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 88
    move-result v17

    .line 89
    shr-int/lit8 v17, v17, 0x3

    .line 91
    add-int v17, v7, v17

    .line 93
    and-int v17, v17, v6

    .line 95
    move/from16 v20, v4

    .line 97
    iget-object v4, v0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 99
    aget-object v4, v4, v17

    .line 101
    invoke-static {v4, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 104
    move-result v4

    .line 105
    if-eqz v4, :cond_6b

    .line 107
    return v17

    .line 108
    :cond_6b
    const-wide/16 v17, 0x1

    .line 110
    sub-long v17, v2, v17

    .line 112
    and-long v2, v2, v17

    .line 114
    move/from16 v4, v20

    .line 116
    goto :goto_4e

    .line 117
    :cond_74
    move/from16 v20, v4

    .line 119
    not-long v2, v9

    .line 120
    const/4 v4, 0x6

    .line 121
    shl-long/2addr v2, v4

    .line 122
    and-long/2addr v2, v9

    .line 123
    and-long/2addr v2, v13

    .line 124
    cmp-long v2, v2, v17

    .line 126
    const/16 v3, 0x8

    .line 128
    if-eqz v2, :cond_2ab

    .line 130
    invoke-virtual {v0, v5}, Landroidx/collection/MutableObjectIntMap;->findFirstAvailableSlot(I)I

    .line 133
    move-result v1

    .line 134
    iget v2, v0, Landroidx/collection/MutableObjectIntMap;->growthLimit:I

    .line 136
    const-wide/16 v8, 0xff

    .line 138
    if-nez v2, :cond_9f

    .line 140
    iget-object v2, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 142
    shr-int/lit8 v10, v1, 0x3

    .line 144
    aget-wide v17, v2, v10

    .line 146
    and-int/lit8 v2, v1, 0x7

    .line 148
    shl-int/lit8 v2, v2, 0x3

    .line 150
    shr-long v17, v17, v2

    .line 152
    and-long v17, v17, v8

    .line 154
    const-wide/16 v21, 0xfe

    .line 156
    cmp-long v2, v17, v21

    .line 158
    if-nez v2, :cond_a9

    .line 160
    :cond_9f
    move-wide/from16 v25, v8

    .line 162
    move-wide/from16 v23, v11

    .line 164
    const/16 p1, 0x7

    .line 166
    const-wide/16 v18, 0x80

    .line 168
    goto/16 :goto_275

    .line 170
    :cond_a9
    iget v1, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 172
    if-le v1, v3, :cond_1f8

    .line 174
    iget v2, v0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 176
    move v10, v3

    .line 177
    const/16 p1, 0x7

    .line 179
    int-to-long v3, v2

    .line 180
    const-wide/16 v17, 0x20

    .line 182
    mul-long v3, v3, v17

    .line 184
    int-to-long v1, v1

    .line 185
    const-wide/16 v17, 0x19

    .line 187
    mul-long v1, v1, v17

    .line 189
    invoke-static {v3, v4, v1, v2}, Ljava/lang/Long;->compareUnsigned(JJ)I

    .line 192
    move-result v1

    .line 193
    if-gtz v1, :cond_1f1

    .line 195
    iget-object v1, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 197
    iget v2, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 199
    iget-object v3, v0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 201
    iget-object v4, v0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 203
    add-int/lit8 v17, v2, 0x7

    .line 205
    const-wide/16 v18, 0x80

    .line 207
    shr-int/lit8 v6, v17, 0x3

    .line 209
    move v7, v15

    .line 210
    :goto_d1
    if-ge v7, v6, :cond_f0

    .line 212
    aget-wide v23, v1, v7

    .line 214
    move-wide/from16 v25, v8

    .line 216
    and-long v8, v23, v13

    .line 218
    move-wide/from16 v23, v11

    .line 220
    move v12, v10

    .line 221
    not-long v10, v8

    .line 222
    ushr-long v8, v8, p1

    .line 224
    add-long/2addr v10, v8

    .line 225
    const-wide v8, -0x101010101010102L

    .line 230
    and-long/2addr v8, v10

    .line 231
    aput-wide v8, v1, v7

    .line 233
    add-int/lit8 v7, v7, 0x1

    .line 235
    move v10, v12

    .line 236
    move-wide/from16 v11, v23

    .line 238
    move-wide/from16 v8, v25

    .line 240
    goto :goto_d1

    .line 241
    :cond_f0
    move-wide/from16 v25, v8

    .line 243
    move-wide/from16 v23, v11

    .line 245
    move v12, v10

    .line 246
    invoke-static {v1}, Lkotlin/collections/ArraysKt;->getLastIndex([J)I

    .line 249
    move-result v6

    .line 250
    add-int/lit8 v7, v6, -0x1

    .line 252
    aget-wide v8, v1, v7

    .line 254
    const-wide v10, 0xffffffffffffffL

    .line 259
    and-long/2addr v8, v10

    .line 260
    const-wide/high16 v13, -0x100000000000000L

    .line 262
    or-long/2addr v8, v13

    .line 263
    aput-wide v8, v1, v7

    .line 265
    aget-wide v7, v1, v15

    .line 267
    aput-wide v7, v1, v6

    .line 269
    move v6, v15

    .line 270
    :goto_10d
    if-eq v6, v2, :cond_1e4

    .line 272
    shr-int/lit8 v7, v6, 0x3

    .line 274
    aget-wide v8, v1, v7

    .line 276
    and-int/lit8 v13, v6, 0x7

    .line 278
    shl-int/lit8 v13, v13, 0x3

    .line 280
    shr-long/2addr v8, v13

    .line 281
    and-long v8, v8, v25

    .line 283
    cmp-long v14, v8, v18

    .line 285
    if-nez v14, :cond_121

    .line 287
    :goto_11e
    add-int/lit8 v6, v6, 0x1

    .line 289
    goto :goto_10d

    .line 290
    :cond_121
    cmp-long v8, v8, v21

    .line 292
    if-eqz v8, :cond_126

    .line 294
    goto :goto_11e

    .line 295
    :cond_126
    aget-object v8, v3, v6

    .line 297
    if-eqz v8, :cond_12f

    .line 299
    invoke-virtual {v8}, Ljava/lang/Object;->hashCode()I

    .line 302
    move-result v8

    .line 303
    goto :goto_130

    .line 304
    :cond_12f
    move v8, v15

    .line 305
    :goto_130
    mul-int v8, v8, v20

    .line 307
    shl-int/lit8 v9, v8, 0x10

    .line 309
    xor-int/2addr v8, v9

    .line 310
    ushr-int/lit8 v9, v8, 0x7

    .line 312
    invoke-virtual {v0, v9}, Landroidx/collection/MutableObjectIntMap;->findFirstAvailableSlot(I)I

    .line 315
    move-result v14

    .line 316
    and-int/2addr v9, v2

    .line 317
    sub-int v17, v14, v9

    .line 319
    and-int v17, v17, v2

    .line 321
    move-wide/from16 v27, v10

    .line 323
    div-int/lit8 v10, v17, 0x8

    .line 325
    sub-int v9, v6, v9

    .line 327
    and-int/2addr v9, v2

    .line 328
    div-int/2addr v9, v12

    .line 329
    const-wide/high16 v29, -0x8000000000000000L

    .line 331
    if-ne v10, v9, :cond_170

    .line 333
    and-int/lit8 v8, v8, 0x7f

    .line 335
    int-to-long v8, v8

    .line 336
    aget-wide v10, v1, v7

    .line 338
    move/from16 v17, v12

    .line 340
    move/from16 v31, v13

    .line 342
    shl-long v12, v25, v31

    .line 344
    not-long v12, v12

    .line 345
    and-long/2addr v10, v12

    .line 346
    shl-long v8, v8, v31

    .line 348
    or-long/2addr v8, v10

    .line 349
    aput-wide v8, v1, v7

    .line 351
    array-length v7, v1

    .line 352
    add-int/lit8 v7, v7, -0x1

    .line 354
    aget-wide v8, v1, v15

    .line 356
    and-long v8, v8, v27

    .line 358
    or-long v8, v8, v29

    .line 360
    aput-wide v8, v1, v7

    .line 362
    add-int/lit8 v6, v6, 0x1

    .line 364
    move/from16 v12, v17

    .line 366
    move-wide/from16 v10, v27

    .line 368
    goto :goto_10d

    .line 369
    :cond_170
    move/from16 v17, v12

    .line 371
    move/from16 v31, v13

    .line 373
    shr-int/lit8 v9, v14, 0x3

    .line 375
    aget-wide v10, v1, v9

    .line 377
    and-int/lit8 v12, v14, 0x7

    .line 379
    shl-int/lit8 v12, v12, 0x3

    .line 381
    shr-long v32, v10, v12

    .line 383
    and-long v32, v32, v25

    .line 385
    cmp-long v13, v32, v18

    .line 387
    if-nez v13, :cond_1ae

    .line 389
    and-int/lit8 v8, v8, 0x7f

    .line 391
    move v13, v2

    .line 392
    move-object/from16 v32, v3

    .line 394
    int-to-long v2, v8

    .line 395
    move-wide/from16 v33, v2

    .line 397
    shl-long v2, v25, v12

    .line 399
    not-long v2, v2

    .line 400
    and-long/2addr v2, v10

    .line 401
    shl-long v10, v33, v12

    .line 403
    or-long/2addr v2, v10

    .line 404
    aput-wide v2, v1, v9

    .line 406
    aget-wide v2, v1, v7

    .line 408
    shl-long v8, v25, v31

    .line 410
    not-long v8, v8

    .line 411
    and-long/2addr v2, v8

    .line 412
    shl-long v8, v18, v31

    .line 414
    or-long/2addr v2, v8

    .line 415
    aput-wide v2, v1, v7

    .line 417
    aget-object v2, v32, v6

    .line 419
    aput-object v2, v32, v14

    .line 421
    const/4 v2, 0x0

    .line 422
    aput-object v2, v32, v6

    .line 424
    aget v2, v4, v6

    .line 426
    aput v2, v4, v14

    .line 428
    aput v15, v4, v6

    .line 430
    goto :goto_1ce

    .line 431
    :cond_1ae
    move v13, v2

    .line 432
    move-object/from16 v32, v3

    .line 434
    and-int/lit8 v2, v8, 0x7f

    .line 436
    int-to-long v2, v2

    .line 437
    shl-long v7, v25, v12

    .line 439
    not-long v7, v7

    .line 440
    and-long/2addr v7, v10

    .line 441
    shl-long/2addr v2, v12

    .line 442
    or-long/2addr v2, v7

    .line 443
    aput-wide v2, v1, v9

    .line 445
    aget-object v2, v32, v14

    .line 447
    aget-object v3, v32, v6

    .line 449
    aput-object v3, v32, v14

    .line 451
    aput-object v2, v32, v6

    .line 453
    aget v2, v4, v14

    .line 455
    aget v3, v4, v6

    .line 457
    aput v3, v4, v14

    .line 459
    aput v2, v4, v6

    .line 461
    add-int/lit8 v6, v6, -0x1

    .line 463
    :goto_1ce
    array-length v2, v1

    .line 464
    add-int/lit8 v2, v2, -0x1

    .line 466
    aget-wide v7, v1, v15

    .line 468
    and-long v7, v7, v27

    .line 470
    or-long v7, v7, v29

    .line 472
    aput-wide v7, v1, v2

    .line 474
    add-int/lit8 v6, v6, 0x1

    .line 476
    move v2, v13

    .line 477
    move/from16 v12, v17

    .line 479
    move-wide/from16 v10, v27

    .line 481
    move-object/from16 v3, v32

    .line 483
    goto/16 :goto_10d

    .line 485
    :cond_1e4
    iget v1, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 487
    invoke-static {v1}, Landroidx/collection/ScatterMapKt;->loadedCapacity(I)I

    .line 490
    move-result v1

    .line 491
    iget v2, v0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 493
    sub-int/2addr v1, v2

    .line 494
    iput v1, v0, Landroidx/collection/MutableObjectIntMap;->growthLimit:I

    .line 496
    goto/16 :goto_271

    .line 498
    :cond_1f1
    :goto_1f1
    move-wide/from16 v25, v8

    .line 500
    move-wide/from16 v23, v11

    .line 502
    const-wide/16 v18, 0x80

    .line 504
    goto :goto_1fb

    .line 505
    :cond_1f8
    const/16 p1, 0x7

    .line 507
    goto :goto_1f1

    .line 508
    :goto_1fb
    iget v1, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 510
    invoke-static {v1}, Landroidx/collection/ScatterMapKt;->nextCapacity(I)I

    .line 513
    move-result v1

    .line 514
    iget-object v2, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 516
    iget-object v3, v0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 518
    iget-object v4, v0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 520
    iget v6, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 522
    invoke-virtual {v0, v1}, Landroidx/collection/MutableObjectIntMap;->initializeStorage(I)V

    .line 525
    iget-object v1, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 527
    iget-object v7, v0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 529
    iget-object v8, v0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 531
    iget v9, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 533
    move v10, v15

    .line 534
    :goto_215
    if-ge v10, v6, :cond_271

    .line 536
    shr-int/lit8 v11, v10, 0x3

    .line 538
    aget-wide v11, v2, v11

    .line 540
    and-int/lit8 v13, v10, 0x7

    .line 542
    shl-int/lit8 v13, v13, 0x3

    .line 544
    shr-long/2addr v11, v13

    .line 545
    and-long v11, v11, v25

    .line 547
    cmp-long v11, v11, v18

    .line 549
    if-gez v11, :cond_268

    .line 551
    aget-object v11, v3, v10

    .line 553
    if-eqz v11, :cond_22f

    .line 555
    invoke-virtual {v11}, Ljava/lang/Object;->hashCode()I

    .line 558
    move-result v12

    .line 559
    goto :goto_230

    .line 560
    :cond_22f
    move v12, v15

    .line 561
    :goto_230
    mul-int v12, v12, v20

    .line 563
    shl-int/lit8 v13, v12, 0x10

    .line 565
    xor-int/2addr v12, v13

    .line 566
    ushr-int/lit8 v13, v12, 0x7

    .line 568
    invoke-virtual {v0, v13}, Landroidx/collection/MutableObjectIntMap;->findFirstAvailableSlot(I)I

    .line 571
    move-result v13

    .line 572
    and-int/lit8 v12, v12, 0x7f

    .line 574
    move-object/from16 v17, v1

    .line 576
    move-object v14, v2

    .line 577
    int-to-long v1, v12

    .line 578
    shr-int/lit8 v12, v13, 0x3

    .line 580
    and-int/lit8 v21, v13, 0x7

    .line 582
    shl-int/lit8 v21, v21, 0x3

    .line 584
    aget-wide v27, v17, v12

    .line 586
    move-wide/from16 v29, v1

    .line 588
    shl-long v1, v25, v21

    .line 590
    not-long v1, v1

    .line 591
    and-long v1, v27, v1

    .line 593
    shl-long v21, v29, v21

    .line 595
    or-long v1, v1, v21

    .line 597
    aput-wide v1, v17, v12

    .line 599
    add-int/lit8 v12, v13, -0x7

    .line 601
    and-int/2addr v12, v9

    .line 602
    and-int/lit8 v21, v9, 0x7

    .line 604
    add-int v12, v12, v21

    .line 606
    shr-int/lit8 v12, v12, 0x3

    .line 608
    aput-wide v1, v17, v12

    .line 610
    aput-object v11, v7, v13

    .line 612
    aget v1, v4, v10

    .line 614
    aput v1, v8, v13

    .line 616
    goto :goto_26b

    .line 617
    :cond_268
    move-object/from16 v17, v1

    .line 619
    move-object v14, v2

    .line 620
    :goto_26b
    add-int/lit8 v10, v10, 0x1

    .line 622
    move-object v2, v14

    .line 623
    move-object/from16 v1, v17

    .line 625
    goto :goto_215

    .line 626
    :cond_271
    :goto_271
    invoke-virtual {v0, v5}, Landroidx/collection/MutableObjectIntMap;->findFirstAvailableSlot(I)I

    .line 629
    move-result v1

    .line 630
    :goto_275
    iget v2, v0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 632
    add-int/lit8 v2, v2, 0x1

    .line 634
    iput v2, v0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 636
    iget v2, v0, Landroidx/collection/MutableObjectIntMap;->growthLimit:I

    .line 638
    iget-object v3, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 640
    shr-int/lit8 v4, v1, 0x3

    .line 642
    aget-wide v5, v3, v4

    .line 644
    and-int/lit8 v7, v1, 0x7

    .line 646
    shl-int/lit8 v7, v7, 0x3

    .line 648
    shr-long v8, v5, v7

    .line 650
    and-long v8, v8, v25

    .line 652
    cmp-long v8, v8, v18

    .line 654
    if-nez v8, :cond_291

    .line 656
    move/from16 v15, v16

    .line 658
    :cond_291
    sub-int/2addr v2, v15

    .line 659
    iput v2, v0, Landroidx/collection/MutableObjectIntMap;->growthLimit:I

    .line 661
    iget v0, v0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 663
    shl-long v8, v25, v7

    .line 665
    not-long v8, v8

    .line 666
    and-long/2addr v5, v8

    .line 667
    shl-long v7, v23, v7

    .line 669
    or-long/2addr v5, v7

    .line 670
    aput-wide v5, v3, v4

    .line 672
    add-int/lit8 v2, v1, -0x7

    .line 674
    and-int/2addr v2, v0

    .line 675
    and-int/lit8 v0, v0, 0x7

    .line 677
    add-int/2addr v2, v0

    .line 678
    shr-int/lit8 v0, v2, 0x3

    .line 680
    aput-wide v5, v3, v0

    .line 682
    not-int v0, v1

    .line 683
    return v0

    .line 684
    :cond_2ab
    move/from16 v17, v3

    .line 686
    add-int/lit8 v8, v8, 0x8

    .line 688
    add-int/2addr v7, v8

    .line 689
    and-int/2addr v7, v6

    .line 690
    move/from16 v3, v19

    .line 692
    move/from16 v4, v20

    .line 694
    goto/16 :goto_1c
.end method

.method public final findKeyIndex(Ljava/lang/Object;)I
    .registers 15

    .line 1
    const/4 v0, 0x0

    .line 2
    if-eqz p1, :cond_8

    .line 4
    invoke-virtual {p1}, Ljava/lang/Object;->hashCode()I

    .line 7
    move-result v1

    .line 8
    goto :goto_9

    .line 9
    :cond_8
    move v1, v0

    .line 10
    :goto_9
    const v2, -0x3361d2af  # -8.293031E7f

    .line 13
    mul-int/2addr v1, v2

    .line 14
    shl-int/lit8 v2, v1, 0x10

    .line 16
    xor-int/2addr v1, v2

    .line 17
    and-int/lit8 v2, v1, 0x7f

    .line 19
    iget v3, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 21
    ushr-int/lit8 v1, v1, 0x7

    .line 23
    :goto_16
    and-int/2addr v1, v3

    .line 24
    iget-object v4, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 26
    shr-int/lit8 v5, v1, 0x3

    .line 28
    and-int/lit8 v6, v1, 0x7

    .line 30
    shl-int/lit8 v6, v6, 0x3

    .line 32
    aget-wide v7, v4, v5

    .line 34
    ushr-long/2addr v7, v6

    .line 35
    add-int/lit8 v5, v5, 0x1

    .line 37
    aget-wide v4, v4, v5

    .line 39
    rsub-int/lit8 v9, v6, 0x40

    .line 41
    shl-long/2addr v4, v9

    .line 42
    int-to-long v9, v6

    .line 43
    neg-long v9, v9

    .line 44
    const/16 v6, 0x3f

    .line 46
    shr-long/2addr v9, v6

    .line 47
    and-long/2addr v4, v9

    .line 48
    or-long/2addr v4, v7

    .line 49
    int-to-long v6, v2

    .line 50
    const-wide v8, 0x101010101010101L

    .line 55
    mul-long/2addr v6, v8

    .line 56
    xor-long/2addr v6, v4

    .line 57
    sub-long v8, v6, v8

    .line 59
    not-long v6, v6

    .line 60
    and-long/2addr v6, v8

    .line 61
    const-wide v8, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 66
    and-long/2addr v6, v8

    .line 67
    :goto_42
    const-wide/16 v10, 0x0

    .line 69
    cmp-long v12, v6, v10

    .line 71
    if-eqz v12, :cond_61

    .line 73
    invoke-static {v6, v7}, Ljava/lang/Long;->numberOfTrailingZeros(J)I

    .line 76
    move-result v10

    .line 77
    shr-int/lit8 v10, v10, 0x3

    .line 79
    add-int/2addr v10, v1

    .line 80
    and-int/2addr v10, v3

    .line 81
    iget-object v11, p0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 83
    aget-object v11, v11, v10

    .line 85
    invoke-static {v11, p1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 88
    move-result v11

    .line 89
    if-eqz v11, :cond_5b

    .line 91
    return v10

    .line 92
    :cond_5b
    const-wide/16 v10, 0x1

    .line 94
    sub-long v10, v6, v10

    .line 96
    and-long/2addr v6, v10

    .line 97
    goto :goto_42

    .line 98
    :cond_61
    not-long v6, v4

    .line 99
    const/4 v12, 0x6

    .line 100
    shl-long/2addr v6, v12

    .line 101
    and-long/2addr v4, v6

    .line 102
    and-long/2addr v4, v8

    .line 103
    cmp-long v4, v4, v10

    .line 105
    if-eqz v4, :cond_6c

    .line 107
    const/4 p0, -0x1

    .line 108
    return p0

    .line 109
    :cond_6c
    add-int/lit8 v0, v0, 0x8

    .line 111
    add-int/2addr v1, v0

    .line 112
    goto :goto_16
.end method

.method public final hashCode()I
    .registers 16

    .line 1
    iget-object v0, p0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 3
    iget-object v1, p0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 5
    iget-object p0, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 7
    array-length v2, p0

    .line 8
    add-int/lit8 v2, v2, -0x2

    .line 10
    const/4 v3, 0x0

    .line 11
    if-ltz v2, :cond_56

    .line 13
    move v4, v3

    .line 14
    move v5, v4

    .line 15
    :goto_e
    aget-wide v6, p0, v4

    .line 17
    not-long v8, v6

    .line 18
    const/4 v10, 0x7

    .line 19
    shl-long/2addr v8, v10

    .line 20
    and-long/2addr v8, v6

    .line 21
    const-wide v10, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 26
    and-long/2addr v8, v10

    .line 27
    cmp-long v8, v8, v10

    .line 29
    if-eqz v8, :cond_50

    .line 31
    sub-int v8, v4, v2

    .line 33
    not-int v8, v8

    .line 34
    ushr-int/lit8 v8, v8, 0x1f

    .line 36
    const/16 v9, 0x8

    .line 38
    rsub-int/lit8 v8, v8, 0x8

    .line 40
    move v10, v3

    .line 41
    :goto_28
    if-ge v10, v8, :cond_4c

    .line 43
    const-wide/16 v11, 0xff

    .line 45
    and-long/2addr v11, v6

    .line 46
    const-wide/16 v13, 0x80

    .line 48
    cmp-long v11, v11, v13

    .line 50
    if-gez v11, :cond_48

    .line 52
    shl-int/lit8 v11, v4, 0x3

    .line 54
    add-int/2addr v11, v10

    .line 55
    aget-object v12, v0, v11

    .line 57
    aget v11, v1, v11

    .line 59
    if-eqz v12, :cond_41

    .line 61
    invoke-virtual {v12}, Ljava/lang/Object;->hashCode()I

    .line 64
    move-result v12

    .line 65
    goto :goto_42

    .line 66
    :cond_41
    move v12, v3

    .line 67
    :goto_42
    invoke-static {v11}, Ljava/lang/Integer;->hashCode(I)I

    .line 70
    move-result v11

    .line 71
    xor-int/2addr v11, v12

    .line 72
    add-int/2addr v5, v11

    .line 73
    :cond_48
    shr-long/2addr v6, v9

    .line 74
    add-int/lit8 v10, v10, 0x1

    .line 76
    goto :goto_28

    .line 77
    :cond_4c
    if-ne v8, v9, :cond_4f

    .line 79
    goto :goto_50

    .line 80
    :cond_4f
    return v5

    .line 81
    :cond_50
    :goto_50
    if-eq v4, v2, :cond_55

    .line 83
    add-int/lit8 v4, v4, 0x1

    .line 85
    goto :goto_e

    .line 86
    :cond_55
    return v5

    .line 87
    :cond_56
    return v3
.end method

.method public final initializeStorage(I)V
    .registers 11

    .line 1
    const/4 v0, 0x0

    .line 2
    if-lez p1, :cond_d

    .line 4
    invoke-static {p1}, Landroidx/collection/ScatterMapKt;->normalizeCapacity(I)I

    .line 7
    move-result p1

    .line 8
    const/4 v1, 0x7

    .line 9
    invoke-static {v1, p1}, Ljava/lang/Math;->max(II)I

    .line 12
    move-result p1

    .line 13
    goto :goto_e

    .line 14
    :cond_d
    move p1, v0

    .line 15
    :goto_e
    iput p1, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 17
    if-nez p1, :cond_15

    .line 19
    sget-object v0, Landroidx/collection/ScatterMapKt;->EmptyGroup:[J

    .line 21
    goto :goto_26

    .line 22
    :cond_15
    add-int/lit8 v1, p1, 0xf

    .line 24
    and-int/lit8 v1, v1, -0x8

    .line 26
    shr-int/lit8 v1, v1, 0x3

    .line 28
    new-array v2, v1, [J

    .line 30
    const-wide v3, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 35
    invoke-static {v2, v0, v1, v3, v4}, Ljava/util/Arrays;->fill([JIIJ)V

    .line 38
    move-object v0, v2

    .line 39
    :goto_26
    iput-object v0, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 41
    shr-int/lit8 v1, p1, 0x3

    .line 43
    and-int/lit8 v2, p1, 0x7

    .line 45
    shl-int/lit8 v2, v2, 0x3

    .line 47
    aget-wide v3, v0, v1

    .line 49
    const-wide/16 v5, 0xff

    .line 51
    shl-long/2addr v5, v2

    .line 52
    not-long v7, v5

    .line 53
    and-long v2, v3, v7

    .line 55
    or-long/2addr v2, v5

    .line 56
    aput-wide v2, v0, v1

    .line 58
    iget v0, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 60
    invoke-static {v0}, Landroidx/collection/ScatterMapKt;->loadedCapacity(I)I

    .line 63
    move-result v0

    .line 64
    iget v1, p0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 66
    sub-int/2addr v0, v1

    .line 67
    iput v0, p0, Landroidx/collection/MutableObjectIntMap;->growthLimit:I

    .line 69
    new-array v0, p1, [Ljava/lang/Object;

    .line 71
    iput-object v0, p0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 73
    new-array p1, p1, [I

    .line 75
    iput-object p1, p0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 77
    return-void
.end method

.method public final removeValueAt(I)V
    .registers 10

    .line 1
    iget v0, p0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 3
    add-int/lit8 v0, v0, -0x1

    .line 5
    iput v0, p0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 7
    iget-object v0, p0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 9
    iget v1, p0, Landroidx/collection/MutableObjectIntMap;->_capacity:I

    .line 11
    shr-int/lit8 v2, p1, 0x3

    .line 13
    and-int/lit8 v3, p1, 0x7

    .line 15
    shl-int/lit8 v3, v3, 0x3

    .line 17
    aget-wide v4, v0, v2

    .line 19
    const-wide/16 v6, 0xff

    .line 21
    shl-long/2addr v6, v3

    .line 22
    not-long v6, v6

    .line 23
    and-long/2addr v4, v6

    .line 24
    const-wide/16 v6, 0xfe

    .line 26
    shl-long/2addr v6, v3

    .line 27
    or-long v3, v4, v6

    .line 29
    aput-wide v3, v0, v2

    .line 31
    add-int/lit8 v2, p1, -0x7

    .line 33
    and-int/2addr v2, v1

    .line 34
    and-int/lit8 v1, v1, 0x7

    .line 36
    add-int/2addr v2, v1

    .line 37
    shr-int/lit8 v1, v2, 0x3

    .line 39
    aput-wide v3, v0, v1

    .line 41
    iget-object p0, p0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 43
    const/4 v0, 0x0

    .line 44
    aput-object v0, p0, p1

    .line 46
    return-void
.end method

.method public final set(ILjava/lang/Object;)V
    .registers 5

    .line 1
    invoke-virtual {p0, p2}, Landroidx/collection/MutableObjectIntMap;->findIndex(Ljava/lang/Object;)I

    .line 4
    move-result v0

    .line 5
    if-gez v0, :cond_7

    .line 7
    not-int v0, v0

    .line 8
    :cond_7
    iget-object v1, p0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 10
    aput-object p2, v1, v0

    .line 12
    iget-object p0, p0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 14
    aput p1, p0, v0

    .line 16
    return-void
.end method

.method public final toString()Ljava/lang/String;
    .registers 19

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget v1, v0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 5
    if-nez v1, :cond_9

    .line 7
    const-string v0, "{}"

    .line 9
    return-object v0

    .line 10
    :cond_9
    new-instance v1, Ljava/lang/StringBuilder;

    .line 12
    const-string v2, "{"

    .line 14
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    iget-object v2, v0, Landroidx/collection/MutableObjectIntMap;->keys:[Ljava/lang/Object;

    .line 19
    iget-object v3, v0, Landroidx/collection/MutableObjectIntMap;->values:[I

    .line 21
    iget-object v4, v0, Landroidx/collection/MutableObjectIntMap;->metadata:[J

    .line 23
    array-length v5, v4

    .line 24
    add-int/lit8 v5, v5, -0x2

    .line 26
    if-ltz v5, :cond_6f

    .line 28
    const/4 v6, 0x0

    .line 29
    move v7, v6

    .line 30
    move v8, v7

    .line 31
    :goto_1e
    aget-wide v9, v4, v7

    .line 33
    not-long v11, v9

    .line 34
    const/4 v13, 0x7

    .line 35
    shl-long/2addr v11, v13

    .line 36
    and-long/2addr v11, v9

    .line 37
    const-wide v13, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 42
    and-long/2addr v11, v13

    .line 43
    cmp-long v11, v11, v13

    .line 45
    if-eqz v11, :cond_6a

    .line 47
    sub-int v11, v7, v5

    .line 49
    not-int v11, v11

    .line 50
    ushr-int/lit8 v11, v11, 0x1f

    .line 52
    const/16 v12, 0x8

    .line 54
    rsub-int/lit8 v11, v11, 0x8

    .line 56
    move v13, v6

    .line 57
    :goto_38
    if-ge v13, v11, :cond_68

    .line 59
    const-wide/16 v14, 0xff

    .line 61
    and-long/2addr v14, v9

    .line 62
    const-wide/16 v16, 0x80

    .line 64
    cmp-long v14, v14, v16

    .line 66
    if-gez v14, :cond_64

    .line 68
    shl-int/lit8 v14, v7, 0x3

    .line 70
    add-int/2addr v14, v13

    .line 71
    aget-object v15, v2, v14

    .line 73
    aget v14, v3, v14

    .line 75
    if-ne v15, v0, :cond_4e

    .line 77
    const-string v15, "(this)"

    .line 79
    :cond_4e
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 82
    const-string v15, "="

    .line 84
    invoke-virtual {v1, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 90
    add-int/lit8 v8, v8, 0x1

    .line 92
    iget v14, v0, Landroidx/collection/MutableObjectIntMap;->_size:I

    .line 94
    if-ge v8, v14, :cond_64

    .line 96
    const-string v14, ", "

    .line 98
    invoke-virtual {v1, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 101
    :cond_64
    shr-long/2addr v9, v12

    .line 102
    add-int/lit8 v13, v13, 0x1

    .line 104
    goto :goto_38

    .line 105
    :cond_68
    if-ne v11, v12, :cond_6f

    .line 107
    :cond_6a
    if-eq v7, v5, :cond_6f

    .line 109
    add-int/lit8 v7, v7, 0x1

    .line 111
    goto :goto_1e

    .line 112
    :cond_6f
    const/16 v0, 0x7d

    .line 114
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 117
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 120
    move-result-object v0

    .line 121
    return-object v0
.end method
