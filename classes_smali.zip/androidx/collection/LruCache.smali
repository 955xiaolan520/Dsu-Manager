.class public Landroidx/collection/LruCache;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public hitCount:I

.field public final lock:Landroidx/collection/internal/Lock;

.field public final map:Landroidx/collection/internal/LruHashMap;

.field public final maxSize:I

.field public missCount:I

.field public size:I


# direct methods
.method public constructor <init>(I)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Landroidx/collection/LruCache;->maxSize:I

    .line 6
    if-lez p1, :cond_18

    .line 8
    new-instance p1, Landroidx/collection/internal/LruHashMap;

    .line 10
    const/4 v0, 0x0

    .line 11
    invoke-direct {p1, v0}, Landroidx/collection/internal/LruHashMap;-><init>(I)V

    .line 14
    iput-object p1, p0, Landroidx/collection/LruCache;->map:Landroidx/collection/internal/LruHashMap;

    .line 16
    new-instance p1, Landroidx/collection/internal/Lock;

    .line 18
    const/4 v1, 0x0

    .line 19
    invoke-direct {p1, v0, v1}, Landroidx/collection/internal/Lock;-><init>(IZ)V

    .line 22
    iput-object p1, p0, Landroidx/collection/LruCache;->lock:Landroidx/collection/internal/Lock;

    .line 24
    return-void

    .line 25
    :cond_18
    const-string p0, "maxSize <= 0"

    .line 27
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 30
    const/4 p0, 0x0

    .line 31
    throw p0
.end method


# virtual methods
.method public final get(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget-object v0, p0, Landroidx/collection/LruCache;->lock:Landroidx/collection/internal/Lock;

    .line 3
    monitor-enter v0

    .line 4
    :try_start_3
    iget-object v1, p0, Landroidx/collection/LruCache;->map:Landroidx/collection/internal/LruHashMap;

    .line 6
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    iget-object v1, v1, Landroidx/collection/internal/LruHashMap;->map:Ljava/util/LinkedHashMap;

    .line 11
    invoke-virtual {v1, p1}, Ljava/util/LinkedHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    move-result-object p1

    .line 15
    if-eqz p1, :cond_1a

    .line 17
    iget v1, p0, Landroidx/collection/LruCache;->hitCount:I

    .line 19
    add-int/lit8 v1, v1, 0x1

    .line 21
    iput v1, p0, Landroidx/collection/LruCache;->hitCount:I
    :try_end_16
    .catchall {:try_start_3 .. :try_end_16} :catchall_18

    .line 23
    monitor-exit v0

    .line 24
    return-object p1

    .line 25
    :catchall_18
    move-exception p0

    .line 26
    goto :goto_23

    .line 27
    :cond_1a
    :try_start_1a
    iget p1, p0, Landroidx/collection/LruCache;->missCount:I

    .line 29
    add-int/lit8 p1, p1, 0x1

    .line 31
    iput p1, p0, Landroidx/collection/LruCache;->missCount:I
    :try_end_20
    .catchall {:try_start_1a .. :try_end_20} :catchall_18

    .line 33
    monitor-exit v0

    .line 34
    const/4 p0, 0x0

    .line 35
    return-object p0

    .line 36
    :goto_23
    monitor-exit v0

    .line 37
    throw p0
.end method

.method public final put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    iget-object v0, p0, Landroidx/collection/LruCache;->lock:Landroidx/collection/internal/Lock;

    .line 6
    monitor-enter v0

    .line 7
    :try_start_6
    iget v1, p0, Landroidx/collection/LruCache;->size:I

    .line 9
    add-int/lit8 v1, v1, 0x1

    .line 11
    iput v1, p0, Landroidx/collection/LruCache;->size:I

    .line 13
    iget-object v1, p0, Landroidx/collection/LruCache;->map:Landroidx/collection/internal/LruHashMap;

    .line 15
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 18
    iget-object v1, v1, Landroidx/collection/internal/LruHashMap;->map:Ljava/util/LinkedHashMap;

    .line 20
    invoke-virtual {v1, p1, p2}, Ljava/util/AbstractMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 23
    move-result-object p1

    .line 24
    if-eqz p1, :cond_23

    .line 26
    iget p2, p0, Landroidx/collection/LruCache;->size:I

    .line 28
    add-int/lit8 p2, p2, -0x1

    .line 30
    iput p2, p0, Landroidx/collection/LruCache;->size:I
    :try_end_1f
    .catchall {:try_start_6 .. :try_end_1f} :catchall_20

    .line 32
    goto :goto_23

    .line 33
    :catchall_20
    move-exception p0

    .line 34
    goto/16 :goto_b0

    .line 36
    :cond_23
    :goto_23
    monitor-exit v0

    .line 37
    iget p2, p0, Landroidx/collection/LruCache;->maxSize:I

    .line 39
    :goto_26
    iget-object v0, p0, Landroidx/collection/LruCache;->lock:Landroidx/collection/internal/Lock;

    .line 41
    monitor-enter v0

    .line 42
    :try_start_29
    iget v1, p0, Landroidx/collection/LruCache;->size:I

    .line 44
    if-ltz v1, :cond_a6

    .line 46
    iget-object v1, p0, Landroidx/collection/LruCache;->map:Landroidx/collection/internal/LruHashMap;

    .line 48
    iget-object v1, v1, Landroidx/collection/internal/LruHashMap;->map:Ljava/util/LinkedHashMap;

    .line 50
    invoke-virtual {v1}, Ljava/util/AbstractMap;->isEmpty()Z

    .line 53
    move-result v1

    .line 54
    if-eqz v1, :cond_3f

    .line 56
    iget v1, p0, Landroidx/collection/LruCache;->size:I

    .line 58
    if-nez v1, :cond_a6

    .line 60
    goto :goto_3f

    .line 61
    :catchall_3c
    move-exception p0

    .line 62
    goto/16 :goto_ae

    .line 64
    :cond_3f
    :goto_3f
    iget v1, p0, Landroidx/collection/LruCache;->size:I

    .line 66
    if-le v1, p2, :cond_a4

    .line 68
    iget-object v1, p0, Landroidx/collection/LruCache;->map:Landroidx/collection/internal/LruHashMap;

    .line 70
    iget-object v1, v1, Landroidx/collection/internal/LruHashMap;->map:Ljava/util/LinkedHashMap;

    .line 72
    invoke-virtual {v1}, Ljava/util/AbstractMap;->isEmpty()Z

    .line 75
    move-result v1

    .line 76
    if-eqz v1, :cond_4e

    .line 78
    goto :goto_a4

    .line 79
    :cond_4e
    iget-object v1, p0, Landroidx/collection/LruCache;->map:Landroidx/collection/internal/LruHashMap;

    .line 81
    iget-object v1, v1, Landroidx/collection/internal/LruHashMap;->map:Ljava/util/LinkedHashMap;

    .line 83
    invoke-virtual {v1}, Ljava/util/LinkedHashMap;->entrySet()Ljava/util/Set;

    .line 86
    move-result-object v1

    .line 87
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    check-cast v1, Ljava/lang/Iterable;

    .line 92
    instance-of v2, v1, Ljava/util/List;

    .line 94
    const/4 v3, 0x0

    .line 95
    if-eqz v2, :cond_6f

    .line 97
    check-cast v1, Ljava/util/List;

    .line 99
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 102
    move-result v2

    .line 103
    if-eqz v2, :cond_69

    .line 105
    goto :goto_7e

    .line 106
    :cond_69
    const/4 v2, 0x0

    .line 107
    invoke-interface {v1, v2}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 110
    move-result-object v3

    .line 111
    goto :goto_7e

    .line 112
    :cond_6f
    invoke-interface {v1}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 115
    move-result-object v1

    .line 116
    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    .line 119
    move-result v2

    .line 120
    if-nez v2, :cond_7a

    .line 122
    goto :goto_7e

    .line 123
    :cond_7a
    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 126
    move-result-object v3

    .line 127
    :goto_7e
    check-cast v3, Ljava/util/Map$Entry;
    :try_end_80
    .catchall {:try_start_29 .. :try_end_80} :catchall_3c

    .line 129
    if-nez v3, :cond_84

    .line 131
    monitor-exit v0

    .line 132
    return-object p1

    .line 133
    :cond_84
    :try_start_84
    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    .line 136
    move-result-object v1

    .line 137
    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    .line 140
    move-result-object v2

    .line 141
    iget-object v3, p0, Landroidx/collection/LruCache;->map:Landroidx/collection/internal/LruHashMap;

    .line 143
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 146
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 149
    iget-object v3, v3, Landroidx/collection/internal/LruHashMap;->map:Ljava/util/LinkedHashMap;

    .line 151
    invoke-virtual {v3, v1}, Ljava/util/AbstractMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    iget v1, p0, Landroidx/collection/LruCache;->size:I

    .line 156
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 159
    add-int/lit8 v1, v1, -0x1

    .line 161
    iput v1, p0, Landroidx/collection/LruCache;->size:I
    :try_end_a2
    .catchall {:try_start_84 .. :try_end_a2} :catchall_3c

    .line 163
    monitor-exit v0

    .line 164
    goto :goto_26

    .line 165
    :cond_a4
    :goto_a4
    monitor-exit v0

    .line 166
    return-object p1

    .line 167
    :cond_a6
    :try_start_a6
    const-string p0, "LruCache.sizeOf() is reporting inconsistent results!"

    .line 169
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 171
    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 174
    throw p1
    :try_end_ae
    .catchall {:try_start_a6 .. :try_end_ae} :catchall_3c

    .line 175
    :goto_ae
    monitor-exit v0

    .line 176
    throw p0

    .line 177
    :goto_b0
    monitor-exit v0

    .line 178
    throw p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 5

    .line 1
    const-string v0, "LruCache[maxSize="

    .line 3
    iget-object v1, p0, Landroidx/collection/LruCache;->lock:Landroidx/collection/internal/Lock;

    .line 5
    monitor-enter v1

    .line 6
    :try_start_5
    iget v2, p0, Landroidx/collection/LruCache;->hitCount:I

    .line 8
    iget v3, p0, Landroidx/collection/LruCache;->missCount:I

    .line 10
    add-int/2addr v3, v2

    .line 11
    if-eqz v3, :cond_12

    .line 13
    mul-int/lit8 v2, v2, 0x64

    .line 15
    div-int/2addr v2, v3

    .line 16
    goto :goto_13

    .line 17
    :catchall_10
    move-exception p0

    .line 18
    goto :goto_44

    .line 19
    :cond_12
    const/4 v2, 0x0

    .line 20
    :goto_13
    new-instance v3, Ljava/lang/StringBuilder;

    .line 22
    invoke-direct {v3, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 25
    iget v0, p0, Landroidx/collection/LruCache;->maxSize:I

    .line 27
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 30
    const-string v0, ",hits="

    .line 32
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 35
    iget v0, p0, Landroidx/collection/LruCache;->hitCount:I

    .line 37
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 40
    const-string v0, ",misses="

    .line 42
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    iget p0, p0, Landroidx/collection/LruCache;->missCount:I

    .line 47
    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 50
    const-string p0, ",hitRate="

    .line 52
    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 58
    const-string p0, "%]"

    .line 60
    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 66
    move-result-object p0
    :try_end_42
    .catchall {:try_start_5 .. :try_end_42} :catchall_10

    .line 67
    monitor-exit v1

    .line 68
    return-object p0

    .line 69
    :goto_44
    monitor-exit v1

    .line 70
    throw p0
.end method
