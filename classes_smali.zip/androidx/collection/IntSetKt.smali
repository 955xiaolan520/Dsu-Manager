.class public abstract Landroidx/collection/IntSetKt;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# static fields
.field public static final EmptyIntArray:[I


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Landroidx/collection/MutableIntSet;

    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Landroidx/collection/MutableIntSet;-><init>(I)V

    .line 7
    new-array v0, v1, [I

    .line 9
    sput-object v0, Landroidx/collection/IntSetKt;->EmptyIntArray:[I

    .line 11
    return-void
.end method
