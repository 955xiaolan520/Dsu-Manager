.class public interface abstract Landroidx/compose/foundation/IndicationNodeFactory;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# virtual methods
.method public abstract create(Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;)Landroidx/compose/ui/node/DelegatableNode;
.end method

.method public abstract hashCode()I
.end method
