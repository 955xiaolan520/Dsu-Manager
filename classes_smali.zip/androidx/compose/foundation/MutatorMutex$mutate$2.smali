.class public final Landroidx/compose/foundation/MutatorMutex$mutate$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $block:Ljava/lang/Object;

.field public final synthetic $priority:Ljava/lang/Object;

.field public final synthetic $r8$classId:I

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroid/content/ContentResolver;Landroid/net/Uri;Landroidx/compose/ui/platform/WindowRecomposer_androidKt$getAnimationScaleFlowFor$1$1$contentObserver$1;Lkotlinx/coroutines/channels/BufferedChannel;Landroid/content/Context;Lkotlin/coroutines/Continuation;)V
    .registers 8

    .line 1
    const/4 v0, 0x2

    .line 2
    iput v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:I

    .line 4
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 6
    iput-object p2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 8
    iput-object p3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 10
    iput-object p4, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$priority:Ljava/lang/Object;

    .line 12
    iput-object p5, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 14
    invoke-direct {p0, v0, p6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 17
    return-void
.end method

.method public synthetic constructor <init>(Landroidx/compose/foundation/MutatePriority;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)V
    .registers 6

    .line 18
    iput p5, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:I

    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$priority:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    iput-object p3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 14

    .line 1
    iget v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:I

    .line 3
    iget-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 5
    iget-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$priority:Ljava/lang/Object;

    .line 7
    iget-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 9
    packed-switch v0, :pswitch_data_4e

    .line 12
    new-instance v4, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 14
    iget-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 16
    move-object v5, v0

    .line 17
    check-cast v5, Landroid/content/ContentResolver;

    .line 19
    iget-object p0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 21
    move-object v6, p0

    .line 22
    check-cast v6, Landroid/net/Uri;

    .line 24
    move-object v7, v3

    .line 25
    check-cast v7, Landroidx/compose/ui/platform/WindowRecomposer_androidKt$getAnimationScaleFlowFor$1$1$contentObserver$1;

    .line 27
    move-object v8, v2

    .line 28
    check-cast v8, Lkotlinx/coroutines/channels/BufferedChannel;

    .line 30
    move-object v9, v1

    .line 31
    check-cast v9, Landroid/content/Context;

    .line 33
    move-object v10, p2

    .line 34
    invoke-direct/range {v4 .. v10}, Landroidx/compose/foundation/MutatorMutex$mutate$2;-><init>(Landroid/content/ContentResolver;Landroid/net/Uri;Landroidx/compose/ui/platform/WindowRecomposer_androidKt$getAnimationScaleFlowFor$1$1$contentObserver$1;Lkotlinx/coroutines/channels/BufferedChannel;Landroid/content/Context;Lkotlin/coroutines/Continuation;)V

    .line 37
    iput-object p1, v4, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 39
    return-object v4

    .line 40
    :pswitch_27  #0x1
    move-object v9, p2

    .line 41
    new-instance v5, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 43
    move-object v6, v2

    .line 44
    check-cast v6, Landroidx/compose/foundation/MutatePriority;

    .line 46
    move-object v7, v3

    .line 47
    check-cast v7, Landroidx/compose/material3/internal/InternalMutatorMutex;

    .line 49
    move-object v8, v1

    .line 50
    check-cast v8, Lkotlin/jvm/functions/Function1;

    .line 52
    const/4 v10, 0x1

    .line 53
    invoke-direct/range {v5 .. v10}, Landroidx/compose/foundation/MutatorMutex$mutate$2;-><init>(Landroidx/compose/foundation/MutatePriority;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)V

    .line 56
    iput-object p1, v5, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 58
    return-object v5

    .line 59
    :pswitch_3a  #0x0
    move-object v9, p2

    .line 60
    new-instance v5, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 62
    move-object v6, v2

    .line 63
    check-cast v6, Landroidx/compose/foundation/MutatePriority;

    .line 65
    move-object v7, v3

    .line 66
    check-cast v7, Landroidx/compose/foundation/MutatorMutex;

    .line 68
    move-object v8, v1

    .line 69
    check-cast v8, Lkotlin/jvm/functions/Function1;

    .line 71
    const/4 v10, 0x0

    .line 72
    invoke-direct/range {v5 .. v10}, Landroidx/compose/foundation/MutatorMutex$mutate$2;-><init>(Landroidx/compose/foundation/MutatePriority;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)V

    .line 75
    iput-object p1, v5, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 77
    return-object v5

    nop

    .line 79
    :pswitch_data_4e
    .packed-switch 0x0
        :pswitch_3a  #00000000
        :pswitch_27  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:I

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    packed-switch v0, :pswitch_data_34

    .line 8
    check-cast p1, Lkotlinx/coroutines/flow/FlowCollector;

    .line 10
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 12
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 18
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 25
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 27
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 33
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_25  #0x0
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 40
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 42
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;

    .line 48
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_data_34
    .packed-switch 0x0
        :pswitch_25  #00000000
        :pswitch_16  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 1
    iget v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$r8$classId:I

    .line 3
    iget-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 5
    iget-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->$priority:Ljava/lang/Object;

    .line 7
    const-string v3, "call to \'resume\' before \'invoke\' with coroutine"

    .line 9
    sget-object v4, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 11
    iget-object v5, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 13
    const/4 v6, 0x1

    .line 14
    const/4 v7, 0x2

    .line 15
    const/4 v8, 0x0

    .line 16
    packed-switch v0, :pswitch_data_238

    .line 19
    check-cast v5, Landroidx/compose/ui/platform/WindowRecomposer_androidKt$getAnimationScaleFlowFor$1$1$contentObserver$1;

    .line 21
    iget-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 23
    check-cast v0, Landroid/content/ContentResolver;

    .line 25
    iget v9, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 27
    if-eqz v9, :cond_42

    .line 29
    if-eq v9, v6, :cond_36

    .line 31
    if-ne v9, v7, :cond_31

    .line 33
    iget-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 35
    check-cast v2, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 37
    iget-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 39
    check-cast v3, Lkotlinx/coroutines/flow/FlowCollector;

    .line 41
    :try_start_28
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_2b
    .catchall {:try_start_28 .. :try_end_2b} :catchall_2e

    .line 44
    :cond_2b
    move-object p1, v3

    .line 45
    move-object v3, v2

    .line 46
    goto :goto_58

    .line 47
    :catchall_2e
    move-exception p0

    .line 48
    goto/16 :goto_9d

    .line 50
    :cond_31
    invoke-static {v3}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 53
    move-object v4, v8

    .line 54
    goto :goto_9c

    .line 55
    :cond_36
    iget-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 57
    check-cast v2, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 59
    iget-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 61
    check-cast v3, Lkotlinx/coroutines/flow/FlowCollector;

    .line 63
    :try_start_3e
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_41
    .catchall {:try_start_3e .. :try_end_41} :catchall_2e

    .line 66
    goto :goto_69

    .line 67
    :cond_42
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 70
    iget-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 72
    check-cast p1, Lkotlinx/coroutines/flow/FlowCollector;

    .line 74
    iget-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 76
    check-cast v3, Landroid/net/Uri;

    .line 78
    const/4 v8, 0x0

    .line 79
    invoke-virtual {v0, v3, v8, v5}, Landroid/content/ContentResolver;->registerContentObserver(Landroid/net/Uri;ZLandroid/database/ContentObserver;)V

    .line 82
    :try_start_51
    check-cast v2, Lkotlinx/coroutines/channels/BufferedChannel;

    .line 84
    new-instance v3, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 86
    invoke-direct {v3, v2}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;-><init>(Lkotlinx/coroutines/channels/BufferedChannel;)V

    .line 89
    :goto_58
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 91
    iput-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 93
    iput v6, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 95
    invoke-virtual {v3, p0}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;->hasNext(Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 98
    move-result-object v2

    .line 99
    if-ne v2, v4, :cond_65

    .line 101
    goto :goto_9c

    .line 102
    :cond_65
    move-object v12, v3

    .line 103
    move-object v3, p1

    .line 104
    move-object p1, v2

    .line 105
    move-object v2, v12

    .line 106
    :goto_69
    check-cast p1, Ljava/lang/Boolean;

    .line 108
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 111
    move-result p1

    .line 112
    if-eqz p1, :cond_97

    .line 114
    invoke-virtual {v2}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;->next()Ljava/lang/Object;

    .line 117
    move-object p1, v1

    .line 118
    check-cast p1, Landroid/content/Context;

    .line 120
    sget-object v8, Landroidx/compose/ui/platform/WindowRecomposer_androidKt;->animationScale:Landroidx/collection/MutableScatterMap;

    .line 122
    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    .line 125
    move-result-object p1

    .line 126
    const-string v8, "animator_duration_scale"

    .line 128
    const/high16 v9, 0x3f800000  # 1.0f

    .line 130
    invoke-static {p1, v8, v9}, Landroid/provider/Settings$Global;->getFloat(Landroid/content/ContentResolver;Ljava/lang/String;F)F

    .line 133
    move-result p1

    .line 134
    new-instance v8, Ljava/lang/Float;

    .line 136
    invoke-direct {v8, p1}, Ljava/lang/Float;-><init>(F)V

    .line 139
    iput-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 141
    iput-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 143
    iput v7, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 145
    invoke-interface {v3, v8, p0}, Lkotlinx/coroutines/flow/FlowCollector;->emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 148
    move-result-object p1
    :try_end_94
    .catchall {:try_start_51 .. :try_end_94} :catchall_2e

    .line 149
    if-ne p1, v4, :cond_2b

    .line 151
    goto :goto_9c

    .line 152
    :cond_97
    invoke-virtual {v0, v5}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 155
    sget-object v4, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 157
    :goto_9c
    return-object v4

    .line 158
    :goto_9d
    invoke-virtual {v0, v5}, Landroid/content/ContentResolver;->unregisterContentObserver(Landroid/database/ContentObserver;)V

    .line 161
    throw p0

    .line 162
    :pswitch_a1  #0x1
    move-object v0, v5

    .line 163
    check-cast v0, Landroidx/compose/material3/internal/InternalMutatorMutex;

    .line 165
    iget v5, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 167
    if-eqz v5, :cond_db

    .line 169
    if-eq v5, v6, :cond_c6

    .line 171
    if-ne v5, v7, :cond_c0

    .line 173
    iget-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 175
    check-cast v0, Landroidx/compose/material3/internal/InternalMutatorMutex;

    .line 177
    iget-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 179
    check-cast v1, Lkotlinx/coroutines/sync/MutexImpl;

    .line 181
    iget-object p0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 183
    check-cast p0, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;

    .line 185
    :try_start_b8
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_bb
    .catchall {:try_start_b8 .. :try_end_bb} :catchall_bd

    .line 188
    goto/16 :goto_14d

    .line 190
    :catchall_bd
    move-exception p1

    .line 191
    goto/16 :goto_167

    .line 193
    :cond_c0
    invoke-static {v3}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 196
    move-object v4, v8

    .line 197
    goto/16 :goto_160

    .line 199
    :cond_c6
    iget-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 201
    check-cast v0, Landroidx/compose/material3/internal/InternalMutatorMutex;

    .line 203
    iget-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 205
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 207
    iget-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 209
    check-cast v2, Lkotlinx/coroutines/sync/MutexImpl;

    .line 211
    iget-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 213
    check-cast v3, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;

    .line 215
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 218
    move-object p1, v2

    .line 219
    goto :goto_139

    .line 220
    :cond_db
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 223
    iget-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 225
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 227
    new-instance v9, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;

    .line 229
    check-cast v2, Landroidx/compose/foundation/MutatePriority;

    .line 231
    invoke-interface {p1}, Lkotlinx/coroutines/CoroutineScope;->getCoroutineContext()Lkotlin/coroutines/CoroutineContext;

    .line 234
    move-result-object p1

    .line 235
    sget-object v3, Lkotlinx/coroutines/Job$Key;->$$INSTANCE:Lkotlinx/coroutines/Job$Key;

    .line 237
    invoke-interface {p1, v3}, Lkotlin/coroutines/CoroutineContext;->get(Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;

    .line 240
    move-result-object p1

    .line 241
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 244
    check-cast p1, Lkotlinx/coroutines/Job;

    .line 246
    invoke-direct {v9, v2, p1}, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;-><init>(Landroidx/compose/foundation/MutatePriority;Lkotlinx/coroutines/Job;)V

    .line 249
    iget-object v10, v0, Landroidx/compose/material3/internal/InternalMutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 251
    :goto_fa
    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 254
    move-result-object p1

    .line 255
    move-object v11, p1

    .line 256
    check-cast v11, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;

    .line 258
    if-eqz v11, :cond_116

    .line 260
    iget-object p1, v9, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;->priority:Landroidx/compose/foundation/MutatePriority;

    .line 262
    iget-object v2, v11, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;->priority:Landroidx/compose/foundation/MutatePriority;

    .line 264
    invoke-virtual {p1, v2}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 267
    move-result p1

    .line 268
    if-ltz p1, :cond_10e

    .line 270
    goto :goto_116

    .line 271
    :cond_10e
    new-instance p0, Ljava/util/concurrent/CancellationException;

    .line 273
    const-string p1, "Current mutation had a higher priority"

    .line 275
    invoke-direct {p0, p1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 278
    throw p0

    .line 279
    :cond_116
    :goto_116
    invoke-virtual {v10, v11, v9}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 282
    move-result p1

    .line 283
    if-eqz p1, :cond_17b

    .line 285
    if-eqz v11, :cond_123

    .line 287
    iget-object p1, v11, Landroidx/compose/material3/internal/InternalMutatorMutex$Mutator;->job:Lkotlinx/coroutines/Job;

    .line 289
    invoke-interface {p1, v8}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 292
    :cond_123
    iget-object p1, v0, Landroidx/compose/material3/internal/InternalMutatorMutex;->mutex:Lkotlinx/coroutines/sync/MutexImpl;

    .line 294
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 296
    iput-object v9, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 298
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 300
    iput-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 302
    iput-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 304
    iput v6, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 306
    invoke-virtual {p1, p0}, Lkotlinx/coroutines/sync/MutexImpl;->lock(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 309
    move-result-object v2

    .line 310
    if-ne v2, v4, :cond_138

    .line 312
    goto :goto_160

    .line 313
    :cond_138
    move-object v3, v9

    .line 314
    :goto_139
    :try_start_139
    iput-object v3, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 316
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 318
    iput-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 320
    iput-object v8, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 322
    iput v7, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 324
    invoke-interface {v1, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 327
    move-result-object p0
    :try_end_147
    .catchall {:try_start_139 .. :try_end_147} :catchall_163

    .line 328
    if-ne p0, v4, :cond_14a

    .line 330
    goto :goto_160

    .line 331
    :cond_14a
    move-object v1, p1

    .line 332
    move-object p1, p0

    .line 333
    move-object p0, v3

    .line 334
    :goto_14d
    :try_start_14d
    iget-object v0, v0, Landroidx/compose/material3/internal/InternalMutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 336
    :cond_14f
    invoke-virtual {v0, p0, v8}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 339
    move-result v2

    .line 340
    if-eqz v2, :cond_156

    .line 342
    goto :goto_15c

    .line 343
    :cond_156
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 346
    move-result-object v2
    :try_end_15a
    .catchall {:try_start_14d .. :try_end_15a} :catchall_161

    .line 347
    if-eq v2, p0, :cond_14f

    .line 349
    :goto_15c
    invoke-virtual {v1, v8}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 352
    move-object v4, p1

    .line 353
    :goto_160
    return-object v4

    .line 354
    :catchall_161
    move-exception p0

    .line 355
    goto :goto_177

    .line 356
    :catchall_163
    move-exception p0

    .line 357
    move-object v1, p1

    .line 358
    move-object p1, p0

    .line 359
    move-object p0, v3

    .line 360
    :goto_167
    :try_start_167
    iget-object v0, v0, Landroidx/compose/material3/internal/InternalMutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 362
    :goto_169
    invoke-virtual {v0, p0, v8}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 365
    move-result v2

    .line 366
    if-nez v2, :cond_176

    .line 368
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 371
    move-result-object v2

    .line 372
    if-ne v2, p0, :cond_176

    .line 374
    goto :goto_169

    .line 375
    :cond_176
    throw p1
    :try_end_177
    .catchall {:try_start_167 .. :try_end_177} :catchall_161

    .line 376
    :goto_177
    invoke-virtual {v1, v8}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 379
    throw p0

    .line 380
    :cond_17b
    invoke-virtual {v10}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 383
    move-result-object p1

    .line 384
    if-eq p1, v11, :cond_116

    .line 386
    goto/16 :goto_fa

    .line 388
    :pswitch_183  #0x0
    check-cast v5, Landroidx/compose/foundation/MutatorMutex;

    .line 390
    iget v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 392
    if-eqz v0, :cond_1bf

    .line 394
    if-eq v0, v6, :cond_1a7

    .line 396
    if-ne v0, v7, :cond_1a1

    .line 398
    iget-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 400
    check-cast v0, Landroidx/compose/foundation/MutatorMutex;

    .line 402
    iget-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 404
    check-cast v1, Lkotlinx/coroutines/sync/MutexImpl;

    .line 406
    iget-object p0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 408
    check-cast p0, Landroidx/compose/foundation/MutatorMutex$Mutator;

    .line 410
    :try_start_199
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_19c
    .catchall {:try_start_199 .. :try_end_19c} :catchall_19e

    .line 413
    goto/16 :goto_209

    .line 415
    :catchall_19e
    move-exception p1

    .line 416
    goto/16 :goto_224

    .line 418
    :cond_1a1
    invoke-static {v3}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 421
    move-object v4, v8

    .line 422
    goto/16 :goto_21c

    .line 424
    :cond_1a7
    iget-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 426
    move-object v5, v0

    .line 427
    check-cast v5, Landroidx/compose/foundation/MutatorMutex;

    .line 429
    iget-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 431
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 433
    iget-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 435
    check-cast v1, Lkotlinx/coroutines/sync/MutexImpl;

    .line 437
    iget-object v2, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 439
    check-cast v2, Landroidx/compose/foundation/MutatorMutex$Mutator;

    .line 441
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 444
    move-object p1, v1

    .line 445
    move-object v1, v0

    .line 446
    move-object v0, v2

    .line 447
    goto :goto_1f4

    .line 448
    :cond_1bf
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 451
    iget-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 453
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 455
    new-instance v0, Landroidx/compose/foundation/MutatorMutex$Mutator;

    .line 457
    check-cast v2, Landroidx/compose/foundation/MutatePriority;

    .line 459
    invoke-interface {p1}, Lkotlinx/coroutines/CoroutineScope;->getCoroutineContext()Lkotlin/coroutines/CoroutineContext;

    .line 462
    move-result-object p1

    .line 463
    sget-object v3, Lkotlinx/coroutines/Job$Key;->$$INSTANCE:Lkotlinx/coroutines/Job$Key;

    .line 465
    invoke-interface {p1, v3}, Lkotlin/coroutines/CoroutineContext;->get(Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;

    .line 468
    move-result-object p1

    .line 469
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 472
    check-cast p1, Lkotlinx/coroutines/Job;

    .line 474
    invoke-direct {v0, v2, p1}, Landroidx/compose/foundation/MutatorMutex$Mutator;-><init>(Landroidx/compose/foundation/MutatePriority;Lkotlinx/coroutines/Job;)V

    .line 477
    invoke-static {v5, v0}, Landroidx/compose/foundation/MutatorMutex;->access$tryMutateOrCancel(Landroidx/compose/foundation/MutatorMutex;Landroidx/compose/foundation/MutatorMutex$Mutator;)V

    .line 480
    iget-object p1, v5, Landroidx/compose/foundation/MutatorMutex;->mutex:Lkotlinx/coroutines/sync/MutexImpl;

    .line 482
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 484
    iput-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 486
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 488
    iput-object v1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 490
    iput-object v5, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 492
    iput v6, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 494
    invoke-virtual {p1, p0}, Lkotlinx/coroutines/sync/MutexImpl;->lock(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 497
    move-result-object v2

    .line 498
    if-ne v2, v4, :cond_1f4

    .line 500
    goto :goto_21c

    .line 501
    :cond_1f4
    :goto_1f4
    :try_start_1f4
    iput-object v0, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 503
    iput-object p1, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 505
    iput-object v5, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 507
    iput-object v8, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 509
    iput v7, p0, Landroidx/compose/foundation/MutatorMutex$mutate$2;->label:I

    .line 511
    invoke-interface {v1, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 514
    move-result-object p0
    :try_end_202
    .catchall {:try_start_1f4 .. :try_end_202} :catchall_21f

    .line 515
    if-ne p0, v4, :cond_205

    .line 517
    goto :goto_21c

    .line 518
    :cond_205
    move-object v1, p1

    .line 519
    move-object p1, p0

    .line 520
    move-object p0, v0

    .line 521
    move-object v0, v5

    .line 522
    :goto_209
    :try_start_209
    iget-object v0, v0, Landroidx/compose/foundation/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 524
    :cond_20b
    invoke-virtual {v0, p0, v8}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 527
    move-result v2

    .line 528
    if-eqz v2, :cond_212

    .line 530
    goto :goto_218

    .line 531
    :cond_212
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 534
    move-result-object v2
    :try_end_216
    .catchall {:try_start_209 .. :try_end_216} :catchall_21d

    .line 535
    if-eq v2, p0, :cond_20b

    .line 537
    :goto_218
    invoke-virtual {v1, v8}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 540
    move-object v4, p1

    .line 541
    :goto_21c
    return-object v4

    .line 542
    :catchall_21d
    move-exception p0

    .line 543
    goto :goto_234

    .line 544
    :catchall_21f
    move-exception p0

    .line 545
    move-object v1, p1

    .line 546
    move-object p1, p0

    .line 547
    move-object p0, v0

    .line 548
    move-object v0, v5

    .line 549
    :goto_224
    :try_start_224
    iget-object v0, v0, Landroidx/compose/foundation/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 551
    :goto_226
    invoke-virtual {v0, p0, v8}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 554
    move-result v2

    .line 555
    if-nez v2, :cond_233

    .line 557
    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 560
    move-result-object v2

    .line 561
    if-ne v2, p0, :cond_233

    .line 563
    goto :goto_226

    .line 564
    :cond_233
    throw p1
    :try_end_234
    .catchall {:try_start_224 .. :try_end_234} :catchall_21d

    .line 565
    :goto_234
    invoke-virtual {v1, v8}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 568
    throw p0

    .line 569
    :pswitch_data_238
    .packed-switch 0x0
        :pswitch_183  #00000000
        :pswitch_a1  #00000001
    .end packed-switch
.end method
