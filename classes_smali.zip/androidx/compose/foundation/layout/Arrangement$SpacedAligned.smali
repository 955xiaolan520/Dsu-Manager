.class public final Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Landroidx/compose/foundation/layout/Arrangement$HorizontalOrVertical;


# instance fields
.field public final alignment:Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

.field public final space:F

.field public final spacing:F


# direct methods
.method public constructor <init>(FLandroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;)V
    .registers 3

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput p1, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->space:F

    .line 6
    iput-object p2, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->alignment:Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 8
    iput p1, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->spacing:F

    .line 10
    return-void
.end method


# virtual methods
.method public final arrange(ILandroidx/compose/ui/layout/MeasureScope;[I[I)V
    .registers 11

    .line 123
    sget-object v4, Landroidx/compose/ui/unit/LayoutDirection;->Ltr:Landroidx/compose/ui/unit/LayoutDirection;

    move-object v0, p0

    move v2, p1

    move-object v1, p2

    move-object v3, p3

    move-object v5, p4

    invoke-virtual/range {v0 .. v5}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->arrange(Landroidx/compose/ui/layout/MeasureScope;I[ILandroidx/compose/ui/unit/LayoutDirection;[I)V

    return-void
.end method

.method public final arrange(Landroidx/compose/ui/layout/MeasureScope;I[ILandroidx/compose/ui/unit/LayoutDirection;[I)V
    .registers 15

    .line 1
    array-length v0, p3

    .line 2
    if-nez v0, :cond_5

    .line 4
    goto/16 :goto_79

    .line 6
    :cond_5
    iget v0, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->space:F

    .line 8
    invoke-interface {p1, v0}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 11
    move-result p1

    .line 12
    sget-object v0, Landroidx/compose/ui/unit/LayoutDirection;->Rtl:Landroidx/compose/ui/unit/LayoutDirection;

    .line 14
    const/4 v1, 0x0

    .line 15
    if-ne p4, v0, :cond_34

    .line 17
    array-length v0, p3

    .line 18
    add-int/lit8 v0, v0, -0x1

    .line 20
    move v2, v1

    .line 21
    move v3, v2

    .line 22
    :goto_15
    const/4 v4, -0x1

    .line 23
    if-ge v4, v0, :cond_5a

    .line 25
    aget v3, p3, v0

    .line 27
    sub-int v4, p2, v3

    .line 29
    invoke-static {v2, v4}, Ljava/lang/Math;->min(II)I

    .line 32
    move-result v2

    .line 33
    aput v2, p5, v0

    .line 35
    sub-int v2, p2, v2

    .line 37
    sub-int/2addr v2, v3

    .line 38
    invoke-static {p1, v2}, Ljava/lang/Math;->min(II)I

    .line 41
    move-result v2

    .line 42
    aget v4, p5, v0

    .line 44
    add-int/2addr v4, v3

    .line 45
    add-int v3, v4, v2

    .line 47
    add-int/lit8 v0, v0, -0x1

    .line 49
    move v8, v3

    .line 50
    move v3, v2

    .line 51
    move v2, v8

    .line 52
    goto :goto_15

    .line 53
    :cond_34
    array-length v0, p3

    .line 54
    move v2, v1

    .line 55
    move v3, v2

    .line 56
    move v4, v3

    .line 57
    move v5, v4

    .line 58
    :goto_39
    if-ge v4, v0, :cond_5a

    .line 60
    aget v3, p3, v4

    .line 62
    add-int/lit8 v6, v5, 0x1

    .line 64
    sub-int v7, p2, v3

    .line 66
    invoke-static {v2, v7}, Ljava/lang/Math;->min(II)I

    .line 69
    move-result v2

    .line 70
    aput v2, p5, v5

    .line 72
    sub-int v2, p2, v2

    .line 74
    sub-int/2addr v2, v3

    .line 75
    invoke-static {p1, v2}, Ljava/lang/Math;->min(II)I

    .line 78
    move-result v2

    .line 79
    aget v5, p5, v5

    .line 81
    add-int/2addr v5, v3

    .line 82
    add-int v3, v5, v2

    .line 84
    add-int/lit8 v4, v4, 0x1

    .line 86
    move v5, v3

    .line 87
    move v3, v2

    .line 88
    move v2, v5

    .line 89
    move v5, v6

    .line 90
    goto :goto_39

    .line 91
    :cond_5a
    sub-int/2addr v2, v3

    .line 92
    if-ge v2, p2, :cond_79

    .line 94
    sub-int/2addr p2, v2

    .line 95
    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 98
    move-result-object p1

    .line 99
    iget-object p0, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->alignment:Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 101
    invoke-virtual {p0, p1, p4}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    move-result-object p0

    .line 105
    check-cast p0, Ljava/lang/Number;

    .line 107
    invoke-virtual {p0}, Ljava/lang/Number;->intValue()I

    .line 110
    move-result p0

    .line 111
    array-length p1, p5

    .line 112
    :goto_6f
    if-ge v1, p1, :cond_79

    .line 114
    aget p2, p5, v1

    .line 116
    add-int/2addr p2, p0

    .line 117
    aput p2, p5, v1

    .line 119
    add-int/lit8 v1, v1, 0x1

    .line 121
    goto :goto_6f

    .line 122
    :cond_79
    :goto_79
    return-void
.end method

.method public final equals(Ljava/lang/Object;)Z
    .registers 6

    .line 1
    const/4 v0, 0x1

    .line 2
    if-ne p0, p1, :cond_4

    .line 4
    return v0

    .line 5
    :cond_4
    instance-of v1, p1, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 7
    const/4 v2, 0x0

    .line 8
    if-nez v1, :cond_a

    .line 10
    goto :goto_16

    .line 11
    :cond_a
    check-cast p1, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 13
    iget v1, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->space:F

    .line 15
    iget v3, p1, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->space:F

    .line 17
    invoke-static {v1, v3}, Landroidx/compose/ui/unit/Dp;->equals-impl0(FF)Z

    .line 20
    move-result v1

    .line 21
    if-nez v1, :cond_17

    .line 23
    :goto_16
    return v2

    .line 24
    :cond_17
    iget-object p0, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->alignment:Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 26
    iget-object p1, p1, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->alignment:Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 28
    if-eq p0, p1, :cond_1e

    .line 30
    return v2

    .line 31
    :cond_1e
    return v0
.end method

.method public final getSpacing-D9Ej5fM()F
    .registers 1

    .line 1
    iget p0, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->spacing:F

    .line 3
    return p0
.end method

.method public final hashCode()I
    .registers 4

    .line 1
    iget v0, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->space:F

    .line 3
    invoke-static {v0}, Ljava/lang/Float;->hashCode(F)I

    .line 6
    move-result v0

    .line 7
    const/16 v1, 0x1f

    .line 9
    mul-int/2addr v0, v1

    .line 10
    const/4 v2, 0x1

    .line 11
    invoke-static {v0, v1, v2}, Landroidx/collection/ObjectListKt$$ExternalSyntheticOutline0;->m(IIZ)I

    .line 14
    move-result v0

    .line 15
    iget-object p0, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->alignment:Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 17
    invoke-virtual {p0}, Ljava/lang/Object;->hashCode()I

    .line 20
    move-result p0

    .line 21
    add-int/2addr p0, v0

    .line 22
    return p0
.end method

.method public final toString()Ljava/lang/String;
    .registers 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 3
    const-string v1, "Arrangement#spacedAligned("

    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 8
    iget v1, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->space:F

    .line 10
    invoke-static {v1}, Landroidx/compose/ui/unit/Dp;->toString-impl(F)Ljava/lang/String;

    .line 13
    move-result-object v1

    .line 14
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 17
    const-string v1, ", "

    .line 19
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 22
    iget-object p0, p0, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;->alignment:Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 24
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 27
    const/16 p0, 0x29

    .line 29
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 32
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 35
    move-result-object p0

    .line 36
    return-object p0
.end method
