.class public interface abstract Landroidx/compose/foundation/layout/Arrangement$Horizontal;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# virtual methods
.method public abstract arrange(Landroidx/compose/ui/layout/MeasureScope;I[ILandroidx/compose/ui/unit/LayoutDirection;[I)V
.end method

.method public getSpacing-D9Ej5fM()F
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
