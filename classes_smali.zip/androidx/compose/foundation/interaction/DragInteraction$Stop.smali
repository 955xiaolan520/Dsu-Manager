.class public final Landroidx/compose/foundation/interaction/DragInteraction$Stop;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Landroidx/compose/foundation/interaction/Interaction;


# instance fields
.field public final start:Landroidx/compose/foundation/interaction/DragInteraction$Start;


# direct methods
.method public constructor <init>(Landroidx/compose/foundation/interaction/DragInteraction$Start;)V
    .registers 2

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/compose/foundation/interaction/DragInteraction$Stop;->start:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 6
    return-void
.end method
