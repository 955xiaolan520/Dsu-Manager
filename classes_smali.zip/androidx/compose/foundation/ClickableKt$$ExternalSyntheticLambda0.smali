.class public final synthetic Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function3;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic f$0:Z

.field public final synthetic f$3:Lkotlin/jvm/functions/Function0;


# direct methods
.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function0;ZI)V
    .registers 4

    .line 12
    iput p3, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->$r8$classId:I

    iput-object p1, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/functions/Function0;

    iput-boolean p2, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$0:Z

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(ZLkotlin/jvm/functions/Function0;)V
    .registers 4

    .line 1
    const/4 v0, 0x0

    .line 2
    iput v0, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    iput-boolean p1, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$0:Z

    .line 9
    iput-object p2, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/functions/Function0;

    .line 11
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 1
    iget v0, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 3
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 5
    iget-object v2, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/functions/Function0;

    .line 7
    const/4 v3, 0x0

    .line 8
    packed-switch v0, :pswitch_data_d4

    .line 11
    move-object v6, v2

    .line 12
    check-cast v6, Landroidx/compose/runtime/GapComposer$$ExternalSyntheticLambda0;

    .line 14
    check-cast p1, Landroidx/compose/foundation/layout/RowScopeInstance;

    .line 16
    move-object v8, p2

    .line 17
    check-cast v8, Landroidx/compose/runtime/GapComposer;

    .line 19
    check-cast p3, Ljava/lang/Integer;

    .line 21
    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    .line 24
    move-result p2

    .line 25
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 28
    and-int/lit8 p1, p2, 0x11

    .line 30
    const/16 p3, 0x10

    .line 32
    const/4 v0, 0x1

    .line 33
    if-eq p1, p3, :cond_23

    .line 35
    move v3, v0

    .line 36
    :cond_23
    and-int/lit8 p1, p2, 0x1

    .line 38
    invoke-virtual {v8, p1, v3}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 41
    move-result p1

    .line 42
    if-eqz p1, :cond_3b

    .line 44
    const p1, 0x7f100020

    .line 47
    invoke-static {p1, v8}, Landroidx/compose/ui/geometry/RectKt;->stringResource(ILandroidx/compose/runtime/GapComposer;)Ljava/lang/String;

    .line 50
    move-result-object v5

    .line 51
    const/4 v9, 0x0

    .line 52
    const/4 v10, 0x1

    .line 53
    const/4 v4, 0x0

    .line 54
    iget-boolean v7, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$0:Z

    .line 56
    invoke-static/range {v4 .. v10}, Lyangfentuozi/dsusideloaderplus/ui/components/buttons/ErrorButtonKt;->PrimaryButton(Landroidx/compose/ui/Modifier;Ljava/lang/String;Lkotlin/jvm/functions/Function0;ZLandroidx/compose/runtime/GapComposer;II)V

    .line 59
    goto :goto_3e

    .line 60
    :cond_3b
    invoke-virtual {v8}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 63
    :goto_3e
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 65
    return-object p0

    .line 66
    :pswitch_41  #0x1
    check-cast p1, Landroidx/compose/ui/Modifier;

    .line 68
    check-cast p2, Landroidx/compose/runtime/GapComposer;

    .line 70
    check-cast p3, Ljava/lang/Integer;

    .line 72
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 75
    const p3, -0xbba9706

    .line 78
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 81
    sget-object p3, Landroidx/compose/foundation/text/selection/TextSelectionColorsKt;->LocalTextSelectionColors:Landroidx/compose/runtime/DynamicProvidableCompositionLocal;

    .line 83
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 86
    move-result-object p3

    .line 87
    check-cast p3, Landroidx/compose/foundation/text/selection/TextSelectionColors;

    .line 89
    iget-wide v4, p3, Landroidx/compose/foundation/text/selection/TextSelectionColors;->handleColor:J

    .line 91
    invoke-virtual {p2, v4, v5}, Landroidx/compose/runtime/GapComposer;->changed(J)Z

    .line 94
    move-result p3

    .line 95
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 98
    move-result v0

    .line 99
    or-int/2addr p3, v0

    .line 100
    iget-boolean p0, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$0:Z

    .line 102
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/GapComposer;->changed(Z)Z

    .line 105
    move-result v0

    .line 106
    or-int/2addr p3, v0

    .line 107
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 110
    move-result-object v0

    .line 111
    if-nez p3, :cond_72

    .line 113
    if-ne v0, v1, :cond_7a

    .line 115
    :cond_72
    new-instance v0, Landroidx/compose/foundation/text/selection/AndroidSelectionHandles_androidKt$$ExternalSyntheticLambda9;

    .line 117
    invoke-direct {v0, v4, v5, v2, p0}, Landroidx/compose/foundation/text/selection/AndroidSelectionHandles_androidKt$$ExternalSyntheticLambda9;-><init>(JLkotlin/jvm/functions/Function0;Z)V

    .line 120
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 123
    :cond_7a
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 125
    invoke-static {p1, v0}, Landroidx/compose/ui/draw/ClipKt;->drawWithCache(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 128
    move-result-object p0

    .line 129
    invoke-virtual {p2, v3}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 132
    return-object p0

    .line 133
    :pswitch_84  #0x0
    check-cast p1, Landroidx/compose/ui/Modifier;

    .line 135
    check-cast p2, Landroidx/compose/runtime/GapComposer;

    .line 137
    check-cast p3, Ljava/lang/Integer;

    .line 139
    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 142
    const p1, -0x2d10e1f7

    .line 145
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 148
    sget-object p1, Landroidx/compose/foundation/IndicationKt;->LocalIndication:Landroidx/compose/runtime/DynamicProvidableCompositionLocal;

    .line 150
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 153
    move-result-object p1

    .line 154
    move-object v6, p1

    .line 155
    check-cast v6, Landroidx/compose/foundation/IndicationNodeFactory;

    .line 157
    if-eqz v6, :cond_aa

    .line 159
    const p1, -0x5fa58202

    .line 162
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 165
    invoke-virtual {p2, v3}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 168
    const/4 p1, 0x0

    .line 169
    :goto_a8
    move-object v5, p1

    .line 170
    goto :goto_c4

    .line 171
    :cond_aa
    const p1, -0x5fa37bf8

    .line 174
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 177
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 180
    move-result-object p1

    .line 181
    if-ne p1, v1, :cond_be

    .line 183
    new-instance p1, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 185
    invoke-direct {p1}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;-><init>()V

    .line 188
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 191
    :cond_be
    check-cast p1, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 193
    invoke-virtual {p2, v3}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 196
    goto :goto_a8

    .line 197
    :goto_c4
    sget-object v4, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 199
    iget-boolean v7, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$0:Z

    .line 201
    const/4 v8, 0x0

    .line 202
    iget-object v9, p0, Landroidx/compose/foundation/ClickableKt$$ExternalSyntheticLambda0;->f$3:Lkotlin/jvm/functions/Function0;

    .line 204
    invoke-static/range {v4 .. v9}, Landroidx/compose/foundation/ImageKt;->clickable-O2vRcR0(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;Landroidx/compose/foundation/IndicationNodeFactory;ZLandroidx/compose/ui/semantics/Role;Lkotlin/jvm/functions/Function0;)Landroidx/compose/ui/Modifier;

    .line 207
    move-result-object p0

    .line 208
    invoke-virtual {p2, v3}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 211
    return-object p0

    nop

    .line 213
    :pswitch_data_d4
    .packed-switch 0x0
        :pswitch_84  #00000000
        :pswitch_41  #00000001
    .end packed-switch
.end method
