.class public final synthetic Landroidx/compose/foundation/FocusableNode$applySemantics$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function0;


# instance fields
.field public final synthetic $r8$classId:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V
    .registers 9

    .line 1
    iput p8, p0, Landroidx/compose/foundation/FocusableNode$applySemantics$1;->$r8$classId:I

    .line 3
    invoke-direct/range {p0 .. p7}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    .line 6
    return-void
.end method


# virtual methods
.method public final invoke()Ljava/lang/Object;
    .registers 27

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget v1, v0, Landroidx/compose/foundation/FocusableNode$applySemantics$1;->$r8$classId:I

    .line 5
    sget-object v3, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    iget-object v0, v0, Lkotlin/jvm/internal/CallableReference;->receiver:Ljava/lang/Object;

    .line 9
    packed-switch v1, :pswitch_data_204

    .line 12
    move-object v1, v0

    .line 13
    check-cast v1, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 15
    iget-object v2, v1, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->_uiState:Lkotlinx/coroutines/flow/StateFlowImpl;

    .line 17
    :cond_10
    invoke-virtual {v2}, Lkotlinx/coroutines/flow/StateFlowImpl;->getValue()Ljava/lang/Object;

    .line 20
    move-result-object v0

    .line 21
    move-object v4, v0

    .line 22
    check-cast v4, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;

    .line 24
    iget-object v5, v1, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->logger:Landroidx/profileinstaller/DeviceProfileWriter;

    .line 26
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 29
    iget-object v5, v5, Landroidx/profileinstaller/DeviceProfileWriter;->mApkName:Ljava/lang/Object;

    .line 31
    move-object v10, v5

    .line 32
    check-cast v10, Ljava/lang/String;

    .line 34
    const/4 v13, 0x0

    .line 35
    const/16 v14, 0x1df

    .line 37
    const/4 v5, 0x0

    .line 38
    const/4 v6, 0x0

    .line 39
    const/4 v7, 0x0

    .line 40
    const/4 v8, 0x0

    .line 41
    const/4 v9, 0x0

    .line 42
    const/4 v11, 0x0

    .line 43
    const/4 v12, 0x0

    .line 44
    invoke-static/range {v4 .. v14}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;->copy$default(Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/UserDataCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/ImageSizeCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/AdditionalCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/SheetDisplayState;Ljava/lang/String;ZZZI)Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;

    .line 47
    move-result-object v4

    .line 48
    invoke-virtual {v2, v0, v4}, Lkotlinx/coroutines/flow/StateFlowImpl;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_10

    .line 54
    return-object v3

    .line 55
    :pswitch_36  #0x6
    check-cast v0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 57
    iget-object v1, v0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->_uiState:Lkotlinx/coroutines/flow/StateFlowImpl;

    .line 59
    :cond_3a
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/StateFlowImpl;->getValue()Ljava/lang/Object;

    .line 62
    move-result-object v0

    .line 63
    move-object v4, v0

    .line 64
    check-cast v4, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;

    .line 66
    iget-object v5, v4, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;->installationCard:Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;

    .line 68
    const/4 v9, 0x0

    .line 69
    const/16 v10, 0x1f

    .line 71
    const/4 v6, 0x0

    .line 72
    const/4 v7, 0x0

    .line 73
    const/4 v8, 0x0

    .line 74
    invoke-static/range {v5 .. v10}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;->copy$default(Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;Ljava/lang/String;FLjava/lang/String;I)Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;

    .line 77
    move-result-object v11

    .line 78
    const/4 v15, 0x0

    .line 79
    const/16 v16, 0x1e

    .line 81
    sget-object v12, Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;->INSTALL_SUCCESS:Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;

    .line 83
    const/4 v13, 0x0

    .line 84
    const/4 v14, 0x0

    .line 85
    invoke-static/range {v11 .. v16}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;->copy$default(Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;Ljava/lang/String;FLjava/lang/String;I)Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;

    .line 88
    move-result-object v5

    .line 89
    const/4 v13, 0x0

    .line 90
    const/16 v14, 0x1fe

    .line 92
    const/4 v8, 0x0

    .line 93
    const/4 v10, 0x0

    .line 94
    const/4 v11, 0x0

    .line 95
    const/4 v12, 0x0

    .line 96
    invoke-static/range {v4 .. v14}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;->copy$default(Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/UserDataCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/ImageSizeCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/AdditionalCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/SheetDisplayState;Ljava/lang/String;ZZZI)Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;

    .line 99
    move-result-object v2

    .line 100
    invoke-virtual {v1, v0, v2}, Lkotlinx/coroutines/flow/StateFlowImpl;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 103
    move-result v0

    .line 104
    if-eqz v0, :cond_3a

    .line 106
    return-object v3

    .line 107
    :pswitch_6a  #0x5
    check-cast v0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 109
    iget-object v1, v0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->_uiState:Lkotlinx/coroutines/flow/StateFlowImpl;

    .line 111
    :cond_6e
    invoke-virtual {v1}, Lkotlinx/coroutines/flow/StateFlowImpl;->getValue()Ljava/lang/Object;

    .line 114
    move-result-object v0

    .line 115
    move-object v4, v0

    .line 116
    check-cast v4, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;

    .line 118
    iget-object v5, v4, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;->installationCard:Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;

    .line 120
    const/4 v9, 0x0

    .line 121
    const/16 v10, 0x1f

    .line 123
    const/4 v6, 0x0

    .line 124
    const/4 v7, 0x0

    .line 125
    const/4 v8, 0x0

    .line 126
    invoke-static/range {v5 .. v10}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;->copy$default(Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;Ljava/lang/String;FLjava/lang/String;I)Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;

    .line 129
    move-result-object v11

    .line 130
    const/4 v15, 0x0

    .line 131
    const/16 v16, 0x1e

    .line 133
    sget-object v12, Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;->INSTALL_SUCCESS_REBOOT_DYN_OS:Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;

    .line 135
    const/4 v13, 0x0

    .line 136
    const/4 v14, 0x0

    .line 137
    invoke-static/range {v11 .. v16}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;->copy$default(Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;Ljava/lang/String;FLjava/lang/String;I)Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;

    .line 140
    move-result-object v5

    .line 141
    const/4 v13, 0x0

    .line 142
    const/16 v14, 0x1fe

    .line 144
    const/4 v8, 0x0

    .line 145
    const/4 v10, 0x0

    .line 146
    const/4 v11, 0x0

    .line 147
    const/4 v12, 0x0

    .line 148
    invoke-static/range {v4 .. v14}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;->copy$default(Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/InstallationCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/UserDataCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/ImageSizeCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/AdditionalCardState;Lyangfentuozi/dsusideloaderplus/ui/screen/home/SheetDisplayState;Ljava/lang/String;ZZZI)Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeUiState;

    .line 151
    move-result-object v2

    .line 152
    invoke-virtual {v1, v0, v2}, Lkotlinx/coroutines/flow/StateFlowImpl;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 155
    move-result v0

    .line 156
    if-eqz v0, :cond_6e

    .line 158
    return-object v3

    .line 159
    :pswitch_9e  #0x4
    check-cast v0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 161
    invoke-virtual {v0}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->onClickCancelInstallationButton()V

    .line 164
    return-object v3

    .line 165
    :pswitch_a4  #0x3
    check-cast v0, Landroid/view/View;

    .line 167
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 169
    const/16 v3, 0x1e

    .line 171
    if-lt v1, v3, :cond_af

    .line 173
    invoke-static {v0}, Landroidx/core/os/BuildCompat$Api30Impl;->setImportantForContentCapture(Landroid/view/View;)V

    .line 176
    :cond_af
    invoke-virtual {v0}, Landroid/view/View;->getContentCaptureSession()Landroid/view/contentcapture/ContentCaptureSession;

    .line 179
    move-result-object v1

    .line 180
    if-nez v1, :cond_b7

    .line 182
    const/4 v2, 0x0

    .line 183
    goto :goto_be

    .line 184
    :cond_b7
    new-instance v2, Landroidx/compose/ui/platform/WeakCache;

    .line 186
    const/16 v3, 0x14

    .line 188
    invoke-direct {v2, v3, v1, v0}, Landroidx/compose/ui/platform/WeakCache;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 191
    :goto_be
    return-object v2

    .line 192
    :pswitch_bf  #0x2
    check-cast v0, Landroidx/compose/ui/focus/FocusInvalidationManager;

    .line 194
    iget-object v1, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->focusTargetNodes:Landroidx/collection/MutableScatterSet;

    .line 196
    iget-object v4, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->focusEventNodes:Landroidx/collection/MutableScatterSet;

    .line 198
    iget-object v5, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->focusOwner:Landroidx/compose/ui/focus/FocusOwnerImpl;

    .line 200
    invoke-virtual {v5}, Landroidx/compose/ui/focus/FocusOwnerImpl;->getActiveFocusTargetNode()Landroidx/compose/ui/focus/FocusTargetNode;

    .line 203
    move-result-object v6

    .line 204
    sget-object v7, Landroidx/compose/ui/focus/FocusStateImpl;->Inactive:Landroidx/compose/ui/focus/FocusStateImpl;

    .line 206
    const/16 v15, 0x8

    .line 208
    if-nez v6, :cond_11f

    .line 210
    iget-object v6, v4, Landroidx/collection/MutableScatterSet;->elements:[Ljava/lang/Object;

    .line 212
    const-wide/16 v17, 0x80

    .line 214
    iget-object v8, v4, Landroidx/collection/MutableScatterSet;->metadata:[J

    .line 216
    array-length v9, v8

    .line 217
    add-int/lit8 v9, v9, -0x2

    .line 219
    if-ltz v9, :cond_11c

    .line 221
    const/16 p0, 0x7

    .line 223
    const/4 v10, 0x0

    .line 224
    const-wide/16 v19, 0xff

    .line 226
    const-wide v21, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 231
    :goto_e6
    aget-wide v12, v8, v10

    .line 233
    move-object v11, v3

    .line 234
    not-long v2, v12

    .line 235
    shl-long v2, v2, p0

    .line 237
    and-long/2addr v2, v12

    .line 238
    and-long v2, v2, v21

    .line 240
    cmp-long v2, v2, v21

    .line 242
    if-eqz v2, :cond_116

    .line 244
    sub-int v2, v10, v9

    .line 246
    not-int v2, v2

    .line 247
    ushr-int/lit8 v2, v2, 0x1f

    .line 249
    rsub-int/lit8 v2, v2, 0x8

    .line 251
    const/4 v3, 0x0

    .line 252
    :goto_fb
    if-ge v3, v2, :cond_114

    .line 254
    and-long v23, v12, v19

    .line 256
    cmp-long v16, v23, v17

    .line 258
    if-gez v16, :cond_110

    .line 260
    shl-int/lit8 v16, v10, 0x3

    .line 262
    add-int v16, v16, v3

    .line 264
    aget-object v16, v6, v16

    .line 266
    move-object/from16 v14, v16

    .line 268
    check-cast v14, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 270
    invoke-interface {v14, v7}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusStateImpl;)V

    .line 273
    :cond_110
    shr-long/2addr v12, v15

    .line 274
    add-int/lit8 v3, v3, 0x1

    .line 276
    goto :goto_fb

    .line 277
    :cond_114
    if-ne v2, v15, :cond_1d5

    .line 279
    :cond_116
    if-eq v10, v9, :cond_1d5

    .line 281
    add-int/lit8 v10, v10, 0x1

    .line 283
    move-object v3, v11

    .line 284
    goto :goto_e6

    .line 285
    :cond_11c
    move-object v11, v3

    .line 286
    goto/16 :goto_1d5

    .line 288
    :cond_11f
    move-object v11, v3

    .line 289
    const/16 p0, 0x7

    .line 291
    const-wide/16 v17, 0x80

    .line 293
    const-wide/16 v19, 0xff

    .line 295
    const-wide v21, -0x7f7f7f7f7f7f7f80L  # -2.937446524422997E-306

    .line 300
    iget-boolean v2, v6, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 302
    if-eqz v2, :cond_1d5

    .line 304
    invoke-virtual {v1, v6}, Landroidx/collection/MutableScatterSet;->contains(Ljava/lang/Object;)Z

    .line 307
    move-result v2

    .line 308
    if-eqz v2, :cond_138

    .line 310
    invoke-virtual {v6}, Landroidx/compose/ui/focus/FocusTargetNode;->invalidateFocus$ui()V

    .line 313
    :cond_138
    invoke-virtual {v6}, Landroidx/compose/ui/focus/FocusTargetNode;->getFocusState$1()Landroidx/compose/ui/focus/FocusStateImpl;

    .line 316
    move-result-object v2

    .line 317
    iget-object v3, v6, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 319
    iget-boolean v3, v3, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 321
    if-nez v3, :cond_147

    .line 323
    const-string v3, "visitAncestors called on an unattached node"

    .line 325
    invoke-static {v3}, Landroidx/compose/ui/internal/InlineClassHelperKt;->throwIllegalStateException(Ljava/lang/String;)V

    .line 328
    :cond_147
    iget-object v3, v6, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 330
    invoke-static {v6}, Landroidx/compose/ui/node/HitTestResultKt;->requireLayoutNode(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/LayoutNode;

    .line 333
    move-result-object v6

    .line 334
    const/4 v8, 0x0

    .line 335
    :goto_14e
    if-eqz v6, :cond_19a

    .line 337
    iget-object v9, v6, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 339
    iget-object v9, v9, Landroidx/compose/ui/node/NodeChain;->head:Landroidx/compose/ui/Modifier$Node;

    .line 341
    iget v9, v9, Landroidx/compose/ui/Modifier$Node;->aggregateChildKindSet:I

    .line 343
    and-int/lit16 v9, v9, 0x1400

    .line 345
    if-eqz v9, :cond_18b

    .line 347
    :goto_15a
    if-eqz v3, :cond_18b

    .line 349
    iget v9, v3, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 351
    and-int/lit16 v10, v9, 0x1400

    .line 353
    if-eqz v10, :cond_188

    .line 355
    and-int/lit16 v9, v9, 0x400

    .line 357
    if-eqz v9, :cond_168

    .line 359
    add-int/lit8 v8, v8, 0x1

    .line 361
    :cond_168
    instance-of v9, v3, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 363
    if-eqz v9, :cond_188

    .line 365
    invoke-virtual {v4, v3}, Landroidx/collection/MutableScatterSet;->contains(Ljava/lang/Object;)Z

    .line 368
    move-result v9

    .line 369
    if-nez v9, :cond_173

    .line 371
    goto :goto_188

    .line 372
    :cond_173
    const/4 v9, 0x1

    .line 373
    if-gt v8, v9, :cond_17d

    .line 375
    move-object v9, v3

    .line 376
    check-cast v9, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 378
    invoke-interface {v9, v2}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusStateImpl;)V

    .line 381
    goto :goto_185

    .line 382
    :cond_17d
    move-object v9, v3

    .line 383
    check-cast v9, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 385
    sget-object v10, Landroidx/compose/ui/focus/FocusStateImpl;->ActiveParent:Landroidx/compose/ui/focus/FocusStateImpl;

    .line 387
    invoke-interface {v9, v10}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusStateImpl;)V

    .line 390
    :goto_185
    invoke-virtual {v4, v3}, Landroidx/collection/MutableScatterSet;->remove(Ljava/lang/Object;)Z

    .line 393
    :cond_188
    :goto_188
    iget-object v3, v3, Landroidx/compose/ui/Modifier$Node;->parent:Landroidx/compose/ui/Modifier$Node;

    .line 395
    goto :goto_15a

    .line 396
    :cond_18b
    invoke-virtual {v6}, Landroidx/compose/ui/node/LayoutNode;->getParent$ui()Landroidx/compose/ui/node/LayoutNode;

    .line 399
    move-result-object v6

    .line 400
    if-eqz v6, :cond_198

    .line 402
    iget-object v3, v6, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 404
    if-eqz v3, :cond_198

    .line 406
    iget-object v3, v3, Landroidx/compose/ui/node/NodeChain;->tail:Landroidx/compose/ui/node/TailModifierNode;

    .line 408
    goto :goto_14e

    .line 409
    :cond_198
    const/4 v3, 0x0

    .line 410
    goto :goto_14e

    .line 411
    :cond_19a
    iget-object v2, v4, Landroidx/collection/MutableScatterSet;->elements:[Ljava/lang/Object;

    .line 413
    iget-object v3, v4, Landroidx/collection/MutableScatterSet;->metadata:[J

    .line 415
    array-length v6, v3

    .line 416
    add-int/lit8 v6, v6, -0x2

    .line 418
    if-ltz v6, :cond_1d5

    .line 420
    const/4 v8, 0x0

    .line 421
    :goto_1a4
    aget-wide v9, v3, v8

    .line 423
    not-long v12, v9

    .line 424
    shl-long v12, v12, p0

    .line 426
    and-long/2addr v12, v9

    .line 427
    and-long v12, v12, v21

    .line 429
    cmp-long v12, v12, v21

    .line 431
    if-eqz v12, :cond_1d0

    .line 433
    sub-int v12, v8, v6

    .line 435
    not-int v12, v12

    .line 436
    ushr-int/lit8 v12, v12, 0x1f

    .line 438
    rsub-int/lit8 v12, v12, 0x8

    .line 440
    const/4 v13, 0x0

    .line 441
    :goto_1b8
    if-ge v13, v12, :cond_1ce

    .line 443
    and-long v24, v9, v19

    .line 445
    cmp-long v14, v24, v17

    .line 447
    if-gez v14, :cond_1ca

    .line 449
    shl-int/lit8 v14, v8, 0x3

    .line 451
    add-int/2addr v14, v13

    .line 452
    aget-object v14, v2, v14

    .line 454
    check-cast v14, Landroidx/compose/ui/focus/FocusEventModifierNode;

    .line 456
    invoke-interface {v14, v7}, Landroidx/compose/ui/focus/FocusEventModifierNode;->onFocusEvent(Landroidx/compose/ui/focus/FocusStateImpl;)V

    .line 459
    :cond_1ca
    shr-long/2addr v9, v15

    .line 460
    add-int/lit8 v13, v13, 0x1

    .line 462
    goto :goto_1b8

    .line 463
    :cond_1ce
    if-ne v12, v15, :cond_1d5

    .line 465
    :cond_1d0
    if-eq v8, v6, :cond_1d5

    .line 467
    add-int/lit8 v8, v8, 0x1

    .line 469
    goto :goto_1a4

    .line 470
    :cond_1d5
    :goto_1d5
    invoke-virtual {v5}, Landroidx/compose/ui/focus/FocusOwnerImpl;->getActiveFocusTargetNode()Landroidx/compose/ui/focus/FocusTargetNode;

    .line 473
    move-result-object v2

    .line 474
    if-eqz v2, :cond_1e3

    .line 476
    iget-object v2, v5, Landroidx/compose/ui/focus/FocusOwnerImpl;->rootFocusNode:Landroidx/compose/ui/focus/FocusTargetNode;

    .line 478
    invoke-virtual {v2}, Landroidx/compose/ui/focus/FocusTargetNode;->getFocusState$1()Landroidx/compose/ui/focus/FocusStateImpl;

    .line 481
    move-result-object v2

    .line 482
    if-ne v2, v7, :cond_1e6

    .line 484
    :cond_1e3
    invoke-virtual {v5}, Landroidx/compose/ui/focus/FocusOwnerImpl;->clearOwnerFocus()V

    .line 487
    :cond_1e6
    invoke-virtual {v1}, Landroidx/collection/MutableScatterSet;->clear()V

    .line 490
    invoke-virtual {v4}, Landroidx/collection/MutableScatterSet;->clear()V

    .line 493
    const/4 v14, 0x0

    .line 494
    iput-boolean v14, v0, Landroidx/compose/ui/focus/FocusInvalidationManager;->isInvalidationScheduled:Z

    .line 496
    return-object v11

    .line 497
    :pswitch_1f0  #0x1
    check-cast v0, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuDataProvider;

    .line 499
    invoke-interface {v0}, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuDataProvider;->data()Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;

    .line 502
    move-result-object v0

    .line 503
    return-object v0

    .line 504
    :pswitch_1f7  #0x0
    check-cast v0, Landroidx/compose/foundation/FocusableNode;

    .line 506
    iget-object v0, v0, Landroidx/compose/foundation/FocusableNode;->focusTargetNode:Landroidx/compose/ui/focus/FocusTargetNode;

    .line 508
    invoke-static {v0}, Landroidx/compose/ui/focus/FocusTargetNode;->requestFocus-3ESFkO8$default(Landroidx/compose/ui/focus/FocusTargetNode;)Z

    .line 511
    move-result v0

    .line 512
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 515
    move-result-object v0

    .line 516
    return-object v0

    .line 517
    :pswitch_data_204
    .packed-switch 0x0
        :pswitch_1f7  #00000000
        :pswitch_1f0  #00000001
        :pswitch_bf  #00000002
        :pswitch_a4  #00000003
        :pswitch_9e  #00000004
        :pswitch_6a  #00000005
        :pswitch_36  #00000006
    .end packed-switch
.end method
