.class public abstract Landroidx/compose/foundation/contextmenu/ContextMenuUiKt;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# static fields
.field public static final DefaultContextMenuColors:Landroidx/compose/foundation/contextmenu/ContextMenuColors;


# direct methods
.method static constructor <clinit>()V
    .registers 12

    .line 1
    sget-object v0, Landroidx/compose/ui/window/AndroidPopup_androidKt;->LocalPopupTestTag:Landroidx/compose/runtime/DynamicProvidableCompositionLocal;

    .line 3
    new-instance v1, Landroidx/compose/foundation/contextmenu/ContextMenuColors;

    .line 5
    sget-wide v2, Landroidx/compose/ui/graphics/Color;->White:J

    .line 7
    sget-wide v4, Landroidx/compose/ui/graphics/Color;->Black:J

    .line 9
    const v0, 0x3ec28f5c  # 0.38f

    .line 12
    invoke-static {v0, v4, v5}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 15
    move-result-wide v8

    .line 16
    invoke-static {v0, v4, v5}, Landroidx/compose/ui/graphics/Color;->copy-wmQWz5c$default(FJ)J

    .line 19
    move-result-wide v10

    .line 20
    move-wide v6, v4

    .line 21
    invoke-direct/range {v1 .. v11}, Landroidx/compose/foundation/contextmenu/ContextMenuColors;-><init>(JJJJJ)V

    .line 24
    sput-object v1, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt;->DefaultContextMenuColors:Landroidx/compose/foundation/contextmenu/ContextMenuColors;

    .line 26
    return-void
.end method

.method public static final ContextMenuColumn(Landroidx/compose/foundation/contextmenu/ContextMenuColors;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V
    .registers 22

    .line 1
    move-object/from16 v1, p0

    .line 3
    move-object/from16 v2, p1

    .line 5
    move-object/from16 v3, p2

    .line 7
    move-object/from16 v0, p3

    .line 9
    move/from16 v4, p4

    .line 11
    const v5, -0x1f76910f

    .line 14
    invoke-virtual {v0, v5}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 17
    and-int/lit8 v5, v4, 0x6

    .line 19
    if-nez v5, :cond_1f

    .line 21
    invoke-virtual {v0, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 24
    move-result v5

    .line 25
    if-eqz v5, :cond_1c

    .line 27
    const/4 v5, 0x4

    .line 28
    goto :goto_1d

    .line 29
    :cond_1c
    const/4 v5, 0x2

    .line 30
    :goto_1d
    or-int/2addr v5, v4

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v5, v4

    .line 33
    :goto_20
    and-int/lit8 v6, v4, 0x30

    .line 35
    if-nez v6, :cond_30

    .line 37
    invoke-virtual {v0, v2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 40
    move-result v6

    .line 41
    if-eqz v6, :cond_2d

    .line 43
    const/16 v6, 0x20

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v6, 0x10

    .line 48
    :goto_2f
    or-int/2addr v5, v6

    .line 49
    :cond_30
    and-int/lit16 v6, v4, 0x180

    .line 51
    if-nez v6, :cond_40

    .line 53
    invoke-virtual {v0, v3}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 56
    move-result v6

    .line 57
    if-eqz v6, :cond_3d

    .line 59
    const/16 v6, 0x100

    .line 61
    goto :goto_3f

    .line 62
    :cond_3d
    const/16 v6, 0x80

    .line 64
    :goto_3f
    or-int/2addr v5, v6

    .line 65
    :cond_40
    and-int/lit16 v6, v5, 0x93

    .line 67
    const/16 v7, 0x92

    .line 69
    const/4 v8, 0x0

    .line 70
    const/4 v9, 0x1

    .line 71
    if-eq v6, v7, :cond_4a

    .line 73
    move v6, v9

    .line 74
    goto :goto_4b

    .line 75
    :cond_4a
    move v6, v8

    .line 76
    :goto_4b
    and-int/lit8 v7, v5, 0x1

    .line 78
    invoke-virtual {v0, v7, v6}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 81
    move-result v6

    .line 82
    if-eqz v6, :cond_f7

    .line 84
    sget-object v6, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->LabelVerticalTextAlignment:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 86
    const/high16 v6, 0x40800000  # 4.0f

    .line 88
    invoke-static {v6}, Landroidx/compose/foundation/shape/RoundedCornerShapeKt;->RoundedCornerShape-0680j_4(F)Landroidx/compose/foundation/shape/RoundedCornerShape;

    .line 91
    move-result-object v11

    .line 92
    const/high16 v6, 0x40400000  # 3.0f

    .line 94
    const/4 v7, 0x0

    .line 95
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/Dp;->compareTo-0680j_4(FF)I

    .line 98
    move-result v10

    .line 99
    if-lez v10, :cond_66

    .line 101
    move v12, v9

    .line 102
    goto :goto_67

    .line 103
    :cond_66
    move v12, v8

    .line 104
    :goto_67
    sget-wide v13, Landroidx/compose/ui/graphics/GraphicsLayerScopeKt;->DefaultShadowColor:J

    .line 106
    invoke-static {v6, v7}, Landroidx/compose/ui/unit/Dp;->compareTo-0680j_4(FF)I

    .line 109
    move-result v6

    .line 110
    if-gtz v6, :cond_74

    .line 112
    if-eqz v12, :cond_72

    .line 114
    goto :goto_74

    .line 115
    :cond_72
    move-object v6, v2

    .line 116
    goto :goto_7e

    .line 117
    :cond_74
    :goto_74
    new-instance v10, Landroidx/compose/ui/draw/ShadowGraphicsLayerElement;

    .line 119
    move-wide v15, v13

    .line 120
    invoke-direct/range {v10 .. v16}, Landroidx/compose/ui/draw/ShadowGraphicsLayerElement;-><init>(Landroidx/compose/ui/graphics/Shape;ZJJ)V

    .line 123
    invoke-interface {v2, v10}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 126
    move-result-object v6

    .line 127
    :goto_7e
    iget-wide v10, v1, Landroidx/compose/foundation/contextmenu/ContextMenuColors;->backgroundColor:J

    .line 129
    sget-object v12, Landroidx/compose/ui/graphics/ColorKt;->RectangleShape:Landroidx/compose/ui/graphics/RectangleShapeKt$RectangleShape$1;

    .line 131
    invoke-static {v6, v10, v11, v12}, Landroidx/compose/foundation/ImageKt;->background-bw27NRU(Landroidx/compose/ui/Modifier;JLandroidx/compose/ui/graphics/Shape;)Landroidx/compose/ui/Modifier;

    .line 134
    move-result-object v6

    .line 135
    invoke-static {v6}, Landroidx/compose/foundation/layout/SpacerKt;->width(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 138
    move-result-object v6

    .line 139
    sget v10, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->VerticalPadding:F

    .line 141
    invoke-static {v6, v7, v10, v9}, Landroidx/compose/foundation/layout/SpacerKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 144
    move-result-object v6

    .line 145
    invoke-static {v0}, Landroidx/compose/foundation/ImageKt;->rememberScrollState(Landroidx/compose/runtime/GapComposer;)Landroidx/compose/foundation/ScrollState;

    .line 148
    move-result-object v7

    .line 149
    invoke-static {v6, v7}, Landroidx/compose/foundation/ImageKt;->verticalScroll$default(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/ScrollState;)Landroidx/compose/ui/Modifier;

    .line 152
    move-result-object v6

    .line 153
    shl-int/lit8 v5, v5, 0x3

    .line 155
    and-int/lit16 v5, v5, 0x1c00

    .line 157
    sget-object v7, Landroidx/compose/foundation/layout/SpacerKt;->Top:Landroidx/compose/foundation/layout/Arrangement$Top$1;

    .line 159
    sget-object v10, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 161
    invoke-static {v7, v10, v0, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/GapComposer;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 164
    move-result-object v7

    .line 165
    iget-wide v10, v0, Landroidx/compose/runtime/GapComposer;->compositeKeyHashCode:J

    .line 167
    invoke-static {v10, v11}, Ljava/lang/Long;->hashCode(J)I

    .line 170
    move-result v8

    .line 171
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 174
    move-result-object v10

    .line 175
    invoke-static {v0, v6}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/GapComposer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 178
    move-result-object v6

    .line 179
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 181
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 184
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 186
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->startReusableNode()V

    .line 189
    iget-boolean v12, v0, Landroidx/compose/runtime/GapComposer;->inserting:Z

    .line 191
    if-eqz v12, :cond_c4

    .line 193
    invoke-virtual {v0, v11}, Landroidx/compose/runtime/GapComposer;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 196
    goto :goto_c7

    .line 197
    :cond_c4
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->useNode()V

    .line 200
    :goto_c7
    sget-object v11, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 202
    invoke-static {v0, v7, v11}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 205
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 207
    invoke-static {v0, v10, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 210
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 213
    move-result-object v7

    .line 214
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 216
    invoke-static {v0, v7, v8}, Landroidx/compose/runtime/Updater;->init-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Integer;Lkotlin/jvm/functions/Function2;)V

    .line 219
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->ApplyOnDeactivatedNodeAssertion:Landroidx/compose/ui/node/OwnerSnapshotObserver$onCommitAffectingLayout$1;

    .line 221
    invoke-static {v0, v7}, Landroidx/compose/runtime/Updater;->reconcile-impl(Landroidx/compose/runtime/GapComposer;Lkotlin/jvm/functions/Function1;)V

    .line 224
    sget-object v7, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 226
    invoke-static {v0, v6, v7}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 229
    shr-int/lit8 v5, v5, 0x6

    .line 231
    and-int/lit8 v5, v5, 0x70

    .line 233
    or-int/lit8 v5, v5, 0x6

    .line 235
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 238
    move-result-object v5

    .line 239
    sget-object v6, Landroidx/compose/foundation/layout/ColumnScopeInstance;->INSTANCE:Landroidx/compose/foundation/layout/ColumnScopeInstance;

    .line 241
    invoke-virtual {v3, v6, v0, v5}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 244
    invoke-virtual {v0, v9}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 247
    goto :goto_fa

    .line 248
    :cond_f7
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 251
    :goto_fa
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 254
    move-result-object v6

    .line 255
    if-eqz v6, :cond_108

    .line 257
    new-instance v0, Landroidx/compose/material3/MaterialThemeKt$$ExternalSyntheticLambda0;

    .line 259
    const/4 v5, 0x2

    .line 260
    invoke-direct/range {v0 .. v5}, Landroidx/compose/material3/MaterialThemeKt$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;II)V

    .line 263
    iput-object v0, v6, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 265
    :cond_108
    return-void
.end method

.method public static final ContextMenuColumnBuilder(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/contextmenu/ContextMenuColors;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;II)V
    .registers 14

    .line 1
    const v0, -0x2548d191

    .line 4
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 7
    and-int/lit8 v0, p5, 0x1

    .line 9
    if-eqz v0, :cond_d

    .line 11
    or-int/lit8 v1, p4, 0x6

    .line 13
    goto :goto_17

    .line 14
    :cond_d
    invoke-virtual {p3, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 17
    move-result v1

    .line 18
    if-eqz v1, :cond_15

    .line 20
    const/4 v1, 0x4

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    const/4 v1, 0x2

    .line 23
    :goto_16
    or-int/2addr v1, p4

    .line 24
    :goto_17
    and-int/lit8 v2, p5, 0x2

    .line 26
    if-eqz v2, :cond_1e

    .line 28
    or-int/lit8 v1, v1, 0x30

    .line 30
    goto :goto_2a

    .line 31
    :cond_1e
    invoke-virtual {p3, p1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 34
    move-result v3

    .line 35
    if-eqz v3, :cond_27

    .line 37
    const/16 v3, 0x20

    .line 39
    goto :goto_29

    .line 40
    :cond_27
    const/16 v3, 0x10

    .line 42
    :goto_29
    or-int/2addr v1, v3

    .line 43
    :goto_2a
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 46
    move-result v3

    .line 47
    if-eqz v3, :cond_33

    .line 49
    const/16 v3, 0x100

    .line 51
    goto :goto_35

    .line 52
    :cond_33
    const/16 v3, 0x80

    .line 54
    :goto_35
    or-int/2addr v1, v3

    .line 55
    and-int/lit16 v3, v1, 0x93

    .line 57
    const/16 v4, 0x92

    .line 59
    const/4 v5, 0x1

    .line 60
    if-eq v3, v4, :cond_3f

    .line 62
    move v3, v5

    .line 63
    goto :goto_40

    .line 64
    :cond_3f
    const/4 v3, 0x0

    .line 65
    :goto_40
    and-int/lit8 v4, v1, 0x1

    .line 67
    invoke-virtual {p3, v4, v3}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 70
    move-result v3

    .line 71
    if-eqz v3, :cond_6d

    .line 73
    if-eqz v0, :cond_4c

    .line 75
    sget-object p0, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 77
    :cond_4c
    if-eqz v2, :cond_50

    .line 79
    sget-object p1, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt;->DefaultContextMenuColors:Landroidx/compose/foundation/contextmenu/ContextMenuColors;

    .line 81
    :cond_50
    new-instance v0, Lyangfentuozi/dsusideloaderplus/ui/components/TopBarKt$$ExternalSyntheticLambda3;

    .line 83
    invoke-direct {v0, v5, p2, p1}, Lyangfentuozi/dsusideloaderplus/ui/components/TopBarKt$$ExternalSyntheticLambda3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 86
    const v2, -0xeebf658

    .line 89
    invoke-static {v2, v0, p3}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 92
    move-result-object v0

    .line 93
    shr-int/lit8 v2, v1, 0x3

    .line 95
    and-int/lit8 v2, v2, 0xe

    .line 97
    or-int/lit16 v2, v2, 0x180

    .line 99
    shl-int/lit8 v1, v1, 0x3

    .line 101
    and-int/lit8 v1, v1, 0x70

    .line 103
    or-int/2addr v1, v2

    .line 104
    invoke-static {p1, p0, v0, p3, v1}, Landroidx/compose/foundation/contextmenu/ContextMenuUiKt;->ContextMenuColumn(Landroidx/compose/foundation/contextmenu/ContextMenuColors;Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V

    .line 107
    :goto_6a
    move-object v3, p0

    .line 108
    move-object v4, p1

    .line 109
    goto :goto_71

    .line 110
    :cond_6d
    invoke-virtual {p3}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 113
    goto :goto_6a

    .line 114
    :goto_71
    invoke-virtual {p3}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 117
    move-result-object p0

    .line 118
    if-eqz p0, :cond_81

    .line 120
    new-instance v2, Landroidx/compose/material3/MaterialThemeKt$$ExternalSyntheticLambda0;

    .line 122
    move-object v5, p2

    .line 123
    move v6, p4

    .line 124
    move v7, p5

    .line 125
    invoke-direct/range {v2 .. v7}, Landroidx/compose/material3/MaterialThemeKt$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/ui/Modifier;Landroidx/compose/foundation/contextmenu/ContextMenuColors;Lkotlin/jvm/functions/Function1;II)V

    .line 128
    iput-object v2, p0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 130
    :cond_81
    return-void
.end method

.method public static final ContextMenuItem(Ljava/lang/String;ZLandroidx/compose/foundation/contextmenu/ContextMenuColors;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/GapComposer;I)V
    .registers 38

    .line 1
    move-object/from16 v0, p0

    .line 3
    move/from16 v10, p1

    .line 5
    move-object/from16 v11, p2

    .line 7
    move-object/from16 v12, p3

    .line 9
    move-object/from16 v13, p4

    .line 11
    move-object/from16 v14, p5

    .line 13
    move-object/from16 v7, p6

    .line 15
    move/from16 v15, p7

    .line 17
    const v1, -0x774762b3

    .line 20
    invoke-virtual {v7, v1}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 23
    and-int/lit8 v1, v15, 0x6

    .line 25
    const/4 v2, 0x2

    .line 26
    if-nez v1, :cond_26

    .line 28
    invoke-virtual {v7, v0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_23

    .line 34
    const/4 v1, 0x4

    .line 35
    goto :goto_24

    .line 36
    :cond_23
    move v1, v2

    .line 37
    :goto_24
    or-int/2addr v1, v15

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    move v1, v15

    .line 40
    :goto_27
    and-int/lit8 v3, v15, 0x30

    .line 42
    const/16 v4, 0x20

    .line 44
    if-nez v3, :cond_38

    .line 46
    invoke-virtual {v7, v10}, Landroidx/compose/runtime/GapComposer;->changed(Z)Z

    .line 49
    move-result v3

    .line 50
    if-eqz v3, :cond_35

    .line 52
    move v3, v4

    .line 53
    goto :goto_37

    .line 54
    :cond_35
    const/16 v3, 0x10

    .line 56
    :goto_37
    or-int/2addr v1, v3

    .line 57
    :cond_38
    and-int/lit16 v3, v15, 0x180

    .line 59
    if-nez v3, :cond_48

    .line 61
    invoke-virtual {v7, v11}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 64
    move-result v3

    .line 65
    if-eqz v3, :cond_45

    .line 67
    const/16 v3, 0x100

    .line 69
    goto :goto_47

    .line 70
    :cond_45
    const/16 v3, 0x80

    .line 72
    :goto_47
    or-int/2addr v1, v3

    .line 73
    :cond_48
    and-int/lit16 v3, v15, 0xc00

    .line 75
    if-nez v3, :cond_58

    .line 77
    invoke-virtual {v7, v12}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 80
    move-result v3

    .line 81
    if-eqz v3, :cond_55

    .line 83
    const/16 v3, 0x800

    .line 85
    goto :goto_57

    .line 86
    :cond_55
    const/16 v3, 0x400

    .line 88
    :goto_57
    or-int/2addr v1, v3

    .line 89
    :cond_58
    and-int/lit16 v3, v15, 0x6000

    .line 91
    if-nez v3, :cond_68

    .line 93
    invoke-virtual {v7, v13}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 96
    move-result v3

    .line 97
    if-eqz v3, :cond_65

    .line 99
    const/16 v3, 0x4000

    .line 101
    goto :goto_67

    .line 102
    :cond_65
    const/16 v3, 0x2000

    .line 104
    :goto_67
    or-int/2addr v1, v3

    .line 105
    :cond_68
    const/high16 v3, 0x30000

    .line 107
    and-int/2addr v3, v15

    .line 108
    const/high16 v5, 0x20000

    .line 110
    if-nez v3, :cond_7a

    .line 112
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 115
    move-result v3

    .line 116
    if-eqz v3, :cond_77

    .line 118
    move v3, v5

    .line 119
    goto :goto_79

    .line 120
    :cond_77
    const/high16 v3, 0x10000

    .line 122
    :goto_79
    or-int/2addr v1, v3

    .line 123
    :cond_7a
    const v3, 0x12493

    .line 126
    and-int/2addr v3, v1

    .line 127
    const v6, 0x12492

    .line 130
    if-eq v3, v6, :cond_85

    .line 132
    const/4 v3, 0x1

    .line 133
    goto :goto_86

    .line 134
    :cond_85
    const/4 v3, 0x0

    .line 135
    :goto_86
    and-int/lit8 v6, v1, 0x1

    .line 137
    invoke-virtual {v7, v6, v3}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 140
    move-result v3

    .line 141
    if-eqz v3, :cond_1d8

    .line 143
    sget-object v3, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->LabelVerticalTextAlignment:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 145
    sget v6, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->HorizontalPadding:F

    .line 147
    new-instance v8, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 149
    new-instance v9, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 151
    invoke-direct {v9, v2}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(I)V

    .line 154
    invoke-direct {v8, v6, v9}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLandroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;)V

    .line 157
    and-int/lit8 v9, v1, 0x70

    .line 159
    if-ne v9, v4, :cond_a2

    .line 161
    const/4 v4, 0x1

    .line 162
    goto :goto_a3

    .line 163
    :cond_a2
    const/4 v4, 0x0

    .line 164
    :goto_a3
    const/high16 v9, 0x70000

    .line 166
    and-int/2addr v9, v1

    .line 167
    if-ne v9, v5, :cond_aa

    .line 169
    const/4 v5, 0x1

    .line 170
    goto :goto_ab

    .line 171
    :cond_aa
    const/4 v5, 0x0

    .line 172
    :goto_ab
    or-int/2addr v4, v5

    .line 173
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 176
    move-result-object v5

    .line 177
    if-nez v4, :cond_b6

    .line 179
    sget-object v4, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 181
    if-ne v5, v4, :cond_bf

    .line 183
    :cond_b6
    new-instance v5, Lyangfentuozi/dsusideloaderplus/ui/theme/ThemeKt$$ExternalSyntheticLambda0;

    .line 185
    const/4 v4, 0x1

    .line 186
    invoke-direct {v5, v4, v14, v10}, Lyangfentuozi/dsusideloaderplus/ui/theme/ThemeKt$$ExternalSyntheticLambda0;-><init>(ILjava/lang/Object;Z)V

    .line 189
    invoke-virtual {v7, v5}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 192
    :cond_bf
    check-cast v5, Lkotlin/jvm/functions/Function0;

    .line 194
    invoke-static {v12, v10, v0, v5}, Landroidx/compose/foundation/ImageKt;->clickable-oSLSa3U$default(Landroidx/compose/ui/Modifier;ZLjava/lang/String;Lkotlin/jvm/functions/Function0;)Landroidx/compose/ui/Modifier;

    .line 197
    move-result-object v4

    .line 198
    sget-object v5, Landroidx/compose/foundation/layout/SizeKt;->FillWholeMaxWidth:Landroidx/compose/foundation/layout/FillElement;

    .line 200
    invoke-interface {v4, v5}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 203
    move-result-object v4

    .line 204
    const/high16 v5, 0x42e00000  # 112.0f

    .line 206
    const/high16 v9, 0x438c0000  # 280.0f

    .line 208
    const/high16 v2, 0x42400000  # 48.0f

    .line 210
    invoke-static {v4, v5, v2, v9, v2}, Landroidx/compose/foundation/layout/SizeKt;->sizeIn-qDBjuR0(Landroidx/compose/ui/Modifier;FFFF)Landroidx/compose/ui/Modifier;

    .line 213
    move-result-object v2

    .line 214
    const/4 v4, 0x0

    .line 215
    const/4 v5, 0x2

    .line 216
    invoke-static {v2, v6, v4, v5}, Landroidx/compose/foundation/layout/SpacerKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 219
    move-result-object v2

    .line 220
    const/16 v4, 0x36

    .line 222
    invoke-static {v8, v3, v7, v4}, Landroidx/compose/foundation/layout/RowKt;->rowMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Horizontal;Landroidx/compose/ui/BiasAlignment$Vertical;Landroidx/compose/runtime/GapComposer;I)Landroidx/compose/foundation/layout/RowMeasurePolicy;

    .line 225
    move-result-object v3

    .line 226
    iget-wide v4, v7, Landroidx/compose/runtime/GapComposer;->compositeKeyHashCode:J

    .line 228
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 231
    move-result v4

    .line 232
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 235
    move-result-object v5

    .line 236
    invoke-static {v7, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/GapComposer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 239
    move-result-object v2

    .line 240
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 242
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 245
    sget-object v6, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 247
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->startReusableNode()V

    .line 250
    iget-boolean v8, v7, Landroidx/compose/runtime/GapComposer;->inserting:Z

    .line 252
    if-eqz v8, :cond_101

    .line 254
    invoke-virtual {v7, v6}, Landroidx/compose/runtime/GapComposer;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 257
    goto :goto_104

    .line 258
    :cond_101
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->useNode()V

    .line 261
    :goto_104
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 263
    invoke-static {v7, v3, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 266
    sget-object v3, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 268
    invoke-static {v7, v5, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 271
    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 274
    move-result-object v4

    .line 275
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 277
    invoke-static {v7, v4, v5}, Landroidx/compose/runtime/Updater;->init-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Integer;Lkotlin/jvm/functions/Function2;)V

    .line 280
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->ApplyOnDeactivatedNodeAssertion:Landroidx/compose/ui/node/OwnerSnapshotObserver$onCommitAffectingLayout$1;

    .line 282
    invoke-static {v7, v4}, Landroidx/compose/runtime/Updater;->reconcile-impl(Landroidx/compose/runtime/GapComposer;Lkotlin/jvm/functions/Function1;)V

    .line 285
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 287
    invoke-static {v7, v2, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 290
    if-nez v13, :cond_130

    .line 292
    const v2, -0x5f3ebcd6

    .line 295
    invoke-virtual {v7, v2}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 298
    const/4 v2, 0x0

    .line 299
    invoke-virtual {v7, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 302
    move/from16 v17, v1

    .line 304
    goto :goto_199

    .line 305
    :cond_130
    const v2, -0x5f3ebcd5

    .line 308
    invoke-virtual {v7, v2}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 311
    sget v18, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->IconSize:F

    .line 313
    const/16 v19, 0x0

    .line 315
    const/16 v22, 0x2

    .line 317
    sget-object v17, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 319
    move/from16 v20, v18

    .line 321
    move/from16 v21, v18

    .line 323
    invoke-static/range {v17 .. v22}, Landroidx/compose/foundation/layout/SizeKt;->requiredSizeIn-qDBjuR0$default(Landroidx/compose/ui/Modifier;FFFFI)Landroidx/compose/ui/Modifier;

    .line 326
    move-result-object v2

    .line 327
    sget-object v0, Landroidx/compose/ui/Alignment$Companion;->TopStart:Landroidx/compose/ui/BiasAlignment;

    .line 329
    move/from16 v17, v1

    .line 331
    const/4 v1, 0x0

    .line 332
    invoke-static {v0, v1}, Landroidx/compose/foundation/layout/BoxKt;->maybeCachedBoxMeasurePolicy(Landroidx/compose/ui/BiasAlignment;Z)Landroidx/compose/ui/layout/MeasurePolicy;

    .line 335
    move-result-object v0

    .line 336
    iget-wide v14, v7, Landroidx/compose/runtime/GapComposer;->compositeKeyHashCode:J

    .line 338
    invoke-static {v14, v15}, Ljava/lang/Long;->hashCode(J)I

    .line 341
    move-result v1

    .line 342
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 345
    move-result-object v14

    .line 346
    invoke-static {v7, v2}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/GapComposer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 349
    move-result-object v2

    .line 350
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->startReusableNode()V

    .line 353
    iget-boolean v15, v7, Landroidx/compose/runtime/GapComposer;->inserting:Z

    .line 355
    if-eqz v15, :cond_168

    .line 357
    invoke-virtual {v7, v6}, Landroidx/compose/runtime/GapComposer;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 360
    goto :goto_16b

    .line 361
    :cond_168
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->useNode()V

    .line 364
    :goto_16b
    invoke-static {v7, v0, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 367
    invoke-static {v7, v14, v3}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 370
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 373
    move-result-object v0

    .line 374
    invoke-static {v7, v0, v5}, Landroidx/compose/runtime/Updater;->init-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Integer;Lkotlin/jvm/functions/Function2;)V

    .line 377
    invoke-static {v7, v4}, Landroidx/compose/runtime/Updater;->reconcile-impl(Landroidx/compose/runtime/GapComposer;Lkotlin/jvm/functions/Function1;)V

    .line 380
    invoke-static {v7, v2, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 383
    if-eqz v10, :cond_183

    .line 385
    iget-wide v0, v11, Landroidx/compose/foundation/contextmenu/ContextMenuColors;->iconColor:J

    .line 387
    goto :goto_185

    .line 388
    :cond_183
    iget-wide v0, v11, Landroidx/compose/foundation/contextmenu/ContextMenuColors;->disabledIconColor:J

    .line 390
    :goto_185
    new-instance v2, Landroidx/compose/ui/graphics/Color;

    .line 392
    invoke-direct {v2, v0, v1}, Landroidx/compose/ui/graphics/Color;-><init>(J)V

    .line 395
    const/4 v1, 0x0

    .line 396
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 399
    move-result-object v0

    .line 400
    invoke-interface {v13, v2, v7, v0}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 403
    const/4 v4, 0x1

    .line 404
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 407
    invoke-virtual {v7, v1}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 410
    :goto_199
    if-eqz v10, :cond_1a0

    .line 412
    iget-wide v0, v11, Landroidx/compose/foundation/contextmenu/ContextMenuColors;->textColor:J

    .line 414
    :goto_19d
    move-wide/from16 v19, v0

    .line 416
    goto :goto_1a3

    .line 417
    :cond_1a0
    iget-wide v0, v11, Landroidx/compose/foundation/contextmenu/ContextMenuColors;->disabledTextColor:J

    .line 419
    goto :goto_19d

    .line 420
    :goto_1a3
    sget v26, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->LabelHorizontalTextAlignment:I

    .line 422
    sget-wide v21, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->FontSize:J

    .line 424
    sget-object v23, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->FontWeight:Landroidx/compose/ui/text/font/FontWeight;

    .line 426
    sget-wide v27, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->LineHeight:J

    .line 428
    sget-wide v24, Landroidx/compose/foundation/contextmenu/ContextMenuSpec;->LetterSpacing:J

    .line 430
    new-instance v2, Landroidx/compose/ui/text/TextStyle;

    .line 432
    const v29, 0xfd7f78

    .line 435
    move-object/from16 v18, v2

    .line 437
    invoke-direct/range {v18 .. v29}, Landroidx/compose/ui/text/TextStyle;-><init>(JJLandroidx/compose/ui/text/font/FontWeight;JIJI)V

    .line 440
    new-instance v1, Landroidx/compose/foundation/layout/LayoutWeightElement;

    .line 442
    const/high16 v0, 0x3f800000  # 1.0f

    .line 444
    const/4 v4, 0x1

    .line 445
    invoke-direct {v1, v0, v4}, Landroidx/compose/foundation/layout/LayoutWeightElement;-><init>(FZ)V

    .line 448
    and-int/lit8 v0, v17, 0xe

    .line 450
    const/high16 v3, 0x180000

    .line 452
    or-int v8, v0, v3

    .line 454
    const/16 v9, 0x3b8

    .line 456
    const/4 v3, 0x0

    .line 457
    move/from16 v16, v4

    .line 459
    const/4 v4, 0x0

    .line 460
    const/4 v5, 0x1

    .line 461
    const/4 v6, 0x0

    .line 462
    move-object/from16 v0, p0

    .line 464
    move/from16 v14, v16

    .line 466
    invoke-static/range {v0 .. v9}, Landroidx/compose/foundation/text/BasicTextKt;->BasicText-RWo7tUw(Ljava/lang/String;Landroidx/compose/ui/Modifier;Landroidx/compose/ui/text/TextStyle;IZIILandroidx/compose/runtime/GapComposer;II)V

    .line 469
    invoke-virtual {v7, v14}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 472
    goto :goto_1db

    .line 473
    :cond_1d8
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 476
    :goto_1db
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 479
    move-result-object v8

    .line 480
    if-eqz v8, :cond_1f2

    .line 482
    new-instance v0, Landroidx/compose/material3/TooltipKt$$ExternalSyntheticLambda2;

    .line 484
    move-object/from16 v1, p0

    .line 486
    move-object/from16 v6, p5

    .line 488
    move/from16 v7, p7

    .line 490
    move v2, v10

    .line 491
    move-object v3, v11

    .line 492
    move-object v4, v12

    .line 493
    move-object v5, v13

    .line 494
    invoke-direct/range {v0 .. v7}, Landroidx/compose/material3/TooltipKt$$ExternalSyntheticLambda2;-><init>(Ljava/lang/String;ZLandroidx/compose/foundation/contextmenu/ContextMenuColors;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;Lkotlin/jvm/functions/Function0;I)V

    .line 497
    iput-object v0, v8, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 499
    :cond_1f2
    return-void
.end method
