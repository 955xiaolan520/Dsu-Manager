.class public final Landroidx/compose/foundation/gestures/ScrollingLogic;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public flingBehavior:Landroidx/compose/foundation/gestures/DefaultFlingBehavior;

.field public isFlinging:Z

.field public final isScrollableNodeAttached:Landroidx/compose/foundation/gestures/ScrollableNode$$ExternalSyntheticLambda0;

.field public latestScrollSource:I

.field public nestedScrollDispatcher:Lkotlin/text/MatcherMatchResult;

.field public final nestedScrollScope:Landroidx/compose/foundation/gestures/ScrollingLogic$nestedScrollScope$1;

.field public final onScrollChangedDispatcher:Landroidx/compose/foundation/gestures/ScrollableNode;

.field public orientation:Landroidx/compose/foundation/gestures/Orientation;

.field public outerStateScope:Landroidx/compose/foundation/gestures/ScrollScope;

.field public overscrollEffect:Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect;

.field public final performScrollForOverscroll:Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda4;

.field public reverseDirection:Z

.field public scrollableState:Landroidx/compose/foundation/gestures/ScrollableState;


# direct methods
.method public constructor <init>(Landroidx/compose/foundation/gestures/ScrollableState;Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect;Landroidx/compose/foundation/gestures/DefaultFlingBehavior;Landroidx/compose/foundation/gestures/Orientation;ZLkotlin/text/MatcherMatchResult;Landroidx/compose/foundation/gestures/ScrollableNode;Landroidx/compose/foundation/gestures/ScrollableNode$$ExternalSyntheticLambda0;)V
    .registers 9

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->scrollableState:Landroidx/compose/foundation/gestures/ScrollableState;

    .line 6
    iput-object p2, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->overscrollEffect:Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect;

    .line 8
    iput-object p3, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->flingBehavior:Landroidx/compose/foundation/gestures/DefaultFlingBehavior;

    .line 10
    iput-object p4, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 12
    iput-boolean p5, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->reverseDirection:Z

    .line 14
    iput-object p6, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->nestedScrollDispatcher:Lkotlin/text/MatcherMatchResult;

    .line 16
    iput-object p7, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->onScrollChangedDispatcher:Landroidx/compose/foundation/gestures/ScrollableNode;

    .line 18
    iput-object p8, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->isScrollableNodeAttached:Landroidx/compose/foundation/gestures/ScrollableNode$$ExternalSyntheticLambda0;

    .line 20
    const/4 p1, 0x1

    .line 21
    iput p1, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->latestScrollSource:I

    .line 23
    sget-object p1, Landroidx/compose/foundation/gestures/ScrollableKt;->NoOpScrollScope:Landroidx/compose/foundation/gestures/ScrollableKt$NoOpScrollScope$1;

    .line 25
    iput-object p1, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->outerStateScope:Landroidx/compose/foundation/gestures/ScrollScope;

    .line 27
    new-instance p1, Landroidx/compose/foundation/gestures/ScrollingLogic$nestedScrollScope$1;

    .line 29
    invoke-direct {p1, p0}, Landroidx/compose/foundation/gestures/ScrollingLogic$nestedScrollScope$1;-><init>(Landroidx/compose/foundation/gestures/ScrollingLogic;)V

    .line 32
    iput-object p1, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->nestedScrollScope:Landroidx/compose/foundation/gestures/ScrollingLogic$nestedScrollScope$1;

    .line 34
    new-instance p1, Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda4;

    .line 36
    const/4 p2, 0x6

    .line 37
    invoke-direct {p1, p2, p0}, Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda4;-><init>(ILjava/lang/Object;)V

    .line 40
    iput-object p1, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->performScrollForOverscroll:Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda4;

    .line 42
    return-void
.end method


# virtual methods
.method public final doFlingAnimation-QWom1Mo(JLkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;
    .registers 14

    .line 1
    instance-of v0, p3, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;

    .line 3
    if-eqz v0, :cond_13

    .line 5
    move-object v0, p3

    .line 6
    check-cast v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;

    .line 8
    iget v1, v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;->label:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_13

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;->label:I

    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;

    .line 22
    invoke-direct {v0, p0, p3}, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;-><init>(Landroidx/compose/foundation/gestures/ScrollingLogic;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)V

    .line 25
    :goto_18
    iget-object p3, v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;->result:Ljava/lang/Object;

    .line 27
    iget v1, v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;->label:I

    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x1

    .line 31
    if-eqz v1, :cond_34

    .line 33
    if-ne v1, v3, :cond_2d

    .line 35
    iget-object p1, v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;->L$0:Lkotlin/jvm/internal/Ref$LongRef;

    .line 37
    :try_start_24
    invoke-static {p3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_27
    .catchall {:try_start_24 .. :try_end_27} :catchall_29

    .line 40
    move-object v5, p0

    .line 41
    goto :goto_58

    .line 42
    :catchall_29
    move-exception v0

    .line 43
    move-object p1, v0

    .line 44
    move-object v5, p0

    .line 45
    goto :goto_68

    .line 46
    :cond_2d
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 48
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 51
    const/4 p0, 0x0

    .line 52
    return-object p0

    .line 53
    :cond_34
    invoke-static {p3}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 56
    new-instance v6, Lkotlin/jvm/internal/Ref$LongRef;

    .line 58
    invoke-direct {v6}, Ljava/lang/Object;-><init>()V

    .line 61
    iput-wide p1, v6, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 63
    iput-boolean v3, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->isFlinging:Z

    .line 65
    :try_start_40
    sget-object p3, Landroidx/compose/foundation/MutatePriority;->Default:Landroidx/compose/foundation/MutatePriority;

    .line 67
    new-instance v4, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$2;
    :try_end_44
    .catchall {:try_start_40 .. :try_end_44} :catchall_65

    .line 69
    const/4 v9, 0x0

    .line 70
    move-object v5, p0

    .line 71
    move-wide v7, p1

    .line 72
    :try_start_47
    invoke-direct/range {v4 .. v9}, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$2;-><init>(Landroidx/compose/foundation/gestures/ScrollingLogic;Lkotlin/jvm/internal/Ref$LongRef;JLkotlin/coroutines/Continuation;)V

    .line 75
    iput-object v6, v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;->L$0:Lkotlin/jvm/internal/Ref$LongRef;

    .line 77
    iput v3, v0, Landroidx/compose/foundation/gestures/ScrollingLogic$doFlingAnimation$1;->label:I

    .line 79
    invoke-virtual {v5, p3, v4, v0}, Landroidx/compose/foundation/gestures/ScrollingLogic;->scroll(Landroidx/compose/foundation/MutatePriority;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 82
    move-result-object p0
    :try_end_52
    .catchall {:try_start_47 .. :try_end_52} :catchall_62

    .line 83
    sget-object p1, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 85
    if-ne p0, p1, :cond_57

    .line 87
    return-object p1

    .line 88
    :cond_57
    move-object p1, v6

    .line 89
    :goto_58
    iput-boolean v2, v5, Landroidx/compose/foundation/gestures/ScrollingLogic;->isFlinging:Z

    .line 91
    iget-wide p0, p1, Lkotlin/jvm/internal/Ref$LongRef;->element:J

    .line 93
    new-instance p2, Landroidx/compose/ui/unit/Velocity;

    .line 95
    invoke-direct {p2, p0, p1}, Landroidx/compose/ui/unit/Velocity;-><init>(J)V

    .line 98
    return-object p2

    .line 99
    :catchall_62
    move-exception v0

    .line 100
    :goto_63
    move-object p1, v0

    .line 101
    goto :goto_68

    .line 102
    :catchall_65
    move-exception v0

    .line 103
    move-object v5, p0

    .line 104
    goto :goto_63

    .line 105
    :goto_68
    iput-boolean v2, v5, Landroidx/compose/foundation/gestures/ScrollingLogic;->isFlinging:Z

    .line 107
    throw p1
.end method

.method public final onScrollStopped-BMRW4eQ(JZLkotlin/coroutines/jvm/internal/SuspendLambda;)Ljava/lang/Object;
    .registers 9

    .line 1
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 3
    if-eqz p3, :cond_d

    .line 5
    iget-object p3, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->flingBehavior:Landroidx/compose/foundation/gestures/DefaultFlingBehavior;

    .line 7
    sget-object v1, Landroidx/compose/foundation/gestures/ScrollableKt;->CanDragCalculation:Landroidx/compose/material3/ButtonKt$$ExternalSyntheticLambda0;

    .line 9
    instance-of p3, p3, Landroidx/compose/foundation/gestures/DefaultFlingBehavior;

    .line 11
    if-eqz p3, :cond_d

    .line 13
    goto :goto_4d

    .line 14
    :cond_d
    iget-object p3, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 16
    sget-object v1, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 18
    const/4 v2, 0x0

    .line 19
    if-ne p3, v1, :cond_1a

    .line 21
    const/4 p3, 0x1

    .line 22
    :goto_15
    invoke-static {p1, p2, v2, v2, p3}, Landroidx/compose/ui/unit/Velocity;->copy-OhffZ5M$default(JFFI)J

    .line 25
    move-result-wide p1

    .line 26
    goto :goto_1c

    .line 27
    :cond_1a
    const/4 p3, 0x2

    .line 28
    goto :goto_15

    .line 29
    :goto_1c
    new-instance p3, Landroidx/compose/foundation/gestures/ScrollingLogic$onScrollStopped$performFling$1;

    .line 31
    const/4 v1, 0x0

    .line 32
    invoke-direct {p3, p0, v1}, Landroidx/compose/foundation/gestures/ScrollingLogic$onScrollStopped$performFling$1;-><init>(Landroidx/compose/foundation/gestures/ScrollingLogic;Lkotlin/coroutines/Continuation;)V

    .line 35
    iget-object v1, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->overscrollEffect:Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect;

    .line 37
    sget-object v2, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 39
    if-eqz v1, :cond_3f

    .line 41
    iget-object v3, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->scrollableState:Landroidx/compose/foundation/gestures/ScrollableState;

    .line 43
    invoke-interface {v3}, Landroidx/compose/foundation/gestures/ScrollableState;->getCanScrollForward()Z

    .line 46
    move-result v3

    .line 47
    if-nez v3, :cond_38

    .line 49
    iget-object v3, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->scrollableState:Landroidx/compose/foundation/gestures/ScrollableState;

    .line 51
    invoke-interface {v3}, Landroidx/compose/foundation/gestures/ScrollableState;->getCanScrollBackward()Z

    .line 54
    move-result v3

    .line 55
    if-eqz v3, :cond_3f

    .line 57
    :cond_38
    invoke-virtual {v1, p1, p2, p3, p4}, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollEffect;->applyToFling-BMRW4eQ(JLandroidx/compose/foundation/gestures/ScrollingLogic$onScrollStopped$performFling$1;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 60
    move-result-object p0

    .line 61
    if-ne p0, v2, :cond_4d

    .line 63
    return-object p0

    .line 64
    :cond_3f
    new-instance p3, Landroidx/compose/foundation/gestures/ScrollingLogic$onScrollStopped$performFling$1;

    .line 66
    invoke-direct {p3, p0, p4}, Landroidx/compose/foundation/gestures/ScrollingLogic$onScrollStopped$performFling$1;-><init>(Landroidx/compose/foundation/gestures/ScrollingLogic;Lkotlin/coroutines/Continuation;)V

    .line 69
    iput-wide p1, p3, Landroidx/compose/foundation/gestures/ScrollingLogic$onScrollStopped$performFling$1;->J$0:J

    .line 71
    invoke-virtual {p3, v0}, Landroidx/compose/foundation/gestures/ScrollingLogic$onScrollStopped$performFling$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 74
    move-result-object p0

    .line 75
    if-ne p0, v2, :cond_4d

    .line 77
    return-object p0

    .line 78
    :cond_4d
    :goto_4d
    return-object v0
.end method

.method public final performScroll-3eAAhYA(Landroidx/compose/foundation/gestures/ScrollScope;JI)J
    .registers 28

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-wide/from16 v1, p2

    .line 5
    iget-object v3, v0, Landroidx/compose/foundation/gestures/ScrollingLogic;->nestedScrollDispatcher:Lkotlin/text/MatcherMatchResult;

    .line 7
    iget-object v3, v3, Lkotlin/text/MatcherMatchResult;->matcher:Ljava/lang/Object;

    .line 9
    check-cast v3, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;

    .line 11
    const/16 v4, 0x10

    .line 13
    const-class v5, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;

    .line 15
    const-string v6, "visitAncestors called on an unattached node"

    .line 17
    const/high16 v7, 0x40000

    .line 19
    const/4 v9, 0x1

    .line 20
    const/4 v10, 0x0

    .line 21
    if-eqz v3, :cond_c1

    .line 23
    iget-boolean v11, v3, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 25
    if-eqz v11, :cond_c1

    .line 27
    iget-object v11, v3, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 29
    iget-boolean v11, v11, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 31
    if-nez v11, :cond_23

    .line 33
    invoke-static {v6}, Landroidx/compose/ui/internal/InlineClassHelperKt;->throwIllegalStateException(Ljava/lang/String;)V

    .line 36
    :cond_23
    iget-object v11, v3, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 38
    iget-object v11, v11, Landroidx/compose/ui/Modifier$Node;->parent:Landroidx/compose/ui/Modifier$Node;

    .line 40
    invoke-static {v3}, Landroidx/compose/ui/node/HitTestResultKt;->requireLayoutNode(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/LayoutNode;

    .line 43
    move-result-object v12

    .line 44
    :goto_2b
    if-eqz v12, :cond_bb

    .line 46
    iget-object v13, v12, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 48
    iget-object v13, v13, Landroidx/compose/ui/node/NodeChain;->head:Landroidx/compose/ui/Modifier$Node;

    .line 50
    iget v13, v13, Landroidx/compose/ui/Modifier$Node;->aggregateChildKindSet:I

    .line 52
    and-int/2addr v13, v7

    .line 53
    if-eqz v13, :cond_a6

    .line 55
    :goto_36
    if-eqz v11, :cond_a6

    .line 57
    iget v13, v11, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 59
    and-int/2addr v13, v7

    .line 60
    if-eqz v13, :cond_9f

    .line 62
    move-object v14, v10

    .line 63
    move-object v13, v11

    .line 64
    :goto_3f
    if-eqz v13, :cond_9f

    .line 66
    instance-of v15, v13, Landroidx/compose/ui/node/TraversableNode;

    .line 68
    if-eqz v15, :cond_60

    .line 70
    move-object v15, v13

    .line 71
    check-cast v15, Landroidx/compose/ui/node/TraversableNode;

    .line 73
    move/from16 v16, v7

    .line 75
    invoke-virtual {v3}, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;->getTraverseKey()Ljava/lang/Object;

    .line 78
    move-result-object v7

    .line 79
    invoke-interface {v15}, Landroidx/compose/ui/node/TraversableNode;->getTraverseKey()Ljava/lang/Object;

    .line 82
    move-result-object v8

    .line 83
    invoke-static {v7, v8}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 86
    move-result v7

    .line 87
    if-eqz v7, :cond_62

    .line 89
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 92
    move-result-object v7

    .line 93
    if-ne v5, v7, :cond_62

    .line 95
    goto/16 :goto_be

    .line 97
    :cond_60
    move/from16 v16, v7

    .line 99
    :cond_62
    iget v7, v13, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 101
    and-int v7, v7, v16

    .line 103
    if-eqz v7, :cond_9a

    .line 105
    instance-of v7, v13, Landroidx/compose/ui/node/DelegatingNode;

    .line 107
    if-eqz v7, :cond_9a

    .line 109
    move-object v7, v13

    .line 110
    check-cast v7, Landroidx/compose/ui/node/DelegatingNode;

    .line 112
    iget-object v7, v7, Landroidx/compose/ui/node/DelegatingNode;->delegate:Landroidx/compose/ui/Modifier$Node;

    .line 114
    const/4 v8, 0x0

    .line 115
    :goto_72
    if-eqz v7, :cond_95

    .line 117
    iget v15, v7, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 119
    and-int v15, v15, v16

    .line 121
    if-eqz v15, :cond_92

    .line 123
    add-int/lit8 v8, v8, 0x1

    .line 125
    if-ne v8, v9, :cond_80

    .line 127
    move-object v13, v7

    .line 128
    goto :goto_92

    .line 129
    :cond_80
    if-nez v14, :cond_89

    .line 131
    new-instance v14, Landroidx/compose/runtime/collection/MutableVector;

    .line 133
    new-array v15, v4, [Landroidx/compose/ui/Modifier$Node;

    .line 135
    invoke-direct {v14, v15}, Landroidx/compose/runtime/collection/MutableVector;-><init>([Ljava/lang/Object;)V

    .line 138
    :cond_89
    if-eqz v13, :cond_8f

    .line 140
    invoke-virtual {v14, v13}, Landroidx/compose/runtime/collection/MutableVector;->add(Ljava/lang/Object;)V

    .line 143
    move-object v13, v10

    .line 144
    :cond_8f
    invoke-virtual {v14, v7}, Landroidx/compose/runtime/collection/MutableVector;->add(Ljava/lang/Object;)V

    .line 147
    :cond_92
    :goto_92
    iget-object v7, v7, Landroidx/compose/ui/Modifier$Node;->child:Landroidx/compose/ui/Modifier$Node;

    .line 149
    goto :goto_72

    .line 150
    :cond_95
    if-ne v8, v9, :cond_9a

    .line 152
    :goto_97
    move/from16 v7, v16

    .line 154
    goto :goto_3f

    .line 155
    :cond_9a
    invoke-static {v14}, Landroidx/compose/ui/node/HitTestResultKt;->access$pop(Landroidx/compose/runtime/collection/MutableVector;)Landroidx/compose/ui/Modifier$Node;

    .line 158
    move-result-object v13

    .line 159
    goto :goto_97

    .line 160
    :cond_9f
    move/from16 v16, v7

    .line 162
    iget-object v11, v11, Landroidx/compose/ui/Modifier$Node;->parent:Landroidx/compose/ui/Modifier$Node;

    .line 164
    move/from16 v7, v16

    .line 166
    goto :goto_36

    .line 167
    :cond_a6
    move/from16 v16, v7

    .line 169
    invoke-virtual {v12}, Landroidx/compose/ui/node/LayoutNode;->getParent$ui()Landroidx/compose/ui/node/LayoutNode;

    .line 172
    move-result-object v12

    .line 173
    if-eqz v12, :cond_b6

    .line 175
    iget-object v7, v12, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 177
    if-eqz v7, :cond_b6

    .line 179
    iget-object v7, v7, Landroidx/compose/ui/node/NodeChain;->tail:Landroidx/compose/ui/node/TailModifierNode;

    .line 181
    move-object v11, v7

    .line 182
    goto :goto_b7

    .line 183
    :cond_b6
    move-object v11, v10

    .line 184
    :goto_b7
    move/from16 v7, v16

    .line 186
    goto/16 :goto_2b

    .line 188
    :cond_bb
    move/from16 v16, v7

    .line 190
    move-object v15, v10

    .line 191
    :goto_be
    check-cast v15, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;

    .line 193
    goto :goto_c4

    .line 194
    :cond_c1
    move/from16 v16, v7

    .line 196
    move-object v15, v10

    .line 197
    :goto_c4
    move/from16 v3, p4

    .line 199
    if-eqz v15, :cond_cd

    .line 201
    invoke-virtual {v15, v3, v1, v2}, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;->onPreScroll-OzD1aCk(IJ)J

    .line 204
    move-result-wide v11

    .line 205
    goto :goto_cf

    .line 206
    :cond_cd
    const-wide/16 v11, 0x0

    .line 208
    :goto_cf
    invoke-static {v1, v2, v11, v12}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 211
    move-result-wide v1

    .line 212
    iget-object v13, v0, Landroidx/compose/foundation/gestures/ScrollingLogic;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 214
    sget-object v14, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 216
    const/4 v15, 0x0

    .line 217
    if-ne v13, v14, :cond_df

    .line 219
    invoke-static {v1, v2, v15, v9}, Landroidx/compose/ui/geometry/Offset;->copy-dBAh8RU$default(JFI)J

    .line 222
    move-result-wide v13

    .line 223
    goto :goto_e4

    .line 224
    :cond_df
    const/4 v13, 0x2

    .line 225
    invoke-static {v1, v2, v15, v13}, Landroidx/compose/ui/geometry/Offset;->copy-dBAh8RU$default(JFI)J

    .line 228
    move-result-wide v13

    .line 229
    :goto_e4
    invoke-virtual {v0, v13, v14}, Landroidx/compose/foundation/gestures/ScrollingLogic;->reverseIfNeeded-MK-Hz9U(J)J

    .line 232
    move-result-wide v13

    .line 233
    invoke-virtual {v0, v13, v14}, Landroidx/compose/foundation/gestures/ScrollingLogic;->toFloat-k-4lQ0M(J)F

    .line 236
    move-result v13

    .line 237
    move-object/from16 v14, p1

    .line 239
    invoke-interface {v14, v13}, Landroidx/compose/foundation/gestures/ScrollScope;->scrollBy(F)F

    .line 242
    move-result v13

    .line 243
    invoke-virtual {v0, v13}, Landroidx/compose/foundation/gestures/ScrollingLogic;->toOffset-tuRUvjQ(F)J

    .line 246
    move-result-wide v13

    .line 247
    invoke-virtual {v0, v13, v14}, Landroidx/compose/foundation/gestures/ScrollingLogic;->reverseIfNeeded-MK-Hz9U(J)J

    .line 250
    move-result-wide v13

    .line 251
    iget-object v15, v0, Landroidx/compose/foundation/gestures/ScrollingLogic;->onScrollChangedDispatcher:Landroidx/compose/foundation/gestures/ScrollableNode;

    .line 253
    iget-boolean v7, v15, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 255
    if-nez v7, :cond_101

    .line 257
    goto :goto_125

    .line 258
    :cond_101
    invoke-static {v15}, Landroidx/compose/ui/node/HitTestResultKt;->requireOwner(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/Owner;

    .line 261
    move-result-object v7

    .line 262
    check-cast v7, Landroidx/compose/ui/platform/AndroidComposeView;

    .line 264
    invoke-virtual {v7}, Landroid/view/View;->getViewTreeObserver()Landroid/view/ViewTreeObserver;

    .line 267
    move-result-object v7

    .line 268
    :try_start_10b
    sget-object v8, Landroidx/compose/ui/platform/AndroidComposeView;->dispatchOnScrollChangedMethod:Ljava/lang/reflect/Method;

    .line 270
    if-nez v8, :cond_11e

    .line 272
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 275
    move-result-object v8

    .line 276
    const-string v15, "dispatchOnScrollChanged"

    .line 278
    invoke-virtual {v8, v15, v10}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    .line 281
    move-result-object v8

    .line 282
    invoke-virtual {v8, v9}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 285
    sput-object v8, Landroidx/compose/ui/platform/AndroidComposeView;->dispatchOnScrollChangedMethod:Ljava/lang/reflect/Method;

    .line 287
    :cond_11e
    sget-object v8, Landroidx/compose/ui/platform/AndroidComposeView;->dispatchOnScrollChangedMethod:Ljava/lang/reflect/Method;

    .line 289
    if-eqz v8, :cond_125

    .line 291
    invoke-virtual {v8, v7, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_125
    .catch Ljava/lang/Exception; {:try_start_10b .. :try_end_125} :catch_125

    .line 294
    :catch_125
    :cond_125
    :goto_125
    invoke-static {v1, v2, v13, v14}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 297
    move-result-wide v21

    .line 298
    iget-object v0, v0, Landroidx/compose/foundation/gestures/ScrollingLogic;->nestedScrollDispatcher:Lkotlin/text/MatcherMatchResult;

    .line 300
    iget-object v0, v0, Lkotlin/text/MatcherMatchResult;->matcher:Ljava/lang/Object;

    .line 302
    check-cast v0, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;

    .line 304
    if-eqz v0, :cond_1d2

    .line 306
    iget-boolean v1, v0, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 308
    if-eqz v1, :cond_1d2

    .line 310
    iget-object v1, v0, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 312
    iget-boolean v1, v1, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 314
    if-nez v1, :cond_13e

    .line 316
    invoke-static {v6}, Landroidx/compose/ui/internal/InlineClassHelperKt;->throwIllegalStateException(Ljava/lang/String;)V

    .line 319
    :cond_13e
    iget-object v1, v0, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 321
    iget-object v1, v1, Landroidx/compose/ui/Modifier$Node;->parent:Landroidx/compose/ui/Modifier$Node;

    .line 323
    invoke-static {v0}, Landroidx/compose/ui/node/HitTestResultKt;->requireLayoutNode(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/LayoutNode;

    .line 326
    move-result-object v2

    .line 327
    :goto_146
    if-eqz v2, :cond_1cc

    .line 329
    iget-object v6, v2, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 331
    iget-object v6, v6, Landroidx/compose/ui/node/NodeChain;->head:Landroidx/compose/ui/Modifier$Node;

    .line 333
    iget v6, v6, Landroidx/compose/ui/Modifier$Node;->aggregateChildKindSet:I

    .line 335
    and-int v6, v6, v16

    .line 337
    if-eqz v6, :cond_1bb

    .line 339
    :goto_152
    if-eqz v1, :cond_1bb

    .line 341
    iget v6, v1, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 343
    and-int v6, v6, v16

    .line 345
    if-eqz v6, :cond_1b7

    .line 347
    move-object v6, v1

    .line 348
    move-object v7, v10

    .line 349
    :goto_15c
    if-eqz v6, :cond_1b7

    .line 351
    instance-of v8, v6, Landroidx/compose/ui/node/TraversableNode;

    .line 353
    if-eqz v8, :cond_17b

    .line 355
    move-object v8, v6

    .line 356
    check-cast v8, Landroidx/compose/ui/node/TraversableNode;

    .line 358
    invoke-virtual {v0}, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;->getTraverseKey()Ljava/lang/Object;

    .line 361
    move-result-object v15

    .line 362
    invoke-interface {v8}, Landroidx/compose/ui/node/TraversableNode;->getTraverseKey()Ljava/lang/Object;

    .line 365
    move-result-object v10

    .line 366
    invoke-static {v15, v10}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 369
    move-result v10

    .line 370
    if-eqz v10, :cond_17b

    .line 372
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 375
    move-result-object v10

    .line 376
    if-ne v5, v10, :cond_17b

    .line 378
    move-object v10, v8

    .line 379
    goto :goto_1cd

    .line 380
    :cond_17b
    iget v8, v6, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 382
    and-int v8, v8, v16

    .line 384
    if-eqz v8, :cond_1b2

    .line 386
    instance-of v8, v6, Landroidx/compose/ui/node/DelegatingNode;

    .line 388
    if-eqz v8, :cond_1b2

    .line 390
    move-object v8, v6

    .line 391
    check-cast v8, Landroidx/compose/ui/node/DelegatingNode;

    .line 393
    iget-object v8, v8, Landroidx/compose/ui/node/DelegatingNode;->delegate:Landroidx/compose/ui/Modifier$Node;

    .line 395
    const/4 v10, 0x0

    .line 396
    :goto_18b
    if-eqz v8, :cond_1ae

    .line 398
    iget v15, v8, Landroidx/compose/ui/Modifier$Node;->kindSet:I

    .line 400
    and-int v15, v15, v16

    .line 402
    if-eqz v15, :cond_1ab

    .line 404
    add-int/lit8 v10, v10, 0x1

    .line 406
    if-ne v10, v9, :cond_199

    .line 408
    move-object v6, v8

    .line 409
    goto :goto_1ab

    .line 410
    :cond_199
    if-nez v7, :cond_1a2

    .line 412
    new-instance v7, Landroidx/compose/runtime/collection/MutableVector;

    .line 414
    new-array v15, v4, [Landroidx/compose/ui/Modifier$Node;

    .line 416
    invoke-direct {v7, v15}, Landroidx/compose/runtime/collection/MutableVector;-><init>([Ljava/lang/Object;)V

    .line 419
    :cond_1a2
    if-eqz v6, :cond_1a8

    .line 421
    invoke-virtual {v7, v6}, Landroidx/compose/runtime/collection/MutableVector;->add(Ljava/lang/Object;)V

    .line 424
    const/4 v6, 0x0

    .line 425
    :cond_1a8
    invoke-virtual {v7, v8}, Landroidx/compose/runtime/collection/MutableVector;->add(Ljava/lang/Object;)V

    .line 428
    :cond_1ab
    :goto_1ab
    iget-object v8, v8, Landroidx/compose/ui/Modifier$Node;->child:Landroidx/compose/ui/Modifier$Node;

    .line 430
    goto :goto_18b

    .line 431
    :cond_1ae
    if-ne v10, v9, :cond_1b2

    .line 433
    :goto_1b0
    const/4 v10, 0x0

    .line 434
    goto :goto_15c

    .line 435
    :cond_1b2
    invoke-static {v7}, Landroidx/compose/ui/node/HitTestResultKt;->access$pop(Landroidx/compose/runtime/collection/MutableVector;)Landroidx/compose/ui/Modifier$Node;

    .line 438
    move-result-object v6

    .line 439
    goto :goto_1b0

    .line 440
    :cond_1b7
    iget-object v1, v1, Landroidx/compose/ui/Modifier$Node;->parent:Landroidx/compose/ui/Modifier$Node;

    .line 442
    const/4 v10, 0x0

    .line 443
    goto :goto_152

    .line 444
    :cond_1bb
    invoke-virtual {v2}, Landroidx/compose/ui/node/LayoutNode;->getParent$ui()Landroidx/compose/ui/node/LayoutNode;

    .line 447
    move-result-object v2

    .line 448
    if-eqz v2, :cond_1c8

    .line 450
    iget-object v1, v2, Landroidx/compose/ui/node/LayoutNode;->nodes:Landroidx/compose/ui/node/NodeChain;

    .line 452
    if-eqz v1, :cond_1c8

    .line 454
    iget-object v1, v1, Landroidx/compose/ui/node/NodeChain;->tail:Landroidx/compose/ui/node/TailModifierNode;

    .line 456
    goto :goto_1c9

    .line 457
    :cond_1c8
    const/4 v1, 0x0

    .line 458
    :goto_1c9
    const/4 v10, 0x0

    .line 459
    goto/16 :goto_146

    .line 461
    :cond_1cc
    const/4 v10, 0x0

    .line 462
    :goto_1cd
    check-cast v10, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;

    .line 464
    move-object/from16 v17, v10

    .line 466
    goto :goto_1d4

    .line 467
    :cond_1d2
    const/16 v17, 0x0

    .line 469
    :goto_1d4
    if-eqz v17, :cond_1e1

    .line 471
    move/from16 v18, v3

    .line 473
    move-wide/from16 v19, v13

    .line 475
    invoke-virtual/range {v17 .. v22}, Landroidx/compose/ui/input/nestedscroll/NestedScrollNode;->onPostScroll-DzOQY0M(IJJ)J

    .line 478
    move-result-wide v7

    .line 479
    move-wide/from16 v0, v19

    .line 481
    goto :goto_1e4

    .line 482
    :cond_1e1
    move-wide v0, v13

    .line 483
    const-wide/16 v7, 0x0

    .line 485
    :goto_1e4
    invoke-static {v11, v12, v0, v1}, Landroidx/compose/ui/geometry/Offset;->plus-MK-Hz9U(JJ)J

    .line 488
    move-result-wide v0

    .line 489
    invoke-static {v0, v1, v7, v8}, Landroidx/compose/ui/geometry/Offset;->plus-MK-Hz9U(JJ)J

    .line 492
    move-result-wide v0

    .line 493
    return-wide v0
.end method

.method public final reverseIfNeeded(F)F
    .registers 2

    .line 1
    iget-boolean p0, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->reverseDirection:Z

    .line 3
    if-eqz p0, :cond_7

    .line 5
    const/high16 p0, -0x40800000  # -1.0f

    .line 7
    mul-float/2addr p1, p0

    .line 8
    :cond_7
    return p1
.end method

.method public final reverseIfNeeded-MK-Hz9U(J)J
    .registers 3

    .line 1
    iget-boolean p0, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->reverseDirection:Z

    .line 3
    if-eqz p0, :cond_b

    .line 5
    const/high16 p0, -0x40800000  # -1.0f

    .line 7
    invoke-static {p0, p1, p2}, Landroidx/compose/ui/geometry/Offset;->times-tuRUvjQ(FJ)J

    .line 10
    move-result-wide p0

    .line 11
    return-wide p0

    .line 12
    :cond_b
    return-wide p1
.end method

.method public final scroll(Landroidx/compose/foundation/MutatePriority;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;
    .registers 8

    .line 1
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->scrollableState:Landroidx/compose/foundation/gestures/ScrollableState;

    .line 3
    new-instance v1, Landroidx/datastore/core/DataStoreImpl$data$1;

    .line 5
    const/4 v2, 0x0

    .line 6
    const/16 v3, 0xa

    .line 8
    invoke-direct {v1, p0, p2, v2, v3}, Landroidx/datastore/core/DataStoreImpl$data$1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 11
    invoke-interface {v0, p1, v1, p3}, Landroidx/compose/foundation/gestures/ScrollableState;->scroll(Landroidx/compose/foundation/MutatePriority;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 14
    move-result-object p0

    .line 15
    sget-object p1, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 17
    if-ne p0, p1, :cond_13

    .line 19
    return-object p0

    .line 20
    :cond_13
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 22
    return-object p0
.end method

.method public final toFloat-k-4lQ0M(J)F
    .registers 5

    .line 1
    iget-object p0, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 3
    sget-object v0, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 5
    if-ne p0, v0, :cond_10

    .line 7
    const/16 p0, 0x20

    .line 9
    shr-long p0, p1, p0

    .line 11
    :goto_a
    long-to-int p0, p0

    .line 12
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 15
    move-result p0

    .line 16
    return p0

    .line 17
    :cond_10
    const-wide v0, 0xffffffffL

    .line 22
    and-long p0, p1, v0

    .line 24
    goto :goto_a
.end method

.method public final toOffset-tuRUvjQ(F)J
    .registers 7

    .line 1
    const/4 v0, 0x0

    .line 2
    cmpg-float v1, p1, v0

    .line 4
    if-nez v1, :cond_8

    .line 6
    const-wide/16 p0, 0x0

    .line 8
    return-wide p0

    .line 9
    :cond_8
    iget-object p0, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 11
    sget-object v1, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 13
    const-wide v2, 0xffffffffL

    .line 18
    const/16 v4, 0x20

    .line 20
    if-ne p0, v1, :cond_23

    .line 22
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 25
    move-result p0

    .line 26
    int-to-long p0, p0

    .line 27
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 30
    move-result v0

    .line 31
    int-to-long v0, v0

    .line 32
    shl-long/2addr p0, v4

    .line 33
    and-long/2addr v0, v2

    .line 34
    or-long/2addr p0, v0

    .line 35
    return-wide p0

    .line 36
    :cond_23
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 39
    move-result p0

    .line 40
    int-to-long v0, p0

    .line 41
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 44
    move-result p0

    .line 45
    int-to-long p0, p0

    .line 46
    shl-long/2addr v0, v4

    .line 47
    and-long/2addr p0, v2

    .line 48
    or-long/2addr p0, v0

    .line 49
    return-wide p0
.end method

.method public final toSingleAxisDeltaFromAngle-k-4lQ0M(J)F
    .registers 8

    .line 1
    const-wide v0, 0xffffffffL

    .line 6
    and-long/2addr v0, p1

    .line 7
    long-to-int v0, v0

    .line 8
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 11
    move-result v1

    .line 12
    invoke-static {v1}, Ljava/lang/Math;->abs(F)F

    .line 15
    move-result v1

    .line 16
    const/16 v2, 0x20

    .line 18
    shr-long/2addr p1, v2

    .line 19
    long-to-int p1, p1

    .line 20
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 23
    move-result p2

    .line 24
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    .line 27
    move-result p2

    .line 28
    float-to-double v1, v1

    .line 29
    float-to-double v3, p2

    .line 30
    invoke-static {v1, v2, v3, v4}, Ljava/lang/Math;->atan2(DD)D

    .line 33
    move-result-wide v1

    .line 34
    double-to-float p2, v1

    .line 35
    float-to-double v1, p2

    .line 36
    const-wide v3, 0x3fe921fb54442d18L  # 0.7853981633974483

    .line 41
    cmpl-double p2, v1, v3

    .line 43
    iget-object p0, p0, Landroidx/compose/foundation/gestures/ScrollingLogic;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 45
    const/4 v1, 0x0

    .line 46
    if-ltz p2, :cond_39

    .line 48
    sget-object p1, Landroidx/compose/foundation/gestures/Orientation;->Vertical:Landroidx/compose/foundation/gestures/Orientation;

    .line 50
    if-ne p0, p1, :cond_38

    .line 52
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 55
    move-result p0

    .line 56
    return p0

    .line 57
    :cond_38
    return v1

    .line 58
    :cond_39
    sget-object p2, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 60
    if-ne p0, p2, :cond_42

    .line 62
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 65
    move-result p0

    .line 66
    return p0

    .line 67
    :cond_42
    return v1
.end method
