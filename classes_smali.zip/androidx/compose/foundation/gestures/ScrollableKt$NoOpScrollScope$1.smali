.class public final Landroidx/compose/foundation/gestures/ScrollableKt$NoOpScrollScope$1;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Landroidx/compose/foundation/gestures/ScrollScope;


# virtual methods
.method public final scrollBy(F)F
    .registers 2

    .line 1
    return p1
.end method
