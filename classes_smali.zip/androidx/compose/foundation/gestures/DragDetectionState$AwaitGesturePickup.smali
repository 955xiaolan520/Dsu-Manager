.class public final Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;
.super Lkotlin/math/MathKt;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

.field public pointerId:J
