.class public final Landroidx/compose/foundation/gestures/LongPressResult$Success;
.super Landroidx/compose/foundation/gestures/LongPressResult;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# static fields
.field public static final INSTANCE:Landroidx/compose/foundation/gestures/LongPressResult$Success;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 1
    new-instance v0, Landroidx/compose/foundation/gestures/LongPressResult$Success;

    .line 3
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 6
    sput-object v0, Landroidx/compose/foundation/gestures/LongPressResult$Success;->INSTANCE:Landroidx/compose/foundation/gestures/LongPressResult$Success;

    .line 8
    return-void
.end method
