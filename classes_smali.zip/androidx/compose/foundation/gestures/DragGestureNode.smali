.class public abstract Landroidx/compose/foundation/gestures/DragGestureNode;
.super Landroidx/compose/ui/node/DelegatingNode;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Landroidx/compose/ui/node/PointerInputModifierNode;
.implements Landroidx/compose/ui/input/indirect/IndirectPointerInputModifierNode;
.implements Landroidx/compose/ui/node/CompositionLocalConsumerModifierNode;


# instance fields
.field public _awaitDownState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

.field public _awaitGesturePickupState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;

.field public _awaitTouchSlopState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;

.field public _draggingState:Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

.field public canDrag:Lkotlin/jvm/functions/Function1;

.field public channel:Lkotlinx/coroutines/channels/BufferedChannel;

.field public currentDragState:Lkotlin/math/MathKt;

.field public dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

.field public enabled:Z

.field public indirectPointerInputDragCycleDetector:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

.field public interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

.field public isListeningForEvents:Z

.field public isListeningForPointerInputEvents:Z

.field public nodeOffset:J

.field public orientationLock:Landroidx/compose/foundation/gestures/Orientation;

.field public previousPositionOnScreen:J

.field public touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

.field public velocityTracker:Landroidx/compose/ui/draw/DrawResult;


# direct methods
.method public constructor <init>(Lkotlin/jvm/functions/Function1;ZLandroidx/compose/foundation/interaction/MutableInteractionSourceImpl;Landroidx/compose/foundation/gestures/Orientation;)V
    .registers 5

    .line 1
    invoke-direct {p0}, Landroidx/compose/ui/node/DelegatingNode;-><init>()V

    .line 4
    iput-object p4, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 6
    iput-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->canDrag:Lkotlin/jvm/functions/Function1;

    .line 8
    iput-boolean p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->enabled:Z

    .line 10
    iput-object p3, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 12
    const-wide p1, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 17
    iput-wide p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->previousPositionOnScreen:J

    .line 19
    const-wide/16 p1, 0x0

    .line 21
    iput-wide p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->nodeOffset:J

    .line 23
    return-void
.end method

.method public static final access$processDragCancel(Landroidx/compose/foundation/gestures/DragGestureNode;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;
    .registers 7

    .line 1
    instance-of v0, p1, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;

    .line 3
    if-eqz v0, :cond_13

    .line 5
    move-object v0, p1

    .line 6
    check-cast v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;

    .line 8
    iget v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;->label:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_13

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;->label:I

    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;

    .line 22
    invoke-direct {v0, p0, p1}, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;-><init>(Landroidx/compose/foundation/gestures/DragGestureNode;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)V

    .line 25
    :goto_18
    iget-object p1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;->result:Ljava/lang/Object;

    .line 27
    iget v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;->label:I

    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x1

    .line 31
    if-eqz v1, :cond_2c

    .line 33
    if-ne v1, v3, :cond_26

    .line 35
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 38
    goto :goto_47

    .line 39
    :cond_26
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 41
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 44
    return-object v2

    .line 45
    :cond_2c
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 48
    iget-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 50
    if-eqz p1, :cond_49

    .line 52
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 54
    if-eqz v1, :cond_47

    .line 56
    new-instance v4, Landroidx/compose/foundation/interaction/DragInteraction$Cancel;

    .line 58
    invoke-direct {v4, p1}, Landroidx/compose/foundation/interaction/DragInteraction$Cancel;-><init>(Landroidx/compose/foundation/interaction/DragInteraction$Start;)V

    .line 61
    iput v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragCancel$1;->label:I

    .line 63
    invoke-virtual {v1, v4, v0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 66
    move-result-object p1

    .line 67
    sget-object v0, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 69
    if-ne p1, v0, :cond_47

    .line 71
    return-object v0

    .line 72
    :cond_47
    :goto_47
    iput-object v2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 74
    :cond_49
    new-instance p1, Landroidx/compose/foundation/gestures/DragEvent$DragStopped;

    .line 76
    const-wide/16 v0, 0x0

    .line 78
    const/4 v2, 0x0

    .line 79
    invoke-direct {p1, v0, v1, v2}, Landroidx/compose/foundation/gestures/DragEvent$DragStopped;-><init>(JZ)V

    .line 82
    invoke-virtual {p0, p1}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragStopped(Landroidx/compose/foundation/gestures/DragEvent$DragStopped;)V

    .line 85
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 87
    return-object p0
.end method

.method public static final access$processDragStart(Landroidx/compose/foundation/gestures/DragGestureNode;Landroidx/compose/foundation/gestures/DragEvent$DragStarted;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;
    .registers 9

    .line 1
    instance-of v0, p2, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;

    .line 3
    if-eqz v0, :cond_13

    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;

    .line 8
    iget v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->label:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_13

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->label:I

    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;

    .line 22
    invoke-direct {v0, p0, p2}, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;-><init>(Landroidx/compose/foundation/gestures/DragGestureNode;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)V

    .line 25
    :goto_18
    iget-object p2, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->result:Ljava/lang/Object;

    .line 27
    iget v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->label:I

    .line 29
    const/4 v2, 0x2

    .line 30
    const/4 v3, 0x1

    .line 31
    sget-object v4, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 33
    if-eqz v1, :cond_3b

    .line 35
    if-eq v1, v3, :cond_35

    .line 37
    if-ne v1, v2, :cond_2e

    .line 39
    iget-object p1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->L$1:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 41
    iget-object v0, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->L$0:Landroidx/compose/foundation/gestures/DragEvent$DragStarted;

    .line 43
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 46
    goto :goto_6e

    .line 47
    :cond_2e
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 49
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 52
    const/4 p0, 0x0

    .line 53
    return-object p0

    .line 54
    :cond_35
    iget-object p1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->L$0:Landroidx/compose/foundation/gestures/DragEvent$DragStarted;

    .line 56
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 59
    goto :goto_56

    .line 60
    :cond_3b
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 63
    iget-object p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 65
    if-eqz p2, :cond_56

    .line 67
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 69
    if-eqz v1, :cond_56

    .line 71
    new-instance v5, Landroidx/compose/foundation/interaction/DragInteraction$Cancel;

    .line 73
    invoke-direct {v5, p2}, Landroidx/compose/foundation/interaction/DragInteraction$Cancel;-><init>(Landroidx/compose/foundation/interaction/DragInteraction$Start;)V

    .line 76
    iput-object p1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->L$0:Landroidx/compose/foundation/gestures/DragEvent$DragStarted;

    .line 78
    iput v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->label:I

    .line 80
    invoke-virtual {v1, v5, v0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 83
    move-result-object p2

    .line 84
    if-ne p2, v4, :cond_56

    .line 86
    goto :goto_6b

    .line 87
    :cond_56
    :goto_56
    new-instance p2, Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 89
    invoke-direct {p2}, Ljava/lang/Object;-><init>()V

    .line 92
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 94
    if-eqz v1, :cond_70

    .line 96
    iput-object p1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->L$0:Landroidx/compose/foundation/gestures/DragEvent$DragStarted;

    .line 98
    iput-object p2, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->L$1:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 100
    iput v2, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStart$1;->label:I

    .line 102
    invoke-virtual {v1, p2, v0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 105
    move-result-object v0

    .line 106
    if-ne v0, v4, :cond_6c

    .line 108
    :goto_6b
    return-object v4

    .line 109
    :cond_6c
    move-object v0, p1

    .line 110
    move-object p1, p2

    .line 111
    :goto_6e
    move-object p2, p1

    .line 112
    move-object p1, v0

    .line 113
    :cond_70
    iput-object p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 115
    iget-wide p1, p1, Landroidx/compose/foundation/gestures/DragEvent$DragStarted;->startPoint:J

    .line 117
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragStarted-k-4lQ0M(J)V

    .line 120
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 122
    return-object p0
.end method

.method public static final access$processDragStop(Landroidx/compose/foundation/gestures/DragGestureNode;Landroidx/compose/foundation/gestures/DragEvent$DragStopped;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;
    .registers 8

    .line 1
    instance-of v0, p2, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;

    .line 3
    if-eqz v0, :cond_13

    .line 5
    move-object v0, p2

    .line 6
    check-cast v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;

    .line 8
    iget v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;->label:I

    .line 10
    const/high16 v2, -0x80000000

    .line 12
    and-int v3, v1, v2

    .line 14
    if-eqz v3, :cond_13

    .line 16
    sub-int/2addr v1, v2

    .line 17
    iput v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;->label:I

    .line 19
    goto :goto_18

    .line 20
    :cond_13
    new-instance v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;

    .line 22
    invoke-direct {v0, p0, p2}, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;-><init>(Landroidx/compose/foundation/gestures/DragGestureNode;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)V

    .line 25
    :goto_18
    iget-object p2, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;->result:Ljava/lang/Object;

    .line 27
    iget v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;->label:I

    .line 29
    const/4 v2, 0x0

    .line 30
    const/4 v3, 0x1

    .line 31
    if-eqz v1, :cond_2e

    .line 33
    if-ne v1, v3, :cond_28

    .line 35
    iget-object p1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;->L$0:Landroidx/compose/foundation/gestures/DragEvent$DragStopped;

    .line 37
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 40
    goto :goto_4b

    .line 41
    :cond_28
    const-string p0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 43
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 46
    return-object v2

    .line 47
    :cond_2e
    invoke-static {p2}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 50
    iget-object p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 52
    if-eqz p2, :cond_4d

    .line 54
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 56
    if-eqz v1, :cond_4b

    .line 58
    new-instance v4, Landroidx/compose/foundation/interaction/DragInteraction$Stop;

    .line 60
    invoke-direct {v4, p2}, Landroidx/compose/foundation/interaction/DragInteraction$Stop;-><init>(Landroidx/compose/foundation/interaction/DragInteraction$Start;)V

    .line 63
    iput-object p1, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;->L$0:Landroidx/compose/foundation/gestures/DragEvent$DragStopped;

    .line 65
    iput v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode$processDragStop$1;->label:I

    .line 67
    invoke-virtual {v1, v4, v0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 70
    move-result-object p2

    .line 71
    sget-object v0, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 73
    if-ne p2, v0, :cond_4b

    .line 75
    return-object v0

    .line 76
    :cond_4b
    :goto_4b
    iput-object v2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 78
    :cond_4d
    invoke-virtual {p0, p1}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragStopped(Landroidx/compose/foundation/gestures/DragEvent$DragStopped;)V

    .line 81
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 83
    return-object p0
.end method

.method public static moveToAwaitTouchSlopState-aWI9W7U$default(Landroidx/compose/foundation/gestures/DragGestureNode;Landroidx/compose/ui/input/pointer/PointerInputChange;JJI)V
    .registers 10

    .line 1
    and-int/lit8 p6, p6, 0x4

    .line 3
    if-eqz p6, :cond_6

    .line 5
    const-wide/16 p4, 0x0

    .line 7
    :cond_6
    iget-object p6, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitTouchSlopState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;

    .line 9
    const/4 v0, 0x0

    .line 10
    if-nez p6, :cond_1e

    .line 12
    new-instance p6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;

    .line 14
    invoke-direct {p6}, Ljava/lang/Object;-><init>()V

    .line 17
    const/4 v1, 0x0

    .line 18
    iput-object v1, p6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 20
    const-wide v1, 0x7fffffffffffffffL

    .line 25
    iput-wide v1, p6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 27
    iput-boolean v0, p6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 29
    iput-object p6, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitTouchSlopState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;

    .line 31
    :cond_1e
    iput-object p1, p6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 33
    iput-wide p2, p6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 35
    iget-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 37
    iget-object p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 39
    if-nez p1, :cond_30

    .line 41
    new-instance p1, Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 43
    invoke-direct {p1, p2}, Landroidx/compose/foundation/gestures/TouchSlopDetector;-><init>(Landroidx/compose/foundation/gestures/Orientation;)V

    .line 46
    iput-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 48
    goto :goto_34

    .line 49
    :cond_30
    iput-object p2, p1, Landroidx/compose/foundation/gestures/TouchSlopDetector;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 51
    iput-wide p4, p1, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 53
    :goto_34
    iput-boolean v0, p6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 55
    iput-object p6, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 57
    return-void
.end method


# virtual methods
.method public final disposeInteractionSource$1()V
    .registers 4

    .line 1
    iget-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 3
    if-eqz v0, :cond_13

    .line 5
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 7
    if-eqz v1, :cond_10

    .line 9
    new-instance v2, Landroidx/compose/foundation/interaction/DragInteraction$Cancel;

    .line 11
    invoke-direct {v2, v0}, Landroidx/compose/foundation/interaction/DragInteraction$Cancel;-><init>(Landroidx/compose/foundation/interaction/DragInteraction$Start;)V

    .line 14
    invoke-virtual {v1, v2}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->tryEmit(Landroidx/compose/foundation/interaction/Interaction;)V

    .line 17
    :cond_10
    const/4 v0, 0x0

    .line 18
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->dragInteraction:Landroidx/compose/foundation/interaction/DragInteraction$Start;

    .line 20
    :cond_13
    return-void
.end method

.method public abstract drag(Landroidx/compose/foundation/gestures/DragGestureNode$startListeningForEvents$1;Landroidx/compose/foundation/gestures/DragGestureNode$startListeningForEvents$1;)Ljava/lang/Object;
.end method

.method public final moveToAwaitDownState()V
    .registers 4

    .line 1
    iget-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitDownState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 3
    const/4 v1, 0x0

    .line 4
    sget-object v2, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;->NotInitialized:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 6
    if-nez v0, :cond_12

    .line 8
    new-instance v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 10
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 13
    iput-object v2, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 15
    iput-boolean v1, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 17
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitDownState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 19
    :cond_12
    iput-object v2, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 21
    iput-boolean v1, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 23
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 25
    return-void
.end method

.method public final moveToAwaitGesturePickupState-rnUCldI(Landroidx/compose/ui/input/pointer/PointerInputChange;JLandroidx/compose/foundation/gestures/TouchSlopDetector;)V
    .registers 8

    .line 1
    iget-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitGesturePickupState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;

    .line 3
    if-nez v0, :cond_15

    .line 5
    new-instance v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;

    .line 7
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 10
    const/4 v1, 0x0

    .line 11
    iput-object v1, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 13
    const-wide v1, 0x7fffffffffffffffL

    .line 18
    iput-wide v1, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;->pointerId:J

    .line 20
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitGesturePickupState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;

    .line 22
    :cond_15
    iput-object p1, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 24
    iput-wide p2, v0, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;->pointerId:J

    .line 26
    const-wide/16 p1, 0x0

    .line 28
    iput-wide p1, p4, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 30
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 32
    return-void
.end method

.method public final onCancelIndirectPointerInput()V
    .registers 3

    .line 1
    iget-object p0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->indirectPointerInputDragCycleDetector:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

    .line 3
    if-eqz p0, :cond_1f

    .line 5
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitDownState()V

    .line 8
    iget-object v0, p0, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->node:Landroidx/compose/foundation/gestures/DragGestureNode;

    .line 10
    iget-boolean v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 12
    if-eqz v1, :cond_12

    .line 14
    sget-object v1, Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;->INSTANCE:Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;

    .line 16
    invoke-virtual {v0, v1}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragEvent(Landroidx/compose/foundation/gestures/DragEvent;)V

    .line 19
    :cond_12
    const/4 v0, 0x0

    .line 20
    iput-object v0, p0, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->velocityTracker:Landroidx/compose/ui/draw/DrawResult;

    .line 22
    iget-object p0, p0, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->offsetSmoother:Landroidx/compose/foundation/gestures/OffsetSmoother;

    .line 24
    const/4 v0, 0x0

    .line 25
    iput v0, p0, Landroidx/compose/foundation/gestures/OffsetSmoother;->eventRotatingIndex:I

    .line 27
    iget-object p0, p0, Landroidx/compose/foundation/gestures/OffsetSmoother;->eventRotatingArray:Ljava/util/ArrayList;

    .line 29
    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    .line 32
    :cond_1f
    return-void
.end method

.method public final onCancelPointerInput()V
    .registers 3

    .line 1
    iget-boolean v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForPointerInputEvents:Z

    .line 3
    if-eqz v0, :cond_17

    .line 5
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitDownState()V

    .line 8
    iget-boolean v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 10
    if-eqz v0, :cond_14

    .line 12
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 15
    move-result-object v0

    .line 16
    sget-object v1, Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;->INSTANCE:Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;

    .line 18
    invoke-interface {v0, v1}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    :cond_14
    const/4 v0, 0x0

    .line 22
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->velocityTracker:Landroidx/compose/ui/draw/DrawResult;

    .line 24
    :cond_17
    const/4 v0, 0x0

    .line 25
    iput-boolean v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForPointerInputEvents:Z

    .line 27
    return-void
.end method

.method public final onDetach()V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    iput-boolean v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 4
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->disposeInteractionSource$1()V

    .line 7
    const-wide/16 v0, 0x0

    .line 9
    iput-wide v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->nodeOffset:J

    .line 11
    return-void
.end method

.method public final onDragEvent(Landroidx/compose/foundation/gestures/DragEvent;)V
    .registers 3

    .line 1
    instance-of v0, p1, Landroidx/compose/foundation/gestures/DragEvent$DragStarted;

    .line 3
    if-eqz v0, :cond_e

    .line 5
    iget-boolean v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 7
    if-nez v0, :cond_e

    .line 9
    const/4 v0, 0x1

    .line 10
    iput-boolean v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 12
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->startListeningForEvents()V

    .line 15
    :cond_e
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 18
    move-result-object p0

    .line 19
    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    return-void
.end method

.method public abstract onDragStarted-k-4lQ0M(J)V
.end method

.method public abstract onDragStopped(Landroidx/compose/foundation/gestures/DragEvent$DragStopped;)V
.end method

.method public final onIndirectPointerEvent(Landroidx/compose/ui/spatial/RectList;Landroidx/compose/ui/input/pointer/PointerEventPass;)V
    .registers 29

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    move-object/from16 v2, p2

    .line 7
    iget v3, v1, Landroidx/compose/ui/spatial/RectList;->itemsSize:I

    .line 9
    iget-object v1, v1, Landroidx/compose/ui/spatial/RectList;->items:Ljava/lang/Object;

    .line 11
    check-cast v1, Ljava/util/ArrayList;

    .line 13
    iget-boolean v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->enabled:Z

    .line 15
    if-eqz v4, :cond_3f0

    .line 17
    iget-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->indirectPointerInputDragCycleDetector:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

    .line 19
    if-nez v4, :cond_1b

    .line 21
    new-instance v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

    .line 23
    invoke-direct {v4, v0}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;-><init>(Landroidx/compose/foundation/gestures/DragGestureNode;)V

    .line 26
    iput-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->indirectPointerInputDragCycleDetector:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

    .line 28
    :cond_1b
    iget-object v5, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->indirectPointerInputDragCycleDetector:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

    .line 30
    if-eqz v5, :cond_3f0

    .line 32
    iget-object v0, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->node:Landroidx/compose/foundation/gestures/DragGestureNode;

    .line 34
    iget-object v4, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->currentDragState:Lkotlin/math/MathKt;

    .line 36
    const/4 v11, 0x0

    .line 37
    if-nez v4, :cond_39

    .line 39
    iget-object v4, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->_awaitDownState:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;

    .line 41
    if-nez v4, :cond_37

    .line 43
    new-instance v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;

    .line 45
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 48
    sget-object v6, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;->NotInitialized:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 50
    iput-object v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 52
    iput-boolean v11, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 54
    iput-object v4, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->_awaitDownState:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;

    .line 56
    :cond_37
    iput-object v4, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->currentDragState:Lkotlin/math/MathKt;

    .line 58
    :cond_39
    iget-object v4, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->currentDragState:Lkotlin/math/MathKt;

    .line 60
    if-eqz v4, :cond_3eb

    .line 62
    instance-of v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;

    .line 64
    sget-object v7, Landroidx/compose/ui/input/pointer/PointerEventPass;->Initial:Landroidx/compose/ui/input/pointer/PointerEventPass;

    .line 66
    const/4 v8, 0x1

    .line 67
    const-wide/16 v14, 0x0

    .line 69
    sget-object v9, Landroidx/compose/ui/input/pointer/PointerEventPass;->Main:Landroidx/compose/ui/input/pointer/PointerEventPass;

    .line 71
    if-eqz v6, :cond_d5

    .line 73
    check-cast v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;

    .line 75
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 78
    move-result v6

    .line 79
    if-eqz v6, :cond_52

    .line 81
    goto/16 :goto_3f0

    .line 83
    :cond_52
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 86
    move-result v6

    .line 87
    :goto_56
    if-ge v11, v6, :cond_6a

    .line 89
    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 92
    move-result-object v10

    .line 93
    check-cast v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 95
    iget-boolean v12, v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->previousPressed:Z

    .line 97
    if-nez v12, :cond_69

    .line 99
    iget-boolean v10, v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->pressed:Z

    .line 101
    if-eqz v10, :cond_69

    .line 103
    add-int/lit8 v11, v11, 0x1

    .line 105
    goto :goto_56

    .line 106
    :cond_69
    return-void

    .line 107
    :cond_6a
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 110
    move-result-object v1

    .line 111
    move-object v6, v1

    .line 112
    check-cast v6, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 114
    iget-object v1, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 116
    sget-object v10, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 118
    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    .line 121
    move-result v1

    .line 122
    aget v1, v10, v1

    .line 124
    sget-object v10, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;->No:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 126
    sget-object v11, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;->Yes:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 128
    if-ne v1, v8, :cond_8b

    .line 130
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->startDragImmediately()Z

    .line 133
    move-result v0

    .line 134
    if-nez v0, :cond_89

    .line 136
    move-object v0, v11

    .line 137
    goto :goto_8d

    .line 138
    :cond_89
    move-object v0, v10

    .line 139
    goto :goto_8d

    .line 140
    :cond_8b
    iget-object v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 142
    :goto_8d
    iput-object v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 144
    if-ne v2, v7, :cond_97

    .line 146
    if-ne v0, v10, :cond_97

    .line 148
    iput-boolean v8, v6, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 150
    iput-boolean v8, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 152
    :cond_97
    if-ne v2, v9, :cond_3f0

    .line 154
    if-ne v0, v11, :cond_a5

    .line 156
    iget-wide v7, v6, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 158
    const-wide/16 v9, 0x0

    .line 160
    const/16 v11, 0xc

    .line 162
    invoke-static/range {v5 .. v11}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitTouchSlopState-aWI9W7U$default(Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;JJI)V

    .line 165
    return-void

    .line 166
    :cond_a5
    iget-boolean v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 168
    if-eqz v0, :cond_3f0

    .line 170
    new-instance v8, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 172
    invoke-direct {v8, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 175
    const-wide/16 v9, 0x0

    .line 177
    move-object v7, v6

    .line 178
    invoke-virtual/range {v5 .. v10}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->sendDragStart-3f7A7Is(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;J)V

    .line 181
    new-instance v0, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 183
    invoke-direct {v0, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 186
    invoke-virtual {v5, v6, v0, v14, v15}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->sendDragEvent-Eu1f8Dk(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;J)V

    .line 189
    iget-wide v0, v6, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 191
    iget-object v2, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->_draggingState:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 193
    if-nez v2, :cond_d0

    .line 195
    new-instance v2, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 197
    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    .line 200
    const-wide v3, 0x7fffffffffffffffL

    .line 205
    iput-wide v3, v2, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;->pointerId:J

    .line 207
    iput-object v2, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->_draggingState:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 209
    :cond_d0
    iput-wide v0, v2, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;->pointerId:J

    .line 211
    iput-object v2, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->currentDragState:Lkotlin/math/MathKt;

    .line 213
    return-void

    .line 214
    :cond_d5
    instance-of v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;

    .line 216
    sget-object v12, Landroidx/compose/ui/input/pointer/PointerEventPass;->Final:Landroidx/compose/ui/input/pointer/PointerEventPass;

    .line 218
    if-eqz v6, :cond_25e

    .line 220
    check-cast v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;

    .line 222
    if-ne v2, v7, :cond_e1

    .line 224
    goto/16 :goto_3f0

    .line 226
    :cond_e1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 229
    move-result v6

    .line 230
    move v7, v11

    .line 231
    :goto_e6
    if-ge v7, v6, :cond_104

    .line 233
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 236
    move-result-object v14

    .line 237
    move-object v15, v14

    .line 238
    check-cast v15, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 240
    move-object/from16 v17, v14

    .line 242
    iget-wide v13, v15, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 244
    const/16 v18, 0x0

    .line 246
    iget-wide v10, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 248
    invoke-static {v13, v14, v10, v11}, Landroidx/compose/ui/input/pointer/PointerId;->equals-impl0(JJ)Z

    .line 251
    move-result v10

    .line 252
    if-eqz v10, :cond_100

    .line 254
    move-object/from16 v14, v17

    .line 256
    goto :goto_107

    .line 257
    :cond_100
    add-int/lit8 v7, v7, 0x1

    .line 259
    const/4 v11, 0x0

    .line 260
    goto :goto_e6

    .line 261
    :cond_104
    const/16 v18, 0x0

    .line 263
    const/4 v14, 0x0

    .line 264
    :goto_107
    check-cast v14, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 266
    if-nez v14, :cond_12f

    .line 268
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 271
    move-result v6

    .line 272
    const/4 v7, 0x0

    .line 273
    :goto_110
    if-ge v7, v6, :cond_121

    .line 275
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 278
    move-result-object v10

    .line 279
    move-object v11, v10

    .line 280
    check-cast v11, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 282
    iget-boolean v11, v11, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->pressed:Z

    .line 284
    if-eqz v11, :cond_11e

    .line 286
    goto :goto_122

    .line 287
    :cond_11e
    add-int/lit8 v7, v7, 0x1

    .line 289
    goto :goto_110

    .line 290
    :cond_121
    const/4 v10, 0x0

    .line 291
    :goto_122
    move-object v14, v10

    .line 292
    check-cast v14, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 294
    if-nez v14, :cond_12b

    .line 296
    invoke-virtual {v5}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitDownState()V

    .line 299
    return-void

    .line 300
    :cond_12b
    iget-wide v6, v14, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 302
    iput-wide v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 304
    :cond_12f
    move-object v7, v14

    .line 305
    const-string v11, "AwaitTouchSlop.touchSlopDetector was not initialized"

    .line 307
    const-string v13, "AwaitTouchSlop.initialDown was not initialized"

    .line 309
    if-ne v2, v9, :cond_23a

    .line 311
    iget-boolean v6, v7, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 313
    if-nez v6, :cond_224

    .line 315
    invoke-static {v7}, Lkotlin/math/MathKt;->access$changedToUpIgnoreConsumed(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;)Z

    .line 318
    move-result v6

    .line 319
    if-eqz v6, :cond_16b

    .line 321
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 324
    move-result v0

    .line 325
    const/4 v3, 0x0

    .line 326
    :goto_145
    if-ge v3, v0, :cond_158

    .line 328
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 331
    move-result-object v6

    .line 332
    move-object v8, v6

    .line 333
    check-cast v8, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 335
    iget-boolean v8, v8, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->pressed:Z

    .line 337
    if-eqz v8, :cond_155

    .line 339
    move-object/from16 v16, v6

    .line 341
    goto :goto_15a

    .line 342
    :cond_155
    add-int/lit8 v3, v3, 0x1

    .line 344
    goto :goto_145

    .line 345
    :cond_158
    const/16 v16, 0x0

    .line 347
    :goto_15a
    move-object/from16 v0, v16

    .line 349
    check-cast v0, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 351
    if-nez v0, :cond_165

    .line 353
    invoke-virtual {v5}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitDownState()V

    .line 356
    goto/16 :goto_23a

    .line 358
    :cond_165
    iget-wide v0, v0, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 360
    iput-wide v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 362
    goto/16 :goto_23a

    .line 364
    :cond_16b
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalViewConfiguration:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 366
    invoke-static {v0, v1}, Landroidx/compose/ui/node/HitTestResultKt;->currentValueOf(Landroidx/compose/ui/node/CompositionLocalConsumerModifierNode;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 369
    move-result-object v1

    .line 370
    check-cast v1, Landroidx/compose/ui/platform/ViewConfiguration;

    .line 372
    sget v6, Landroidx/compose/foundation/gestures/DragGestureDetectorKt;->mouseToTouchSlopRatio:F

    .line 374
    invoke-interface {v1}, Landroidx/compose/ui/platform/ViewConfiguration;->getTouchSlop()F

    .line 377
    move-result v20

    .line 378
    iget-object v1, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 380
    if-eqz v1, :cond_21e

    .line 382
    iget-object v6, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 384
    new-instance v9, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 386
    invoke-direct {v9, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 389
    invoke-static {v7, v6, v9}, Lkotlin/math/MathKt;->primaryAxisPosition-_bfSUIo(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;)J

    .line 392
    move-result-wide v21

    .line 393
    iget-object v0, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 395
    iget-wide v9, v7, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->previousPosition:J

    .line 397
    if-nez v0, :cond_193

    .line 399
    :cond_18e
    :goto_18e
    move-object/from16 v19, v1

    .line 401
    move-wide/from16 v23, v9

    .line 403
    goto :goto_1d8

    .line 404
    :cond_193
    const-wide v14, 0xffffffffL

    .line 409
    const/16 v6, 0x20

    .line 411
    if-ne v3, v8, :cond_1a5

    .line 413
    shr-long/2addr v9, v6

    .line 414
    long-to-int v9, v9

    .line 415
    invoke-static {v9}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 418
    move-result v9

    .line 419
    move/from16 v16, v6

    .line 421
    goto :goto_1b0

    .line 422
    :cond_1a5
    move/from16 v16, v6

    .line 424
    const/4 v6, 0x2

    .line 425
    if-ne v3, v6, :cond_18e

    .line 427
    and-long/2addr v9, v14

    .line 428
    long-to-int v6, v9

    .line 429
    invoke-static {v6}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 432
    move-result v9

    .line 433
    :goto_1b0
    sget-object v6, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 435
    if-ne v0, v6, :cond_1c6

    .line 437
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 440
    move-result v0

    .line 441
    int-to-long v9, v0

    .line 442
    invoke-static/range {v18 .. v18}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 445
    move-result v0

    .line 446
    move-wide/from16 v23, v14

    .line 448
    int-to-long v14, v0

    .line 449
    shl-long v9, v9, v16

    .line 451
    and-long v14, v14, v23

    .line 453
    or-long/2addr v9, v14

    .line 454
    goto :goto_18e

    .line 455
    :cond_1c6
    move-wide/from16 v23, v14

    .line 457
    invoke-static/range {v18 .. v18}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 460
    move-result v0

    .line 461
    int-to-long v14, v0

    .line 462
    invoke-static {v9}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 465
    move-result v0

    .line 466
    int-to-long v9, v0

    .line 467
    shl-long v14, v14, v16

    .line 469
    and-long v9, v9, v23

    .line 471
    or-long/2addr v9, v14

    .line 472
    goto :goto_18e

    .line 473
    :goto_1d8
    invoke-virtual/range {v19 .. v24}, Landroidx/compose/foundation/gestures/TouchSlopDetector;->addPositions-akrDWew(FJJ)J

    .line 476
    move-result-wide v9

    .line 477
    const-wide v0, 0x7fffffff7fffffffL

    .line 482
    and-long/2addr v0, v9

    .line 483
    const-wide v14, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 488
    cmp-long v0, v0, v14

    .line 490
    if-eqz v0, :cond_21b

    .line 492
    iput-boolean v8, v7, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 494
    iget-object v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 496
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 499
    new-instance v8, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 501
    invoke-direct {v8, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 504
    invoke-virtual/range {v5 .. v10}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->sendDragStart-3f7A7Is(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;J)V

    .line 507
    new-instance v0, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 509
    invoke-direct {v0, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 512
    invoke-virtual {v5, v7, v0, v9, v10}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->sendDragEvent-Eu1f8Dk(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;J)V

    .line 515
    iget-wide v0, v7, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 517
    iget-object v3, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->_draggingState:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 519
    if-nez v3, :cond_216

    .line 521
    new-instance v3, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 523
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 526
    const-wide v8, 0x7fffffffffffffffL

    .line 531
    iput-wide v8, v3, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;->pointerId:J

    .line 533
    iput-object v3, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->_draggingState:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 535
    :cond_216
    iput-wide v0, v3, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;->pointerId:J

    .line 537
    iput-object v3, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->currentDragState:Lkotlin/math/MathKt;

    .line 539
    goto :goto_23a

    .line 540
    :cond_21b
    iput-boolean v8, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 542
    goto :goto_23a

    .line 543
    :cond_21e
    const-string v0, "Touch slop detector not initialized."

    .line 545
    invoke-static {v0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 548
    return-void

    .line 549
    :cond_224
    iget-object v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 551
    if-eqz v0, :cond_236

    .line 553
    iget-wide v8, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 555
    iget-object v1, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 557
    if-eqz v1, :cond_232

    .line 559
    invoke-virtual {v5, v0, v8, v9, v1}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitGesturePickupState-rnUCldI(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;JLandroidx/compose/foundation/gestures/TouchSlopDetector;)V

    .line 562
    goto :goto_23a

    .line 563
    :cond_232
    invoke-static {v11}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 566
    return-void

    .line 567
    :cond_236
    invoke-static {v13}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 570
    return-void

    .line 571
    :cond_23a
    :goto_23a
    if-ne v2, v12, :cond_3f0

    .line 573
    iget-boolean v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 575
    if-eqz v0, :cond_3f0

    .line 577
    iget-boolean v0, v7, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 579
    if-eqz v0, :cond_25a

    .line 581
    iget-object v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 583
    if-eqz v0, :cond_256

    .line 585
    iget-wide v1, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 587
    iget-object v3, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 589
    if-eqz v3, :cond_252

    .line 591
    invoke-virtual {v5, v0, v1, v2, v3}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitGesturePickupState-rnUCldI(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;JLandroidx/compose/foundation/gestures/TouchSlopDetector;)V

    .line 594
    return-void

    .line 595
    :cond_252
    invoke-static {v11}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 598
    return-void

    .line 599
    :cond_256
    invoke-static {v13}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 602
    return-void

    .line 603
    :cond_25a
    const/4 v0, 0x0

    .line 604
    iput-boolean v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 606
    return-void

    .line 607
    :cond_25e
    const/16 v18, 0x0

    .line 609
    instance-of v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitGesturePickup;

    .line 611
    if-eqz v6, :cond_2d8

    .line 613
    check-cast v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitGesturePickup;

    .line 615
    if-eq v2, v12, :cond_26a

    .line 617
    goto/16 :goto_3f0

    .line 619
    :cond_26a
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 622
    move-result v2

    .line 623
    const/4 v6, 0x0

    .line 624
    :goto_26f
    if-ge v6, v2, :cond_280

    .line 626
    invoke-virtual {v1, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 629
    move-result-object v7

    .line 630
    check-cast v7, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 632
    iget-boolean v7, v7, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 634
    if-eqz v7, :cond_27d

    .line 636
    const/4 v8, 0x0

    .line 637
    goto :goto_280

    .line 638
    :cond_27d
    add-int/lit8 v6, v6, 0x1

    .line 640
    goto :goto_26f

    .line 641
    :cond_280
    :goto_280
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 644
    move-result v2

    .line 645
    const/4 v11, 0x0

    .line 646
    :goto_285
    if-ge v11, v2, :cond_2d4

    .line 648
    invoke-virtual {v1, v11}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 651
    move-result-object v6

    .line 652
    check-cast v6, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 654
    iget-boolean v6, v6, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->pressed:Z

    .line 656
    if-eqz v6, :cond_2d1

    .line 658
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 661
    move-result v2

    .line 662
    if-eqz v2, :cond_298

    .line 664
    goto :goto_2d4

    .line 665
    :cond_298
    if-eqz v8, :cond_3f0

    .line 667
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 670
    move-result-object v1

    .line 671
    check-cast v1, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 673
    iget-object v2, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 675
    new-instance v6, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 677
    invoke-direct {v6, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 680
    invoke-static {v1, v2, v6}, Lkotlin/math/MathKt;->primaryAxisPosition-_bfSUIo(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;)J

    .line 683
    move-result-wide v1

    .line 684
    iget-object v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitGesturePickup;->initialDown:Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 686
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 689
    iget-object v0, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 691
    new-instance v7, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 693
    invoke-direct {v7, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 696
    invoke-static {v6, v0, v7}, Lkotlin/math/MathKt;->primaryAxisPosition-_bfSUIo(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;)J

    .line 699
    move-result-wide v6

    .line 700
    invoke-static {v1, v2, v6, v7}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 703
    move-result-wide v9

    .line 704
    iget-object v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitGesturePickup;->initialDown:Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 706
    if-eqz v6, :cond_2cb

    .line 708
    iget-wide v7, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$AwaitGesturePickup;->pointerId:J

    .line 710
    const/16 v11, 0x8

    .line 712
    invoke-static/range {v5 .. v11}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitTouchSlopState-aWI9W7U$default(Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;JJI)V

    .line 715
    return-void

    .line 716
    :cond_2cb
    const-string v0, "AwaitGesturePickup.initialDown was not initialized."

    .line 718
    invoke-static {v0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 721
    return-void

    .line 722
    :cond_2d1
    add-int/lit8 v11, v11, 0x1

    .line 724
    goto :goto_285

    .line 725
    :cond_2d4
    :goto_2d4
    invoke-virtual {v5}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitDownState()V

    .line 728
    return-void

    .line 729
    :cond_2d8
    instance-of v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 731
    if-eqz v6, :cond_3e7

    .line 733
    check-cast v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;

    .line 735
    if-eq v2, v9, :cond_2e2

    .line 737
    goto/16 :goto_3f0

    .line 739
    :cond_2e2
    iget-wide v6, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;->pointerId:J

    .line 741
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 744
    move-result v2

    .line 745
    const/4 v9, 0x0

    .line 746
    :goto_2e9
    if-ge v9, v2, :cond_2fe

    .line 748
    invoke-virtual {v1, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 751
    move-result-object v10

    .line 752
    move-object v11, v10

    .line 753
    check-cast v11, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 755
    iget-wide v11, v11, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 757
    invoke-static {v11, v12, v6, v7}, Landroidx/compose/ui/input/pointer/PointerId;->equals-impl0(JJ)Z

    .line 760
    move-result v11

    .line 761
    if-eqz v11, :cond_2fb

    .line 763
    goto :goto_2ff

    .line 764
    :cond_2fb
    add-int/lit8 v9, v9, 0x1

    .line 766
    goto :goto_2e9

    .line 767
    :cond_2fe
    const/4 v10, 0x0

    .line 768
    :goto_2ff
    check-cast v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 770
    if-nez v10, :cond_305

    .line 772
    goto/16 :goto_3f0

    .line 774
    :cond_305
    invoke-static {v10}, Lkotlin/math/MathKt;->access$changedToUpIgnoreConsumed(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;)Z

    .line 777
    move-result v2

    .line 778
    sget-object v6, Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;->INSTANCE:Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;

    .line 780
    if-eqz v2, :cond_39f

    .line 782
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 785
    move-result v2

    .line 786
    const/4 v7, 0x0

    .line 787
    :goto_312
    if-ge v7, v2, :cond_323

    .line 789
    invoke-virtual {v1, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 792
    move-result-object v9

    .line 793
    move-object v11, v9

    .line 794
    check-cast v11, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 796
    iget-boolean v11, v11, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->pressed:Z

    .line 798
    if-eqz v11, :cond_320

    .line 800
    goto :goto_324

    .line 801
    :cond_320
    add-int/lit8 v7, v7, 0x1

    .line 803
    goto :goto_312

    .line 804
    :cond_323
    const/4 v9, 0x0

    .line 805
    :goto_324
    check-cast v9, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;

    .line 807
    if-nez v9, :cond_39a

    .line 809
    iget-boolean v1, v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 811
    if-nez v1, :cond_393

    .line 813
    invoke-static {v10}, Lkotlin/math/MathKt;->access$changedToUpIgnoreConsumed(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;)Z

    .line 816
    move-result v1

    .line 817
    if-eqz v1, :cond_393

    .line 819
    new-instance v1, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 821
    invoke-direct {v1, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 824
    invoke-virtual {v5}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 827
    move-result-object v19

    .line 828
    iget-object v2, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 830
    iget-object v3, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->touchSmooth:Landroidx/compose/foundation/gestures/OffsetSmoother;

    .line 832
    iget-wide v6, v5, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->nodeOffset:J

    .line 834
    move-object/from16 v22, v1

    .line 836
    move-object/from16 v21, v2

    .line 838
    move-object/from16 v23, v3

    .line 840
    move-wide/from16 v24, v6

    .line 842
    move-object/from16 v20, v10

    .line 844
    invoke-static/range {v19 .. v25}, Lkotlin/math/MathKt;->access$addIndirectPointerInputChange-Qf4Zb88(Landroidx/compose/ui/draw/DrawResult;Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;Landroidx/compose/foundation/gestures/OffsetSmoother;J)V

    .line 847
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalViewConfiguration:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 849
    invoke-static {v0, v1}, Landroidx/compose/ui/node/HitTestResultKt;->currentValueOf(Landroidx/compose/ui/node/CompositionLocalConsumerModifierNode;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 852
    move-result-object v1

    .line 853
    check-cast v1, Landroidx/compose/ui/platform/ViewConfiguration;

    .line 855
    invoke-interface {v1}, Landroidx/compose/ui/platform/ViewConfiguration;->getMaximumFlingVelocity()F

    .line 858
    move-result v1

    .line 859
    invoke-virtual {v5}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 862
    move-result-object v2

    .line 863
    invoke-static {v1, v1}, Landroidx/core/os/BundleKt;->Velocity(FF)J

    .line 866
    move-result-wide v3

    .line 867
    invoke-virtual {v2, v3, v4}, Landroidx/compose/ui/draw/DrawResult;->calculateVelocity-AH228Gc(J)J

    .line 870
    move-result-wide v1

    .line 871
    invoke-virtual {v5}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 874
    move-result-object v3

    .line 875
    iget-object v3, v3, Landroidx/compose/ui/draw/DrawResult;->block:Ljava/lang/Object;

    .line 877
    check-cast v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;

    .line 879
    iget-object v4, v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;->xVelocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 881
    iget-object v6, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->samples:[Landroidx/compose/ui/input/pointer/util/DataPointAtTime;

    .line 883
    array-length v7, v6

    .line 884
    const/4 v9, 0x0

    .line 885
    const/4 v10, 0x0

    .line 886
    invoke-static {v6, v10, v7, v9}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 889
    iput v10, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->index:I

    .line 891
    iget-object v4, v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;->yVelocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 893
    iget-object v6, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->samples:[Landroidx/compose/ui/input/pointer/util/DataPointAtTime;

    .line 895
    array-length v7, v6

    .line 896
    invoke-static {v6, v10, v7, v9}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 899
    iput v10, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->index:I

    .line 901
    iput-wide v14, v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;->lastMoveEventTimeStamp:J

    .line 903
    new-instance v3, Landroidx/compose/foundation/gestures/DragEvent$DragStopped;

    .line 905
    invoke-static {v1, v2}, Landroidx/compose/foundation/gestures/DraggableKt;->toValidVelocity-TH1AsA0(J)J

    .line 908
    move-result-wide v1

    .line 909
    invoke-direct {v3, v1, v2, v8}, Landroidx/compose/foundation/gestures/DragEvent$DragStopped;-><init>(JZ)V

    .line 912
    invoke-virtual {v0, v3}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragEvent(Landroidx/compose/foundation/gestures/DragEvent;)V

    .line 915
    goto :goto_396

    .line 916
    :cond_393
    invoke-virtual {v0, v6}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragEvent(Landroidx/compose/foundation/gestures/DragEvent;)V

    .line 919
    :goto_396
    invoke-virtual {v5}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitDownState()V

    .line 922
    return-void

    .line 923
    :cond_39a
    iget-wide v0, v9, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->id:J

    .line 925
    iput-wide v0, v4, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector$DragDetectionState$Dragging;->pointerId:J

    .line 927
    return-void

    .line 928
    :cond_39f
    iget-boolean v1, v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 930
    if-eqz v1, :cond_3a7

    .line 932
    invoke-virtual {v0, v6}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragEvent(Landroidx/compose/foundation/gestures/DragEvent;)V

    .line 935
    return-void

    .line 936
    :cond_3a7
    iget-object v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 938
    new-instance v2, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 940
    invoke-direct {v2, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 943
    invoke-static {v10, v1, v2}, Lkotlin/math/MathKt;->primaryAxisPreviousPosition-_bfSUIo(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;)J

    .line 946
    move-result-wide v6

    .line 947
    invoke-static {v10, v1, v2}, Lkotlin/math/MathKt;->primaryAxisPosition-_bfSUIo(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;)J

    .line 950
    move-result-wide v1

    .line 951
    invoke-static {v1, v2, v6, v7}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 954
    move-result-wide v1

    .line 955
    invoke-static {v1, v2}, Landroidx/compose/ui/geometry/Offset;->getDistance-impl(J)F

    .line 958
    move-result v1

    .line 959
    cmpg-float v1, v1, v18

    .line 961
    if-nez v1, :cond_3c3

    .line 963
    goto :goto_3f0

    .line 964
    :cond_3c3
    iget-object v0, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 966
    new-instance v1, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 968
    invoke-direct {v1, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 971
    invoke-static {v10, v0, v1}, Lkotlin/math/MathKt;->primaryAxisPreviousPosition-_bfSUIo(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;)J

    .line 974
    move-result-wide v6

    .line 975
    invoke-static {v10, v0, v1}, Lkotlin/math/MathKt;->primaryAxisPosition-_bfSUIo(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/foundation/gestures/Orientation;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;)J

    .line 978
    move-result-wide v0

    .line 979
    invoke-static {v0, v1, v6, v7}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 982
    move-result-wide v0

    .line 983
    iget-boolean v2, v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 985
    if-eqz v2, :cond_3db

    .line 987
    goto :goto_3dc

    .line 988
    :cond_3db
    move-wide v14, v0

    .line 989
    :goto_3dc
    new-instance v0, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;

    .line 991
    invoke-direct {v0, v3}, Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;-><init>(I)V

    .line 994
    invoke-virtual {v5, v10, v0, v14, v15}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->sendDragEvent-Eu1f8Dk(Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;Landroidx/compose/ui/input/indirect/IndirectPointerEventPrimaryDirectionalMotionAxis;J)V

    .line 997
    iput-boolean v8, v10, Landroidx/compose/ui/input/indirect/IndirectPointerInputChange;->isConsumed:Z

    .line 999
    return-void

    .line 1000
    :cond_3e7
    invoke-static {}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m()V

    .line 1003
    return-void

    .line 1004
    :cond_3eb
    const-string v0, "currentDragState should not be null"

    .line 1006
    invoke-static {v0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 1009
    :cond_3f0
    :goto_3f0
    return-void
.end method

.method public onPointerEvent-H0pRuoY(Landroidx/compose/ui/input/pointer/PointerEvent;Landroidx/compose/ui/input/pointer/PointerEventPass;J)V
    .registers 25

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    move-object/from16 v2, p2

    .line 7
    const/4 v3, 0x1

    .line 8
    iput-boolean v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForPointerInputEvents:Z

    .line 10
    iget-boolean v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->enabled:Z

    .line 12
    if-eqz v4, :cond_331

    .line 14
    iget-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 16
    const/4 v5, 0x0

    .line 17
    if-nez v4, :cond_25

    .line 19
    iget-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitDownState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 21
    if-nez v4, :cond_23

    .line 23
    new-instance v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 25
    invoke-direct {v4}, Ljava/lang/Object;-><init>()V

    .line 28
    sget-object v6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;->NotInitialized:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 30
    iput-object v6, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 32
    iput-boolean v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 34
    iput-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->_awaitDownState:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 36
    :cond_23
    iput-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 38
    :cond_25
    iget-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 40
    if-eqz v4, :cond_32c

    .line 42
    instance-of v6, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 44
    const-wide v7, 0x7fffffffffffffffL

    .line 49
    sget-object v9, Landroidx/compose/ui/input/pointer/PointerEventPass;->Initial:Landroidx/compose/ui/input/pointer/PointerEventPass;

    .line 51
    const-wide/16 v10, 0x0

    .line 53
    sget-object v12, Landroidx/compose/ui/input/pointer/PointerEventPass;->Main:Landroidx/compose/ui/input/pointer/PointerEventPass;

    .line 55
    if-eqz v6, :cond_a7

    .line 57
    check-cast v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;

    .line 59
    iget-object v6, v1, Landroidx/compose/ui/input/pointer/PointerEvent;->changes:Ljava/util/List;

    .line 61
    invoke-interface {v6}, Ljava/util/List;->isEmpty()Z

    .line 64
    move-result v6

    .line 65
    if-eqz v6, :cond_44

    .line 67
    goto/16 :goto_331

    .line 69
    :cond_44
    invoke-static {v1, v5}, Landroidx/compose/foundation/gestures/TapGestureDetectorKt;->isChangedToDown$default(Landroidx/compose/ui/input/pointer/PointerEvent;Z)Z

    .line 72
    move-result v5

    .line 73
    if-nez v5, :cond_4c

    .line 75
    goto/16 :goto_331

    .line 77
    :cond_4c
    iget-object v1, v1, Landroidx/compose/ui/input/pointer/PointerEvent;->changes:Ljava/util/List;

    .line 79
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 82
    move-result-object v1

    .line 83
    check-cast v1, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 85
    iget-object v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 87
    sget-object v6, Landroidx/compose/foundation/gestures/DragGestureNode$WhenMappings;->$EnumSwitchMapping$0:[I

    .line 89
    invoke-virtual {v5}, Ljava/lang/Enum;->ordinal()I

    .line 92
    move-result v5

    .line 93
    aget v5, v6, v5

    .line 95
    sget-object v6, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;->No:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 97
    sget-object v13, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;->Yes:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 99
    if-ne v5, v3, :cond_6e

    .line 101
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->startDragImmediately()Z

    .line 104
    move-result v5

    .line 105
    if-nez v5, :cond_6c

    .line 107
    move-object v5, v13

    .line 108
    goto :goto_70

    .line 109
    :cond_6c
    move-object v5, v6

    .line 110
    goto :goto_70

    .line 111
    :cond_6e
    iget-object v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 113
    :goto_70
    iput-object v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->awaitTouchSlop:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

    .line 115
    if-ne v2, v9, :cond_7b

    .line 117
    if-ne v5, v6, :cond_7b

    .line 119
    invoke-virtual {v1}, Landroidx/compose/ui/input/pointer/PointerInputChange;->consume()V

    .line 122
    iput-boolean v3, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 124
    :cond_7b
    if-ne v2, v12, :cond_331

    .line 126
    if-ne v5, v13, :cond_89

    .line 128
    iget-wide v2, v1, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 130
    const-wide/16 v4, 0x0

    .line 132
    const/16 v6, 0xc

    .line 134
    invoke-static/range {v0 .. v6}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitTouchSlopState-aWI9W7U$default(Landroidx/compose/foundation/gestures/DragGestureNode;Landroidx/compose/ui/input/pointer/PointerInputChange;JJI)V

    .line 137
    return-void

    .line 138
    :cond_89
    iget-boolean v2, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;->consumedOnInitial:Z

    .line 140
    if-eqz v2, :cond_331

    .line 142
    invoke-virtual {v0, v1, v1, v10, v11}, Landroidx/compose/foundation/gestures/DragGestureNode;->sendDragStart-0AR0LA0(Landroidx/compose/ui/input/pointer/PointerInputChange;Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 145
    invoke-virtual {v0, v1, v10, v11}, Landroidx/compose/foundation/gestures/DragGestureNode;->sendDragEvent-Uv8p0NA(Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 148
    iget-wide v1, v1, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 150
    iget-object v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->_draggingState:Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 152
    if-nez v3, :cond_a2

    .line 154
    new-instance v3, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 156
    invoke-direct {v3}, Ljava/lang/Object;-><init>()V

    .line 159
    iput-wide v7, v3, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;->pointerId:J

    .line 161
    iput-object v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->_draggingState:Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 163
    :cond_a2
    iput-wide v1, v3, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;->pointerId:J

    .line 165
    iput-object v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 167
    return-void

    .line 168
    :cond_a7
    instance-of v6, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;

    .line 170
    sget-object v13, Landroidx/compose/ui/input/pointer/PointerEventPass;->Final:Landroidx/compose/ui/input/pointer/PointerEventPass;

    .line 172
    if-eqz v6, :cond_1d1

    .line 174
    check-cast v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;

    .line 176
    if-ne v2, v9, :cond_b3

    .line 178
    goto/16 :goto_331

    .line 180
    :cond_b3
    iget-object v1, v1, Landroidx/compose/ui/input/pointer/PointerEvent;->changes:Ljava/util/List;

    .line 182
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 185
    move-result v6

    .line 186
    move v9, v5

    .line 187
    :goto_ba
    if-ge v9, v6, :cond_d6

    .line 189
    invoke-interface {v1, v9}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 192
    move-result-object v10

    .line 193
    move-object v11, v10

    .line 194
    check-cast v11, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 196
    iget-wide v14, v11, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 198
    move/from16 p1, v6

    .line 200
    iget-wide v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 202
    invoke-static {v14, v15, v5, v6}, Landroidx/compose/ui/input/pointer/PointerId;->equals-impl0(JJ)Z

    .line 205
    move-result v5

    .line 206
    if-eqz v5, :cond_d0

    .line 208
    goto :goto_d7

    .line 209
    :cond_d0
    add-int/lit8 v9, v9, 0x1

    .line 211
    move/from16 v6, p1

    .line 213
    const/4 v5, 0x0

    .line 214
    goto :goto_ba

    .line 215
    :cond_d6
    const/4 v10, 0x0

    .line 216
    :goto_d7
    check-cast v10, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 218
    if-nez v10, :cond_ff

    .line 220
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 223
    move-result v5

    .line 224
    const/4 v6, 0x0

    .line 225
    :goto_e0
    if-ge v6, v5, :cond_f1

    .line 227
    invoke-interface {v1, v6}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 230
    move-result-object v9

    .line 231
    move-object v10, v9

    .line 232
    check-cast v10, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 234
    iget-boolean v10, v10, Landroidx/compose/ui/input/pointer/PointerInputChange;->pressed:Z

    .line 236
    if-eqz v10, :cond_ee

    .line 238
    goto :goto_f2

    .line 239
    :cond_ee
    add-int/lit8 v6, v6, 0x1

    .line 241
    goto :goto_e0

    .line 242
    :cond_f1
    const/4 v9, 0x0

    .line 243
    :goto_f2
    move-object v10, v9

    .line 244
    check-cast v10, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 246
    if-nez v10, :cond_fb

    .line 248
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitDownState()V

    .line 251
    return-void

    .line 252
    :cond_fb
    iget-wide v5, v10, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 254
    iput-wide v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 256
    :cond_ff
    const-string v5, "AwaitTouchSlop.touchSlopDetector was not initialized"

    .line 258
    const-string v6, "AwaitTouchSlop.initialDown was not initialized"

    .line 260
    if-ne v2, v12, :cond_1ab

    .line 262
    invoke-virtual {v10}, Landroidx/compose/ui/input/pointer/PointerInputChange;->isConsumed()Z

    .line 265
    move-result v9

    .line 266
    if-nez v9, :cond_195

    .line 268
    invoke-static {v10}, Landroidx/compose/ui/input/pointer/PointerId;->changedToUpIgnoreConsumed(Landroidx/compose/ui/input/pointer/PointerInputChange;)Z

    .line 271
    move-result v9

    .line 272
    if-eqz v9, :cond_138

    .line 274
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 277
    move-result v3

    .line 278
    const/4 v7, 0x0

    .line 279
    :goto_116
    if-ge v7, v3, :cond_128

    .line 281
    invoke-interface {v1, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 284
    move-result-object v8

    .line 285
    move-object v9, v8

    .line 286
    check-cast v9, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 288
    iget-boolean v9, v9, Landroidx/compose/ui/input/pointer/PointerInputChange;->pressed:Z

    .line 290
    if-eqz v9, :cond_125

    .line 292
    move-object v14, v8

    .line 293
    goto :goto_129

    .line 294
    :cond_125
    add-int/lit8 v7, v7, 0x1

    .line 296
    goto :goto_116

    .line 297
    :cond_128
    const/4 v14, 0x0

    .line 298
    :goto_129
    check-cast v14, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 300
    if-nez v14, :cond_132

    .line 302
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitDownState()V

    .line 305
    goto/16 :goto_1ab

    .line 307
    :cond_132
    iget-wide v7, v14, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 309
    iput-wide v7, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 311
    goto/16 :goto_1ab

    .line 313
    :cond_138
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalViewConfiguration:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 315
    invoke-static {v0, v1}, Landroidx/compose/ui/node/HitTestResultKt;->currentValueOf(Landroidx/compose/ui/node/CompositionLocalConsumerModifierNode;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 318
    move-result-object v1

    .line 319
    check-cast v1, Landroidx/compose/ui/platform/ViewConfiguration;

    .line 321
    iget v9, v10, Landroidx/compose/ui/input/pointer/PointerInputChange;->type:I

    .line 323
    invoke-static {v1, v9}, Landroidx/compose/foundation/gestures/DragGestureDetectorKt;->pointerSlop-E8SPZFQ(Landroidx/compose/ui/platform/ViewConfiguration;I)F

    .line 326
    move-result v15

    .line 327
    iget-object v14, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 329
    if-eqz v14, :cond_18f

    .line 331
    iget-wide v11, v10, Landroidx/compose/ui/input/pointer/PointerInputChange;->position:J

    .line 333
    iget-wide v7, v10, Landroidx/compose/ui/input/pointer/PointerInputChange;->previousPosition:J

    .line 335
    move-wide/from16 v18, v7

    .line 337
    move-wide/from16 v16, v11

    .line 339
    invoke-virtual/range {v14 .. v19}, Landroidx/compose/foundation/gestures/TouchSlopDetector;->addPositions-akrDWew(FJJ)J

    .line 342
    move-result-wide v7

    .line 343
    const-wide v11, 0x7fffffff7fffffffL

    .line 348
    and-long/2addr v11, v7

    .line 349
    const-wide v14, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 354
    cmp-long v1, v11, v14

    .line 356
    if-eqz v1, :cond_18c

    .line 358
    invoke-virtual {v10}, Landroidx/compose/ui/input/pointer/PointerInputChange;->consume()V

    .line 361
    iget-object v1, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 363
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 366
    invoke-virtual {v0, v1, v10, v7, v8}, Landroidx/compose/foundation/gestures/DragGestureNode;->sendDragStart-0AR0LA0(Landroidx/compose/ui/input/pointer/PointerInputChange;Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 369
    invoke-virtual {v0, v10, v7, v8}, Landroidx/compose/foundation/gestures/DragGestureNode;->sendDragEvent-Uv8p0NA(Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 372
    iget-wide v7, v10, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 374
    iget-object v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->_draggingState:Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 376
    if-nez v1, :cond_187

    .line 378
    new-instance v1, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 380
    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    .line 383
    const-wide v11, 0x7fffffffffffffffL

    .line 388
    iput-wide v11, v1, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;->pointerId:J

    .line 390
    iput-object v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->_draggingState:Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 392
    :cond_187
    iput-wide v7, v1, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;->pointerId:J

    .line 394
    iput-object v1, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->currentDragState:Lkotlin/math/MathKt;

    .line 396
    goto :goto_1ab

    .line 397
    :cond_18c
    iput-boolean v3, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 399
    goto :goto_1ab

    .line 400
    :cond_18f
    const-string v0, "Touch slop detector not initialized."

    .line 402
    invoke-static {v0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 405
    return-void

    .line 406
    :cond_195
    iget-object v1, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 408
    if-eqz v1, :cond_1a7

    .line 410
    iget-wide v7, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 412
    iget-object v3, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 414
    if-eqz v3, :cond_1a3

    .line 416
    invoke-virtual {v0, v1, v7, v8, v3}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitGesturePickupState-rnUCldI(Landroidx/compose/ui/input/pointer/PointerInputChange;JLandroidx/compose/foundation/gestures/TouchSlopDetector;)V

    .line 419
    goto :goto_1ab

    .line 420
    :cond_1a3
    invoke-static {v5}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 423
    return-void

    .line 424
    :cond_1a7
    invoke-static {v6}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 427
    return-void

    .line 428
    :cond_1ab
    :goto_1ab
    if-ne v2, v13, :cond_331

    .line 430
    iget-boolean v1, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 432
    if-eqz v1, :cond_331

    .line 434
    invoke-virtual {v10}, Landroidx/compose/ui/input/pointer/PointerInputChange;->isConsumed()Z

    .line 437
    move-result v1

    .line 438
    if-eqz v1, :cond_1cd

    .line 440
    iget-object v1, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 442
    if-eqz v1, :cond_1c9

    .line 444
    iget-wide v2, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->pointerId:J

    .line 446
    iget-object v4, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->touchSlopDetector:Landroidx/compose/foundation/gestures/TouchSlopDetector;

    .line 448
    if-eqz v4, :cond_1c5

    .line 450
    invoke-virtual {v0, v1, v2, v3, v4}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitGesturePickupState-rnUCldI(Landroidx/compose/ui/input/pointer/PointerInputChange;JLandroidx/compose/foundation/gestures/TouchSlopDetector;)V

    .line 453
    return-void

    .line 454
    :cond_1c5
    invoke-static {v5}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 457
    return-void

    .line 458
    :cond_1c9
    invoke-static {v6}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 461
    return-void

    .line 462
    :cond_1cd
    const/4 v0, 0x0

    .line 463
    iput-boolean v0, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitTouchSlop;->verifyConsumptionInFinalPass:Z

    .line 465
    return-void

    .line 466
    :cond_1d1
    instance-of v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;

    .line 468
    if-eqz v5, :cond_23e

    .line 470
    check-cast v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;

    .line 472
    if-eq v2, v13, :cond_1db

    .line 474
    goto/16 :goto_331

    .line 476
    :cond_1db
    iget-object v1, v1, Landroidx/compose/ui/input/pointer/PointerEvent;->changes:Ljava/util/List;

    .line 478
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 481
    move-result v2

    .line 482
    const/4 v5, 0x0

    .line 483
    :goto_1e2
    if-ge v5, v2, :cond_1f5

    .line 485
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 488
    move-result-object v6

    .line 489
    check-cast v6, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 491
    invoke-virtual {v6}, Landroidx/compose/ui/input/pointer/PointerInputChange;->isConsumed()Z

    .line 494
    move-result v6

    .line 495
    if-eqz v6, :cond_1f2

    .line 497
    const/4 v3, 0x0

    .line 498
    goto :goto_1f5

    .line 499
    :cond_1f2
    add-int/lit8 v5, v5, 0x1

    .line 501
    goto :goto_1e2

    .line 502
    :cond_1f5
    :goto_1f5
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 505
    move-result v2

    .line 506
    const/4 v5, 0x0

    .line 507
    :goto_1fa
    if-ge v5, v2, :cond_23a

    .line 509
    invoke-interface {v1, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 512
    move-result-object v6

    .line 513
    check-cast v6, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 515
    iget-boolean v6, v6, Landroidx/compose/ui/input/pointer/PointerInputChange;->pressed:Z

    .line 517
    if-eqz v6, :cond_237

    .line 519
    invoke-interface {v1}, Ljava/util/List;->isEmpty()Z

    .line 522
    move-result v2

    .line 523
    if-eqz v2, :cond_20d

    .line 525
    goto :goto_23a

    .line 526
    :cond_20d
    if-eqz v3, :cond_331

    .line 528
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->first(Ljava/util/List;)Ljava/lang/Object;

    .line 531
    move-result-object v1

    .line 532
    check-cast v1, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 534
    iget-wide v1, v1, Landroidx/compose/ui/input/pointer/PointerInputChange;->position:J

    .line 536
    iget-object v3, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 538
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 541
    iget-wide v5, v3, Landroidx/compose/ui/input/pointer/PointerInputChange;->position:J

    .line 543
    invoke-static {v1, v2, v5, v6}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 546
    move-result-wide v1

    .line 547
    move-wide v2, v1

    .line 548
    iget-object v1, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;->initialDown:Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 550
    if-eqz v1, :cond_231

    .line 552
    move-wide v5, v2

    .line 553
    iget-wide v2, v4, Landroidx/compose/foundation/gestures/DragDetectionState$AwaitGesturePickup;->pointerId:J

    .line 555
    move-wide v4, v5

    .line 556
    const/16 v6, 0x8

    .line 558
    invoke-static/range {v0 .. v6}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitTouchSlopState-aWI9W7U$default(Landroidx/compose/foundation/gestures/DragGestureNode;Landroidx/compose/ui/input/pointer/PointerInputChange;JJI)V

    .line 561
    return-void

    .line 562
    :cond_231
    const-string v0, "AwaitGesturePickup.initialDown was not initialized."

    .line 564
    invoke-static {v0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 567
    return-void

    .line 568
    :cond_237
    add-int/lit8 v5, v5, 0x1

    .line 570
    goto :goto_1fa

    .line 571
    :cond_23a
    :goto_23a
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitDownState()V

    .line 574
    return-void

    .line 575
    :cond_23e
    instance-of v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 577
    if-eqz v5, :cond_328

    .line 579
    check-cast v4, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;

    .line 581
    if-eq v2, v12, :cond_248

    .line 583
    goto/16 :goto_331

    .line 585
    :cond_248
    iget-wide v5, v4, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;->pointerId:J

    .line 587
    iget-object v2, v1, Landroidx/compose/ui/input/pointer/PointerEvent;->changes:Ljava/util/List;

    .line 589
    invoke-interface {v2}, Ljava/util/Collection;->size()I

    .line 592
    move-result v7

    .line 593
    const/4 v8, 0x0

    .line 594
    :goto_251
    if-ge v8, v7, :cond_266

    .line 596
    invoke-interface {v2, v8}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 599
    move-result-object v9

    .line 600
    move-object v12, v9

    .line 601
    check-cast v12, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 603
    iget-wide v12, v12, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 605
    invoke-static {v12, v13, v5, v6}, Landroidx/compose/ui/input/pointer/PointerId;->equals-impl0(JJ)Z

    .line 608
    move-result v12

    .line 609
    if-eqz v12, :cond_263

    .line 611
    goto :goto_267

    .line 612
    :cond_263
    add-int/lit8 v8, v8, 0x1

    .line 614
    goto :goto_251

    .line 615
    :cond_266
    const/4 v9, 0x0

    .line 616
    :goto_267
    check-cast v9, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 618
    if-nez v9, :cond_26d

    .line 620
    goto/16 :goto_331

    .line 622
    :cond_26d
    invoke-static {v9}, Landroidx/compose/ui/input/pointer/PointerId;->changedToUpIgnoreConsumed(Landroidx/compose/ui/input/pointer/PointerInputChange;)Z

    .line 625
    move-result v2

    .line 626
    sget-object v5, Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;->INSTANCE:Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;

    .line 628
    if-eqz v2, :cond_300

    .line 630
    iget-object v1, v1, Landroidx/compose/ui/input/pointer/PointerEvent;->changes:Ljava/util/List;

    .line 632
    invoke-interface {v1}, Ljava/util/Collection;->size()I

    .line 635
    move-result v2

    .line 636
    const/4 v3, 0x0

    .line 637
    :goto_27c
    if-ge v3, v2, :cond_28d

    .line 639
    invoke-interface {v1, v3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 642
    move-result-object v6

    .line 643
    move-object v7, v6

    .line 644
    check-cast v7, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 646
    iget-boolean v7, v7, Landroidx/compose/ui/input/pointer/PointerInputChange;->pressed:Z

    .line 648
    if-eqz v7, :cond_28a

    .line 650
    goto :goto_28e

    .line 651
    :cond_28a
    add-int/lit8 v3, v3, 0x1

    .line 653
    goto :goto_27c

    .line 654
    :cond_28d
    const/4 v6, 0x0

    .line 655
    :goto_28e
    check-cast v6, Landroidx/compose/ui/input/pointer/PointerInputChange;

    .line 657
    if-nez v6, :cond_2fb

    .line 659
    invoke-virtual {v9}, Landroidx/compose/ui/input/pointer/PointerInputChange;->isConsumed()Z

    .line 662
    move-result v1

    .line 663
    if-nez v1, :cond_2f0

    .line 665
    invoke-static {v9}, Landroidx/compose/ui/input/pointer/PointerId;->changedToUpIgnoreConsumed(Landroidx/compose/ui/input/pointer/PointerInputChange;)Z

    .line 668
    move-result v1

    .line 669
    if-eqz v1, :cond_2f0

    .line 671
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 674
    move-result-object v1

    .line 675
    invoke-static {v1, v9, v10, v11}, Landroidx/compose/ui/geometry/RectKt;->addPointerInputChange-0AR0LA0(Landroidx/compose/ui/draw/DrawResult;Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 678
    sget-object v1, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalViewConfiguration:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 680
    invoke-static {v0, v1}, Landroidx/compose/ui/node/HitTestResultKt;->currentValueOf(Landroidx/compose/ui/node/CompositionLocalConsumerModifierNode;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 683
    move-result-object v1

    .line 684
    check-cast v1, Landroidx/compose/ui/platform/ViewConfiguration;

    .line 686
    invoke-interface {v1}, Landroidx/compose/ui/platform/ViewConfiguration;->getMaximumFlingVelocity()F

    .line 689
    move-result v1

    .line 690
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 693
    move-result-object v2

    .line 694
    invoke-static {v1, v1}, Landroidx/core/os/BundleKt;->Velocity(FF)J

    .line 697
    move-result-wide v3

    .line 698
    invoke-virtual {v2, v3, v4}, Landroidx/compose/ui/draw/DrawResult;->calculateVelocity-AH228Gc(J)J

    .line 701
    move-result-wide v1

    .line 702
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 705
    move-result-object v3

    .line 706
    iget-object v3, v3, Landroidx/compose/ui/draw/DrawResult;->block:Ljava/lang/Object;

    .line 708
    check-cast v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;

    .line 710
    iget-object v4, v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;->xVelocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 712
    iget-object v5, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->samples:[Landroidx/compose/ui/input/pointer/util/DataPointAtTime;

    .line 714
    array-length v6, v5

    .line 715
    const/4 v7, 0x0

    .line 716
    const/4 v8, 0x0

    .line 717
    invoke-static {v5, v8, v6, v7}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 720
    iput v8, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->index:I

    .line 722
    iget-object v4, v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;->yVelocityTracker:Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;

    .line 724
    iget-object v5, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->samples:[Landroidx/compose/ui/input/pointer/util/DataPointAtTime;

    .line 726
    array-length v6, v5

    .line 727
    invoke-static {v5, v8, v6, v7}, Ljava/util/Arrays;->fill([Ljava/lang/Object;IILjava/lang/Object;)V

    .line 730
    iput v8, v4, Landroidx/compose/ui/input/pointer/util/VelocityTracker1D;->index:I

    .line 732
    iput-wide v10, v3, Landroidx/compose/ui/input/pointer/util/DefaultVelocityTracker;->lastMoveEventTimeStamp:J

    .line 734
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 737
    move-result-object v3

    .line 738
    new-instance v4, Landroidx/compose/foundation/gestures/DragEvent$DragStopped;

    .line 740
    invoke-static {v1, v2}, Landroidx/compose/foundation/gestures/DraggableKt;->toValidVelocity-TH1AsA0(J)J

    .line 743
    move-result-wide v1

    .line 744
    invoke-direct {v4, v1, v2, v8}, Landroidx/compose/foundation/gestures/DragEvent$DragStopped;-><init>(JZ)V

    .line 747
    invoke-interface {v3, v4}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 750
    iput-boolean v8, v0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForPointerInputEvents:Z

    .line 752
    goto :goto_2f7

    .line 753
    :cond_2f0
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 756
    move-result-object v1

    .line 757
    invoke-interface {v1, v5}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 760
    :goto_2f7
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitDownState()V

    .line 763
    return-void

    .line 764
    :cond_2fb
    iget-wide v0, v6, Landroidx/compose/ui/input/pointer/PointerInputChange;->id:J

    .line 766
    iput-wide v0, v4, Landroidx/compose/foundation/gestures/DragDetectionState$Dragging;->pointerId:J

    .line 768
    return-void

    .line 769
    :cond_300
    invoke-virtual {v9}, Landroidx/compose/ui/input/pointer/PointerInputChange;->isConsumed()Z

    .line 772
    move-result v1

    .line 773
    if-eqz v1, :cond_30e

    .line 775
    invoke-virtual {v0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 778
    move-result-object v0

    .line 779
    invoke-interface {v0, v5}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 782
    return-void

    .line 783
    :cond_30e
    invoke-static {v9, v3}, Landroidx/compose/ui/input/pointer/PointerId;->positionChangeInternal(Landroidx/compose/ui/input/pointer/PointerInputChange;Z)J

    .line 786
    move-result-wide v1

    .line 787
    invoke-static {v1, v2}, Landroidx/compose/ui/geometry/Offset;->getDistance-impl(J)F

    .line 790
    move-result v1

    .line 791
    const/4 v2, 0x0

    .line 792
    cmpg-float v1, v1, v2

    .line 794
    if-nez v1, :cond_31c

    .line 796
    goto :goto_331

    .line 797
    :cond_31c
    const/4 v8, 0x0

    .line 798
    invoke-static {v9, v8}, Landroidx/compose/ui/input/pointer/PointerId;->positionChangeInternal(Landroidx/compose/ui/input/pointer/PointerInputChange;Z)J

    .line 801
    move-result-wide v1

    .line 802
    invoke-virtual {v0, v9, v1, v2}, Landroidx/compose/foundation/gestures/DragGestureNode;->sendDragEvent-Uv8p0NA(Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 805
    invoke-virtual {v9}, Landroidx/compose/ui/input/pointer/PointerInputChange;->consume()V

    .line 808
    return-void

    .line 809
    :cond_328
    invoke-static {}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m()V

    .line 812
    return-void

    .line 813
    :cond_32c
    const-string v0, "currentDragState should not be null"

    .line 815
    invoke-static {v0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 818
    :cond_331
    :goto_331
    return-void
.end method

.method public final requireChannel()Lkotlinx/coroutines/channels/Channel;
    .registers 1

    .line 1
    iget-object p0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->channel:Lkotlinx/coroutines/channels/BufferedChannel;

    .line 3
    if-eqz p0, :cond_5

    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "Events channel not initialized."

    .line 8
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 11
    const/4 p0, 0x0

    .line 12
    return-object p0
.end method

.method public final requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;
    .registers 1

    .line 1
    iget-object p0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->velocityTracker:Landroidx/compose/ui/draw/DrawResult;

    .line 3
    if-eqz p0, :cond_5

    .line 5
    return-object p0

    .line 6
    :cond_5
    const-string p0, "Velocity Tracker not initialized."

    .line 8
    invoke-static {p0}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2(Ljava/lang/String;)V

    .line 11
    const/4 p0, 0x0

    .line 12
    return-object p0
.end method

.method public final sendDragEvent-Uv8p0NA(Landroidx/compose/ui/input/pointer/PointerInputChange;J)V
    .registers 10

    .line 1
    iget-object v0, p0, Landroidx/compose/ui/Modifier$Node;->node:Landroidx/compose/ui/Modifier$Node;

    .line 3
    invoke-static {v0}, Landroidx/compose/ui/node/HitTestResultKt;->requireLayoutCoordinates(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/NodeCoordinator;

    .line 6
    move-result-object v0

    .line 7
    const-wide/16 v1, 0x0

    .line 9
    invoke-virtual {v0, v1, v2}, Landroidx/compose/ui/node/NodeCoordinator;->localToScreen-MK-Hz9U(J)J

    .line 12
    move-result-wide v0

    .line 13
    iget-wide v2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->previousPositionOnScreen:J

    .line 15
    const-wide v4, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 20
    invoke-static {v2, v3, v4, v5}, Landroidx/compose/ui/geometry/Offset;->equals-impl0(JJ)Z

    .line 23
    move-result v2

    .line 24
    if-nez v2, :cond_2f

    .line 26
    iget-wide v2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->previousPositionOnScreen:J

    .line 28
    invoke-static {v0, v1, v2, v3}, Landroidx/compose/ui/geometry/Offset;->equals-impl0(JJ)Z

    .line 31
    move-result v2

    .line 32
    if-nez v2, :cond_2f

    .line 34
    iget-wide v2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->previousPositionOnScreen:J

    .line 36
    invoke-static {v0, v1, v2, v3}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 39
    move-result-wide v2

    .line 40
    iget-wide v4, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->nodeOffset:J

    .line 42
    invoke-static {v4, v5, v2, v3}, Landroidx/compose/ui/geometry/Offset;->plus-MK-Hz9U(JJ)J

    .line 45
    move-result-wide v2

    .line 46
    iput-wide v2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->nodeOffset:J

    .line 48
    :cond_2f
    iput-wide v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->previousPositionOnScreen:J

    .line 50
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 53
    move-result-object v0

    .line 54
    iget-wide v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->nodeOffset:J

    .line 56
    invoke-static {v0, p1, v1, v2}, Landroidx/compose/ui/geometry/RectKt;->addPointerInputChange-0AR0LA0(Landroidx/compose/ui/draw/DrawResult;Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 59
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 62
    move-result-object p0

    .line 63
    new-instance p1, Landroidx/compose/foundation/gestures/DragEvent$DragDelta;

    .line 65
    const/4 v0, 0x0

    .line 66
    invoke-direct {p1, p2, p3, v0}, Landroidx/compose/foundation/gestures/DragEvent$DragDelta;-><init>(JZ)V

    .line 69
    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 72
    return-void
.end method

.method public final sendDragStart-0AR0LA0(Landroidx/compose/ui/input/pointer/PointerInputChange;Landroidx/compose/ui/input/pointer/PointerInputChange;J)V
    .registers 10

    .line 1
    iget-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->velocityTracker:Landroidx/compose/ui/draw/DrawResult;

    .line 3
    if-nez v0, :cond_d

    .line 5
    new-instance v0, Landroidx/compose/ui/draw/DrawResult;

    .line 7
    const/16 v1, 0x1a

    .line 9
    invoke-direct {v0, v1}, Landroidx/compose/ui/draw/DrawResult;-><init>(I)V

    .line 12
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->velocityTracker:Landroidx/compose/ui/draw/DrawResult;

    .line 14
    :cond_d
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireVelocityTracker()Landroidx/compose/ui/draw/DrawResult;

    .line 17
    move-result-object v0

    .line 18
    const-wide/16 v1, 0x0

    .line 20
    invoke-static {v0, p1, v1, v2}, Landroidx/compose/ui/geometry/RectKt;->addPointerInputChange-0AR0LA0(Landroidx/compose/ui/draw/DrawResult;Landroidx/compose/ui/input/pointer/PointerInputChange;J)V

    .line 23
    iget-wide v3, p2, Landroidx/compose/ui/input/pointer/PointerInputChange;->position:J

    .line 25
    invoke-static {v3, v4, p3, p4}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 28
    move-result-wide p2

    .line 29
    iput-wide v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->nodeOffset:J

    .line 31
    iget-object p4, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->canDrag:Lkotlin/jvm/functions/Function1;

    .line 33
    iget p1, p1, Landroidx/compose/ui/input/pointer/PointerInputChange;->type:I

    .line 35
    new-instance v0, Landroidx/compose/ui/input/pointer/PointerType;

    .line 37
    invoke-direct {v0, p1}, Landroidx/compose/ui/input/pointer/PointerType;-><init>(I)V

    .line 40
    invoke-interface {p4, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    move-result-object p1

    .line 44
    check-cast p1, Ljava/lang/Boolean;

    .line 46
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 49
    move-result p1

    .line 50
    if-eqz p1, :cond_5f

    .line 52
    iget-boolean p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 54
    if-nez p1, :cond_49

    .line 56
    iget-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->channel:Lkotlinx/coroutines/channels/BufferedChannel;

    .line 58
    if-nez p1, :cond_46

    .line 60
    const p1, 0x7fffffff

    .line 63
    const/4 p4, 0x6

    .line 64
    const/4 v0, 0x0

    .line 65
    invoke-static {p1, p4, v0}, Lkotlinx/coroutines/channels/ChannelKt;->Channel$default(IILkotlinx/coroutines/channels/BufferOverflow;)Lkotlinx/coroutines/channels/BufferedChannel;

    .line 68
    move-result-object p1

    .line 69
    iput-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->channel:Lkotlinx/coroutines/channels/BufferedChannel;

    .line 71
    :cond_46
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->startListeningForEvents()V

    .line 74
    :cond_49
    invoke-static {p0}, Landroidx/compose/ui/node/HitTestResultKt;->requireLayoutCoordinates(Landroidx/compose/ui/node/DelegatableNode;)Landroidx/compose/ui/node/NodeCoordinator;

    .line 77
    move-result-object p1

    .line 78
    invoke-virtual {p1, v1, v2}, Landroidx/compose/ui/node/NodeCoordinator;->localToScreen-MK-Hz9U(J)J

    .line 81
    move-result-wide v0

    .line 82
    iput-wide v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->previousPositionOnScreen:J

    .line 84
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 87
    move-result-object p0

    .line 88
    new-instance p1, Landroidx/compose/foundation/gestures/DragEvent$DragStarted;

    .line 90
    invoke-direct {p1, p2, p3}, Landroidx/compose/foundation/gestures/DragEvent$DragStarted;-><init>(J)V

    .line 93
    invoke-interface {p0, p1}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    :cond_5f
    return-void
.end method

.method public abstract startDragImmediately()Z
.end method

.method public final startListeningForEvents()V
    .registers 4

    .line 1
    const/4 v0, 0x1

    .line 2
    iput-boolean v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 4
    iget-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->channel:Lkotlinx/coroutines/channels/BufferedChannel;

    .line 6
    const/4 v1, 0x0

    .line 7
    if-nez v0, :cond_12

    .line 9
    const v0, 0x7fffffff

    .line 12
    const/4 v2, 0x6

    .line 13
    invoke-static {v0, v2, v1}, Lkotlinx/coroutines/channels/ChannelKt;->Channel$default(IILkotlinx/coroutines/channels/BufferOverflow;)Lkotlinx/coroutines/channels/BufferedChannel;

    .line 16
    move-result-object v0

    .line 17
    iput-object v0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->channel:Lkotlinx/coroutines/channels/BufferedChannel;

    .line 19
    :cond_12
    invoke-virtual {p0}, Landroidx/compose/ui/Modifier$Node;->getCoroutineScope()Lkotlinx/coroutines/CoroutineScope;

    .line 22
    move-result-object v0

    .line 23
    new-instance v2, Landroidx/compose/foundation/gestures/DragGestureNode$startListeningForEvents$1;

    .line 25
    invoke-direct {v2, p0, v1}, Landroidx/compose/foundation/gestures/DragGestureNode$startListeningForEvents$1;-><init>(Landroidx/compose/foundation/gestures/DragGestureNode;Lkotlin/coroutines/Continuation;)V

    .line 28
    const/4 p0, 0x3

    .line 29
    invoke-static {v0, v1, v2, p0}, Lkotlinx/coroutines/JobKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;I)Lkotlinx/coroutines/StandaloneCoroutine;

    .line 32
    return-void
.end method

.method public final update(Lkotlin/jvm/functions/Function1;ZLandroidx/compose/foundation/interaction/MutableInteractionSourceImpl;Landroidx/compose/foundation/gestures/Orientation;Z)V
    .registers 8

    .line 1
    iput-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->canDrag:Lkotlin/jvm/functions/Function1;

    .line 3
    iget-boolean p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->enabled:Z

    .line 5
    const/4 v0, 0x1

    .line 6
    const/4 v1, 0x0

    .line 7
    if-eq p1, p2, :cond_12

    .line 9
    iput-boolean p2, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->enabled:Z

    .line 11
    if-nez p2, :cond_11

    .line 13
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->disposeInteractionSource$1()V

    .line 16
    iput-object v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->indirectPointerInputDragCycleDetector:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

    .line 18
    :cond_11
    move p5, v0

    .line 19
    :cond_12
    iget-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 21
    invoke-static {p1, p3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 24
    move-result p1

    .line 25
    if-nez p1, :cond_1f

    .line 27
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->disposeInteractionSource$1()V

    .line 30
    iput-object p3, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 32
    :cond_1f
    iget-object p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 34
    if-eq p1, p4, :cond_26

    .line 36
    iput-object p4, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->orientationLock:Landroidx/compose/foundation/gestures/Orientation;

    .line 38
    goto :goto_27

    .line 39
    :cond_26
    move v0, p5

    .line 40
    :goto_27
    if-eqz v0, :cond_5b

    .line 42
    iget-boolean p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForPointerInputEvents:Z

    .line 44
    sget-object p2, Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;->INSTANCE:Landroidx/compose/foundation/gestures/DragEvent$DragCancelled;

    .line 46
    if-eqz p1, :cond_3f

    .line 48
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->moveToAwaitDownState()V

    .line 51
    iget-boolean p1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 53
    if-eqz p1, :cond_3d

    .line 55
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/DragGestureNode;->requireChannel()Lkotlinx/coroutines/channels/Channel;

    .line 58
    move-result-object p1

    .line 59
    invoke-interface {p1, p2}, Lkotlinx/coroutines/channels/SendChannel;->trySend-JP2dKIU(Ljava/lang/Object;)Ljava/lang/Object;

    .line 62
    :cond_3d
    iput-object v1, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->velocityTracker:Landroidx/compose/ui/draw/DrawResult;

    .line 64
    :cond_3f
    iget-object p0, p0, Landroidx/compose/foundation/gestures/DragGestureNode;->indirectPointerInputDragCycleDetector:Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;

    .line 66
    if-eqz p0, :cond_5b

    .line 68
    invoke-virtual {p0}, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->moveToAwaitDownState()V

    .line 71
    iget-object p1, p0, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->node:Landroidx/compose/foundation/gestures/DragGestureNode;

    .line 73
    iget-boolean p3, p1, Landroidx/compose/foundation/gestures/DragGestureNode;->isListeningForEvents:Z

    .line 75
    if-eqz p3, :cond_4f

    .line 77
    invoke-virtual {p1, p2}, Landroidx/compose/foundation/gestures/DragGestureNode;->onDragEvent(Landroidx/compose/foundation/gestures/DragEvent;)V

    .line 80
    :cond_4f
    iput-object v1, p0, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->velocityTracker:Landroidx/compose/ui/draw/DrawResult;

    .line 82
    iget-object p0, p0, Landroidx/compose/foundation/gestures/IndirectPointerInputDragCycleDetector;->offsetSmoother:Landroidx/compose/foundation/gestures/OffsetSmoother;

    .line 84
    const/4 p1, 0x0

    .line 85
    iput p1, p0, Landroidx/compose/foundation/gestures/OffsetSmoother;->eventRotatingIndex:I

    .line 87
    iget-object p0, p0, Landroidx/compose/foundation/gestures/OffsetSmoother;->eventRotatingArray:Ljava/util/ArrayList;

    .line 89
    invoke-virtual {p0}, Ljava/util/ArrayList;->clear()V

    .line 92
    :cond_5b
    return-void
.end method
