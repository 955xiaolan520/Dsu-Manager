.class public abstract Landroidx/compose/foundation/gestures/LongPressResult$Canceled;
.super Landroidx/compose/foundation/gestures/LongPressResult;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"
