.class public final Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

.field public final synthetic $previousValue:Ljava/lang/Object;

.field public final synthetic $r8$classId:I

.field public final synthetic $this_semanticsScrollBy:Ljava/lang/Object;

.field public L$0:Ljava/lang/Object;

.field public label:I


# direct methods
.method public constructor <init>(JLandroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;Ljava/lang/CharSequence;Lkotlin/coroutines/Continuation;)V
    .registers 7

    const/4 v0, 0x4

    iput v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$r8$classId:I

    .line 17
    iput-object p3, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$this_semanticsScrollBy:Ljava/lang/Object;

    iput-object p4, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$previousValue:Ljava/lang/Object;

    iput-wide p1, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method

.method public constructor <init>(Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode;JLandroidx/compose/foundation/text/contextmenu/provider/TextContextMenuProvider;Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode$ClickTextContextMenuDataProvider;Lkotlin/coroutines/Continuation;)V
    .registers 8

    .line 1
    const/4 v0, 0x3

    .line 2
    iput v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$r8$classId:I

    .line 4
    iput-object p1, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 6
    iput-wide p2, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 8
    iput-object p4, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$this_semanticsScrollBy:Ljava/lang/Object;

    .line 10
    iput-object p5, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$previousValue:Ljava/lang/Object;

    .line 12
    const/4 p1, 0x2

    .line 13
    invoke-direct {p0, p1, p6}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 16
    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;JLjava/lang/Object;Lkotlin/coroutines/Continuation;I)V
    .registers 7

    .line 18
    iput p6, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$r8$classId:I

    iput-object p1, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$this_semanticsScrollBy:Ljava/lang/Object;

    iput-wide p2, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    iput-object p4, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$previousValue:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 14

    .line 1
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$r8$classId:I

    .line 3
    iget-object v1, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$previousValue:Ljava/lang/Object;

    .line 5
    iget-object v2, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$this_semanticsScrollBy:Ljava/lang/Object;

    .line 7
    packed-switch v0, :pswitch_data_62

    .line 10
    new-instance v3, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 12
    move-object v6, v2

    .line 13
    check-cast v6, Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;

    .line 15
    move-object v7, v1

    .line 16
    check-cast v7, Ljava/lang/CharSequence;

    .line 18
    iget-wide v4, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 20
    move-object v8, p2

    .line 21
    invoke-direct/range {v3 .. v8}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;-><init>(JLandroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;Ljava/lang/CharSequence;Lkotlin/coroutines/Continuation;)V

    .line 24
    iput-object p1, v3, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 26
    return-object v3

    .line 27
    :pswitch_1a  #0x3
    move-object v9, p2

    .line 28
    new-instance v4, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 30
    iget-object p1, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 32
    move-object v5, p1

    .line 33
    check-cast v5, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode;

    .line 35
    move-object v8, v2

    .line 36
    check-cast v8, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuProvider;

    .line 38
    check-cast v1, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode$ClickTextContextMenuDataProvider;

    .line 40
    iget-wide v6, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 42
    move-object v10, v9

    .line 43
    move-object v9, v1

    .line 44
    invoke-direct/range {v4 .. v10}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;-><init>(Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode;JLandroidx/compose/foundation/text/contextmenu/provider/TextContextMenuProvider;Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode$ClickTextContextMenuDataProvider;Lkotlin/coroutines/Continuation;)V

    .line 47
    return-object v4

    .line 48
    :pswitch_2f  #0x2
    move-object v9, p2

    .line 49
    new-instance v4, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 51
    move-object v5, v2

    .line 52
    check-cast v5, Landroidx/compose/runtime/MutableState;

    .line 54
    move-object v8, v1

    .line 55
    check-cast v8, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 57
    const/4 v10, 0x2

    .line 58
    iget-wide v6, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 60
    invoke-direct/range {v4 .. v10}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;-><init>(Ljava/lang/Object;JLjava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 63
    return-object v4

    .line 64
    :pswitch_3f  #0x1
    move-object v9, p2

    .line 65
    new-instance v4, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 67
    move-object v5, v2

    .line 68
    check-cast v5, Lkotlinx/coroutines/Job;

    .line 70
    move-object v8, v1

    .line 71
    check-cast v8, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 73
    const/4 v10, 0x1

    .line 74
    iget-wide v6, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 76
    invoke-direct/range {v4 .. v10}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;-><init>(Ljava/lang/Object;JLjava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 79
    return-object v4

    .line 80
    :pswitch_4f  #0x0
    move-object v9, p2

    .line 81
    new-instance v4, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 83
    move-object v5, v2

    .line 84
    check-cast v5, Landroidx/compose/foundation/gestures/ScrollingLogic;

    .line 86
    move-object v8, v1

    .line 87
    check-cast v8, Lkotlin/jvm/internal/Ref$FloatRef;

    .line 89
    const/4 v10, 0x0

    .line 90
    iget-wide v6, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 92
    invoke-direct/range {v4 .. v10}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;-><init>(Ljava/lang/Object;JLjava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 95
    iput-object p1, v4, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 97
    return-object v4

    nop

    .line 99
    :pswitch_data_62
    .packed-switch 0x0
        :pswitch_4f  #00000000
        :pswitch_3f  #00000001
        :pswitch_2f  #00000002
        :pswitch_1a  #00000003
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$r8$classId:I

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    packed-switch v0, :pswitch_data_52

    .line 8
    check-cast p1, Landroid/view/textclassifier/TextClassifier;

    .line 10
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 12
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 18
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x3
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 25
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 27
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 30
    move-result-object p0

    .line 31
    check-cast p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 33
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    move-result-object p0

    .line 37
    return-object p0

    .line 38
    :pswitch_25  #0x2
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 40
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 42
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 45
    move-result-object p0

    .line 46
    check-cast p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 48
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    move-result-object p0

    .line 52
    return-object p0

    .line 53
    :pswitch_34  #0x1
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 55
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 57
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 60
    move-result-object p0

    .line 61
    check-cast p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 63
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 66
    move-result-object p0

    .line 67
    return-object p0

    .line 68
    :pswitch_43  #0x0
    check-cast p1, Landroidx/compose/foundation/gestures/ScrollingLogic$nestedScrollScope$1;

    .line 70
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 72
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 75
    move-result-object p0

    .line 76
    check-cast p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;

    .line 78
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 81
    move-result-object p0

    .line 82
    return-object p0

    .line 83
    :pswitch_data_52
    .packed-switch 0x0
        :pswitch_43  #00000000
        :pswitch_34  #00000001
        :pswitch_25  #00000002
        :pswitch_16  #00000003
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 15

    .line 1
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$r8$classId:I

    .line 3
    iget-wide v1, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 5
    const/4 v3, 0x2

    .line 6
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 8
    iget-object v4, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$previousValue:Ljava/lang/Object;

    .line 10
    iget-object v7, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$this_semanticsScrollBy:Ljava/lang/Object;

    .line 12
    const-string v8, "call to \'resume\' before \'invoke\' with coroutine"

    .line 14
    sget-object v9, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 16
    const/4 v10, 0x1

    .line 17
    const/4 v11, 0x0

    .line 18
    packed-switch v0, :pswitch_data_15e

    .line 21
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 23
    if-eqz v0, :cond_23

    .line 25
    if-ne v0, v10, :cond_1e

    .line 27
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 30
    goto :goto_3d

    .line 31
    :cond_1e
    invoke-static {v8}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 34
    move-object v6, v11

    .line 35
    goto :goto_3d

    .line 36
    :cond_23
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 39
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 41
    check-cast v0, Landroid/view/textclassifier/TextClassifier;

    .line 43
    check-cast v7, Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;

    .line 45
    move-object v1, v4

    .line 46
    check-cast v1, Ljava/lang/CharSequence;

    .line 48
    iput v10, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 50
    iget-wide v2, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->$$v$c$androidx-compose-ui-geometry-Offset$-offset$0:J

    .line 52
    move-object v5, p0

    .line 53
    move-object v4, v0

    .line 54
    move-object v0, v7

    .line 55
    invoke-static/range {v0 .. v5}, Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;->access$classifyText-M8tDOmk(Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;Ljava/lang/CharSequence;JLandroid/view/textclassifier/TextClassifier;Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 58
    move-result-object v0

    .line 59
    if-ne v0, v9, :cond_3d

    .line 61
    move-object v6, v9

    .line 62
    :cond_3d
    :goto_3d
    return-object v6

    .line 63
    :pswitch_3e  #0x3
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 65
    if-eqz v0, :cond_53

    .line 67
    if-eq v0, v10, :cond_4f

    .line 69
    if-ne v0, v3, :cond_4a

    .line 71
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 74
    goto :goto_7b

    .line 75
    :cond_4a
    invoke-static {v8}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 78
    move-object v6, v11

    .line 79
    goto :goto_7b

    .line 80
    :cond_4f
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 83
    goto :goto_6e

    .line 84
    :cond_53
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 87
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 89
    check-cast v0, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode;

    .line 91
    iget-object v0, v0, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode;->onPreShowContextMenu:Landroidx/compose/foundation/text/selection/TextFieldSelectionManager$cut$1;

    .line 93
    if-eqz v0, :cond_6e

    .line 95
    iput v10, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 97
    new-instance v1, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager$cut$1;

    .line 99
    iget-object v0, v0, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager$cut$1;->this$0:Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;

    .line 101
    invoke-direct {v1, v0, p0, v10}, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager$cut$1;-><init>(Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;Lkotlin/coroutines/Continuation;I)V

    .line 104
    invoke-virtual {v1, v6}, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager$cut$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 107
    move-result-object v0

    .line 108
    if-ne v0, v9, :cond_6e

    .line 110
    goto :goto_7a

    .line 111
    :cond_6e
    :goto_6e
    check-cast v7, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuProvider;

    .line 113
    check-cast v4, Landroidx/compose/foundation/text/contextmenu/modifier/TextContextMenuGestureNode$ClickTextContextMenuDataProvider;

    .line 115
    iput v3, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 117
    invoke-interface {v7, v4, p0}, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuProvider;->showTextContextMenu(Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuDataProvider;Lkotlin/coroutines/jvm/internal/SuspendLambda;)Ljava/lang/Object;

    .line 120
    move-result-object v0

    .line 121
    if-ne v0, v9, :cond_7b

    .line 123
    :goto_7a
    move-object v6, v9

    .line 124
    :cond_7b
    :goto_7b
    return-object v6

    .line 125
    :pswitch_7c  #0x2
    check-cast v4, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 127
    check-cast v7, Landroidx/compose/runtime/MutableState;

    .line 129
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 131
    if-eqz v0, :cond_9d

    .line 133
    if-eq v0, v10, :cond_95

    .line 135
    if-ne v0, v3, :cond_90

    .line 137
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 139
    check-cast v0, Landroidx/compose/foundation/interaction/PressInteraction$Press;

    .line 141
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 144
    goto :goto_d1

    .line 145
    :cond_90
    invoke-static {v8}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 148
    move-object v6, v11

    .line 149
    goto :goto_d4

    .line 150
    :cond_95
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 152
    check-cast v0, Landroidx/compose/runtime/MutableState;

    .line 154
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 157
    goto :goto_bb

    .line 158
    :cond_9d
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 161
    invoke-interface {v7}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 164
    move-result-object v0

    .line 165
    check-cast v0, Landroidx/compose/foundation/interaction/PressInteraction$Press;

    .line 167
    if-eqz v0, :cond_be

    .line 169
    new-instance v8, Landroidx/compose/foundation/interaction/PressInteraction$Cancel;

    .line 171
    invoke-direct {v8, v0}, Landroidx/compose/foundation/interaction/PressInteraction$Cancel;-><init>(Landroidx/compose/foundation/interaction/PressInteraction$Press;)V

    .line 174
    if-eqz v4, :cond_ba

    .line 176
    iput-object v7, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 178
    iput v10, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 180
    invoke-virtual {v4, v8, p0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 183
    move-result-object v0

    .line 184
    if-ne v0, v9, :cond_ba

    .line 186
    goto :goto_cf

    .line 187
    :cond_ba
    move-object v0, v7

    .line 188
    :goto_bb
    invoke-interface {v0, v11}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 191
    :cond_be
    new-instance v0, Landroidx/compose/foundation/interaction/PressInteraction$Press;

    .line 193
    invoke-direct {v0, v1, v2}, Landroidx/compose/foundation/interaction/PressInteraction$Press;-><init>(J)V

    .line 196
    if-eqz v4, :cond_d1

    .line 198
    iput-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 200
    iput v3, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 202
    invoke-virtual {v4, v0, p0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 205
    move-result-object v1

    .line 206
    if-ne v1, v9, :cond_d1

    .line 208
    :goto_cf
    move-object v6, v9

    .line 209
    goto :goto_d4

    .line 210
    :cond_d1
    :goto_d1
    invoke-interface {v7, v0}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 213
    :goto_d4
    return-object v6

    .line 214
    :pswitch_d5  #0x1
    check-cast v4, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 216
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 218
    const/4 v12, 0x3

    .line 219
    if-eqz v0, :cond_f7

    .line 221
    if-eq v0, v10, :cond_f3

    .line 223
    if-eq v0, v3, :cond_eb

    .line 225
    if-ne v0, v12, :cond_e6

    .line 227
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 230
    goto :goto_126

    .line 231
    :cond_e6
    invoke-static {v8}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 234
    move-object v6, v11

    .line 235
    goto :goto_126

    .line 236
    :cond_eb
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 238
    check-cast v0, Landroidx/compose/foundation/interaction/PressInteraction$Release;

    .line 240
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 243
    goto :goto_11b

    .line 244
    :cond_f3
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 247
    goto :goto_105

    .line 248
    :cond_f7
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 251
    check-cast v7, Lkotlinx/coroutines/Job;

    .line 253
    iput v10, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 255
    invoke-interface {v7, p0}, Lkotlinx/coroutines/Job;->join(Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 258
    move-result-object v0

    .line 259
    if-ne v0, v9, :cond_105

    .line 261
    goto :goto_125

    .line 262
    :cond_105
    :goto_105
    new-instance v0, Landroidx/compose/foundation/interaction/PressInteraction$Press;

    .line 264
    invoke-direct {v0, v1, v2}, Landroidx/compose/foundation/interaction/PressInteraction$Press;-><init>(J)V

    .line 267
    new-instance v1, Landroidx/compose/foundation/interaction/PressInteraction$Release;

    .line 269
    invoke-direct {v1, v0}, Landroidx/compose/foundation/interaction/PressInteraction$Release;-><init>(Landroidx/compose/foundation/interaction/PressInteraction$Press;)V

    .line 272
    iput-object v1, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 274
    iput v3, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 276
    invoke-virtual {v4, v0, p0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 279
    move-result-object v0

    .line 280
    if-ne v0, v9, :cond_11a

    .line 282
    goto :goto_125

    .line 283
    :cond_11a
    move-object v0, v1

    .line 284
    :goto_11b
    iput-object v11, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 286
    iput v12, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 288
    invoke-virtual {v4, v0, p0}, Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;->emit(Landroidx/compose/foundation/interaction/Interaction;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 291
    move-result-object v0

    .line 292
    if-ne v0, v9, :cond_126

    .line 294
    :goto_125
    move-object v6, v9

    .line 295
    :cond_126
    :goto_126
    return-object v6

    .line 296
    :pswitch_127  #0x0
    check-cast v7, Landroidx/compose/foundation/gestures/ScrollingLogic;

    .line 298
    iget v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 300
    if-eqz v0, :cond_138

    .line 302
    if-ne v0, v10, :cond_133

    .line 304
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 307
    goto :goto_15d

    .line 308
    :cond_133
    invoke-static {v8}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 311
    move-object v6, v11

    .line 312
    goto :goto_15d

    .line 313
    :cond_138
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 316
    iget-object v0, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->L$0:Ljava/lang/Object;

    .line 318
    check-cast v0, Landroidx/compose/foundation/gestures/ScrollingLogic$nestedScrollScope$1;

    .line 320
    invoke-virtual {v7, v1, v2}, Landroidx/compose/foundation/gestures/ScrollingLogic;->toFloat-k-4lQ0M(J)F

    .line 323
    move-result v1

    .line 324
    check-cast v4, Lkotlin/jvm/internal/Ref$FloatRef;

    .line 326
    new-instance v2, Landroidx/compose/foundation/text/CoreTextFieldKt$$ExternalSyntheticLambda13;

    .line 328
    invoke-direct {v2, v4, v7, v0, v10}, Landroidx/compose/foundation/text/CoreTextFieldKt$$ExternalSyntheticLambda13;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 331
    iput v10, p0, Landroidx/compose/foundation/gestures/ScrollableKt$semanticsScrollBy$2;->label:I

    .line 333
    const/4 v0, 0x7

    .line 334
    const/4 v3, 0x0

    .line 335
    invoke-static {v3, v3, v11, v0}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FFLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 338
    move-result-object v3

    .line 339
    const/4 v0, 0x0

    .line 340
    move-object v4, v2

    .line 341
    const/4 v2, 0x0

    .line 342
    move-object v5, p0

    .line 343
    invoke-static/range {v0 .. v5}, Landroidx/compose/animation/core/ArcSplineKt;->animate(FFFLandroidx/compose/animation/core/AnimationSpec;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/jvm/internal/SuspendLambda;)Ljava/lang/Object;

    .line 346
    move-result-object v0

    .line 347
    if-ne v0, v9, :cond_15d

    .line 349
    move-object v6, v9

    .line 350
    :cond_15d
    :goto_15d
    return-object v6

    .line 351
    :pswitch_data_15e
    .packed-switch 0x0
        :pswitch_127  #00000000
        :pswitch_d5  #00000001
        :pswitch_7c  #00000002
        :pswitch_3e  #00000003
    .end packed-switch
.end method
