.class public final Landroidx/compose/foundation/gestures/TouchSlopDetector;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public orientation:Landroidx/compose/foundation/gestures/Orientation;

.field public totalPositionChange:J


# direct methods
.method public constructor <init>(JLandroidx/compose/foundation/gestures/Orientation;)V
    .registers 4

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p3, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 6
    iput-wide p1, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 8
    return-void
.end method

.method public synthetic constructor <init>(Landroidx/compose/foundation/gestures/Orientation;)V
    .registers 4

    const-wide/16 v0, 0x0

    .line 9
    invoke-direct {p0, v0, v1, p1}, Landroidx/compose/foundation/gestures/TouchSlopDetector;-><init>(JLandroidx/compose/foundation/gestures/Orientation;)V

    return-void
.end method


# virtual methods
.method public final addPositions-akrDWew(FJJ)J
    .registers 10

    .line 1
    invoke-static {p2, p3, p4, p5}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 4
    move-result-wide p2

    .line 5
    iget-wide p4, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 7
    invoke-static {p4, p5, p2, p3}, Landroidx/compose/ui/geometry/Offset;->plus-MK-Hz9U(JJ)J

    .line 10
    move-result-wide p2

    .line 11
    iput-wide p2, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 13
    iget-object p4, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 15
    if-nez p4, :cond_15

    .line 17
    invoke-static {p2, p3}, Landroidx/compose/ui/geometry/Offset;->getDistance-impl(J)F

    .line 20
    move-result p2

    .line 21
    goto :goto_1d

    .line 22
    :cond_15
    invoke-virtual {p0, p2, p3}, Landroidx/compose/foundation/gestures/TouchSlopDetector;->mainAxis-k-4lQ0M(J)F

    .line 25
    move-result p2

    .line 26
    invoke-static {p2}, Ljava/lang/Math;->abs(F)F

    .line 29
    move-result p2

    .line 30
    :goto_1d
    cmpl-float p2, p2, p1

    .line 32
    if-ltz p2, :cond_9b

    .line 34
    iget-object p2, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 36
    iget-wide p3, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 38
    const-wide v0, 0xffffffffL

    .line 43
    const/16 p5, 0x20

    .line 45
    if-nez p2, :cond_5a

    .line 47
    invoke-static {p3, p4}, Landroidx/compose/ui/geometry/Offset;->getDistance-impl(J)F

    .line 50
    move-result p2

    .line 51
    shr-long v2, p3, p5

    .line 53
    long-to-int v2, v2

    .line 54
    invoke-static {v2}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 57
    move-result v2

    .line 58
    div-float/2addr v2, p2

    .line 59
    and-long/2addr p3, v0

    .line 60
    long-to-int p3, p3

    .line 61
    invoke-static {p3}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 64
    move-result p3

    .line 65
    div-float/2addr p3, p2

    .line 66
    invoke-static {v2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 69
    move-result p2

    .line 70
    int-to-long v2, p2

    .line 71
    invoke-static {p3}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 74
    move-result p2

    .line 75
    int-to-long p2, p2

    .line 76
    shl-long p4, v2, p5

    .line 78
    and-long/2addr p2, v0

    .line 79
    or-long/2addr p2, p4

    .line 80
    invoke-static {p1, p2, p3}, Landroidx/compose/ui/geometry/Offset;->times-tuRUvjQ(FJ)J

    .line 83
    move-result-wide p1

    .line 84
    iget-wide p3, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 86
    invoke-static {p3, p4, p1, p2}, Landroidx/compose/ui/geometry/Offset;->minus-MK-Hz9U(JJ)J

    .line 89
    move-result-wide p0

    .line 90
    return-wide p0

    .line 91
    :cond_5a
    invoke-virtual {p0, p3, p4}, Landroidx/compose/foundation/gestures/TouchSlopDetector;->mainAxis-k-4lQ0M(J)F

    .line 94
    move-result p2

    .line 95
    iget-wide p3, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 97
    invoke-virtual {p0, p3, p4}, Landroidx/compose/foundation/gestures/TouchSlopDetector;->mainAxis-k-4lQ0M(J)F

    .line 100
    move-result p3

    .line 101
    invoke-static {p3}, Ljava/lang/Math;->signum(F)F

    .line 104
    move-result p3

    .line 105
    mul-float/2addr p3, p1

    .line 106
    sub-float/2addr p2, p3

    .line 107
    iget-wide p3, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->totalPositionChange:J

    .line 109
    iget-object p1, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 111
    sget-object v2, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 113
    if-ne p1, v2, :cond_79

    .line 115
    and-long/2addr p3, v0

    .line 116
    :goto_73
    long-to-int p1, p3

    .line 117
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 120
    move-result p1

    .line 121
    goto :goto_7b

    .line 122
    :cond_79
    shr-long/2addr p3, p5

    .line 123
    goto :goto_73

    .line 124
    :goto_7b
    iget-object p0, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 126
    if-ne p0, v2, :cond_8d

    .line 128
    invoke-static {p2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 131
    move-result p0

    .line 132
    int-to-long p2, p0

    .line 133
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 136
    move-result p0

    .line 137
    int-to-long p0, p0

    .line 138
    shl-long/2addr p2, p5

    .line 139
    and-long/2addr p0, v0

    .line 140
    or-long/2addr p0, p2

    .line 141
    return-wide p0

    .line 142
    :cond_8d
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 145
    move-result p0

    .line 146
    int-to-long p0, p0

    .line 147
    invoke-static {p2}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 150
    move-result p2

    .line 151
    int-to-long p2, p2

    .line 152
    shl-long/2addr p0, p5

    .line 153
    and-long/2addr p2, v0

    .line 154
    or-long/2addr p0, p2

    .line 155
    return-wide p0

    .line 156
    :cond_9b
    const-wide p0, 0x7fc000007fc00000L  # 2.247117487993712E307

    .line 161
    return-wide p0
.end method

.method public final mainAxis-k-4lQ0M(J)F
    .registers 5

    .line 1
    iget-object p0, p0, Landroidx/compose/foundation/gestures/TouchSlopDetector;->orientation:Landroidx/compose/foundation/gestures/Orientation;

    .line 3
    sget-object v0, Landroidx/compose/foundation/gestures/Orientation;->Horizontal:Landroidx/compose/foundation/gestures/Orientation;

    .line 5
    if-ne p0, v0, :cond_10

    .line 7
    const/16 p0, 0x20

    .line 9
    shr-long p0, p1, p0

    .line 11
    :goto_a
    long-to-int p0, p0

    .line 12
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 15
    move-result p0

    .line 16
    return p0

    .line 17
    :cond_10
    const-wide v0, 0xffffffffL

    .line 22
    and-long p0, p1, v0

    .line 24
    goto :goto_a
.end method
