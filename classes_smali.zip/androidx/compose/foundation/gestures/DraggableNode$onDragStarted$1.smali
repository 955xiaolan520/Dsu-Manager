.class public final Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $$v$c$androidx-compose-ui-geometry-Offset$-startedPosition$0:J

.field public final synthetic $r8$classId:I

.field public synthetic L$0:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Landroidx/compose/ui/Modifier$Node;


# direct methods
.method public constructor <init>(Landroidx/compose/animation/SizeAnimationModifierNode$AnimData;JLandroidx/compose/animation/SizeAnimationModifierNode;Lkotlin/coroutines/Continuation;)V
    .registers 7

    .line 1
    const/4 v0, 0x1

    .line 2
    iput v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$r8$classId:I

    .line 4
    iput-object p1, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->L$0:Ljava/lang/Object;

    .line 6
    iput-wide p2, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$$v$c$androidx-compose-ui-geometry-Offset$-startedPosition$0:J

    .line 8
    iput-object p4, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->this$0:Landroidx/compose/ui/Modifier$Node;

    .line 10
    const/4 p1, 0x2

    .line 11
    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 14
    return-void
.end method

.method public constructor <init>(Landroidx/compose/foundation/gestures/DraggableNode;JLkotlin/coroutines/Continuation;)V
    .registers 6

    const/4 v0, 0x0

    iput v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$r8$classId:I

    .line 15
    iput-object p1, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->this$0:Landroidx/compose/ui/Modifier$Node;

    iput-wide p2, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$$v$c$androidx-compose-ui-geometry-Offset$-startedPosition$0:J

    const/4 p1, 0x2

    invoke-direct {p0, p1, p4}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 11

    .line 1
    iget v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$r8$classId:I

    .line 3
    iget-object v1, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->this$0:Landroidx/compose/ui/Modifier$Node;

    .line 5
    packed-switch v0, :pswitch_data_26

    .line 8
    new-instance v2, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;

    .line 10
    iget-object p1, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->L$0:Ljava/lang/Object;

    .line 12
    move-object v3, p1

    .line 13
    check-cast v3, Landroidx/compose/animation/SizeAnimationModifierNode$AnimData;

    .line 15
    iget-wide v4, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$$v$c$androidx-compose-ui-geometry-Offset$-startedPosition$0:J

    .line 17
    move-object v6, v1

    .line 18
    check-cast v6, Landroidx/compose/animation/SizeAnimationModifierNode;

    .line 20
    move-object v7, p2

    .line 21
    invoke-direct/range {v2 .. v7}, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;-><init>(Landroidx/compose/animation/SizeAnimationModifierNode$AnimData;JLandroidx/compose/animation/SizeAnimationModifierNode;Lkotlin/coroutines/Continuation;)V

    .line 24
    return-object v2

    .line 25
    :pswitch_18  #0x0
    move-object v7, p2

    .line 26
    new-instance p2, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;

    .line 28
    check-cast v1, Landroidx/compose/foundation/gestures/DraggableNode;

    .line 30
    iget-wide v2, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$$v$c$androidx-compose-ui-geometry-Offset$-startedPosition$0:J

    .line 32
    invoke-direct {p2, v1, v2, v3, v7}, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;-><init>(Landroidx/compose/foundation/gestures/DraggableNode;JLkotlin/coroutines/Continuation;)V

    .line 35
    iput-object p1, p2, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->L$0:Ljava/lang/Object;

    .line 37
    return-object p2

    nop

    .line 39
    :pswitch_data_26
    .packed-switch 0x0
        :pswitch_18  #00000000
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$r8$classId:I

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 7
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 9
    packed-switch v0, :pswitch_data_22

    .line 12
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;

    .line 18
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x0
    invoke-virtual {p0, p1, p2}, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;

    .line 29
    invoke-virtual {p0, v1}, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    move-result-object p0

    .line 33
    return-object p0

    nop

    .line 35
    :pswitch_data_22
    .packed-switch 0x0
        :pswitch_16  #00000000
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .line 1
    iget v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$r8$classId:I

    .line 3
    sget-object v6, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    iget-wide v1, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->$$v$c$androidx-compose-ui-geometry-Offset$-startedPosition$0:J

    .line 7
    const/4 v3, 0x0

    .line 8
    const-string v5, "call to \'resume\' before \'invoke\' with coroutine"

    .line 10
    sget-object v7, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 12
    const/4 v8, 0x1

    .line 13
    iget-object v9, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->this$0:Landroidx/compose/ui/Modifier$Node;

    .line 15
    packed-switch v0, :pswitch_data_70

    .line 18
    check-cast v9, Landroidx/compose/animation/SizeAnimationModifierNode;

    .line 20
    iget-object v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->L$0:Ljava/lang/Object;

    .line 22
    check-cast v0, Landroidx/compose/animation/SizeAnimationModifierNode$AnimData;

    .line 24
    iget v10, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->label:I

    .line 26
    if-eqz v10, :cond_27

    .line 28
    if-ne v10, v8, :cond_22

    .line 30
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 33
    move-object v0, p1

    .line 34
    goto :goto_42

    .line 35
    :cond_22
    invoke-static {v5}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 38
    move-object v6, v3

    .line 39
    goto :goto_46

    .line 40
    :cond_27
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 43
    iget-object v0, v0, Landroidx/compose/animation/SizeAnimationModifierNode$AnimData;->anim:Landroidx/compose/animation/core/Animatable;

    .line 45
    new-instance v3, Landroidx/compose/ui/unit/IntSize;

    .line 47
    invoke-direct {v3, v1, v2}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 50
    iget-object v2, v9, Landroidx/compose/animation/SizeAnimationModifierNode;->animationSpec:Landroidx/compose/animation/core/SpringSpec;

    .line 52
    iput v8, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->label:I

    .line 54
    move-object v1, v3

    .line 55
    const/4 v3, 0x0

    .line 56
    const/16 v5, 0xc

    .line 58
    move-object v4, p0

    .line 59
    invoke-static/range {v0 .. v5}, Landroidx/compose/animation/core/Animatable;->animateTo$default(Landroidx/compose/animation/core/Animatable;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationSpec;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;I)Ljava/lang/Object;

    .line 62
    move-result-object v0

    .line 63
    if-ne v0, v7, :cond_42

    .line 65
    move-object v6, v7

    .line 66
    goto :goto_46

    .line 67
    :cond_42
    :goto_42
    check-cast v0, Landroidx/compose/animation/core/AnimationResult;

    .line 69
    iget-object v0, v0, Landroidx/compose/animation/core/AnimationResult;->endReason:Landroidx/compose/animation/core/AnimationEndReason;

    .line 71
    :goto_46
    return-object v6

    .line 72
    :pswitch_47  #0x0
    iget v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->label:I

    .line 74
    if-eqz v0, :cond_56

    .line 76
    if-ne v0, v8, :cond_51

    .line 78
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 81
    goto :goto_6f

    .line 82
    :cond_51
    invoke-static {v5}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 85
    move-object v6, v3

    .line 86
    goto :goto_6f

    .line 87
    :cond_56
    invoke-static {p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 90
    iget-object v0, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->L$0:Ljava/lang/Object;

    .line 92
    check-cast v0, Lkotlinx/coroutines/CoroutineScope;

    .line 94
    check-cast v9, Landroidx/compose/foundation/gestures/DraggableNode;

    .line 96
    iget-object v3, v9, Landroidx/compose/foundation/gestures/DraggableNode;->onDragStarted:Lkotlin/jvm/functions/Function3;

    .line 98
    new-instance v5, Landroidx/compose/ui/geometry/Offset;

    .line 100
    invoke-direct {v5, v1, v2}, Landroidx/compose/ui/geometry/Offset;-><init>(J)V

    .line 103
    iput v8, p0, Landroidx/compose/foundation/gestures/DraggableNode$onDragStarted$1;->label:I

    .line 105
    invoke-interface {v3, v0, v5, p0}, Lkotlin/jvm/functions/Function3;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 108
    move-result-object v0

    .line 109
    if-ne v0, v7, :cond_6f

    .line 111
    move-object v6, v7

    .line 112
    :cond_6f
    :goto_6f
    return-object v6

    .line 113
    :pswitch_data_70
    .packed-switch 0x0
        :pswitch_47  #00000000
    .end packed-switch
.end method
