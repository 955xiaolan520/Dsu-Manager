.class public final Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown;
.super Lkotlin/math/MathKt;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public awaitTouchSlop:Landroidx/compose/foundation/gestures/DragDetectionState$AwaitDown$AwaitTouchSlop;

.field public consumedOnInitial:Z
