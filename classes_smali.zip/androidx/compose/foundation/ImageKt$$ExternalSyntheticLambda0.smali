.class public final synthetic Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:I


# direct methods
.method public synthetic constructor <init>(I)V
    .registers 2

    .line 1
    iput p1, p0, Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 9

    .line 1
    iget p0, p0, Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 3
    const/4 v0, 0x1

    .line 4
    const/4 v1, 0x0

    .line 5
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    const-wide v3, 0xffffffffL

    .line 12
    const/16 v5, 0x20

    .line 14
    packed-switch p0, :pswitch_data_254

    .line 17
    check-cast p1, Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 19
    sget-object p0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->LocalContext:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 21
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 24
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 27
    move-result-object p0

    .line 28
    check-cast p0, Landroid/content/Context;

    .line 30
    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    .line 33
    move-result-object p0

    .line 34
    const-string p1, "android.software.leanback"

    .line 36
    invoke-virtual {p0, p1}, Landroid/content/pm/PackageManager;->hasSystemFeature(Ljava/lang/String;)Z

    .line 39
    move-result p0

    .line 40
    if-nez p0, :cond_31

    .line 42
    sget-object p0, Landroidx/compose/foundation/gestures/BringIntoViewSpec;->Companion:Landroidx/compose/foundation/gestures/BringIntoViewSpec$Companion;

    .line 44
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 47
    sget-object p0, Landroidx/compose/foundation/gestures/BringIntoViewSpec$Companion;->DefaultBringIntoViewSpec:Landroidx/compose/foundation/gestures/BringIntoViewSpec$Companion$DefaultBringIntoViewSpec$1;

    .line 49
    goto :goto_33

    .line 50
    :cond_31
    sget-object p0, Landroidx/compose/foundation/gestures/BringIntoViewSpec_androidKt;->PivotBringIntoViewSpec:Landroidx/compose/foundation/gestures/BringIntoViewSpec_androidKt$PivotBringIntoViewSpec$1;

    .line 52
    :goto_33
    return-object p0

    .line 53
    :pswitch_34  #0x1c
    check-cast p1, Ljava/lang/Integer;

    .line 55
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 58
    move-result p0

    .line 59
    new-instance p1, Landroidx/compose/foundation/ScrollState;

    .line 61
    invoke-direct {p1, p0}, Landroidx/compose/foundation/ScrollState;-><init>(I)V

    .line 64
    return-object p1

    .line 65
    :pswitch_40  #0x1b
    check-cast p1, Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    .line 67
    sget-object p0, Landroidx/compose/ui/semantics/ProgressBarRangeInfo;->Indeterminate:Landroidx/compose/ui/semantics/ProgressBarRangeInfo;

    .line 69
    sget-object v1, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->$$delegatedProperties:[Lkotlin/reflect/KProperty;

    .line 71
    sget-object v1, Landroidx/compose/ui/semantics/SemanticsProperties;->ProgressBarRangeInfo:Landroidx/compose/ui/semantics/SemanticsPropertyKey;

    .line 73
    sget-object v3, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->$$delegatedProperties:[Lkotlin/reflect/KProperty;

    .line 75
    aget-object v0, v3, v0

    .line 77
    invoke-interface {p1, v1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;->set(Landroidx/compose/ui/semantics/SemanticsPropertyKey;Ljava/lang/Object;)V

    .line 80
    return-object v2

    .line 81
    :pswitch_50  #0x1a
    check-cast p1, Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 83
    sget p0, Landroidx/compose/foundation/AndroidOverscroll_androidKt;->$r8$clinit:I

    .line 85
    sget-object p0, Landroidx/compose/ui/platform/AndroidCompositionLocals_androidKt;->LocalContext:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 87
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 90
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 93
    move-result-object p0

    .line 94
    move-object v1, p0

    .line 95
    check-cast v1, Landroid/content/Context;

    .line 97
    sget-object p0, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalDensity:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 99
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 102
    move-result-object p0

    .line 103
    move-object v2, p0

    .line 104
    check-cast v2, Landroidx/compose/ui/unit/Density;

    .line 106
    sget-object p0, Landroidx/compose/foundation/OverscrollConfiguration_androidKt;->LocalOverscrollConfiguration:Landroidx/compose/runtime/DynamicProvidableCompositionLocal;

    .line 108
    invoke-static {p1, p0}, Landroidx/compose/runtime/Updater;->read(Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 111
    move-result-object p0

    .line 112
    check-cast p0, Landroidx/compose/foundation/OverscrollConfiguration;

    .line 114
    if-nez p0, :cond_75

    .line 116
    const/4 p0, 0x0

    .line 117
    goto :goto_7f

    .line 118
    :cond_75
    new-instance v0, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollFactory;

    .line 120
    iget-wide v3, p0, Landroidx/compose/foundation/OverscrollConfiguration;->glowColor:J

    .line 122
    iget-object v5, p0, Landroidx/compose/foundation/OverscrollConfiguration;->drawPadding:Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 124
    invoke-direct/range {v0 .. v5}, Landroidx/compose/foundation/AndroidEdgeEffectOverscrollFactory;-><init>(Landroid/content/Context;Landroidx/compose/ui/unit/Density;JLandroidx/compose/foundation/layout/PaddingValues;)V

    .line 127
    move-object p0, v0

    .line 128
    :goto_7f
    return-object p0

    .line 129
    :pswitch_80  #0x19
    check-cast p1, Ljava/lang/Long;

    .line 131
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    return-object v2

    .line 135
    :pswitch_86  #0x18
    check-cast p1, Landroidx/compose/ui/layout/Placeable$PlacementScope;

    .line 137
    return-object v2

    .line 138
    :pswitch_89  #0x17
    check-cast p1, Landroidx/compose/ui/node/LayoutNodeDrawScope;

    .line 140
    invoke-virtual {p1}, Landroidx/compose/ui/node/LayoutNodeDrawScope;->drawContent()V

    .line 143
    return-object v2

    .line 144
    :pswitch_8f  #0x16
    check-cast p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 146
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector1D;->value:F

    .line 148
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 151
    move-result-object p0

    .line 152
    return-object p0

    .line 153
    :pswitch_98  #0x15
    check-cast p1, Landroidx/compose/animation/core/AnimationVector4D;

    .line 155
    new-instance p0, Landroidx/compose/ui/geometry/Rect;

    .line 157
    iget v0, p1, Landroidx/compose/animation/core/AnimationVector4D;->v1:F

    .line 159
    iget v1, p1, Landroidx/compose/animation/core/AnimationVector4D;->v2:F

    .line 161
    iget v2, p1, Landroidx/compose/animation/core/AnimationVector4D;->v3:F

    .line 163
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector4D;->v4:F

    .line 165
    invoke-direct {p0, v0, v1, v2, p1}, Landroidx/compose/ui/geometry/Rect;-><init>(FFFF)V

    .line 168
    return-object p0

    .line 169
    :pswitch_a8  #0x14
    check-cast p1, Landroidx/compose/ui/geometry/Rect;

    .line 171
    new-instance p0, Landroidx/compose/animation/core/AnimationVector4D;

    .line 173
    iget v0, p1, Landroidx/compose/ui/geometry/Rect;->left:F

    .line 175
    iget v1, p1, Landroidx/compose/ui/geometry/Rect;->top:F

    .line 177
    iget v2, p1, Landroidx/compose/ui/geometry/Rect;->right:F

    .line 179
    iget p1, p1, Landroidx/compose/ui/geometry/Rect;->bottom:F

    .line 181
    invoke-direct {p0, v0, v1, v2, p1}, Landroidx/compose/animation/core/AnimationVector4D;-><init>(FFFF)V

    .line 184
    return-object p0

    .line 185
    :pswitch_b8  #0x13
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 187
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 189
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 192
    move-result p0

    .line 193
    if-gez p0, :cond_c3

    .line 195
    move p0, v1

    .line 196
    :cond_c3
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 198
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 201
    move-result p1

    .line 202
    if-gez p1, :cond_cc

    .line 204
    goto :goto_cd

    .line 205
    :cond_cc
    move v1, p1

    .line 206
    :goto_cd
    int-to-long p0, p0

    .line 207
    shl-long/2addr p0, v5

    .line 208
    int-to-long v0, v1

    .line 209
    and-long/2addr v0, v3

    .line 210
    or-long/2addr p0, v0

    .line 211
    new-instance v0, Landroidx/compose/ui/unit/IntSize;

    .line 213
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 216
    return-object v0

    .line 217
    :pswitch_d8  #0x12
    check-cast p1, Landroidx/compose/ui/unit/IntSize;

    .line 219
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 221
    iget-wide v0, p1, Landroidx/compose/ui/unit/IntSize;->packedValue:J

    .line 223
    shr-long v5, v0, v5

    .line 225
    long-to-int p1, v5

    .line 226
    int-to-float p1, p1

    .line 227
    and-long/2addr v0, v3

    .line 228
    long-to-int v0, v0

    .line 229
    int-to-float v0, v0

    .line 230
    invoke-direct {p0, p1, v0}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 233
    return-object p0

    .line 234
    :pswitch_e9  #0x11
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 236
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 238
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    .line 241
    move-result p0

    .line 242
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 244
    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    .line 247
    move-result p1

    .line 248
    int-to-long v0, p0

    .line 249
    shl-long/2addr v0, v5

    .line 250
    int-to-long p0, p1

    .line 251
    and-long/2addr p0, v3

    .line 252
    or-long/2addr p0, v0

    .line 253
    new-instance v0, Landroidx/compose/ui/unit/IntOffset;

    .line 255
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/unit/IntOffset;-><init>(J)V

    .line 258
    return-object v0

    .line 259
    :pswitch_102  #0x10
    check-cast p1, Landroidx/compose/ui/unit/IntOffset;

    .line 261
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 263
    iget-wide v0, p1, Landroidx/compose/ui/unit/IntOffset;->packedValue:J

    .line 265
    shr-long v5, v0, v5

    .line 267
    long-to-int p1, v5

    .line 268
    int-to-float p1, p1

    .line 269
    and-long/2addr v0, v3

    .line 270
    long-to-int v0, v0

    .line 271
    int-to-float v0, v0

    .line 272
    invoke-direct {p0, p1, v0}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 275
    return-object p0

    .line 276
    :pswitch_113  #0xf
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 278
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 280
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 282
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 285
    move-result p0

    .line 286
    int-to-long v0, p0

    .line 287
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 290
    move-result p0

    .line 291
    int-to-long p0, p0

    .line 292
    shl-long/2addr v0, v5

    .line 293
    and-long/2addr p0, v3

    .line 294
    or-long/2addr p0, v0

    .line 295
    new-instance v0, Landroidx/compose/ui/geometry/Offset;

    .line 297
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/geometry/Offset;-><init>(J)V

    .line 300
    return-object v0

    .line 301
    :pswitch_12c  #0xe
    check-cast p1, Landroidx/compose/ui/geometry/Offset;

    .line 303
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 305
    iget-wide v0, p1, Landroidx/compose/ui/geometry/Offset;->packedValue:J

    .line 307
    shr-long/2addr v0, v5

    .line 308
    long-to-int v0, v0

    .line 309
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 312
    move-result v0

    .line 313
    iget-wide v1, p1, Landroidx/compose/ui/geometry/Offset;->packedValue:J

    .line 315
    and-long/2addr v1, v3

    .line 316
    long-to-int p1, v1

    .line 317
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 320
    move-result p1

    .line 321
    invoke-direct {p0, v0, p1}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 324
    return-object p0

    .line 325
    :pswitch_144  #0xd
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 327
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 329
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 331
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 334
    move-result p0

    .line 335
    int-to-long v0, p0

    .line 336
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 339
    move-result p0

    .line 340
    int-to-long p0, p0

    .line 341
    shl-long/2addr v0, v5

    .line 342
    and-long/2addr p0, v3

    .line 343
    or-long/2addr p0, v0

    .line 344
    new-instance v0, Landroidx/compose/ui/geometry/Size;

    .line 346
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/geometry/Size;-><init>(J)V

    .line 349
    return-object v0

    .line 350
    :pswitch_15d  #0xc
    check-cast p1, Landroidx/compose/ui/geometry/Size;

    .line 352
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 354
    iget-wide v0, p1, Landroidx/compose/ui/geometry/Size;->packedValue:J

    .line 356
    shr-long/2addr v0, v5

    .line 357
    long-to-int v0, v0

    .line 358
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 361
    move-result v0

    .line 362
    iget-wide v1, p1, Landroidx/compose/ui/geometry/Size;->packedValue:J

    .line 364
    and-long/2addr v1, v3

    .line 365
    long-to-int p1, v1

    .line 366
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 369
    move-result p1

    .line 370
    invoke-direct {p0, v0, p1}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 373
    return-object p0

    .line 374
    :pswitch_175  #0xb
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 376
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 378
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 380
    invoke-static {p0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 383
    move-result p0

    .line 384
    int-to-long v0, p0

    .line 385
    invoke-static {p1}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 388
    move-result p0

    .line 389
    int-to-long p0, p0

    .line 390
    shl-long/2addr v0, v5

    .line 391
    and-long/2addr p0, v3

    .line 392
    or-long/2addr p0, v0

    .line 393
    new-instance v0, Landroidx/compose/ui/unit/DpOffset;

    .line 395
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/unit/DpOffset;-><init>(J)V

    .line 398
    return-object v0

    .line 399
    :pswitch_18e  #0xa
    check-cast p1, Landroidx/compose/ui/unit/DpOffset;

    .line 401
    new-instance p0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 403
    iget-wide v0, p1, Landroidx/compose/ui/unit/DpOffset;->packedValue:J

    .line 405
    shr-long/2addr v0, v5

    .line 406
    long-to-int v0, v0

    .line 407
    invoke-static {v0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 410
    move-result v0

    .line 411
    iget-wide v1, p1, Landroidx/compose/ui/unit/DpOffset;->packedValue:J

    .line 413
    and-long/2addr v1, v3

    .line 414
    long-to-int p1, v1

    .line 415
    invoke-static {p1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 418
    move-result p1

    .line 419
    invoke-direct {p0, v0, p1}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 422
    return-object p0

    .line 423
    :pswitch_1a6  #0x9
    check-cast p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 425
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector1D;->value:F

    .line 427
    new-instance p1, Landroidx/compose/ui/unit/Dp;

    .line 429
    invoke-direct {p1, p0}, Landroidx/compose/ui/unit/Dp;-><init>(F)V

    .line 432
    return-object p1

    .line 433
    :pswitch_1b0  #0x8
    check-cast p1, Landroidx/compose/ui/unit/Dp;

    .line 435
    new-instance p0, Landroidx/compose/animation/core/AnimationVector1D;

    .line 437
    iget p1, p1, Landroidx/compose/ui/unit/Dp;->value:F

    .line 439
    invoke-direct {p0, p1}, Landroidx/compose/animation/core/AnimationVector1D;-><init>(F)V

    .line 442
    return-object p0

    .line 443
    :pswitch_1ba  #0x7
    check-cast p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 445
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector1D;->value:F

    .line 447
    float-to-int p0, p0

    .line 448
    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 451
    move-result-object p0

    .line 452
    return-object p0

    .line 453
    :pswitch_1c4  #0x6
    check-cast p1, Ljava/lang/Integer;

    .line 455
    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    .line 458
    move-result p0

    .line 459
    new-instance p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 461
    int-to-float p0, p0

    .line 462
    invoke-direct {p1, p0}, Landroidx/compose/animation/core/AnimationVector1D;-><init>(F)V

    .line 465
    return-object p1

    .line 466
    :pswitch_1d1  #0x5
    check-cast p1, Ljava/lang/Float;

    .line 468
    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    .line 471
    move-result p0

    .line 472
    new-instance p1, Landroidx/compose/animation/core/AnimationVector1D;

    .line 474
    invoke-direct {p1, p0}, Landroidx/compose/animation/core/AnimationVector1D;-><init>(F)V

    .line 477
    return-object p1

    .line 478
    :pswitch_1dd  #0x4
    check-cast p1, Lkotlin/jvm/functions/Function0;

    .line 480
    invoke-interface {p1}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 483
    return-object v2

    .line 484
    :pswitch_1e3  #0x3
    check-cast p1, Landroidx/compose/animation/core/SeekableTransitionState;

    .line 486
    iget-wide v3, p1, Landroidx/compose/animation/core/SeekableTransitionState;->totalDurationNanos:J

    .line 488
    sget-object p0, Landroidx/compose/animation/core/TransitionKt;->SeekableStateObserver$delegate:Lkotlin/Lazy;

    .line 490
    invoke-interface {p0}, Lkotlin/Lazy;->getValue()Ljava/lang/Object;

    .line 493
    move-result-object p0

    .line 494
    check-cast p0, Landroidx/compose/runtime/snapshots/SnapshotStateObserver;

    .line 496
    sget-object v0, Landroidx/compose/animation/core/TransitionKt;->SeekableTransitionStateTotalDurationChanged:Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;

    .line 498
    iget-object v5, p1, Landroidx/compose/animation/core/SeekableTransitionState;->recalculateTotalDurationNanos:Landroidx/datastore/core/FileStorage$$ExternalSyntheticLambda1;

    .line 500
    invoke-virtual {p0, p1, v0, v5}, Landroidx/compose/runtime/snapshots/SnapshotStateObserver;->observeReads(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Lkotlin/jvm/functions/Function0;)V

    .line 503
    iget-wide v5, p1, Landroidx/compose/animation/core/SeekableTransitionState;->totalDurationNanos:J

    .line 505
    cmp-long p0, v3, v5

    .line 507
    if-eqz p0, :cond_22e

    .line 509
    iget-object p0, p1, Landroidx/compose/animation/core/SeekableTransitionState;->currentAnimation:Landroidx/compose/animation/core/SeekableTransitionState$SeekingAnimationState;

    .line 511
    if-eqz p0, :cond_225

    .line 513
    iget-wide v3, p0, Landroidx/compose/animation/core/SeekableTransitionState$SeekingAnimationState;->progressNanos:J

    .line 515
    cmp-long v0, v3, v5

    .line 517
    if-lez v0, :cond_20a

    .line 519
    invoke-virtual {p1}, Landroidx/compose/animation/core/SeekableTransitionState;->endAllAnimations()V

    .line 522
    goto :goto_22e

    .line 523
    :cond_20a
    iput-wide v5, p0, Landroidx/compose/animation/core/SeekableTransitionState$SeekingAnimationState;->durationNanos:J

    .line 525
    iget-object v0, p0, Landroidx/compose/animation/core/SeekableTransitionState$SeekingAnimationState;->animationSpec:Landroidx/compose/animation/core/VectorizedFiniteAnimationSpec;

    .line 527
    if-nez v0, :cond_22e

    .line 529
    iget-object v0, p0, Landroidx/compose/animation/core/SeekableTransitionState$SeekingAnimationState;->start:Landroidx/compose/animation/core/AnimationVector1D;

    .line 531
    invoke-virtual {v0, v1}, Landroidx/compose/animation/core/AnimationVector1D;->get$animation_core(I)F

    .line 534
    move-result v0

    .line 535
    float-to-double v0, v0

    .line 536
    const-wide/high16 v3, 0x3ff0000000000000L  # 1.0

    .line 538
    sub-double/2addr v3, v0

    .line 539
    iget-wide v0, p1, Landroidx/compose/animation/core/SeekableTransitionState;->totalDurationNanos:J

    .line 541
    long-to-double v0, v0

    .line 542
    mul-double/2addr v3, v0

    .line 543
    invoke-static {v3, v4}, Lkotlin/math/MathKt;->roundToLong(D)J

    .line 546
    move-result-wide v0

    .line 547
    iput-wide v0, p0, Landroidx/compose/animation/core/SeekableTransitionState$SeekingAnimationState;->animationSpecDuration:J

    .line 549
    goto :goto_22e

    .line 550
    :cond_225
    const-wide/16 v0, 0x0

    .line 552
    cmp-long p0, v5, v0

    .line 554
    if-eqz p0, :cond_22e

    .line 556
    invoke-virtual {p1}, Landroidx/compose/animation/core/SeekableTransitionState;->seekToFraction()V

    .line 559
    :cond_22e
    :goto_22e
    return-object v2

    .line 560
    :pswitch_22f  #0x2
    check-cast p1, Landroidx/compose/animation/core/AnimationScope;

    .line 562
    return-object v2

    .line 563
    :pswitch_232  #0x1
    check-cast p1, Landroid/content/res/Resources;

    .line 565
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 568
    invoke-virtual {p1}, Landroid/content/res/Resources;->getConfiguration()Landroid/content/res/Configuration;

    .line 571
    move-result-object p0

    .line 572
    iget p0, p0, Landroid/content/res/Configuration;->uiMode:I

    .line 574
    and-int/lit8 p0, p0, 0x30

    .line 576
    if-ne p0, v5, :cond_242

    .line 578
    goto :goto_243

    .line 579
    :cond_242
    move v0, v1

    .line 580
    :goto_243
    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 583
    move-result-object p0

    .line 584
    return-object p0

    .line 585
    :pswitch_248  #0x0
    check-cast p1, Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;

    .line 587
    const-string p0, "App icon"

    .line 589
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setContentDescription(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;Ljava/lang/String;)V

    .line 592
    const/4 p0, 0x5

    .line 593
    invoke-static {p1, p0}, Landroidx/compose/ui/semantics/SemanticsPropertiesKt;->setRole-kuIjeqM(Landroidx/compose/ui/semantics/SemanticsPropertyReceiver;I)V

    .line 596
    return-object v2

    .line 597
    :pswitch_data_254
    .packed-switch 0x0
        :pswitch_248  #00000000
        :pswitch_232  #00000001
        :pswitch_22f  #00000002
        :pswitch_1e3  #00000003
        :pswitch_1dd  #00000004
        :pswitch_1d1  #00000005
        :pswitch_1c4  #00000006
        :pswitch_1ba  #00000007
        :pswitch_1b0  #00000008
        :pswitch_1a6  #00000009
        :pswitch_18e  #0000000a
        :pswitch_175  #0000000b
        :pswitch_15d  #0000000c
        :pswitch_144  #0000000d
        :pswitch_12c  #0000000e
        :pswitch_113  #0000000f
        :pswitch_102  #00000010
        :pswitch_e9  #00000011
        :pswitch_d8  #00000012
        :pswitch_b8  #00000013
        :pswitch_a8  #00000014
        :pswitch_98  #00000015
        :pswitch_8f  #00000016
        :pswitch_89  #00000017
        :pswitch_86  #00000018
        :pswitch_80  #00000019
        :pswitch_50  #0000001a
        :pswitch_40  #0000001b
        :pswitch_34  #0000001c
    .end packed-switch
.end method
