.class public final synthetic Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(IILjava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    .line 1
    iput p2, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 3
    iput-object p3, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 5
    iput-object p4, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 7
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    return-void
.end method

.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Object;)V
    .registers 4

    .line 11
    iput p1, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->$r8$classId:I

    iput-object p2, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    iput-object p3, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/functions/Function1;Landroidx/lifecycle/ViewModel;II)V
    .registers 5

    .line 12
    iput p4, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->$r8$classId:I

    iput-object p1, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private final invoke$yangfentuozi$dsusideloaderplus$ui$screen$adb$AdbScreenKt$$ExternalSyntheticLambda1(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 31

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget-object v1, v0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 5
    check-cast v1, Ljava/lang/String;

    .line 7
    iget-object v0, v0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 9
    check-cast v0, Ljava/lang/String;

    .line 11
    move-object/from16 v2, p1

    .line 13
    check-cast v2, Landroidx/compose/runtime/GapComposer;

    .line 15
    move-object/from16 v3, p2

    .line 17
    check-cast v3, Ljava/lang/Integer;

    .line 19
    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    .line 22
    move-result v3

    .line 23
    and-int/lit8 v4, v3, 0x3

    .line 25
    const/4 v5, 0x1

    .line 26
    const/4 v6, 0x0

    .line 27
    const/4 v7, 0x2

    .line 28
    if-eq v4, v7, :cond_1f

    .line 30
    move v4, v5

    .line 31
    goto :goto_20

    .line 32
    :cond_1f
    move v4, v6

    .line 33
    :goto_20
    and-int/2addr v3, v5

    .line 34
    invoke-virtual {v2, v3, v4}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 37
    move-result v3

    .line 38
    if-eqz v3, :cond_138

    .line 40
    const/4 v3, 0x0

    .line 41
    sget-object v4, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 43
    const/high16 v8, 0x41800000  # 16.0f

    .line 45
    invoke-static {v4, v8, v3, v7}, Landroidx/compose/foundation/layout/SpacerKt;->padding-VpY3zN4$default(Landroidx/compose/ui/Modifier;FFI)Landroidx/compose/ui/Modifier;

    .line 48
    move-result-object v3

    .line 49
    new-instance v4, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;

    .line 51
    new-instance v9, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;

    .line 53
    invoke-direct {v9, v7}, Landroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;-><init>(I)V

    .line 56
    invoke-direct {v4, v8, v9}, Landroidx/compose/foundation/layout/Arrangement$SpacedAligned;-><init>(FLandroidx/compose/ui/text/SaversKt$$ExternalSyntheticLambda0;)V

    .line 59
    sget-object v7, Landroidx/compose/ui/Alignment$Companion;->Start:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 61
    const/4 v8, 0x6

    .line 62
    invoke-static {v4, v7, v2, v8}, Landroidx/compose/foundation/layout/ColumnKt;->columnMeasurePolicy(Landroidx/compose/foundation/layout/Arrangement$Vertical;Landroidx/compose/ui/BiasAlignment$Horizontal;Landroidx/compose/runtime/GapComposer;I)Landroidx/compose/foundation/layout/ColumnMeasurePolicy;

    .line 65
    move-result-object v4

    .line 66
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->getCurrentCompositeKeyHash(Landroidx/compose/runtime/GapComposer;)I

    .line 69
    move-result v7

    .line 70
    invoke-virtual {v2}, Landroidx/compose/runtime/GapComposer;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 73
    move-result-object v8

    .line 74
    invoke-static {v2, v3}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/GapComposer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 77
    move-result-object v3

    .line 78
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 80
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 83
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 85
    invoke-virtual {v2}, Landroidx/compose/runtime/GapComposer;->startReusableNode()V

    .line 88
    iget-boolean v10, v2, Landroidx/compose/runtime/GapComposer;->inserting:Z

    .line 90
    if-eqz v10, :cond_5f

    .line 92
    invoke-virtual {v2, v9}, Landroidx/compose/runtime/GapComposer;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 95
    goto :goto_62

    .line 96
    :cond_5f
    invoke-virtual {v2}, Landroidx/compose/runtime/GapComposer;->useNode()V

    .line 99
    :goto_62
    sget-object v9, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 101
    invoke-static {v2, v4, v9}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 104
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 106
    invoke-static {v2, v8, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 109
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 111
    iget-boolean v8, v2, Landroidx/compose/runtime/GapComposer;->inserting:Z

    .line 113
    if-nez v8, :cond_80

    .line 115
    invoke-virtual {v2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 118
    move-result-object v8

    .line 119
    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 122
    move-result-object v9

    .line 123
    invoke-static {v8, v9}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 126
    move-result v8

    .line 127
    if-nez v8, :cond_83

    .line 129
    :cond_80
    invoke-static {v7, v2, v7, v4}, Landroidx/collection/ObjectListKt$$ExternalSyntheticOutline0;->m(ILandroidx/compose/runtime/GapComposer;ILandroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;)V

    .line 132
    :cond_83
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 134
    invoke-static {v2, v3, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 137
    const v3, 0x7f10001d

    .line 140
    invoke-static {v3, v2}, Landroidx/compose/ui/geometry/RectKt;->stringResource(ILandroidx/compose/runtime/GapComposer;)Ljava/lang/String;

    .line 143
    move-result-object v3

    .line 144
    sget-object v4, Landroidx/compose/material3/TypographyKt;->LocalTypography:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 146
    invoke-virtual {v2, v4}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 149
    move-result-object v7

    .line 150
    check-cast v7, Landroidx/compose/material3/Typography;

    .line 152
    iget-object v7, v7, Landroidx/compose/material3/Typography;->bodyMedium:Landroidx/compose/ui/text/TextStyle;

    .line 154
    sget-object v8, Landroidx/compose/material3/ColorSchemeKt;->LocalColorScheme:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 156
    invoke-virtual {v2, v8}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 159
    move-result-object v9

    .line 160
    check-cast v9, Landroidx/compose/material3/ColorScheme;

    .line 162
    iget-wide v9, v9, Landroidx/compose/material3/ColorScheme;->onSurfaceVariant:J

    .line 164
    const/16 v20, 0x0

    .line 166
    const v21, 0x1fffa

    .line 169
    move-object/from16 v18, v2

    .line 171
    move-object v2, v3

    .line 172
    const/4 v3, 0x0

    .line 173
    move v11, v6

    .line 174
    move-object/from16 v17, v7

    .line 176
    const-wide/16 v6, 0x0

    .line 178
    move-object v12, v4

    .line 179
    move v13, v5

    .line 180
    move-wide v4, v9

    .line 181
    move-object v10, v8

    .line 182
    const-wide/16 v8, 0x0

    .line 184
    move-object v14, v10

    .line 185
    const/4 v10, 0x0

    .line 186
    move/from16 v16, v11

    .line 188
    move-object v15, v12

    .line 189
    const-wide/16 v11, 0x0

    .line 191
    move/from16 v19, v13

    .line 193
    const/4 v13, 0x0

    .line 194
    move-object/from16 v22, v14

    .line 196
    const/4 v14, 0x0

    .line 197
    move-object/from16 v23, v15

    .line 199
    const/4 v15, 0x0

    .line 200
    move/from16 v24, v16

    .line 202
    const/16 v16, 0x0

    .line 204
    move/from16 v25, v19

    .line 206
    const/16 v19, 0x0

    .line 208
    move-object/from16 p0, v0

    .line 210
    move-object/from16 v26, v22

    .line 212
    move/from16 v0, v24

    .line 214
    invoke-static/range {v2 .. v21}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJJLandroidx/compose/ui/text/style/TextAlign;JIZIILandroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/GapComposer;III)V

    .line 217
    move-object/from16 v2, v18

    .line 219
    invoke-static {v1, v0, v2, v0}, Lyangfentuozi/dsusideloaderplus/ui/cards/LogcatCardKt;->CopyableTextCard(Ljava/lang/String;ZLandroidx/compose/runtime/GapComposer;I)V

    .line 222
    const v1, 0x7f10001f

    .line 225
    invoke-static {v1, v2}, Landroidx/compose/ui/geometry/RectKt;->stringResource(ILandroidx/compose/runtime/GapComposer;)Ljava/lang/String;

    .line 228
    move-result-object v1

    .line 229
    move-object/from16 v3, v23

    .line 231
    invoke-virtual {v2, v3}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 234
    move-result-object v4

    .line 235
    check-cast v4, Landroidx/compose/material3/Typography;

    .line 237
    iget-object v4, v4, Landroidx/compose/material3/Typography;->bodyMedium:Landroidx/compose/ui/text/TextStyle;

    .line 239
    move-object/from16 v5, v26

    .line 241
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 244
    move-result-object v6

    .line 245
    check-cast v6, Landroidx/compose/material3/ColorScheme;

    .line 247
    iget-wide v6, v6, Landroidx/compose/material3/ColorScheme;->onSurfaceVariant:J

    .line 249
    const/4 v3, 0x0

    .line 250
    move-object/from16 v17, v4

    .line 252
    move-object v14, v5

    .line 253
    move-wide v4, v6

    .line 254
    const-wide/16 v6, 0x0

    .line 256
    move-object/from16 v22, v14

    .line 258
    const/4 v14, 0x0

    .line 259
    move-object/from16 v27, v22

    .line 261
    move-object v2, v1

    .line 262
    move-object/from16 v1, v23

    .line 264
    invoke-static/range {v2 .. v21}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJJLandroidx/compose/ui/text/style/TextAlign;JIZIILandroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/GapComposer;III)V

    .line 267
    move-object/from16 v2, p0

    .line 269
    move-object/from16 v3, v18

    .line 271
    invoke-static {v2, v0, v3, v0}, Lyangfentuozi/dsusideloaderplus/ui/cards/LogcatCardKt;->CopyableTextCard(Ljava/lang/String;ZLandroidx/compose/runtime/GapComposer;I)V

    .line 274
    const v0, 0x7f10001e

    .line 277
    invoke-static {v0, v3}, Landroidx/compose/ui/geometry/RectKt;->stringResource(ILandroidx/compose/runtime/GapComposer;)Ljava/lang/String;

    .line 280
    move-result-object v2

    .line 281
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 284
    move-result-object v0

    .line 285
    check-cast v0, Landroidx/compose/material3/Typography;

    .line 287
    iget-object v0, v0, Landroidx/compose/material3/Typography;->bodyMedium:Landroidx/compose/ui/text/TextStyle;

    .line 289
    move-object/from16 v14, v27

    .line 291
    invoke-virtual {v3, v14}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 294
    move-result-object v1

    .line 295
    check-cast v1, Landroidx/compose/material3/ColorScheme;

    .line 297
    iget-wide v4, v1, Landroidx/compose/material3/ColorScheme;->onSurfaceVariant:J

    .line 299
    const/4 v3, 0x0

    .line 300
    const/4 v14, 0x0

    .line 301
    move-object/from16 v17, v0

    .line 303
    invoke-static/range {v2 .. v21}, Landroidx/compose/material3/TextKt;->Text-Nvy7gAk(Ljava/lang/String;Landroidx/compose/ui/Modifier;JJJLandroidx/compose/ui/text/style/TextAlign;JIZIILandroidx/compose/ui/text/TextStyle;Landroidx/compose/runtime/GapComposer;III)V

    .line 306
    move-object/from16 v2, v18

    .line 308
    const/4 v13, 0x1

    .line 309
    invoke-virtual {v2, v13}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 312
    goto :goto_13b

    .line 313
    :cond_138
    invoke-virtual {v2}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 316
    :goto_13b
    sget-object v0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 318
    return-object v0
.end method

.method private final invoke$yangfentuozi$dsusideloaderplus$ui$screen$images$ImagesScreenKt$$ExternalSyntheticLambda8(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 4

    .line 1
    iget-object v0, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 3
    check-cast v0, Lkotlin/jvm/functions/Function1;

    .line 5
    iget-object p0, p0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 7
    check-cast p0, Lyangfentuozi/dsusideloaderplus/ui/screen/images/ImagesViewModel;

    .line 9
    check-cast p1, Landroidx/compose/runtime/GapComposer;

    .line 11
    check-cast p2, Ljava/lang/Integer;

    .line 13
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 16
    const/4 p2, 0x1

    .line 17
    invoke-static {p2}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 20
    move-result p2

    .line 21
    invoke-static {v0, p0, p1, p2}, Lrikka/sui/Sui;->Images(Lkotlin/jvm/functions/Function1;Lyangfentuozi/dsusideloaderplus/ui/screen/images/ImagesViewModel;Landroidx/compose/runtime/GapComposer;I)V

    .line 24
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 26
    return-object p0
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 58

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p2

    .line 5
    iget v2, v0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->$r8$classId:I

    .line 7
    sget-object v3, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 9
    const/16 v4, 0x31

    .line 11
    const/16 v7, 0x20

    .line 13
    const/4 v8, -0x1

    .line 14
    const/4 v9, 0x2

    .line 15
    const/4 v10, 0x0

    .line 16
    const/4 v11, 0x0

    .line 17
    const/4 v12, 0x1

    .line 18
    sget-object v13, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 20
    iget-object v14, v0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$0:Ljava/lang/Object;

    .line 22
    iget-object v15, v0, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->f$1:Ljava/lang/Object;

    .line 24
    packed-switch v2, :pswitch_data_ce6

    .line 27
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 29
    check-cast v14, Lyangfentuozi/dsusideloaderplus/ui/screen/settings/SettingsViewModel;

    .line 31
    move-object/from16 v0, p1

    .line 33
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 35
    check-cast v1, Ljava/lang/Integer;

    .line 37
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 40
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 43
    move-result v1

    .line 44
    invoke-static {v15, v14, v0, v1}, Lyangfentuozi/dsusideloaderplus/ui/theme/ThemeKt;->Settings(Lkotlin/jvm/functions/Function1;Lyangfentuozi/dsusideloaderplus/ui/screen/settings/SettingsViewModel;Landroidx/compose/runtime/GapComposer;I)V

    .line 47
    return-object v13

    .line 48
    :pswitch_2f  #0x14
    invoke-direct/range {p0 .. p2}, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->invoke$yangfentuozi$dsusideloaderplus$ui$screen$images$ImagesScreenKt$$ExternalSyntheticLambda8(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 51
    move-result-object v0

    .line 52
    return-object v0

    .line 53
    :pswitch_34  #0x13
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 55
    check-cast v14, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 57
    move-object/from16 v0, p1

    .line 59
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 61
    check-cast v1, Ljava/lang/Integer;

    .line 63
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 66
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 69
    move-result v1

    .line 70
    invoke-static {v15, v14, v0, v1}, Lrikka/sui/Sui;->Home(Lkotlin/jvm/functions/Function1;Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;Landroidx/compose/runtime/GapComposer;I)V

    .line 73
    return-object v13

    .line 74
    :pswitch_49  #0x12
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 76
    check-cast v14, Lyangfentuozi/dsusideloaderplus/ui/screen/adb/AdbViewModel;

    .line 78
    move-object/from16 v0, p1

    .line 80
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 82
    check-cast v1, Ljava/lang/Integer;

    .line 84
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 87
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 90
    move-result v1

    .line 91
    invoke-static {v15, v14, v0, v1}, Lrikka/sui/Sui;->AdbScreen(Lkotlin/jvm/functions/Function1;Lyangfentuozi/dsusideloaderplus/ui/screen/adb/AdbViewModel;Landroidx/compose/runtime/GapComposer;I)V

    .line 94
    return-object v13

    .line 95
    :pswitch_5e  #0x11
    invoke-direct/range {p0 .. p2}, Landroidx/compose/foundation/CanvasKt$$ExternalSyntheticLambda0;->invoke$yangfentuozi$dsusideloaderplus$ui$screen$adb$AdbScreenKt$$ExternalSyntheticLambda1(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 98
    move-result-object v0

    .line 99
    return-object v0

    .line 100
    :pswitch_63  #0x10
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 102
    check-cast v14, Lyangfentuozi/dsusideloaderplus/ui/screen/about/AboutViewModel;

    .line 104
    move-object/from16 v0, p1

    .line 106
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 108
    check-cast v1, Ljava/lang/Integer;

    .line 110
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 116
    move-result v1

    .line 117
    invoke-static {v15, v14, v0, v1}, Lrikka/sui/Sui;->AboutScreen(Lkotlin/jvm/functions/Function1;Lyangfentuozi/dsusideloaderplus/ui/screen/about/AboutViewModel;Landroidx/compose/runtime/GapComposer;I)V

    .line 120
    return-object v13

    .line 121
    :pswitch_78  #0xf
    check-cast v14, Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 123
    check-cast v15, Landroidx/compose/material3/PinnedScrollBehavior;

    .line 125
    move-object/from16 v0, p1

    .line 127
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 129
    check-cast v1, Ljava/lang/Integer;

    .line 131
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 134
    move-result v1

    .line 135
    and-int/lit8 v2, v1, 0x3

    .line 137
    if-eq v2, v9, :cond_8c

    .line 139
    move v2, v12

    .line 140
    goto :goto_8d

    .line 141
    :cond_8c
    move v2, v11

    .line 142
    :goto_8d
    and-int/2addr v1, v12

    .line 143
    invoke-virtual {v0, v1, v2}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 146
    move-result v1

    .line 147
    if-eqz v1, :cond_9c

    .line 149
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 152
    move-result-object v1

    .line 153
    invoke-virtual {v14, v15, v0, v1}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 156
    goto :goto_9f

    .line 157
    :cond_9c
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 160
    :goto_9f
    return-object v13

    .line 161
    :pswitch_a0  #0xe
    check-cast v14, Ljava/lang/String;

    .line 163
    check-cast v15, Lkotlin/jvm/functions/Function0;

    .line 165
    move-object/from16 v0, p1

    .line 167
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 169
    check-cast v1, Ljava/lang/Integer;

    .line 171
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 174
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 177
    move-result v1

    .line 178
    invoke-static {v14, v15, v0, v1}, Lyangfentuozi/dsusideloaderplus/ui/cards/warnings/LoadingCardKt;->StorageWarningCard(Ljava/lang/String;Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/GapComposer;I)V

    .line 181
    return-object v13

    .line 182
    :pswitch_b5  #0xd
    check-cast v14, Landroidx/compose/runtime/saveable/SaveableStateHolder;

    .line 184
    check-cast v15, Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 186
    move-object/from16 v0, p1

    .line 188
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 190
    check-cast v1, Ljava/lang/Integer;

    .line 192
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 195
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 198
    move-result v1

    .line 199
    invoke-static {v14, v15, v0, v1}, Landroidx/navigation/NavArgumentKt;->SaveableStateProvider(Landroidx/compose/runtime/saveable/SaveableStateHolder;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V

    .line 202
    return-object v13

    .line 203
    :pswitch_ca  #0xc
    check-cast v14, Ljava/util/List;

    .line 205
    check-cast v15, Ljava/util/Collection;

    .line 207
    move-object/from16 v0, p1

    .line 209
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 211
    check-cast v1, Ljava/lang/Integer;

    .line 213
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 216
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 219
    move-result v1

    .line 220
    invoke-static {v14, v15, v0, v1}, Landroidx/navigation/NavArgumentKt;->PopulateVisibleList(Ljava/util/List;Ljava/util/Collection;Landroidx/compose/runtime/GapComposer;I)V

    .line 223
    return-object v13

    .line 224
    :pswitch_df  #0xb
    check-cast v14, Landroidx/compose/runtime/internal/RememberEventDispatcher;

    .line 226
    check-cast v15, Landroidx/compose/runtime/composer/gapbuffer/SlotWriter;

    .line 228
    move-object/from16 v0, p1

    .line 230
    check-cast v0, Ljava/lang/Integer;

    .line 232
    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    .line 235
    move-result v0

    .line 236
    instance-of v2, v1, Landroidx/compose/runtime/ComposeNodeLifecycleCallback;

    .line 238
    if-eqz v2, :cond_f8

    .line 240
    move-object v0, v1

    .line 241
    check-cast v0, Landroidx/compose/runtime/ComposeNodeLifecycleCallback;

    .line 243
    iget-object v1, v14, Landroidx/compose/runtime/internal/RememberEventDispatcher;->leaving:Landroidx/compose/runtime/collection/MutableVector;

    .line 245
    invoke-virtual {v1, v0}, Landroidx/compose/runtime/collection/MutableVector;->add(Ljava/lang/Object;)V

    .line 248
    goto :goto_117

    .line 249
    :cond_f8
    instance-of v2, v1, Landroidx/compose/runtime/ReusableGapRememberObserverHolder;

    .line 251
    if-nez v2, :cond_117

    .line 253
    instance-of v2, v1, Landroidx/compose/runtime/GapRememberObserverHolder;

    .line 255
    if-eqz v2, :cond_10a

    .line 257
    invoke-static {v15, v0, v1}, Landroidx/compose/runtime/Updater;->removeData(Landroidx/compose/runtime/composer/gapbuffer/SlotWriter;ILjava/lang/Object;)V

    .line 260
    move-object v0, v1

    .line 261
    check-cast v0, Landroidx/compose/runtime/GapRememberObserverHolder;

    .line 263
    invoke-virtual {v14, v0}, Landroidx/compose/runtime/internal/RememberEventDispatcher;->forgetting(Landroidx/compose/runtime/GapRememberObserverHolder;)V

    .line 266
    goto :goto_117

    .line 267
    :cond_10a
    instance-of v2, v1, Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 269
    if-eqz v2, :cond_117

    .line 271
    invoke-static {v15, v0, v1}, Landroidx/compose/runtime/Updater;->removeData(Landroidx/compose/runtime/composer/gapbuffer/SlotWriter;ILjava/lang/Object;)V

    .line 274
    move-object v0, v1

    .line 275
    check-cast v0, Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 277
    invoke-virtual {v0}, Landroidx/compose/runtime/RecomposeScopeImpl;->release()V

    .line 280
    :cond_117
    :goto_117
    return-object v13

    .line 281
    :pswitch_118  #0xa
    check-cast v14, Landroidx/compose/material3/DefaultSingleRowTopAppBarOverride;

    .line 283
    check-cast v15, Landroidx/compose/material3/SingleRowTopAppBarOverrideScope;

    .line 285
    move-object/from16 v0, p1

    .line 287
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 289
    check-cast v1, Ljava/lang/Integer;

    .line 291
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 294
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 297
    move-result v1

    .line 298
    invoke-virtual {v14, v15, v0, v1}, Landroidx/compose/material3/DefaultSingleRowTopAppBarOverride;->SingleRowTopAppBar(Landroidx/compose/material3/SingleRowTopAppBarOverrideScope;Landroidx/compose/runtime/GapComposer;I)V

    .line 301
    return-object v13

    .line 302
    :pswitch_12d  #0x9
    check-cast v14, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;

    .line 304
    check-cast v15, Lkotlinx/coroutines/CoroutineScope;

    .line 306
    move-object/from16 v0, p1

    .line 308
    check-cast v0, Landroidx/compose/foundation/text/contextmenu/builder/TextContextMenuBuilderScope;

    .line 310
    check-cast v1, Landroid/content/Context;

    .line 312
    invoke-virtual {v14}, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;->getEditable()Z

    .line 315
    move-result v18

    .line 316
    invoke-virtual {v14}, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;->getTransformedText$foundation()Landroidx/compose/ui/text/AnnotatedString;

    .line 319
    move-result-object v2

    .line 320
    if-eqz v2, :cond_144

    .line 322
    iget-object v2, v2, Landroidx/compose/ui/text/AnnotatedString;->text:Ljava/lang/String;

    .line 324
    goto :goto_145

    .line 325
    :cond_144
    move-object v2, v10

    .line 326
    :goto_145
    iget-object v3, v14, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;->latestSelection:Landroidx/compose/ui/text/TextRange;

    .line 328
    if-eqz v3, :cond_16a

    .line 330
    iget-wide v3, v3, Landroidx/compose/ui/text/TextRange;->packedValue:J

    .line 332
    iget-object v9, v14, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;->offsetMapping:Landroidx/compose/ui/text/input/OffsetMapping;

    .line 334
    const-wide v16, 0xffffffffL

    .line 339
    shr-long v5, v3, v7

    .line 341
    long-to-int v5, v5

    .line 342
    invoke-interface {v9, v5}, Landroidx/compose/ui/text/input/OffsetMapping;->originalToTransformed(I)I

    .line 345
    move-result v5

    .line 346
    and-long v3, v3, v16

    .line 348
    long-to-int v3, v3

    .line 349
    invoke-interface {v9, v3}, Landroidx/compose/ui/text/input/OffsetMapping;->originalToTransformed(I)I

    .line 352
    move-result v3

    .line 353
    invoke-static {v5, v3}, Landroidx/compose/ui/text/ParagraphKt;->TextRange(II)J

    .line 356
    move-result-wide v3

    .line 357
    new-instance v5, Landroidx/compose/ui/text/TextRange;

    .line 359
    invoke-direct {v5, v3, v4}, Landroidx/compose/ui/text/TextRange;-><init>(J)V

    .line 362
    goto :goto_16b

    .line 363
    :cond_16a
    move-object v5, v10

    .line 364
    :goto_16b
    iget-object v3, v14, Landroidx/compose/foundation/text/selection/TextFieldSelectionManager;->platformSelectionBehaviors:Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;

    .line 366
    new-instance v4, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;

    .line 368
    const/16 v6, 0x9

    .line 370
    invoke-direct {v4, v14, v15, v1, v6}, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 373
    sget-object v6, Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviors_androidKt;->LocalTextClassifierCoroutineContext:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 375
    if-eqz v2, :cond_21c

    .line 377
    if-eqz v5, :cond_21c

    .line 379
    if-eqz v3, :cond_21c

    .line 381
    iget-wide v6, v5, Landroidx/compose/ui/text/TextRange;->packedValue:J

    .line 383
    iget-object v9, v3, Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;->AssistantItemKey:Ljava/lang/Object;

    .line 385
    iget-object v12, v3, Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;->mutex:Lkotlinx/coroutines/sync/MutexImpl;

    .line 387
    invoke-virtual {v12}, Lkotlinx/coroutines/sync/MutexImpl;->tryLock()Z

    .line 390
    move-result v14

    .line 391
    if-nez v14, :cond_189

    .line 393
    goto :goto_1ab

    .line 394
    :cond_189
    iget-object v3, v3, Landroidx/compose/foundation/text/selection/PlatformSelectionBehaviorsImpl;->textClassificationResult$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 396
    invoke-virtual {v3}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 399
    move-result-object v3

    .line 400
    check-cast v3, Landroidx/compose/foundation/text/selection/TextClassificationResult;

    .line 402
    if-eqz v3, :cond_1a6

    .line 404
    iget-wide v14, v3, Landroidx/compose/foundation/text/selection/TextClassificationResult;->selection:J

    .line 406
    invoke-static {v6, v7, v14, v15}, Landroidx/compose/ui/text/TextRange;->equals-impl0(JJ)Z

    .line 409
    move-result v6

    .line 410
    if-eqz v6, :cond_1a6

    .line 412
    iget-object v6, v3, Landroidx/compose/foundation/text/selection/TextClassificationResult;->text:Ljava/lang/CharSequence;

    .line 414
    invoke-static {v2, v6}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 417
    move-result v6

    .line 418
    if-eqz v6, :cond_1a6

    .line 420
    iget-object v3, v3, Landroidx/compose/foundation/text/selection/TextClassificationResult;->textClassification:Landroid/view/textclassifier/TextClassification;

    .line 422
    goto :goto_1a7

    .line 423
    :cond_1a6
    move-object v3, v10

    .line 424
    :goto_1a7
    invoke-virtual {v12, v10}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 427
    move-object v10, v3

    .line 428
    :goto_1ab
    if-nez v10, :cond_1b1

    .line 430
    invoke-virtual {v4, v0}, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 433
    goto :goto_20e

    .line 434
    :cond_1b1
    invoke-virtual {v10}, Landroid/view/textclassifier/TextClassification;->getActions()Ljava/util/List;

    .line 437
    move-result-object v3

    .line 438
    invoke-interface {v3}, Ljava/util/Collection;->isEmpty()Z

    .line 441
    move-result v3

    .line 442
    if-nez v3, :cond_1c6

    .line 444
    new-instance v3, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuTextClassificationItem;

    .line 446
    invoke-direct {v3, v9, v10, v11}, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuTextClassificationItem;-><init>(Ljava/lang/Object;Landroid/view/textclassifier/TextClassification;I)V

    .line 449
    iget-object v6, v0, Landroidx/compose/foundation/text/contextmenu/builder/TextContextMenuBuilderScope;->components:Landroidx/collection/MutableObjectList;

    .line 451
    invoke-virtual {v6, v3}, Landroidx/collection/MutableObjectList;->add(Ljava/lang/Object;)V

    .line 454
    goto :goto_1ec

    .line 455
    :cond_1c6
    invoke-virtual {v10}, Landroid/view/textclassifier/TextClassification;->getIcon()Landroid/graphics/drawable/Drawable;

    .line 458
    move-result-object v3

    .line 459
    if-nez v3, :cond_1d6

    .line 461
    invoke-virtual {v10}, Landroid/view/textclassifier/TextClassification;->getLabel()Ljava/lang/CharSequence;

    .line 464
    move-result-object v3

    .line 465
    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    .line 468
    move-result v3

    .line 469
    if-nez v3, :cond_1ec

    .line 471
    :cond_1d6
    invoke-virtual {v10}, Landroid/view/textclassifier/TextClassification;->getIntent()Landroid/content/Intent;

    .line 474
    move-result-object v3

    .line 475
    if-nez v3, :cond_1e2

    .line 477
    invoke-virtual {v10}, Landroid/view/textclassifier/TextClassification;->getOnClickListener()Landroid/view/View$OnClickListener;

    .line 480
    move-result-object v3

    .line 481
    if-eqz v3, :cond_1ec

    .line 483
    :cond_1e2
    new-instance v3, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuTextClassificationItem;

    .line 485
    invoke-direct {v3, v9, v10, v8}, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuTextClassificationItem;-><init>(Ljava/lang/Object;Landroid/view/textclassifier/TextClassification;I)V

    .line 488
    iget-object v6, v0, Landroidx/compose/foundation/text/contextmenu/builder/TextContextMenuBuilderScope;->components:Landroidx/collection/MutableObjectList;

    .line 490
    invoke-virtual {v6, v3}, Landroidx/collection/MutableObjectList;->add(Ljava/lang/Object;)V

    .line 493
    :cond_1ec
    :goto_1ec
    invoke-virtual {v4, v0}, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 496
    invoke-virtual {v10}, Landroid/view/textclassifier/TextClassification;->getActions()Ljava/util/List;

    .line 499
    move-result-object v3

    .line 500
    invoke-interface {v3}, Ljava/util/Collection;->size()I

    .line 503
    move-result v4

    .line 504
    :goto_1f7
    if-ge v11, v4, :cond_20e

    .line 506
    invoke-interface {v3, v11}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 509
    move-result-object v6

    .line 510
    check-cast v6, Landroid/app/RemoteAction;

    .line 512
    if-lez v11, :cond_20b

    .line 514
    new-instance v6, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuTextClassificationItem;

    .line 516
    invoke-direct {v6, v9, v10, v11}, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuTextClassificationItem;-><init>(Ljava/lang/Object;Landroid/view/textclassifier/TextClassification;I)V

    .line 519
    iget-object v7, v0, Landroidx/compose/foundation/text/contextmenu/builder/TextContextMenuBuilderScope;->components:Landroidx/collection/MutableObjectList;

    .line 521
    invoke-virtual {v7, v6}, Landroidx/collection/MutableObjectList;->add(Ljava/lang/Object;)V

    .line 524
    :cond_20b
    add-int/lit8 v11, v11, 0x1

    .line 526
    goto :goto_1f7

    .line 527
    :cond_20e
    :goto_20e
    iget-wide v3, v5, Landroidx/compose/ui/text/TextRange;->packedValue:J

    .line 529
    move-object/from16 v16, v0

    .line 531
    move-object/from16 v17, v1

    .line 533
    move-object/from16 v19, v2

    .line 535
    move-wide/from16 v20, v3

    .line 537
    invoke-static/range {v16 .. v21}, Landroidx/compose/foundation/text/contextmenu/ProcessTextApi23Impl;->addProcessedTextContextMenuItems-UAq72N0(Landroidx/compose/foundation/text/contextmenu/builder/TextContextMenuBuilderScope;Landroid/content/Context;ZLjava/lang/String;J)V

    .line 540
    goto :goto_230

    .line 541
    :cond_21c
    move-object/from16 v17, v1

    .line 543
    move-object/from16 v19, v2

    .line 545
    invoke-virtual {v4, v0}, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 548
    if-eqz v19, :cond_230

    .line 550
    if-eqz v5, :cond_230

    .line 552
    iget-wide v1, v5, Landroidx/compose/ui/text/TextRange;->packedValue:J

    .line 554
    move-object/from16 v16, v0

    .line 556
    move-wide/from16 v20, v1

    .line 558
    invoke-static/range {v16 .. v21}, Landroidx/compose/foundation/text/contextmenu/ProcessTextApi23Impl;->addProcessedTextContextMenuItems-UAq72N0(Landroidx/compose/foundation/text/contextmenu/builder/TextContextMenuBuilderScope;Landroid/content/Context;ZLjava/lang/String;J)V

    .line 561
    :cond_230
    :goto_230
    return-object v13

    .line 562
    :pswitch_231  #0x8
    check-cast v14, Landroidx/compose/ui/Modifier;

    .line 564
    check-cast v15, Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 566
    move-object/from16 v0, p1

    .line 568
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 570
    check-cast v1, Ljava/lang/Integer;

    .line 572
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 575
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 578
    move-result v1

    .line 579
    invoke-static {v14, v15, v0, v1}, Lkotlin/math/MathKt;->SimpleLayout(Landroidx/compose/ui/Modifier;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V

    .line 582
    return-object v13

    .line 583
    :pswitch_246  #0x7
    check-cast v14, Landroidx/compose/foundation/text/contextmenu/internal/TextContextMenuHelperApi28;

    .line 585
    check-cast v15, Landroid/graphics/drawable/Drawable;

    .line 587
    move-object/from16 v0, p1

    .line 589
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 591
    check-cast v1, Ljava/lang/Integer;

    .line 593
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 596
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 599
    move-result v1

    .line 600
    invoke-virtual {v14, v15, v0, v1}, Landroidx/compose/foundation/text/contextmenu/internal/TextContextMenuHelperApi28;->IconBox(Landroid/graphics/drawable/Drawable;Landroidx/compose/runtime/GapComposer;I)V

    .line 603
    return-object v13

    .line 604
    :pswitch_25b  #0x6
    check-cast v14, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuSession;

    .line 606
    check-cast v15, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;

    .line 608
    move-object/from16 v0, p1

    .line 610
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 612
    check-cast v1, Ljava/lang/Integer;

    .line 614
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 617
    invoke-static {v12}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 620
    move-result v1

    .line 621
    invoke-static {v14, v15, v0, v1}, Landroidx/compose/foundation/text/contextmenu/internal/DefaultTextContextMenuDropdownProvider_androidKt;->DefaultTextContextMenuDropdown(Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuSession;Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;Landroidx/compose/runtime/GapComposer;I)V

    .line 624
    return-object v13

    .line 625
    :pswitch_270  #0x5
    move-object v4, v14

    .line 626
    check-cast v4, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuDataProvider;

    .line 628
    check-cast v15, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuSession;

    .line 630
    move-object/from16 v0, p1

    .line 632
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 634
    check-cast v1, Ljava/lang/Integer;

    .line 636
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 639
    move-result v1

    .line 640
    and-int/lit8 v2, v1, 0x3

    .line 642
    if-eq v2, v9, :cond_285

    .line 644
    move v2, v12

    .line 645
    goto :goto_286

    .line 646
    :cond_285
    move v2, v11

    .line 647
    :goto_286
    and-int/2addr v1, v12

    .line 648
    invoke-virtual {v0, v1, v2}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 651
    move-result v1

    .line 652
    if-eqz v1, :cond_2bb

    .line 654
    invoke-virtual {v0, v4}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 657
    move-result v1

    .line 658
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 661
    move-result-object v2

    .line 662
    if-nez v1, :cond_299

    .line 664
    if-ne v2, v3, :cond_2af

    .line 666
    :cond_299
    new-instance v2, Landroidx/compose/foundation/FocusableNode$applySemantics$1;

    .line 668
    const/4 v9, 0x0

    .line 669
    const/4 v10, 0x1

    .line 670
    const/4 v3, 0x0

    .line 671
    const-class v5, Landroidx/compose/foundation/text/contextmenu/provider/TextContextMenuDataProvider;

    .line 673
    const-string v6, "data"

    .line 675
    const-string v7, "data()Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;"

    .line 677
    const/4 v8, 0x0

    .line 678
    invoke-direct/range {v2 .. v10}, Landroidx/compose/foundation/FocusableNode$applySemantics$1;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V

    .line 681
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->derivedStateOf(Lkotlin/jvm/functions/Function0;)Landroidx/compose/runtime/DerivedSnapshotState;

    .line 684
    move-result-object v2

    .line 685
    invoke-virtual {v0, v2}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 688
    :cond_2af
    check-cast v2, Landroidx/compose/runtime/State;

    .line 690
    invoke-interface {v2}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 693
    move-result-object v1

    .line 694
    check-cast v1, Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;

    .line 696
    invoke-static {v15, v1, v0, v11}, Landroidx/compose/foundation/text/contextmenu/internal/DefaultTextContextMenuDropdownProvider_androidKt;->DefaultTextContextMenuDropdown(Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuSession;Landroidx/compose/foundation/text/contextmenu/data/TextContextMenuData;Landroidx/compose/runtime/GapComposer;I)V

    .line 699
    goto :goto_2be

    .line 700
    :cond_2bb
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 703
    :goto_2be
    return-object v13

    .line 704
    :pswitch_2bf  #0x4
    check-cast v14, Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 706
    check-cast v15, Landroidx/compose/foundation/lazy/layout/LazySaveableStateHolder;

    .line 708
    move-object/from16 v0, p1

    .line 710
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 712
    check-cast v1, Ljava/lang/Integer;

    .line 714
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 717
    move-result v1

    .line 718
    and-int/lit8 v2, v1, 0x3

    .line 720
    if-eq v2, v9, :cond_2d3

    .line 722
    move v2, v12

    .line 723
    goto :goto_2d4

    .line 724
    :cond_2d3
    move v2, v11

    .line 725
    :goto_2d4
    and-int/2addr v1, v12

    .line 726
    invoke-virtual {v0, v1, v2}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 729
    move-result v1

    .line 730
    if-eqz v1, :cond_2e3

    .line 732
    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 735
    move-result-object v1

    .line 736
    invoke-virtual {v14, v15, v0, v1}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 739
    goto :goto_2e6

    .line 740
    :cond_2e3
    invoke-virtual {v0}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 743
    :goto_2e6
    return-object v13

    .line 744
    :pswitch_2e7  #0x3
    const-wide v16, 0xffffffffL

    .line 749
    const-wide/16 v2, 0x0

    .line 751
    invoke-static {v2, v3, v2, v3}, Landroidx/compose/ui/unit/IntSize;->equals-impl0(JJ)Z

    .line 754
    move-result v0

    .line 755
    check-cast v14, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory;

    .line 757
    check-cast v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;

    .line 759
    move-object/from16 v2, p1

    .line 761
    check-cast v2, Landroidx/compose/ui/layout/SubcomposeMeasureScope;

    .line 763
    check-cast v1, Landroidx/compose/ui/unit/Constraints;

    .line 765
    new-instance v3, Landroidx/compose/foundation/lazy/layout/LazyLayoutMeasureScopeImpl;

    .line 767
    invoke-direct {v3, v14, v2}, Landroidx/compose/foundation/lazy/layout/LazyLayoutMeasureScopeImpl;-><init>(Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory;Landroidx/compose/ui/layout/SubcomposeMeasureScope;)V

    .line 770
    iget-wide v4, v1, Landroidx/compose/ui/unit/Constraints;->value:J

    .line 772
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 775
    iget-object v1, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$verticalArrangement:Landroidx/compose/foundation/layout/Arrangement$Vertical;

    .line 777
    iget-object v6, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$contentPadding:Landroidx/compose/foundation/layout/PaddingValuesImpl;

    .line 779
    iget-object v9, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$state:Landroidx/compose/foundation/lazy/LazyListState;

    .line 781
    iget-object v13, v9, Landroidx/compose/foundation/lazy/LazyListState;->measurementScopeInvalidator:Landroidx/compose/runtime/MutableState;

    .line 783
    iget-object v14, v9, Landroidx/compose/foundation/lazy/LazyListState;->scrollPosition:Landroidx/compose/material/ripple/StateLayer;

    .line 785
    invoke-interface {v13}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 788
    iget-boolean v13, v9, Landroidx/compose/foundation/lazy/LazyListState;->hasLookaheadOccurred:Z

    .line 790
    if-nez v13, :cond_322

    .line 792
    invoke-interface {v2}, Landroidx/compose/ui/layout/IntrinsicMeasureScope;->isLookingAhead()Z

    .line 795
    move-result v13

    .line 796
    if-eqz v13, :cond_31e

    .line 798
    goto :goto_322

    .line 799
    :cond_31e
    move v13, v11

    .line 800
    :goto_31f
    move/from16 v18, v7

    .line 802
    goto :goto_324

    .line 803
    :cond_322
    :goto_322
    move v13, v12

    .line 804
    goto :goto_31f

    .line 805
    :goto_324
    sget-object v7, Landroidx/compose/foundation/gestures/Orientation;->Vertical:Landroidx/compose/foundation/gestures/Orientation;

    .line 807
    invoke-static {v4, v5, v7}, Landroidx/compose/foundation/ImageKt;->checkScrollableContainerConstraints-K40F9xA(JLandroidx/compose/foundation/gestures/Orientation;)V

    .line 810
    invoke-interface {v2}, Landroidx/compose/ui/layout/IntrinsicMeasureScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    .line 813
    move-result-object v10

    .line 814
    invoke-virtual {v6, v10}, Landroidx/compose/foundation/layout/PaddingValuesImpl;->calculateLeftPadding-u2uoSUM(Landroidx/compose/ui/unit/LayoutDirection;)F

    .line 817
    move-result v10

    .line 818
    invoke-interface {v2, v10}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 821
    move-result v10

    .line 822
    move/from16 v32, v8

    .line 824
    invoke-interface {v2}, Landroidx/compose/ui/layout/IntrinsicMeasureScope;->getLayoutDirection()Landroidx/compose/ui/unit/LayoutDirection;

    .line 827
    move-result-object v8

    .line 828
    invoke-virtual {v6, v8}, Landroidx/compose/foundation/layout/PaddingValuesImpl;->calculateRightPadding-u2uoSUM(Landroidx/compose/ui/unit/LayoutDirection;)F

    .line 831
    move-result v8

    .line 832
    invoke-interface {v2, v8}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 835
    move-result v8

    .line 836
    move/from16 v33, v12

    .line 838
    iget v12, v6, Landroidx/compose/foundation/layout/PaddingValuesImpl;->top:F

    .line 840
    invoke-interface {v2, v12}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 843
    move-result v12

    .line 844
    iget v6, v6, Landroidx/compose/foundation/layout/PaddingValuesImpl;->bottom:F

    .line 846
    invoke-interface {v2, v6}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 849
    move-result v6

    .line 850
    add-int/2addr v6, v12

    .line 851
    add-int/2addr v8, v10

    .line 852
    sub-int v35, v6, v12

    .line 854
    neg-int v11, v8

    .line 855
    move/from16 p0, v0

    .line 857
    neg-int v0, v6

    .line 858
    invoke-static {v4, v5, v11, v0}, Landroidx/compose/ui/unit/ConstraintsKt;->offset-NN6Ew-U(JII)J

    .line 861
    move-result-wide v19

    .line 862
    iget-object v0, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$itemProviderLambda:Lkotlin/jvm/functions/Function0;

    .line 864
    invoke-interface {v0}, Lkotlin/jvm/functions/Function0;->invoke()Ljava/lang/Object;

    .line 867
    move-result-object v0

    .line 868
    check-cast v0, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;

    .line 870
    iget-object v11, v0, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->itemScope:Landroidx/compose/foundation/lazy/LazyItemScopeImpl;

    .line 872
    move-object/from16 v21, v0

    .line 874
    invoke-static/range {v19 .. v20}, Landroidx/compose/ui/unit/Constraints;->getMaxWidth-impl(J)I

    .line 877
    move-result v0

    .line 878
    move-object/from16 v22, v3

    .line 880
    invoke-static/range {v19 .. v20}, Landroidx/compose/ui/unit/Constraints;->getMaxHeight-impl(J)I

    .line 883
    move-result v3

    .line 884
    move/from16 p1, v6

    .line 886
    iget-object v6, v11, Landroidx/compose/foundation/lazy/LazyItemScopeImpl;->maxWidthState:Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 888
    invoke-virtual {v6, v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;->setIntValue(I)V

    .line 891
    iget-object v0, v11, Landroidx/compose/foundation/lazy/LazyItemScopeImpl;->maxHeightState:Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 893
    invoke-virtual {v0, v3}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;->setIntValue(I)V

    .line 896
    const-string v0, "null verticalArrangement when isVertical == true"

    .line 898
    if-eqz v1, :cond_c18

    .line 900
    invoke-interface {v1}, Landroidx/compose/foundation/layout/Arrangement$Vertical;->getSpacing-D9Ej5fM()F

    .line 903
    move-result v3

    .line 904
    invoke-interface {v2, v3}, Landroidx/compose/ui/unit/Density;->roundToPx-0680j_4(F)I

    .line 907
    move-result v36

    .line 908
    invoke-virtual/range {v21 .. v21}, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->getItemCount()I

    .line 911
    move-result v23

    .line 912
    invoke-static {v4, v5}, Landroidx/compose/ui/unit/Constraints;->getMaxHeight-impl(J)I

    .line 915
    move-result v3

    .line 916
    sub-int v3, v3, p1

    .line 918
    int-to-long v10, v10

    .line 919
    shl-long v10, v10, v18

    .line 921
    move-object/from16 v34, v7

    .line 923
    int-to-long v6, v12

    .line 924
    and-long v6, v6, v16

    .line 926
    or-long v28, v10, v6

    .line 928
    new-instance v18, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;

    .line 930
    iget-object v6, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$horizontalAlignment:Landroidx/compose/ui/BiasAlignment$Horizontal;

    .line 932
    iget-object v7, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$state:Landroidx/compose/foundation/lazy/LazyListState;

    .line 934
    move-object/from16 v25, v6

    .line 936
    move-object/from16 v30, v7

    .line 938
    move/from16 v26, v12

    .line 940
    move/from16 v27, v35

    .line 942
    move/from16 v24, v36

    .line 944
    invoke-direct/range {v18 .. v30}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;-><init>(JLandroidx/compose/foundation/lazy/LazyListItemProviderImpl;Landroidx/compose/foundation/lazy/layout/LazyLayoutMeasureScopeImpl;IILandroidx/compose/ui/BiasAlignment$Horizontal;IIJLandroidx/compose/foundation/lazy/LazyListState;)V

    .line 947
    move-object/from16 p2, v0

    .line 949
    move/from16 v29, v8

    .line 951
    move-object/from16 v6, v18

    .line 953
    move-wide/from16 v10, v19

    .line 955
    move-object/from16 v12, v21

    .line 957
    move-object/from16 v28, v22

    .line 959
    move/from16 v0, v23

    .line 961
    move/from16 v7, v26

    .line 963
    invoke-static {}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->getCurrentThreadSnapshot()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 966
    move-result-object v8

    .line 967
    if-eqz v8, :cond_3d3

    .line 969
    invoke-virtual {v8}, Landroidx/compose/runtime/snapshots/Snapshot;->getReadObserver()Lkotlin/jvm/functions/Function1;

    .line 972
    move-result-object v18

    .line 973
    move/from16 v25, v13

    .line 975
    move-object/from16 v13, v18

    .line 977
    :goto_3d0
    move-object/from16 v18, v1

    .line 979
    goto :goto_3d7

    .line 980
    :cond_3d3
    move/from16 v25, v13

    .line 982
    const/4 v13, 0x0

    .line 983
    goto :goto_3d0

    .line 984
    :goto_3d7
    invoke-static {v8}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->makeCurrentNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;)Landroidx/compose/runtime/snapshots/Snapshot;

    .line 987
    move-result-object v1

    .line 988
    move/from16 v30, v3

    .line 990
    :try_start_3dd
    iget-object v3, v14, Landroidx/compose/material/ripple/StateLayer;->rippleAlpha:Ljava/lang/Object;

    .line 992
    check-cast v3, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 994
    invoke-virtual {v3}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;->getIntValue()I

    .line 997
    move-result v3

    .line 998
    move/from16 v38, v0

    .line 1000
    iget-object v0, v14, Landroidx/compose/material/ripple/StateLayer;->interactions:Ljava/lang/Object;

    .line 1002
    invoke-static {v3, v12, v0}, Landroidx/compose/foundation/lazy/layout/LazyLayoutKt;->findIndexByKey(ILandroidx/compose/foundation/lazy/LazyListItemProviderImpl;Ljava/lang/Object;)I

    .line 1005
    move-result v0

    .line 1006
    if-eq v3, v0, :cond_423

    .line 1008
    move/from16 v39, v7

    .line 1010
    iget-object v7, v14, Landroidx/compose/material/ripple/StateLayer;->rippleAlpha:Ljava/lang/Object;

    .line 1012
    check-cast v7, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 1014
    invoke-virtual {v7, v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;->setIntValue(I)V

    .line 1017
    iget-object v7, v14, Landroidx/compose/material/ripple/StateLayer;->currentInteraction:Ljava/lang/Object;

    .line 1019
    check-cast v7, Landroidx/compose/foundation/lazy/layout/LazyLayoutNearestRangeState;

    .line 1021
    move/from16 v19, v0

    .line 1023
    iget v0, v7, Landroidx/compose/foundation/lazy/layout/LazyLayoutNearestRangeState;->lastFirstVisibleItem:I

    .line 1025
    if-eq v3, v0, :cond_420

    .line 1027
    iput v3, v7, Landroidx/compose/foundation/lazy/layout/LazyLayoutNearestRangeState;->lastFirstVisibleItem:I

    .line 1029
    div-int/lit8 v3, v3, 0x1e

    .line 1031
    mul-int/lit8 v3, v3, 0x1e

    .line 1033
    add-int/lit8 v0, v3, -0x64

    .line 1035
    move-object/from16 v40, v2

    .line 1037
    const/4 v2, 0x0

    .line 1038
    invoke-static {v0, v2}, Ljava/lang/Math;->max(II)I

    .line 1041
    move-result v0

    .line 1042
    add-int/lit16 v3, v3, 0x82

    .line 1044
    invoke-static {v0, v3}, Lrikka/sui/Sui;->until(II)Lkotlin/ranges/IntRange;

    .line 1047
    move-result-object v0

    .line 1048
    iget-object v2, v7, Landroidx/compose/foundation/lazy/layout/LazyLayoutNearestRangeState;->value$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 1050
    invoke-virtual {v2, v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 1053
    goto :goto_429

    .line 1054
    :catchall_41d
    move-exception v0

    .line 1055
    goto/16 :goto_c14

    .line 1057
    :cond_420
    move-object/from16 v40, v2

    .line 1059
    goto :goto_429

    .line 1060
    :cond_423
    move/from16 v19, v0

    .line 1062
    move-object/from16 v40, v2

    .line 1064
    move/from16 v39, v7

    .line 1066
    :goto_429
    iget-object v0, v14, Landroidx/compose/material/ripple/StateLayer;->animatedAlpha:Ljava/lang/Object;

    .line 1068
    check-cast v0, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;

    .line 1070
    invoke-virtual {v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableIntState;->getIntValue()I

    .line 1073
    move-result v0
    :try_end_431
    .catchall {:try_start_3dd .. :try_end_431} :catchall_41d

    .line 1074
    invoke-static {v8, v1, v13}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->restoreNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;Lkotlin/jvm/functions/Function1;)V

    .line 1077
    iget-object v1, v9, Landroidx/compose/foundation/lazy/LazyListState;->pinnedItems:Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnedItemList;

    .line 1079
    iget-object v2, v9, Landroidx/compose/foundation/lazy/LazyListState;->beyondBoundsInfo:Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo;

    .line 1081
    iget-object v3, v2, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo;->beyondBoundsItems:Landroidx/compose/runtime/collection/MutableVector;

    .line 1083
    iget v7, v3, Landroidx/compose/runtime/collection/MutableVector;->size:I

    .line 1085
    if-eqz v7, :cond_443

    .line 1087
    move/from16 v7, v33

    .line 1089
    :goto_440
    move/from16 v8, v30

    .line 1091
    goto :goto_445

    .line 1092
    :cond_443
    const/4 v7, 0x0

    .line 1093
    goto :goto_440

    .line 1094
    :goto_445
    sget-object v30, Lkotlin/collections/EmptyList;->INSTANCE:Lkotlin/collections/EmptyList;

    .line 1096
    if-nez v7, :cond_459

    .line 1098
    iget-object v7, v1, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnedItemList;->items:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 1100
    invoke-virtual {v7}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->isEmpty()Z

    .line 1103
    move-result v7

    .line 1104
    if-eqz v7, :cond_459

    .line 1106
    move/from16 v20, v0

    .line 1108
    move/from16 v41, v8

    .line 1110
    move-object/from16 v7, v30

    .line 1112
    goto/16 :goto_520

    .line 1114
    :cond_459
    new-instance v7, Ljava/util/ArrayList;

    .line 1116
    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    .line 1119
    iget-object v2, v2, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo;->beyondBoundsItems:Landroidx/compose/runtime/collection/MutableVector;

    .line 1121
    iget v2, v2, Landroidx/compose/runtime/collection/MutableVector;->size:I

    .line 1123
    if-eqz v2, :cond_4d6

    .line 1125
    new-instance v2, Lkotlin/ranges/IntRange;

    .line 1127
    iget v13, v3, Landroidx/compose/runtime/collection/MutableVector;->size:I

    .line 1129
    const-string v14, "MutableVector is empty."

    .line 1131
    if-eqz v13, :cond_4d2

    .line 1133
    move/from16 v20, v0

    .line 1135
    iget-object v0, v3, Landroidx/compose/runtime/collection/MutableVector;->content:[Ljava/lang/Object;

    .line 1137
    const/16 v37, 0x0

    .line 1139
    aget-object v21, v0, v37

    .line 1141
    move-object/from16 v22, v0

    .line 1143
    move-object/from16 v0, v21

    .line 1145
    check-cast v0, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;

    .line 1147
    iget v0, v0, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;->start:I

    .line 1149
    move/from16 v41, v8

    .line 1151
    const/4 v8, 0x0

    .line 1152
    :goto_47f
    if-ge v8, v13, :cond_491

    .line 1154
    aget-object v21, v22, v8

    .line 1156
    move/from16 v23, v8

    .line 1158
    move-object/from16 v8, v21

    .line 1160
    check-cast v8, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;

    .line 1162
    iget v8, v8, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;->start:I

    .line 1164
    if-ge v8, v0, :cond_48e

    .line 1166
    move v0, v8

    .line 1167
    :cond_48e
    add-int/lit8 v8, v23, 0x1

    .line 1169
    goto :goto_47f

    .line 1170
    :cond_491
    if-ltz v0, :cond_494

    .line 1172
    goto :goto_499

    .line 1173
    :cond_494
    const-string v8, "negative minIndex"

    .line 1175
    invoke-static {v8}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalArgumentException(Ljava/lang/String;)V

    .line 1178
    :goto_499
    iget v8, v3, Landroidx/compose/runtime/collection/MutableVector;->size:I

    .line 1180
    if-eqz v8, :cond_4cc

    .line 1182
    iget-object v3, v3, Landroidx/compose/runtime/collection/MutableVector;->content:[Ljava/lang/Object;

    .line 1184
    const/16 v37, 0x0

    .line 1186
    aget-object v13, v3, v37

    .line 1188
    check-cast v13, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;

    .line 1190
    iget v13, v13, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;->end:I

    .line 1192
    const/4 v14, 0x0

    .line 1193
    :goto_4a8
    if-ge v14, v8, :cond_4bc

    .line 1195
    aget-object v21, v3, v14

    .line 1197
    move-object/from16 v22, v3

    .line 1199
    move-object/from16 v3, v21

    .line 1201
    check-cast v3, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;

    .line 1203
    iget v3, v3, Landroidx/compose/foundation/lazy/layout/LazyLayoutBeyondBoundsInfo$Interval;->end:I

    .line 1205
    if-le v3, v13, :cond_4b7

    .line 1207
    move v13, v3

    .line 1208
    :cond_4b7
    add-int/lit8 v14, v14, 0x1

    .line 1210
    move-object/from16 v3, v22

    .line 1212
    goto :goto_4a8

    .line 1213
    :cond_4bc
    invoke-virtual {v12}, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->getItemCount()I

    .line 1216
    move-result v3

    .line 1217
    add-int/lit8 v3, v3, -0x1

    .line 1219
    invoke-static {v13, v3}, Ljava/lang/Math;->min(II)I

    .line 1222
    move-result v3

    .line 1223
    move/from16 v8, v33

    .line 1225
    invoke-direct {v2, v0, v3, v8}, Lkotlin/ranges/IntProgression;-><init>(III)V

    .line 1228
    goto :goto_4dc

    .line 1229
    :cond_4cc
    invoke-static {v14}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m(Ljava/lang/String;)V

    .line 1232
    :goto_4cf
    const/4 v10, 0x0

    .line 1233
    goto/16 :goto_c22

    .line 1235
    :cond_4d2
    invoke-static {v14}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m(Ljava/lang/String;)V

    .line 1238
    goto :goto_4cf

    .line 1239
    :cond_4d6
    move/from16 v20, v0

    .line 1241
    move/from16 v41, v8

    .line 1243
    sget-object v2, Lkotlin/ranges/IntRange;->EMPTY:Lkotlin/ranges/IntRange;

    .line 1245
    :goto_4dc
    iget-object v0, v1, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnedItemList;->items:Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 1247
    invoke-virtual {v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    .line 1250
    move-result v0

    .line 1251
    const/4 v3, 0x0

    .line 1252
    :goto_4e3
    if-ge v3, v0, :cond_50e

    .line 1254
    invoke-virtual {v1, v3}, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnedItemList;->get(I)Ljava/lang/Object;

    .line 1257
    move-result-object v8

    .line 1258
    check-cast v8, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;

    .line 1260
    iget-object v13, v8, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;->key:Ljava/lang/Object;

    .line 1262
    iget v8, v8, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;->index:I

    .line 1264
    invoke-static {v8, v12, v13}, Landroidx/compose/foundation/lazy/layout/LazyLayoutKt;->findIndexByKey(ILandroidx/compose/foundation/lazy/LazyListItemProviderImpl;Ljava/lang/Object;)I

    .line 1267
    move-result v8

    .line 1268
    iget v13, v2, Lkotlin/ranges/IntProgression;->first:I

    .line 1270
    iget v14, v2, Lkotlin/ranges/IntProgression;->last:I

    .line 1272
    if-gt v8, v14, :cond_4fc

    .line 1274
    if-gt v13, v8, :cond_4fc

    .line 1276
    goto :goto_50b

    .line 1277
    :cond_4fc
    if-ltz v8, :cond_50b

    .line 1279
    invoke-virtual {v12}, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->getItemCount()I

    .line 1282
    move-result v13

    .line 1283
    if-ge v8, v13, :cond_50b

    .line 1285
    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1288
    move-result-object v8

    .line 1289
    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1292
    :cond_50b
    :goto_50b
    add-int/lit8 v3, v3, 0x1

    .line 1294
    goto :goto_4e3

    .line 1295
    :cond_50e
    iget v0, v2, Lkotlin/ranges/IntProgression;->first:I

    .line 1297
    iget v1, v2, Lkotlin/ranges/IntProgression;->last:I

    .line 1299
    if-gt v0, v1, :cond_520

    .line 1301
    :goto_514
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1304
    move-result-object v2

    .line 1305
    invoke-virtual {v7, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 1308
    if-eq v0, v1, :cond_520

    .line 1310
    add-int/lit8 v0, v0, 0x1

    .line 1312
    goto :goto_514

    .line 1313
    :cond_520
    :goto_520
    invoke-interface/range {v40 .. v40}, Landroidx/compose/ui/layout/IntrinsicMeasureScope;->isLookingAhead()Z

    .line 1316
    move-result v0

    .line 1317
    if-nez v0, :cond_53c

    .line 1319
    if-nez v25, :cond_529

    .line 1321
    goto :goto_53c

    .line 1322
    :cond_529
    iget-object v0, v9, Landroidx/compose/foundation/lazy/LazyListState;->_lazyLayoutScrollDeltaBetweenPasses:Landroidx/compose/ui/platform/WeakCache;

    .line 1324
    iget-object v0, v0, Landroidx/compose/ui/platform/WeakCache;->referenceQueue:Ljava/lang/Object;

    .line 1326
    check-cast v0, Landroidx/compose/animation/core/AnimationState;

    .line 1328
    iget-object v0, v0, Landroidx/compose/animation/core/AnimationState;->value$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 1330
    invoke-virtual {v0}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 1333
    move-result-object v0

    .line 1334
    check-cast v0, Ljava/lang/Number;

    .line 1336
    invoke-virtual {v0}, Ljava/lang/Number;->floatValue()F

    .line 1339
    move-result v0

    .line 1340
    goto :goto_53e

    .line 1341
    :cond_53c
    :goto_53c
    iget v0, v9, Landroidx/compose/foundation/lazy/LazyListState;->scrollToBeConsumed:F

    .line 1343
    :goto_53e
    iget-object v1, v9, Landroidx/compose/foundation/lazy/LazyListState;->itemAnimator:Landroidx/compose/foundation/lazy/layout/LazyLayoutItemAnimator;

    .line 1345
    invoke-interface/range {v40 .. v40}, Landroidx/compose/ui/layout/IntrinsicMeasureScope;->isLookingAhead()Z

    .line 1348
    move-result v24

    .line 1349
    iget-object v2, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$coroutineScope:Lkotlinx/coroutines/CoroutineScope;

    .line 1351
    iget-object v3, v9, Landroidx/compose/foundation/lazy/LazyListState;->placementScopeInvalidator:Landroidx/compose/runtime/MutableState;

    .line 1353
    iget-object v8, v15, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1;->$stickyItemsPlacement:Landroidx/compose/foundation/lazy/layout/DummyHandle;

    .line 1355
    if-ltz v39, :cond_54d

    .line 1357
    goto :goto_552

    .line 1358
    :cond_54d
    const-string v12, "invalid beforeContentPadding"

    .line 1360
    invoke-static {v12}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalArgumentException(Ljava/lang/String;)V

    .line 1363
    :goto_552
    if-ltz v35, :cond_555

    .line 1365
    goto :goto_55a

    .line 1366
    :cond_555
    const-string v12, "invalid afterContentPadding"

    .line 1368
    invoke-static {v12}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalArgumentException(Ljava/lang/String;)V

    .line 1371
    :goto_55a
    sget-object v12, Lkotlin/collections/EmptyMap;->INSTANCE:Lkotlin/collections/EmptyMap;

    .line 1373
    iget-object v13, v6, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->itemProvider:Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;

    .line 1375
    if-gtz v38, :cond_5cd

    .line 1377
    invoke-static {v10, v11}, Landroidx/compose/ui/unit/Constraints;->getMinWidth-impl(J)I

    .line 1380
    move-result v19

    .line 1381
    invoke-static {v10, v11}, Landroidx/compose/ui/unit/Constraints;->getMinHeight-impl(J)I

    .line 1384
    move-result v20

    .line 1385
    new-instance v21, Ljava/util/ArrayList;

    .line 1387
    invoke-direct/range {v21 .. v21}, Ljava/util/ArrayList;-><init>()V

    .line 1390
    iget-object v0, v13, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->keyIndexMap:Landroidx/compose/ui/spatial/RectList;

    .line 1392
    const/16 v26, 0x0

    .line 1394
    const/16 v27, 0x0

    .line 1396
    move-object/from16 v22, v0

    .line 1398
    move-object/from16 v18, v1

    .line 1400
    move-object/from16 v23, v6

    .line 1402
    invoke-virtual/range {v18 .. v27}, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemAnimator;->onMeasured(IILjava/util/ArrayList;Landroidx/compose/ui/spatial/RectList;Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;ZZII)V

    .line 1405
    if-nez v24, :cond_58c

    .line 1407
    invoke-virtual {v1}, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemAnimator;->getMinSizeToFitDisappearingItems-YbymL2g()J

    .line 1410
    if-nez p0, :cond_58c

    .line 1412
    const/4 v0, 0x0

    .line 1413
    invoke-static {v0, v10, v11}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainWidth-K40F9xA(IJ)I

    .line 1416
    move-result v19

    .line 1417
    invoke-static {v0, v10, v11}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainHeight-K40F9xA(IJ)I

    .line 1420
    move-result v20

    .line 1421
    :cond_58c
    new-instance v0, Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;

    .line 1423
    const/16 v1, 0x18

    .line 1425
    invoke-direct {v0, v1}, Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;-><init>(I)V

    .line 1428
    add-int v1, v19, v29

    .line 1430
    invoke-static {v1, v4, v5}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainWidth-K40F9xA(IJ)I

    .line 1433
    move-result v1

    .line 1434
    add-int v3, v20, p1

    .line 1436
    invoke-static {v3, v4, v5}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainHeight-K40F9xA(IJ)I

    .line 1439
    move-result v3

    .line 1440
    move-object/from16 v14, v40

    .line 1442
    invoke-interface {v14, v1, v3, v12, v0}, Landroidx/compose/ui/layout/MeasureScope;->layout(IILjava/util/Map;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/layout/MeasureResult;

    .line 1445
    move-result-object v23

    .line 1446
    move/from16 v15, v39

    .line 1448
    neg-int v0, v15

    .line 1449
    add-int v32, v41, v35

    .line 1451
    new-instance v18, Landroidx/compose/foundation/lazy/LazyListMeasureResult;

    .line 1453
    const/16 v25, 0x0

    .line 1455
    const/16 v33, 0x0

    .line 1457
    const/16 v19, 0x0

    .line 1459
    const/16 v20, 0x0

    .line 1461
    const/16 v21, 0x0

    .line 1463
    const/16 v22, 0x0

    .line 1465
    const/16 v24, 0x0

    .line 1467
    iget-wide v3, v6, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->childConstraints:J

    .line 1469
    move/from16 v31, v0

    .line 1471
    move-object/from16 v26, v2

    .line 1473
    move-object/from16 v27, v28

    .line 1475
    move-wide/from16 v28, v3

    .line 1477
    invoke-direct/range {v18 .. v36}, Landroidx/compose/foundation/lazy/LazyListMeasureResult;-><init>(Landroidx/compose/foundation/lazy/LazyListMeasuredItem;IZFLandroidx/compose/ui/layout/MeasureResult;FZLkotlinx/coroutines/CoroutineScope;Landroidx/compose/ui/unit/Density;JLjava/util/List;IIILandroidx/compose/foundation/gestures/Orientation;II)V

    .line 1480
    move-object/from16 v39, v9

    .line 1482
    :goto_5c9
    move-object/from16 v10, v18

    .line 1484
    goto/16 :goto_c09

    .line 1486
    :cond_5cd
    move-object/from16 v14, v28

    .line 1488
    move-object/from16 v28, v2

    .line 1490
    move-object v2, v14

    .line 1491
    move-object/from16 v21, v1

    .line 1493
    move/from16 v1, v19

    .line 1495
    move/from16 v15, v39

    .line 1497
    move-object/from16 v14, v40

    .line 1499
    move/from16 v19, v0

    .line 1501
    move/from16 v0, v38

    .line 1503
    if-lt v1, v0, :cond_5e4

    .line 1505
    add-int/lit8 v1, v0, -0x1

    .line 1507
    const/16 v20, 0x0

    .line 1509
    :cond_5e4
    invoke-static/range {v19 .. v19}, Ljava/lang/Math;->round(F)I

    .line 1512
    move-result v22

    .line 1513
    sub-int v20, v20, v22

    .line 1515
    if-nez v1, :cond_5f2

    .line 1517
    if-gez v20, :cond_5f2

    .line 1519
    add-int v22, v22, v20

    .line 1521
    const/16 v20, 0x0

    .line 1523
    :cond_5f2
    move/from16 v23, v1

    .line 1525
    new-instance v1, Lkotlin/collections/ArrayDeque;

    .line 1527
    invoke-direct {v1}, Lkotlin/collections/ArrayDeque;-><init>()V

    .line 1530
    move-object/from16 v38, v8

    .line 1532
    neg-int v8, v15

    .line 1533
    if-gez v36, :cond_603

    .line 1535
    move/from16 v26, v36

    .line 1537
    :goto_600
    move-object/from16 v39, v9

    .line 1539
    goto :goto_606

    .line 1540
    :cond_603
    const/16 v26, 0x0

    .line 1542
    goto :goto_600

    .line 1543
    :goto_606
    add-int v9, v8, v26

    .line 1545
    add-int v20, v20, v9

    .line 1547
    move-wide/from16 v43, v4

    .line 1549
    move-object/from16 v40, v12

    .line 1551
    move-object/from16 v42, v14

    .line 1553
    move/from16 v12, v20

    .line 1555
    const/4 v14, 0x0

    .line 1556
    :goto_613
    iget-wide v4, v6, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->childConstraints:J

    .line 1558
    if-gez v12, :cond_633

    .line 1560
    if-lez v23, :cond_633

    .line 1562
    move-object/from16 v45, v3

    .line 1564
    add-int/lit8 v3, v23, -0x1

    .line 1566
    invoke-virtual {v6, v3, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1569
    move-result-object v4

    .line 1570
    const/4 v5, 0x0

    .line 1571
    invoke-virtual {v1, v5, v4}, Lkotlin/collections/ArrayDeque;->add(ILjava/lang/Object;)V

    .line 1574
    iget v5, v4, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->crossAxisSize:I

    .line 1576
    invoke-static {v14, v5}, Ljava/lang/Math;->max(II)I

    .line 1579
    move-result v14

    .line 1580
    iget v4, v4, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 1582
    add-int/2addr v12, v4

    .line 1583
    move/from16 v23, v3

    .line 1585
    move-object/from16 v3, v45

    .line 1587
    goto :goto_613

    .line 1588
    :cond_633
    move-object/from16 v45, v3

    .line 1590
    if-ge v12, v9, :cond_63c

    .line 1592
    sub-int v3, v9, v12

    .line 1594
    sub-int v22, v22, v3

    .line 1596
    move v12, v9

    .line 1597
    :cond_63c
    move/from16 v3, v22

    .line 1599
    sub-int/2addr v12, v9

    .line 1600
    add-int v46, v41, v35

    .line 1602
    move/from16 v20, v14

    .line 1604
    if-gez v46, :cond_649

    .line 1606
    const/4 v14, 0x0

    .line 1607
    :goto_646
    move/from16 v47, v8

    .line 1609
    goto :goto_64c

    .line 1610
    :cond_649
    move/from16 v14, v46

    .line 1612
    goto :goto_646

    .line 1613
    :goto_64c
    neg-int v8, v12

    .line 1614
    move/from16 v26, v12

    .line 1616
    move-object/from16 v48, v13

    .line 1618
    move/from16 v27, v23

    .line 1620
    const/4 v12, 0x0

    .line 1621
    const/16 v22, 0x0

    .line 1623
    :goto_656
    iget v13, v1, Lkotlin/collections/ArrayDeque;->size:I

    .line 1625
    if-ge v12, v13, :cond_670

    .line 1627
    if-lt v8, v14, :cond_662

    .line 1629
    invoke-virtual {v1, v12}, Lkotlin/collections/ArrayDeque;->removeAt(I)Ljava/lang/Object;

    .line 1632
    const/16 v22, 0x1

    .line 1634
    goto :goto_656

    .line 1635
    :cond_662
    add-int/lit8 v27, v27, 0x1

    .line 1637
    invoke-virtual {v1, v12}, Lkotlin/collections/ArrayDeque;->get(I)Ljava/lang/Object;

    .line 1640
    move-result-object v13

    .line 1641
    check-cast v13, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1643
    iget v13, v13, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 1645
    add-int/2addr v8, v13

    .line 1646
    add-int/lit8 v12, v12, 0x1

    .line 1648
    goto :goto_656

    .line 1649
    :cond_670
    move/from16 v12, v20

    .line 1651
    move/from16 v49, v22

    .line 1653
    move/from16 v13, v27

    .line 1655
    :goto_676
    if-ge v13, v0, :cond_685

    .line 1657
    if-lt v8, v14, :cond_682

    .line 1659
    if-lez v8, :cond_682

    .line 1661
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->isEmpty()Z

    .line 1664
    move-result v20

    .line 1665
    if-eqz v20, :cond_685

    .line 1667
    :cond_682
    move/from16 v20, v14

    .line 1669
    goto :goto_68a

    .line 1670
    :cond_685
    move/from16 v50, v0

    .line 1672
    move/from16 v0, v41

    .line 1674
    goto :goto_6b5

    .line 1675
    :goto_68a
    invoke-virtual {v6, v13, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1678
    move-result-object v14

    .line 1679
    move/from16 v50, v0

    .line 1681
    iget v0, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 1683
    add-int/2addr v8, v0

    .line 1684
    if-gt v8, v9, :cond_6a4

    .line 1686
    move/from16 v22, v0

    .line 1688
    add-int/lit8 v0, v50, -0x1

    .line 1690
    if-eq v13, v0, :cond_6a4

    .line 1692
    add-int/lit8 v0, v13, 0x1

    .line 1694
    sub-int v26, v26, v22

    .line 1696
    move/from16 v23, v0

    .line 1698
    const/16 v49, 0x1

    .line 1700
    goto :goto_6ae

    .line 1701
    :cond_6a4
    iget v0, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->crossAxisSize:I

    .line 1703
    invoke-static {v12, v0}, Ljava/lang/Math;->max(II)I

    .line 1706
    move-result v0

    .line 1707
    invoke-virtual {v1, v14}, Lkotlin/collections/ArrayDeque;->addLast(Ljava/lang/Object;)V

    .line 1710
    move v12, v0

    .line 1711
    :goto_6ae
    add-int/lit8 v13, v13, 0x1

    .line 1713
    move/from16 v14, v20

    .line 1715
    move/from16 v0, v50

    .line 1717
    goto :goto_676

    .line 1718
    :goto_6b5
    if-ge v8, v0, :cond_6f9

    .line 1720
    sub-int v9, v0, v8

    .line 1722
    sub-int v26, v26, v9

    .line 1724
    add-int/2addr v8, v9

    .line 1725
    move/from16 v14, v26

    .line 1727
    :goto_6be
    if-ge v14, v15, :cond_6e0

    .line 1729
    if-lez v23, :cond_6e0

    .line 1731
    move/from16 v20, v8

    .line 1733
    add-int/lit8 v8, v23, -0x1

    .line 1735
    move/from16 v22, v9

    .line 1737
    invoke-virtual {v6, v8, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1740
    move-result-object v9

    .line 1741
    move/from16 v23, v8

    .line 1743
    const/4 v8, 0x0

    .line 1744
    invoke-virtual {v1, v8, v9}, Lkotlin/collections/ArrayDeque;->add(ILjava/lang/Object;)V

    .line 1747
    iget v8, v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->crossAxisSize:I

    .line 1749
    invoke-static {v12, v8}, Ljava/lang/Math;->max(II)I

    .line 1752
    move-result v12

    .line 1753
    iget v8, v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 1755
    add-int/2addr v14, v8

    .line 1756
    move/from16 v8, v20

    .line 1758
    move/from16 v9, v22

    .line 1760
    goto :goto_6be

    .line 1761
    :cond_6e0
    move/from16 v20, v8

    .line 1763
    move/from16 v22, v9

    .line 1765
    add-int v9, v3, v22

    .line 1767
    if-gez v14, :cond_6f1

    .line 1769
    add-int/2addr v9, v14

    .line 1770
    add-int v8, v20, v14

    .line 1772
    move/from16 v20, v12

    .line 1774
    move/from16 v14, v23

    .line 1776
    const/4 v12, 0x0

    .line 1777
    goto :goto_700

    .line 1778
    :cond_6f1
    move/from16 v8, v20

    .line 1780
    move/from16 v20, v12

    .line 1782
    move v12, v14

    .line 1783
    move/from16 v14, v23

    .line 1785
    goto :goto_700

    .line 1786
    :cond_6f9
    move v9, v3

    .line 1787
    move/from16 v20, v12

    .line 1789
    move/from16 v14, v23

    .line 1791
    move/from16 v12, v26

    .line 1793
    :goto_700
    invoke-static/range {v19 .. v19}, Ljava/lang/Math;->round(F)I

    .line 1796
    move-result v22

    .line 1797
    move/from16 v26, v15

    .line 1799
    invoke-static/range {v22 .. v22}, Ljava/lang/Integer;->signum(I)I

    .line 1802
    move-result v15

    .line 1803
    move/from16 v41, v13

    .line 1805
    invoke-static {v9}, Ljava/lang/Integer;->signum(I)I

    .line 1808
    move-result v13

    .line 1809
    if-ne v15, v13, :cond_722

    .line 1811
    invoke-static/range {v19 .. v19}, Ljava/lang/Math;->round(F)I

    .line 1814
    move-result v13

    .line 1815
    invoke-static {v13}, Ljava/lang/Math;->abs(I)I

    .line 1818
    move-result v13

    .line 1819
    invoke-static {v9}, Ljava/lang/Math;->abs(I)I

    .line 1822
    move-result v15

    .line 1823
    if-lt v13, v15, :cond_722

    .line 1825
    int-to-float v13, v9

    .line 1826
    goto :goto_724

    .line 1827
    :cond_722
    move/from16 v13, v19

    .line 1829
    :goto_724
    sub-float v15, v19, v13

    .line 1831
    const/16 v19, 0x0

    .line 1833
    if-eqz v24, :cond_734

    .line 1835
    if-le v9, v3, :cond_734

    .line 1837
    cmpg-float v22, v15, v19

    .line 1839
    if-gtz v22, :cond_734

    .line 1841
    sub-int/2addr v9, v3

    .line 1842
    int-to-float v3, v9

    .line 1843
    add-float v19, v3, v15

    .line 1845
    :cond_734
    move/from16 v3, v19

    .line 1847
    if-ltz v12, :cond_739

    .line 1849
    goto :goto_73e

    .line 1850
    :cond_739
    const-string v9, "negative currentFirstItemScrollOffset"

    .line 1852
    invoke-static {v9}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalArgumentException(Ljava/lang/String;)V

    .line 1855
    :goto_73e
    neg-int v9, v12

    .line 1856
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->first()Ljava/lang/Object;

    .line 1859
    move-result-object v15

    .line 1860
    check-cast v15, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1862
    if-gtz v26, :cond_749

    .line 1864
    if-gez v36, :cond_74c

    .line 1866
    :cond_749
    move/from16 v51, v3

    .line 1868
    goto :goto_754

    .line 1869
    :cond_74c
    move/from16 v51, v3

    .line 1871
    move/from16 v19, v9

    .line 1873
    :cond_750
    move/from16 v26, v12

    .line 1875
    const/4 v3, 0x0

    .line 1876
    goto :goto_787

    .line 1877
    :goto_754
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->getSize()I

    .line 1880
    move-result v3

    .line 1881
    move/from16 v19, v9

    .line 1883
    const/4 v9, 0x0

    .line 1884
    :goto_75b
    if-ge v9, v3, :cond_750

    .line 1886
    invoke-virtual {v1, v9}, Lkotlin/collections/ArrayDeque;->get(I)Ljava/lang/Object;

    .line 1889
    move-result-object v22

    .line 1890
    move/from16 v23, v3

    .line 1892
    move-object/from16 v3, v22

    .line 1894
    check-cast v3, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1896
    iget v3, v3, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 1898
    if-eqz v12, :cond_750

    .line 1900
    if-gt v3, v12, :cond_750

    .line 1902
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->getSize()I

    .line 1905
    move-result v22

    .line 1906
    move/from16 v26, v3

    .line 1908
    const/16 v33, 0x1

    .line 1910
    add-int/lit8 v3, v22, -0x1

    .line 1912
    if-eq v9, v3, :cond_750

    .line 1914
    sub-int v12, v12, v26

    .line 1916
    add-int/lit8 v9, v9, 0x1

    .line 1918
    invoke-virtual {v1, v9}, Lkotlin/collections/ArrayDeque;->get(I)Ljava/lang/Object;

    .line 1921
    move-result-object v3

    .line 1922
    move-object v15, v3

    .line 1923
    check-cast v15, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1925
    move/from16 v3, v23

    .line 1927
    goto :goto_75b

    .line 1928
    :goto_787
    invoke-static {v3, v14}, Ljava/lang/Math;->max(II)I

    .line 1931
    move-result v9

    .line 1932
    const/16 v33, 0x1

    .line 1934
    add-int/lit8 v14, v14, -0x1

    .line 1936
    const/4 v3, 0x0

    .line 1937
    if-gt v9, v14, :cond_7a5

    .line 1939
    :goto_792
    if-nez v3, :cond_799

    .line 1941
    new-instance v3, Ljava/util/ArrayList;

    .line 1943
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1946
    :cond_799
    invoke-virtual {v6, v14, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1949
    move-result-object v12

    .line 1950
    invoke-interface {v3, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1953
    if-eq v14, v9, :cond_7a5

    .line 1955
    add-int/lit8 v14, v14, -0x1

    .line 1957
    goto :goto_792

    .line 1958
    :cond_7a5
    invoke-interface {v7}, Ljava/util/Collection;->size()I

    .line 1961
    move-result v12

    .line 1962
    add-int/lit8 v12, v12, -0x1

    .line 1964
    if-ltz v12, :cond_7ce

    .line 1966
    :goto_7ad
    add-int/lit8 v14, v12, -0x1

    .line 1968
    invoke-interface {v7, v12}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1971
    move-result-object v12

    .line 1972
    check-cast v12, Ljava/lang/Number;

    .line 1974
    invoke-virtual {v12}, Ljava/lang/Number;->intValue()I

    .line 1977
    move-result v12

    .line 1978
    if-ge v12, v9, :cond_7c9

    .line 1980
    if-nez v3, :cond_7c2

    .line 1982
    new-instance v3, Ljava/util/ArrayList;

    .line 1984
    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    .line 1987
    :cond_7c2
    invoke-virtual {v6, v12, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 1990
    move-result-object v12

    .line 1991
    invoke-interface {v3, v12}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 1994
    :cond_7c9
    if-gez v14, :cond_7cc

    .line 1996
    goto :goto_7ce

    .line 1997
    :cond_7cc
    move v12, v14

    .line 1998
    goto :goto_7ad

    .line 1999
    :cond_7ce
    :goto_7ce
    if-nez v3, :cond_7d2

    .line 2001
    move-object/from16 v3, v30

    .line 2003
    :cond_7d2
    invoke-interface {v3}, Ljava/util/Collection;->size()I

    .line 2006
    move-result v9

    .line 2007
    move/from16 v12, v20

    .line 2009
    const/4 v14, 0x0

    .line 2010
    :goto_7d9
    if-ge v14, v9, :cond_7f0

    .line 2012
    invoke-interface {v3, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2015
    move-result-object v20

    .line 2016
    move/from16 v22, v9

    .line 2018
    move-object/from16 v9, v20

    .line 2020
    check-cast v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2022
    iget v9, v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->crossAxisSize:I

    .line 2024
    invoke-static {v12, v9}, Ljava/lang/Math;->max(II)I

    .line 2027
    move-result v12

    .line 2028
    add-int/lit8 v14, v14, 0x1

    .line 2030
    move/from16 v9, v22

    .line 2032
    goto :goto_7d9

    .line 2033
    :cond_7f0
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 2036
    move-result-object v9

    .line 2037
    check-cast v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2039
    iget v9, v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2041
    add-int/lit8 v14, v50, -0x1

    .line 2043
    invoke-static {v9, v14}, Ljava/lang/Math;->min(II)I

    .line 2046
    move-result v9

    .line 2047
    invoke-static {v1}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 2050
    move-result-object v14

    .line 2051
    check-cast v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2053
    iget v14, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2055
    const/16 v33, 0x1

    .line 2057
    add-int/lit8 v14, v14, 0x1

    .line 2059
    if-gt v14, v9, :cond_82d

    .line 2061
    const/16 v20, 0x0

    .line 2063
    :goto_80e
    if-nez v20, :cond_815

    .line 2065
    new-instance v20, Ljava/util/ArrayList;

    .line 2067
    invoke-direct/range {v20 .. v20}, Ljava/util/ArrayList;-><init>()V

    .line 2070
    :cond_815
    move/from16 v22, v12

    .line 2072
    move/from16 v52, v13

    .line 2074
    move-object/from16 v12, v20

    .line 2076
    invoke-virtual {v6, v14, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2079
    move-result-object v13

    .line 2080
    invoke-interface {v12, v13}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2083
    if-eq v14, v9, :cond_832

    .line 2085
    add-int/lit8 v14, v14, 0x1

    .line 2087
    move-object/from16 v20, v12

    .line 2089
    move/from16 v12, v22

    .line 2091
    move/from16 v13, v52

    .line 2093
    goto :goto_80e

    .line 2094
    :cond_82d
    move/from16 v22, v12

    .line 2096
    move/from16 v52, v13

    .line 2098
    const/4 v12, 0x0

    .line 2099
    :cond_832
    if-eqz v12, :cond_846

    .line 2101
    invoke-static {v12}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 2104
    move-result-object v13

    .line 2105
    check-cast v13, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2107
    iget v13, v13, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2109
    if-le v13, v9, :cond_846

    .line 2111
    invoke-static {v12}, Lkotlin/collections/CollectionsKt;->last(Ljava/util/List;)Ljava/lang/Object;

    .line 2114
    move-result-object v9

    .line 2115
    check-cast v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2117
    iget v9, v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2119
    :cond_846
    invoke-interface {v7}, Ljava/util/Collection;->size()I

    .line 2122
    move-result v13

    .line 2123
    const/4 v14, 0x0

    .line 2124
    :goto_84b
    if-ge v14, v13, :cond_86e

    .line 2126
    invoke-interface {v7, v14}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2129
    move-result-object v20

    .line 2130
    check-cast v20, Ljava/lang/Number;

    .line 2132
    move-object/from16 v23, v7

    .line 2134
    invoke-virtual/range {v20 .. v20}, Ljava/lang/Number;->intValue()I

    .line 2137
    move-result v7

    .line 2138
    if-le v7, v9, :cond_869

    .line 2140
    if-nez v12, :cond_862

    .line 2142
    new-instance v12, Ljava/util/ArrayList;

    .line 2144
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 2147
    :cond_862
    invoke-virtual {v6, v7, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2150
    move-result-object v7

    .line 2151
    invoke-interface {v12, v7}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 2154
    :cond_869
    add-int/lit8 v14, v14, 0x1

    .line 2156
    move-object/from16 v7, v23

    .line 2158
    goto :goto_84b

    .line 2159
    :cond_86e
    if-nez v12, :cond_872

    .line 2161
    move-object/from16 v12, v30

    .line 2163
    :cond_872
    invoke-interface {v12}, Ljava/util/Collection;->size()I

    .line 2166
    move-result v7

    .line 2167
    move/from16 v9, v22

    .line 2169
    const/4 v13, 0x0

    .line 2170
    :goto_879
    if-ge v13, v7, :cond_88a

    .line 2172
    invoke-interface {v12, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2175
    move-result-object v14

    .line 2176
    check-cast v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2178
    iget v14, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->crossAxisSize:I

    .line 2180
    invoke-static {v9, v14}, Ljava/lang/Math;->max(II)I

    .line 2183
    move-result v9

    .line 2184
    add-int/lit8 v13, v13, 0x1

    .line 2186
    goto :goto_879

    .line 2187
    :cond_88a
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->first()Ljava/lang/Object;

    .line 2190
    move-result-object v7

    .line 2191
    invoke-static {v15, v7}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 2194
    move-result v7

    .line 2195
    if-eqz v7, :cond_8a2

    .line 2197
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 2200
    move-result v7

    .line 2201
    if-eqz v7, :cond_8a2

    .line 2203
    invoke-interface {v12}, Ljava/util/List;->isEmpty()Z

    .line 2206
    move-result v7

    .line 2207
    if-eqz v7, :cond_8a2

    .line 2209
    const/4 v7, 0x1

    .line 2210
    goto :goto_8a3

    .line 2211
    :cond_8a2
    const/4 v7, 0x0

    .line 2212
    :goto_8a3
    invoke-static {v9, v10, v11}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainWidth-K40F9xA(IJ)I

    .line 2215
    move-result v9

    .line 2216
    invoke-static {v8, v10, v11}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainHeight-K40F9xA(IJ)I

    .line 2219
    move-result v13

    .line 2220
    invoke-static {v13, v0}, Ljava/lang/Math;->min(II)I

    .line 2223
    move-result v14

    .line 2224
    if-ge v8, v14, :cond_8b3

    .line 2226
    const/4 v14, 0x1

    .line 2227
    goto :goto_8b4

    .line 2228
    :cond_8b3
    const/4 v14, 0x0

    .line 2229
    :goto_8b4
    if-eqz v14, :cond_8be

    .line 2231
    if-nez v19, :cond_8b9

    .line 2233
    goto :goto_8be

    .line 2234
    :cond_8b9
    const-string v20, "non-zero itemsScrollOffset"

    .line 2236
    invoke-static/range {v20 .. v20}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalStateException(Ljava/lang/String;)V

    .line 2239
    :cond_8be
    :goto_8be
    move-object/from16 v23, v6

    .line 2241
    new-instance v6, Ljava/util/ArrayList;

    .line 2243
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->getSize()I

    .line 2246
    move-result v20

    .line 2247
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 2250
    move-result v22

    .line 2251
    add-int v22, v22, v20

    .line 2253
    invoke-interface {v12}, Ljava/util/List;->size()I

    .line 2256
    move-result v20

    .line 2257
    move/from16 v53, v7

    .line 2259
    add-int v7, v20, v22

    .line 2261
    invoke-direct {v6, v7}, Ljava/util/ArrayList;-><init>(I)V

    .line 2264
    if-eqz v14, :cond_938

    .line 2266
    invoke-interface {v3}, Ljava/util/List;->isEmpty()Z

    .line 2269
    move-result v3

    .line 2270
    if-eqz v3, :cond_8e6

    .line 2272
    invoke-interface {v12}, Ljava/util/List;->isEmpty()Z

    .line 2275
    move-result v3

    .line 2276
    if-eqz v3, :cond_8e6

    .line 2278
    goto :goto_8eb

    .line 2279
    :cond_8e6
    const-string v3, "no extra items"

    .line 2281
    invoke-static {v3}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalArgumentException(Ljava/lang/String;)V

    .line 2284
    :goto_8eb
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->getSize()I

    .line 2287
    move-result v3

    .line 2288
    new-array v7, v3, [I

    .line 2290
    const/4 v12, 0x0

    .line 2291
    :goto_8f2
    if-ge v12, v3, :cond_901

    .line 2293
    invoke-virtual {v1, v12}, Lkotlin/collections/ArrayDeque;->get(I)Ljava/lang/Object;

    .line 2296
    move-result-object v14

    .line 2297
    check-cast v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2299
    iget v14, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->size:I

    .line 2301
    aput v14, v7, v12

    .line 2303
    add-int/lit8 v12, v12, 0x1

    .line 2305
    goto :goto_8f2

    .line 2306
    :cond_901
    new-array v12, v3, [I

    .line 2308
    if-eqz v18, :cond_930

    .line 2310
    move-object/from16 v14, v18

    .line 2312
    invoke-interface {v14, v13, v2, v7, v12}, Landroidx/compose/foundation/layout/Arrangement$Vertical;->arrange(ILandroidx/compose/ui/layout/MeasureScope;[I[I)V

    .line 2315
    new-instance v7, Lkotlin/ranges/IntRange;

    .line 2317
    const/4 v14, 0x1

    .line 2318
    sub-int/2addr v3, v14

    .line 2319
    move-object/from16 v54, v2

    .line 2321
    const/4 v2, 0x0

    .line 2322
    invoke-direct {v7, v2, v3, v14}, Lkotlin/ranges/IntProgression;-><init>(III)V

    .line 2325
    iget v2, v7, Lkotlin/ranges/IntProgression;->last:I

    .line 2327
    if-gez v2, :cond_91c

    .line 2329
    :cond_918
    move-object/from16 v2, v48

    .line 2331
    goto/16 :goto_993

    .line 2333
    :cond_91c
    const/4 v3, 0x0

    .line 2334
    :goto_91d
    aget v7, v12, v3

    .line 2336
    invoke-virtual {v1, v3}, Lkotlin/collections/ArrayDeque;->get(I)Ljava/lang/Object;

    .line 2339
    move-result-object v14

    .line 2340
    check-cast v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2342
    invoke-virtual {v14, v7, v9, v13}, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->position(III)V

    .line 2345
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2348
    if-eq v3, v2, :cond_918

    .line 2350
    add-int/lit8 v3, v3, 0x1

    .line 2352
    goto :goto_91d

    .line 2353
    :cond_930
    invoke-static/range {p2 .. p2}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalArgumentExceptionForNullCheck(Ljava/lang/String;)Ljava/lang/Void;

    .line 2356
    invoke-static {}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2()V

    .line 2359
    goto/16 :goto_4cf

    .line 2361
    :cond_938
    move-object/from16 v54, v2

    .line 2363
    invoke-interface {v3}, Ljava/util/Collection;->size()I

    .line 2366
    move-result v2

    .line 2367
    move/from16 v14, v19

    .line 2369
    const/4 v7, 0x0

    .line 2370
    :goto_941
    if-ge v7, v2, :cond_95f

    .line 2372
    invoke-interface {v3, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2375
    move-result-object v18

    .line 2376
    move/from16 p2, v2

    .line 2378
    move-object/from16 v2, v18

    .line 2380
    check-cast v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2382
    move-object/from16 v18, v3

    .line 2384
    iget v3, v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 2386
    sub-int/2addr v14, v3

    .line 2387
    invoke-virtual {v2, v14, v9, v13}, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->position(III)V

    .line 2390
    invoke-virtual {v6, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2393
    add-int/lit8 v7, v7, 0x1

    .line 2395
    move/from16 v2, p2

    .line 2397
    move-object/from16 v3, v18

    .line 2399
    goto :goto_941

    .line 2400
    :cond_95f
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->getSize()I

    .line 2403
    move-result v2

    .line 2404
    move/from16 v3, v19

    .line 2406
    const/4 v7, 0x0

    .line 2407
    :goto_966
    if-ge v7, v2, :cond_97a

    .line 2409
    invoke-virtual {v1, v7}, Lkotlin/collections/ArrayDeque;->get(I)Ljava/lang/Object;

    .line 2412
    move-result-object v14

    .line 2413
    check-cast v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2415
    invoke-virtual {v14, v3, v9, v13}, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->position(III)V

    .line 2418
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2421
    iget v14, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 2423
    add-int/2addr v3, v14

    .line 2424
    add-int/lit8 v7, v7, 0x1

    .line 2426
    goto :goto_966

    .line 2427
    :cond_97a
    invoke-interface {v12}, Ljava/util/Collection;->size()I

    .line 2430
    move-result v2

    .line 2431
    const/4 v7, 0x0

    .line 2432
    :goto_97f
    if-ge v7, v2, :cond_918

    .line 2434
    invoke-interface {v12, v7}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 2437
    move-result-object v14

    .line 2438
    check-cast v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2440
    invoke-virtual {v14, v3, v9, v13}, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->position(III)V

    .line 2443
    invoke-virtual {v6, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2446
    iget v14, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 2448
    add-int/2addr v3, v14

    .line 2449
    add-int/lit8 v7, v7, 0x1

    .line 2451
    goto :goto_97f

    .line 2452
    :goto_993
    iget-object v3, v2, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->keyIndexMap:Landroidx/compose/ui/spatial/RectList;

    .line 2454
    move-object/from16 v22, v3

    .line 2456
    move/from16 v27, v8

    .line 2458
    move/from16 v19, v9

    .line 2460
    move/from16 v20, v13

    .line 2462
    move-object/from16 v18, v21

    .line 2464
    move-object/from16 v21, v6

    .line 2466
    invoke-virtual/range {v18 .. v27}, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemAnimator;->onMeasured(IILjava/util/ArrayList;Landroidx/compose/ui/spatial/RectList;Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;ZZII)V

    .line 2469
    move-object/from16 v7, v21

    .line 2471
    move-object/from16 v6, v23

    .line 2473
    move/from16 v3, v24

    .line 2475
    move/from16 v20, v26

    .line 2477
    if-nez v3, :cond_9d9

    .line 2479
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemAnimator;->getMinSizeToFitDisappearingItems-YbymL2g()J

    .line 2482
    if-nez p0, :cond_9d9

    .line 2484
    const/4 v12, 0x0

    .line 2485
    invoke-static {v9, v12}, Ljava/lang/Math;->max(II)I

    .line 2488
    move-result v9

    .line 2489
    invoke-static {v9, v10, v11}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainWidth-K40F9xA(IJ)I

    .line 2492
    move-result v9

    .line 2493
    invoke-static {v13, v12}, Ljava/lang/Math;->max(II)I

    .line 2496
    move-result v14

    .line 2497
    invoke-static {v14, v10, v11}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainHeight-K40F9xA(IJ)I

    .line 2500
    move-result v10

    .line 2501
    if-eq v10, v13, :cond_9d8

    .line 2503
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 2506
    move-result v11

    .line 2507
    const/4 v12, 0x0

    .line 2508
    :goto_9cb
    if-ge v12, v11, :cond_9d8

    .line 2510
    invoke-virtual {v7, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 2513
    move-result-object v13

    .line 2514
    check-cast v13, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2516
    iput v10, v13, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisLayoutSize:I

    .line 2518
    add-int/lit8 v12, v12, 0x1

    .line 2520
    goto :goto_9cb

    .line 2521
    :cond_9d8
    move v13, v10

    .line 2522
    :cond_9d9
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->firstOrNull()Ljava/lang/Object;

    .line 2525
    move-result-object v10

    .line 2526
    check-cast v10, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2528
    if-eqz v10, :cond_9e4

    .line 2530
    iget v10, v10, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2532
    goto :goto_9e5

    .line 2533
    :cond_9e4
    const/4 v10, 0x0

    .line 2534
    :goto_9e5
    invoke-virtual {v1}, Lkotlin/collections/ArrayDeque;->lastOrNull()Ljava/lang/Object;

    .line 2537
    move-result-object v11

    .line 2538
    check-cast v11, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2540
    if-eqz v11, :cond_9f0

    .line 2542
    iget v11, v11, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2544
    goto :goto_9f1

    .line 2545
    :cond_9f0
    const/4 v11, 0x0

    .line 2546
    :goto_9f1
    iget-object v2, v2, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->intervalContent:Landroidx/compose/foundation/lazy/LazyListIntervalContent;

    .line 2548
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2551
    sget-object v2, Landroidx/collection/IntListKt;->EmptyIntList:Landroidx/collection/MutableIntList;

    .line 2553
    if-eqz v38, :cond_b35

    .line 2555
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    .line 2558
    move-result v12

    .line 2559
    if-nez v12, :cond_b35

    .line 2561
    iget v12, v2, Landroidx/collection/MutableIntList;->_size:I

    .line 2563
    if-eqz v12, :cond_b35

    .line 2565
    sub-int/2addr v11, v10

    .line 2566
    if-ltz v11, :cond_a09

    .line 2568
    if-nez v12, :cond_a0c

    .line 2570
    :cond_a09
    move-object/from16 p0, v1

    .line 2572
    goto :goto_a3f

    .line 2573
    :cond_a0c
    const/4 v11, 0x0

    .line 2574
    invoke-static {v11, v12}, Lrikka/sui/Sui;->until(II)Lkotlin/ranges/IntRange;

    .line 2577
    move-result-object v12

    .line 2578
    iget v11, v12, Lkotlin/ranges/IntProgression;->first:I

    .line 2580
    iget v12, v12, Lkotlin/ranges/IntProgression;->last:I

    .line 2582
    move-object/from16 p0, v1

    .line 2584
    if-gt v11, v12, :cond_a2d

    .line 2586
    move/from16 v14, v32

    .line 2588
    :goto_a1b
    invoke-virtual {v2, v11}, Landroidx/collection/MutableIntList;->get(I)I

    .line 2591
    move-result v1

    .line 2592
    if-gt v1, v10, :cond_a2a

    .line 2594
    invoke-virtual {v2, v11}, Landroidx/collection/MutableIntList;->get(I)I

    .line 2597
    move-result v14

    .line 2598
    if-eq v11, v12, :cond_a2a

    .line 2600
    add-int/lit8 v11, v11, 0x1

    .line 2602
    goto :goto_a1b

    .line 2603
    :cond_a2a
    move/from16 v1, v32

    .line 2605
    goto :goto_a30

    .line 2606
    :cond_a2d
    move/from16 v1, v32

    .line 2608
    move v14, v1

    .line 2609
    :goto_a30
    if-ne v14, v1, :cond_a35

    .line 2611
    sget-object v1, Landroidx/collection/IntListKt;->EmptyIntList:Landroidx/collection/MutableIntList;

    .line 2613
    goto :goto_a40

    .line 2614
    :cond_a35
    new-instance v1, Landroidx/collection/MutableIntList;

    .line 2616
    const/4 v10, 0x1

    .line 2617
    invoke-direct {v1, v10}, Landroidx/collection/MutableIntList;-><init>(I)V

    .line 2620
    invoke-virtual {v1, v14}, Landroidx/collection/MutableIntList;->add(I)V

    .line 2623
    goto :goto_a40

    .line 2624
    :goto_a3f
    move-object v1, v2

    .line 2625
    :goto_a40
    new-instance v10, Ljava/util/ArrayList;

    .line 2627
    invoke-direct {v10}, Ljava/util/ArrayList;-><init>()V

    .line 2630
    new-instance v11, Ljava/util/ArrayList;

    .line 2632
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 2635
    move-result v12

    .line 2636
    invoke-direct {v11, v12}, Ljava/util/ArrayList;-><init>(I)V

    .line 2639
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 2642
    move-result v12

    .line 2643
    const/4 v14, 0x0

    .line 2644
    :goto_a53
    if-ge v14, v12, :cond_a85

    .line 2646
    move/from16 p2, v12

    .line 2648
    invoke-virtual {v7, v14}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 2651
    move-result-object v12

    .line 2652
    move/from16 v18, v14

    .line 2654
    move-object v14, v12

    .line 2655
    check-cast v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2657
    iget v14, v14, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2659
    move-object/from16 v19, v15

    .line 2661
    iget-object v15, v2, Landroidx/collection/MutableIntList;->content:[I

    .line 2663
    move-object/from16 v21, v15

    .line 2665
    iget v15, v2, Landroidx/collection/MutableIntList;->_size:I

    .line 2667
    move-object/from16 v22, v2

    .line 2669
    const/4 v2, 0x0

    .line 2670
    :goto_a6d
    if-ge v2, v15, :cond_a7c

    .line 2672
    move/from16 v23, v2

    .line 2674
    aget v2, v21, v23

    .line 2676
    if-ne v2, v14, :cond_a79

    .line 2678
    invoke-virtual {v11, v12}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2681
    goto :goto_a7c

    .line 2682
    :cond_a79
    add-int/lit8 v2, v23, 0x1

    .line 2684
    goto :goto_a6d

    .line 2685
    :cond_a7c
    :goto_a7c
    add-int/lit8 v14, v18, 0x1

    .line 2687
    move/from16 v12, p2

    .line 2689
    move-object/from16 v15, v19

    .line 2691
    move-object/from16 v2, v22

    .line 2693
    goto :goto_a53

    .line 2694
    :cond_a85
    move-object/from16 v19, v15

    .line 2696
    iget-object v2, v1, Landroidx/collection/MutableIntList;->content:[I

    .line 2698
    iget v1, v1, Landroidx/collection/MutableIntList;->_size:I

    .line 2700
    const/4 v12, 0x0

    .line 2701
    :goto_a8c
    if-ge v12, v1, :cond_b32

    .line 2703
    aget v14, v2, v12

    .line 2705
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 2708
    move-result v15

    .line 2709
    move/from16 v21, v1

    .line 2711
    const/4 v1, 0x0

    .line 2712
    const/16 v18, 0x0

    .line 2714
    :goto_a99
    if-ge v1, v15, :cond_ab4

    .line 2716
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 2719
    move-result-object v22

    .line 2720
    add-int/lit8 v1, v1, 0x1

    .line 2722
    move/from16 p2, v1

    .line 2724
    move-object/from16 v1, v22

    .line 2726
    check-cast v1, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2728
    iget v1, v1, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2730
    if-ne v1, v14, :cond_aaf

    .line 2732
    move/from16 v1, v18

    .line 2734
    :goto_aad
    const/4 v15, -0x1

    .line 2735
    goto :goto_ab6

    .line 2736
    :cond_aaf
    add-int/lit8 v18, v18, 0x1

    .line 2738
    move/from16 v1, p2

    .line 2740
    goto :goto_a99

    .line 2741
    :cond_ab4
    const/4 v1, -0x1

    .line 2742
    goto :goto_aad

    .line 2743
    :goto_ab6
    if-ne v1, v15, :cond_ac1

    .line 2745
    invoke-virtual {v6, v14, v4, v5}, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->getAndMeasure-0kLqBqw(IJ)Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2748
    move-result-object v18

    .line 2749
    :goto_abc
    move-object/from16 v15, v18

    .line 2751
    move-object/from16 v18, v2

    .line 2753
    goto :goto_ac8

    .line 2754
    :cond_ac1
    invoke-virtual {v7, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 2757
    move-result-object v18

    .line 2758
    check-cast v18, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2760
    goto :goto_abc

    .line 2761
    :goto_ac8
    iget v2, v15, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->mainAxisSizeWithSpacings:I

    .line 2763
    move/from16 v22, v2

    .line 2765
    const/4 v2, -0x1

    .line 2766
    if-ne v1, v2, :cond_ad2

    .line 2768
    const/high16 v1, -0x80000000

    .line 2770
    goto :goto_ada

    .line 2771
    :cond_ad2
    const/4 v2, 0x0

    .line 2772
    invoke-virtual {v15, v2}, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->getOffset-Bjo55l4(I)J

    .line 2775
    move-result-wide v23

    .line 2776
    and-long v1, v23, v16

    .line 2778
    long-to-int v1, v1

    .line 2779
    :goto_ada
    invoke-virtual {v11}, Ljava/util/ArrayList;->size()I

    .line 2782
    move-result v2

    .line 2783
    move-wide/from16 v23, v4

    .line 2785
    const/4 v4, 0x0

    .line 2786
    :goto_ae1
    if-ge v4, v2, :cond_af6

    .line 2788
    invoke-virtual {v11, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 2791
    move-result-object v5

    .line 2792
    move/from16 v25, v2

    .line 2794
    move-object v2, v5

    .line 2795
    check-cast v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2797
    iget v2, v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2799
    if-eq v2, v14, :cond_af1

    .line 2801
    goto :goto_af7

    .line 2802
    :cond_af1
    add-int/lit8 v4, v4, 0x1

    .line 2804
    move/from16 v2, v25

    .line 2806
    goto :goto_ae1

    .line 2807
    :cond_af6
    const/4 v5, 0x0

    .line 2808
    :goto_af7
    check-cast v5, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2810
    if-eqz v5, :cond_b06

    .line 2812
    const/4 v2, 0x0

    .line 2813
    invoke-virtual {v5, v2}, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->getOffset-Bjo55l4(I)J

    .line 2816
    move-result-wide v4

    .line 2817
    and-long v4, v4, v16

    .line 2819
    long-to-int v2, v4

    .line 2820
    :goto_b03
    const/high16 v4, -0x80000000

    .line 2822
    goto :goto_b09

    .line 2823
    :cond_b06
    const/high16 v2, -0x80000000

    .line 2825
    goto :goto_b03

    .line 2826
    :goto_b09
    if-ne v1, v4, :cond_b0f

    .line 2828
    move/from16 v1, v47

    .line 2830
    move v5, v1

    .line 2831
    goto :goto_b15

    .line 2832
    :cond_b0f
    move/from16 v5, v47

    .line 2834
    invoke-static {v5, v1}, Ljava/lang/Math;->max(II)I

    .line 2837
    move-result v1

    .line 2838
    :goto_b15
    if-eq v2, v4, :cond_b1d

    .line 2840
    sub-int v2, v2, v22

    .line 2842
    invoke-static {v1, v2}, Ljava/lang/Math;->min(II)I

    .line 2845
    move-result v1

    .line 2846
    :cond_b1d
    const/4 v14, 0x1

    .line 2847
    iput-boolean v14, v15, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->nonScrollableItem:Z

    .line 2849
    invoke-virtual {v15, v1, v9, v13}, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->position(III)V

    .line 2852
    invoke-virtual {v10, v15}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 2855
    add-int/lit8 v12, v12, 0x1

    .line 2857
    move/from16 v47, v5

    .line 2859
    move-object/from16 v2, v18

    .line 2861
    move/from16 v1, v21

    .line 2863
    move-wide/from16 v4, v23

    .line 2865
    goto/16 :goto_a8c

    .line 2867
    :cond_b32
    move/from16 v5, v47

    .line 2869
    goto :goto_b3d

    .line 2870
    :cond_b35
    move-object/from16 p0, v1

    .line 2872
    move-object/from16 v19, v15

    .line 2874
    move/from16 v5, v47

    .line 2876
    move-object/from16 v10, v30

    .line 2878
    :goto_b3d
    if-eqz v53, :cond_b50

    .line 2880
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->firstOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 2883
    move-result-object v1

    .line 2884
    check-cast v1, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2886
    if-eqz v1, :cond_b4e

    .line 2888
    iget v1, v1, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2890
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2893
    move-result-object v1

    .line 2894
    goto :goto_b5e

    .line 2895
    :cond_b4e
    const/4 v1, 0x0

    .line 2896
    goto :goto_b5e

    .line 2897
    :cond_b50
    invoke-virtual/range {p0 .. p0}, Lkotlin/collections/ArrayDeque;->firstOrNull()Ljava/lang/Object;

    .line 2900
    move-result-object v1

    .line 2901
    check-cast v1, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2903
    if-eqz v1, :cond_b4e

    .line 2905
    iget v1, v1, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2907
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2910
    move-result-object v1

    .line 2911
    :goto_b5e
    if-eqz v53, :cond_b7c

    .line 2913
    invoke-static {v7}, Lkotlin/collections/CollectionsKt;->lastOrNull(Ljava/util/List;)Ljava/lang/Object;

    .line 2916
    move-result-object v2

    .line 2917
    check-cast v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2919
    if-eqz v2, :cond_b75

    .line 2921
    iget v2, v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2923
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2926
    move-result-object v2

    .line 2927
    :goto_b6e
    move-object/from16 v31, v2

    .line 2929
    move/from16 v4, v41

    .line 2931
    move/from16 v2, v50

    .line 2933
    goto :goto_b8b

    .line 2934
    :cond_b75
    move/from16 v4, v41

    .line 2936
    move/from16 v2, v50

    .line 2938
    const/16 v31, 0x0

    .line 2940
    goto :goto_b8b

    .line 2941
    :cond_b7c
    invoke-virtual/range {p0 .. p0}, Lkotlin/collections/ArrayDeque;->lastOrNull()Ljava/lang/Object;

    .line 2944
    move-result-object v2

    .line 2945
    check-cast v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 2947
    if-eqz v2, :cond_b75

    .line 2949
    iget v2, v2, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 2951
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 2954
    move-result-object v2

    .line 2955
    goto :goto_b6e

    .line 2956
    :goto_b8b
    if-lt v4, v2, :cond_b93

    .line 2958
    if-le v8, v0, :cond_b90

    .line 2960
    goto :goto_b93

    .line 2961
    :cond_b90
    const/16 v21, 0x0

    .line 2963
    goto :goto_b95

    .line 2964
    :cond_b93
    :goto_b93
    const/16 v21, 0x1

    .line 2966
    :goto_b95
    new-instance v0, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;

    .line 2968
    move-object/from16 v4, v45

    .line 2970
    invoke-direct {v0, v4, v7, v10, v3}, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/runtime/MutableState;Ljava/util/ArrayList;Ljava/util/List;Z)V

    .line 2973
    add-int v9, v9, v29

    .line 2975
    move-wide/from16 v3, v43

    .line 2977
    invoke-static {v9, v3, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainWidth-K40F9xA(IJ)I

    .line 2980
    move-result v8

    .line 2981
    add-int v13, v13, p1

    .line 2983
    invoke-static {v13, v3, v4}, Landroidx/compose/ui/unit/ConstraintsKt;->constrainHeight-K40F9xA(IJ)I

    .line 2986
    move-result v3

    .line 2987
    move-object/from16 v4, v40

    .line 2989
    move-object/from16 v14, v42

    .line 2991
    invoke-interface {v14, v8, v3, v4, v0}, Landroidx/compose/ui/layout/MeasureScope;->layout(IILjava/util/Map;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/layout/MeasureResult;

    .line 2994
    move-result-object v23

    .line 2995
    if-eqz v1, :cond_bb9

    .line 2997
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 3000
    move-result v0

    .line 3001
    goto :goto_bba

    .line 3002
    :cond_bb9
    const/4 v0, 0x0

    .line 3003
    :goto_bba
    if-eqz v31, :cond_bc1

    .line 3005
    invoke-virtual/range {v31 .. v31}, Ljava/lang/Integer;->intValue()I

    .line 3008
    move-result v1

    .line 3009
    goto :goto_bc2

    .line 3010
    :cond_bc1
    const/4 v1, 0x0

    .line 3011
    :goto_bc2
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    .line 3014
    move-result v3

    .line 3015
    if-eqz v3, :cond_bc9

    .line 3017
    goto :goto_bee

    .line 3018
    :cond_bc9
    new-instance v3, Ljava/util/ArrayList;

    .line 3020
    invoke-direct {v3, v10}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    .line 3023
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 3026
    move-result v4

    .line 3027
    const/4 v8, 0x0

    .line 3028
    :goto_bd3
    if-ge v8, v4, :cond_be7

    .line 3030
    invoke-virtual {v7, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 3033
    move-result-object v9

    .line 3034
    check-cast v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;

    .line 3036
    iget v10, v9, Landroidx/compose/foundation/lazy/LazyListMeasuredItem;->index:I

    .line 3038
    if-gt v0, v10, :cond_be4

    .line 3040
    if-gt v10, v1, :cond_be4

    .line 3042
    invoke-virtual {v3, v9}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 3045
    :cond_be4
    add-int/lit8 v8, v8, 0x1

    .line 3047
    goto :goto_bd3

    .line 3048
    :cond_be7
    sget-object v0, Landroidx/compose/foundation/lazy/layout/LazyLayoutKt;->LazyLayoutMeasuredItemIndexComparator:Landroidx/compose/ui/node/LayoutNode$$ExternalSyntheticLambda1;

    .line 3050
    invoke-static {v3, v0}, Lkotlin/collections/CollectionsKt__MutableCollectionsJVMKt;->sortWith(Ljava/util/List;Ljava/util/Comparator;)V

    .line 3053
    move-object/from16 v30, v3

    .line 3055
    :goto_bee
    new-instance v18, Landroidx/compose/foundation/lazy/LazyListMeasureResult;

    .line 3057
    iget-wide v0, v6, Landroidx/compose/foundation/lazy/LazyListKt$rememberLazyListMeasurePolicy$1$1$measuredItemProvider$1;->childConstraints:J

    .line 3059
    move/from16 v33, v2

    .line 3061
    move/from16 v31, v5

    .line 3063
    move-object/from16 v26, v28

    .line 3065
    move/from16 v32, v46

    .line 3067
    move/from16 v25, v49

    .line 3069
    move/from16 v24, v51

    .line 3071
    move/from16 v22, v52

    .line 3073
    move-object/from16 v27, v54

    .line 3075
    move-wide/from16 v28, v0

    .line 3077
    invoke-direct/range {v18 .. v36}, Landroidx/compose/foundation/lazy/LazyListMeasureResult;-><init>(Landroidx/compose/foundation/lazy/LazyListMeasuredItem;IZFLandroidx/compose/ui/layout/MeasureResult;FZLkotlinx/coroutines/CoroutineScope;Landroidx/compose/ui/unit/Density;JLjava/util/List;IIILandroidx/compose/foundation/gestures/Orientation;II)V

    .line 3080
    goto/16 :goto_5c9

    .line 3082
    :goto_c09
    invoke-interface {v14}, Landroidx/compose/ui/layout/IntrinsicMeasureScope;->isLookingAhead()Z

    .line 3085
    move-result v0

    .line 3086
    move-object/from16 v1, v39

    .line 3088
    const/4 v2, 0x0

    .line 3089
    invoke-virtual {v1, v10, v0, v2}, Landroidx/compose/foundation/lazy/LazyListState;->applyMeasureResult$foundation(Landroidx/compose/foundation/lazy/LazyListMeasureResult;ZZ)V

    .line 3092
    goto :goto_c22

    .line 3093
    :goto_c14
    invoke-static {v8, v1, v13}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->restoreNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;Lkotlin/jvm/functions/Function1;)V

    .line 3096
    throw v0

    .line 3097
    :cond_c18
    move-object/from16 p2, v0

    .line 3099
    invoke-static/range {p2 .. p2}, Landroidx/compose/foundation/internal/InlineClassHelperKt;->throwIllegalArgumentExceptionForNullCheck(Ljava/lang/String;)Ljava/lang/Void;

    .line 3102
    invoke-static {}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$2()V

    .line 3105
    goto/16 :goto_4cf

    .line 3107
    :goto_c22
    return-object v10

    .line 3108
    :pswitch_c23  #0x2
    check-cast v14, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory;

    .line 3110
    check-cast v15, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory$CachedItemContent;

    .line 3112
    iget-object v0, v15, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory$CachedItemContent;->key:Ljava/lang/Object;

    .line 3114
    move-object/from16 v2, p1

    .line 3116
    check-cast v2, Landroidx/compose/runtime/GapComposer;

    .line 3118
    check-cast v1, Ljava/lang/Integer;

    .line 3120
    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    .line 3123
    move-result v1

    .line 3124
    and-int/lit8 v4, v1, 0x3

    .line 3126
    if-eq v4, v9, :cond_c3b

    .line 3128
    const/4 v4, 0x1

    .line 3129
    :goto_c38
    const/16 v33, 0x1

    .line 3131
    goto :goto_c3d

    .line 3132
    :cond_c3b
    const/4 v4, 0x0

    .line 3133
    goto :goto_c38

    .line 3134
    :goto_c3d
    and-int/lit8 v1, v1, 0x1

    .line 3136
    invoke-virtual {v2, v1, v4}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 3139
    move-result v1

    .line 3140
    if-eqz v1, :cond_cb2

    .line 3142
    iget-object v1, v14, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory;->itemProvider:Landroidx/compose/material3/TooltipKt$$ExternalSyntheticLambda1;

    .line 3144
    invoke-virtual {v1}, Landroidx/compose/material3/TooltipKt$$ExternalSyntheticLambda1;->invoke()Ljava/lang/Object;

    .line 3147
    move-result-object v1

    .line 3148
    check-cast v1, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;

    .line 3150
    iget v4, v15, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory$CachedItemContent;->index:I

    .line 3152
    invoke-virtual {v1}, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->getItemCount()I

    .line 3155
    move-result v5

    .line 3156
    if-ge v4, v5, :cond_c62

    .line 3158
    invoke-virtual {v1, v4}, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->getKey(I)Ljava/lang/Object;

    .line 3161
    move-result-object v5

    .line 3162
    invoke-virtual {v5, v0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 3165
    move-result v5

    .line 3166
    if-nez v5, :cond_c60

    .line 3168
    goto :goto_c62

    .line 3169
    :cond_c60
    const/4 v5, -0x1

    .line 3170
    goto :goto_c6d

    .line 3171
    :cond_c62
    :goto_c62
    iget-object v4, v1, Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;->keyIndexMap:Landroidx/compose/ui/spatial/RectList;

    .line 3173
    invoke-virtual {v4, v0}, Landroidx/compose/ui/spatial/RectList;->getIndex(Ljava/lang/Object;)I

    .line 3176
    move-result v4

    .line 3177
    const/4 v5, -0x1

    .line 3178
    if-eq v4, v5, :cond_c6d

    .line 3180
    iput v4, v15, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory$CachedItemContent;->index:I

    .line 3182
    :cond_c6d
    :goto_c6d
    if-eq v4, v5, :cond_c8d

    .line 3184
    const v5, -0x6339ef97

    .line 3187
    invoke-virtual {v2, v5}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 3190
    iget-object v5, v14, Landroidx/compose/foundation/lazy/layout/LazyLayoutItemContentFactory;->saveableStateHolder:Landroidx/compose/runtime/saveable/SaveableStateHolder;

    .line 3192
    const/16 v21, 0x0

    .line 3194
    move-object/from16 v19, v0

    .line 3196
    move-object/from16 v16, v1

    .line 3198
    move-object/from16 v20, v2

    .line 3200
    move/from16 v18, v4

    .line 3202
    move-object/from16 v17, v5

    .line 3204
    invoke-static/range {v16 .. v21}, Landroidx/compose/foundation/lazy/layout/LazyLayoutKt;->SkippableItem-JVlU9Rs(Landroidx/compose/foundation/lazy/LazyListItemProviderImpl;Ljava/lang/Object;ILjava/lang/Object;Landroidx/compose/runtime/GapComposer;I)V

    .line 3207
    move-object/from16 v1, v20

    .line 3209
    const/4 v2, 0x0

    .line 3210
    :goto_c89
    invoke-virtual {v1, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 3213
    goto :goto_c96

    .line 3214
    :cond_c8d
    move-object v1, v2

    .line 3215
    const/4 v2, 0x0

    .line 3216
    const v4, -0x63716822

    .line 3219
    invoke-virtual {v1, v4}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 3222
    goto :goto_c89

    .line 3223
    :goto_c96
    invoke-virtual {v1, v15}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 3226
    move-result v2

    .line 3227
    invoke-virtual {v1}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 3230
    move-result-object v4

    .line 3231
    if-nez v2, :cond_ca2

    .line 3233
    if-ne v4, v3, :cond_cac

    .line 3235
    :cond_ca2
    new-instance v4, Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda4;

    .line 3237
    const/16 v2, 0x8

    .line 3239
    invoke-direct {v4, v2, v15}, Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda4;-><init>(ILjava/lang/Object;)V

    .line 3242
    invoke-virtual {v1, v4}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 3245
    :cond_cac
    check-cast v4, Lkotlin/jvm/functions/Function1;

    .line 3247
    invoke-static {v0, v4, v1}, Landroidx/compose/runtime/Updater;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;)V

    .line 3250
    goto :goto_cb6

    .line 3251
    :cond_cb2
    move-object v1, v2

    .line 3252
    invoke-virtual {v1}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 3255
    :goto_cb6
    return-object v13

    .line 3256
    :pswitch_cb7  #0x1
    check-cast v14, Landroidx/compose/foundation/contextmenu/ContextMenuScope;

    .line 3258
    check-cast v15, Landroidx/compose/foundation/contextmenu/ContextMenuColors;

    .line 3260
    move-object/from16 v0, p1

    .line 3262
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 3264
    check-cast v1, Ljava/lang/Integer;

    .line 3266
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3269
    const/16 v33, 0x1

    .line 3271
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 3274
    move-result v1

    .line 3275
    invoke-virtual {v14, v15, v0, v1}, Landroidx/compose/foundation/contextmenu/ContextMenuScope;->Content$foundation(Landroidx/compose/foundation/contextmenu/ContextMenuColors;Landroidx/compose/runtime/GapComposer;I)V

    .line 3278
    return-object v13

    .line 3279
    :pswitch_cce  #0x0
    move/from16 v33, v12

    .line 3281
    check-cast v14, Landroidx/compose/ui/Modifier;

    .line 3283
    check-cast v15, Lkotlin/jvm/functions/Function1;

    .line 3285
    move-object/from16 v0, p1

    .line 3287
    check-cast v0, Landroidx/compose/runtime/GapComposer;

    .line 3289
    check-cast v1, Ljava/lang/Integer;

    .line 3291
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 3294
    invoke-static/range {v33 .. v33}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 3297
    move-result v1

    .line 3298
    invoke-static {v14, v15, v0, v1}, Landroidx/compose/foundation/ImageKt;->Canvas(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;I)V

    .line 3301
    return-object v13

    nop

    :pswitch_data_ce6
    .packed-switch 0x0
        :pswitch_cce  #00000000
        :pswitch_cb7  #00000001
        :pswitch_c23  #00000002
        :pswitch_2e7  #00000003
        :pswitch_2bf  #00000004
        :pswitch_270  #00000005
        :pswitch_25b  #00000006
        :pswitch_246  #00000007
        :pswitch_231  #00000008
        :pswitch_12d  #00000009
        :pswitch_118  #0000000a
        :pswitch_df  #0000000b
        :pswitch_ca  #0000000c
        :pswitch_b5  #0000000d
        :pswitch_a0  #0000000e
        :pswitch_78  #0000000f
        :pswitch_63  #00000010
        :pswitch_5e  #00000011
        :pswitch_49  #00000012
        :pswitch_34  #00000013
        :pswitch_2f  #00000014
    .end packed-switch
.end method
