.class public final synthetic Landroidx/compose/foundation/FocusableNode$focusTargetNode$1;
.super Lkotlin/jvm/internal/FunctionReferenceImpl;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $r8$classId:I


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;III)V
    .registers 9

    .line 1
    iput p8, p0, Landroidx/compose/foundation/FocusableNode$focusTargetNode$1;->$r8$classId:I

    .line 3
    invoke-direct/range {p0 .. p7}, Lkotlin/jvm/internal/FunctionReferenceImpl;-><init>(ILjava/lang/Object;Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;II)V

    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Landroidx/compose/foundation/FocusableNode$focusTargetNode$1;->$r8$classId:I

    .line 3
    const/16 v1, 0x12

    .line 5
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    iget-object p0, p0, Lkotlin/jvm/internal/CallableReference;->receiver:Ljava/lang/Object;

    .line 9
    packed-switch v0, :pswitch_data_132

    .line 12
    check-cast p1, Ljava/lang/Number;

    .line 14
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 17
    move-result p1

    .line 18
    check-cast p2, Ljava/lang/String;

    .line 20
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 23
    check-cast p0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 25
    invoke-static {p0, p1, p2}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->access$onInstallationProgressUpdate(Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;FLjava/lang/String;)V

    .line 28
    return-object v2

    .line 29
    :pswitch_1c  #0x5
    check-cast p1, Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;

    .line 31
    check-cast p2, Ljava/lang/String;

    .line 33
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 36
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 39
    check-cast p0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 41
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    new-instance v0, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;

    .line 46
    invoke-direct {v0, p1, p0, p2, v1}, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 49
    invoke-virtual {p0, v0}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->updateInstallationCard(Lkotlin/jvm/functions/Function1;)V

    .line 52
    return-object v2

    .line 53
    :pswitch_34  #0x4
    check-cast p1, Ljava/lang/Number;

    .line 55
    invoke-virtual {p1}, Ljava/lang/Number;->floatValue()F

    .line 58
    move-result p1

    .line 59
    check-cast p2, Ljava/lang/String;

    .line 61
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 64
    check-cast p0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 66
    invoke-static {p0, p1, p2}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->access$onInstallationProgressUpdate(Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;FLjava/lang/String;)V

    .line 69
    return-object v2

    .line 70
    :pswitch_45  #0x3
    check-cast p1, Lyangfentuozi/dsusideloaderplus/preparation/InstallationStep;

    .line 72
    check-cast p2, Ljava/lang/String;

    .line 74
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 77
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    check-cast p0, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;

    .line 82
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 85
    new-instance v0, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;

    .line 87
    invoke-direct {v0, p1, p0, p2, v1}, Landroidx/datastore/core/SimpleActor$$ExternalSyntheticLambda0;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 90
    invoke-virtual {p0, v0}, Lyangfentuozi/dsusideloaderplus/ui/screen/home/HomeViewModel;->updateInstallationCard(Lkotlin/jvm/functions/Function1;)V

    .line 93
    return-object v2

    .line 94
    :pswitch_5d  #0x2
    check-cast p1, Ljava/lang/Number;

    .line 96
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 99
    move-result p1

    .line 100
    check-cast p2, Ljava/lang/Number;

    .line 102
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 105
    move-result p2

    .line 106
    check-cast p0, Lyangfentuozi/dsusideloaderplus/MainActivity;

    .line 108
    invoke-virtual {p0, p1, p2}, Lyangfentuozi/dsusideloaderplus/MainActivity;->onRequestPermissionResult(II)V

    .line 111
    return-object v2

    .line 112
    :pswitch_6f  #0x1
    check-cast p1, Lkotlinx/serialization/descriptors/SerialDescriptor;

    .line 114
    check-cast p2, Ljava/lang/Number;

    .line 116
    invoke-virtual {p2}, Ljava/lang/Number;->intValue()I

    .line 119
    move-result p2

    .line 120
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 123
    check-cast p0, Lkotlinx/serialization/json/internal/JsonElementMarker;

    .line 125
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 128
    invoke-interface {p1, p2}, Lkotlinx/serialization/descriptors/SerialDescriptor;->isElementOptional(I)Z

    .line 131
    move-result v0

    .line 132
    if-nez v0, :cond_91

    .line 134
    invoke-interface {p1, p2}, Lkotlinx/serialization/descriptors/SerialDescriptor;->getElementDescriptor(I)Lkotlinx/serialization/descriptors/SerialDescriptor;

    .line 137
    move-result-object p1

    .line 138
    invoke-interface {p1}, Lkotlinx/serialization/descriptors/SerialDescriptor;->isNullable()Z

    .line 141
    move-result p1

    .line 142
    if-eqz p1, :cond_91

    .line 144
    const/4 p1, 0x1

    .line 145
    goto :goto_92

    .line 146
    :cond_91
    const/4 p1, 0x0

    .line 147
    :goto_92
    iput-boolean p1, p0, Lkotlinx/serialization/json/internal/JsonElementMarker;->isUnmarkedNull:Z

    .line 149
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 152
    move-result-object p0

    .line 153
    return-object p0

    .line 154
    :pswitch_99  #0x0
    check-cast p1, Landroidx/compose/ui/focus/FocusStateImpl;

    .line 156
    check-cast p2, Landroidx/compose/ui/focus/FocusStateImpl;

    .line 158
    check-cast p0, Landroidx/compose/foundation/FocusableNode;

    .line 160
    iget-boolean v0, p0, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 162
    if-nez v0, :cond_a5

    .line 164
    goto/16 :goto_131

    .line 166
    :cond_a5
    invoke-virtual {p2}, Landroidx/compose/ui/focus/FocusStateImpl;->isFocused()Z

    .line 169
    move-result p2

    .line 170
    invoke-virtual {p1}, Landroidx/compose/ui/focus/FocusStateImpl;->isFocused()Z

    .line 173
    move-result p1

    .line 174
    if-ne p2, p1, :cond_b1

    .line 176
    goto/16 :goto_131

    .line 178
    :cond_b1
    iget-object p1, p0, Landroidx/compose/foundation/FocusableNode;->onFocusChange:Lkotlin/jvm/functions/Function1;

    .line 180
    if-eqz p1, :cond_bc

    .line 182
    invoke-static {p2}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 185
    move-result-object v0

    .line 186
    invoke-interface {p1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 189
    :cond_bc
    const/4 p1, 0x0

    .line 190
    if-eqz p2, :cond_f7

    .line 192
    invoke-virtual {p0}, Landroidx/compose/ui/Modifier$Node;->getCoroutineScope()Lkotlinx/coroutines/CoroutineScope;

    .line 195
    move-result-object v0

    .line 196
    new-instance v1, Landroidx/compose/material3/ThumbNode$onAttach$1;

    .line 198
    const/4 v3, 0x3

    .line 199
    invoke-direct {v1, p0, p1, v3}, Landroidx/compose/material3/ThumbNode$onAttach$1;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 202
    invoke-static {v0, p1, v1, v3}, Lkotlinx/coroutines/JobKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;I)Lkotlinx/coroutines/StandaloneCoroutine;

    .line 205
    new-instance v0, Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 207
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 210
    new-instance v1, Landroidx/compose/runtime/Recomposer$$ExternalSyntheticLambda6;

    .line 212
    const/4 v3, 0x4

    .line 213
    invoke-direct {v1, v3, v0, p0}, Landroidx/compose/runtime/Recomposer$$ExternalSyntheticLambda6;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 216
    invoke-static {p0, v1}, Landroidx/compose/ui/node/HitTestResultKt;->observeReads(Landroidx/compose/ui/Modifier$Node;Lkotlin/jvm/functions/Function0;)V

    .line 219
    iget-object v0, v0, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 221
    check-cast v0, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;

    .line 223
    if-eqz v0, :cond_e4

    .line 225
    invoke-virtual {v0}, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;->pin()Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;

    .line 228
    goto :goto_e5

    .line 229
    :cond_e4
    move-object v0, p1

    .line 230
    :goto_e5
    iput-object v0, p0, Landroidx/compose/foundation/FocusableNode;->pinnedHandle:Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;

    .line 232
    iget-object v0, p0, Landroidx/compose/foundation/FocusableNode;->globalLayoutCoordinates:Landroidx/compose/ui/node/NodeCoordinator;

    .line 234
    if-eqz v0, :cond_103

    .line 236
    invoke-virtual {v0}, Landroidx/compose/ui/node/NodeCoordinator;->getTail()Landroidx/compose/ui/Modifier$Node;

    .line 239
    move-result-object v0

    .line 240
    iget-boolean v0, v0, Landroidx/compose/ui/Modifier$Node;->isAttached:Z

    .line 242
    if-eqz v0, :cond_103

    .line 244
    invoke-virtual {p0}, Landroidx/compose/foundation/FocusableNode;->getFocusedBoundsObserver()V

    .line 247
    goto :goto_103

    .line 248
    :cond_f7
    iget-object v0, p0, Landroidx/compose/foundation/FocusableNode;->pinnedHandle:Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;

    .line 250
    if-eqz v0, :cond_fe

    .line 252
    invoke-virtual {v0}, Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;->release()V

    .line 255
    :cond_fe
    iput-object p1, p0, Landroidx/compose/foundation/FocusableNode;->pinnedHandle:Landroidx/compose/foundation/lazy/layout/LazyLayoutPinnableItem;

    .line 257
    invoke-virtual {p0}, Landroidx/compose/foundation/FocusableNode;->getFocusedBoundsObserver()V

    .line 260
    :cond_103
    :goto_103
    invoke-static {p0}, Landroidx/compose/ui/node/HitTestResultKt;->invalidateSemantics(Landroidx/compose/ui/node/SemanticsModifierNode;)V

    .line 263
    iget-object v0, p0, Landroidx/compose/foundation/FocusableNode;->interactionSource:Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;

    .line 265
    if-eqz v0, :cond_131

    .line 267
    iget-object v1, p0, Landroidx/compose/foundation/FocusableNode;->focusedInteraction:Landroidx/compose/foundation/interaction/FocusInteraction$Focus;

    .line 269
    if-eqz p2, :cond_125

    .line 271
    if-eqz v1, :cond_11a

    .line 273
    new-instance p2, Landroidx/compose/foundation/interaction/FocusInteraction$Unfocus;

    .line 275
    invoke-direct {p2, v1}, Landroidx/compose/foundation/interaction/FocusInteraction$Unfocus;-><init>(Landroidx/compose/foundation/interaction/FocusInteraction$Focus;)V

    .line 278
    invoke-virtual {p0, v0, p2}, Landroidx/compose/foundation/FocusableNode;->emitWithFallback(Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;Landroidx/compose/foundation/interaction/Interaction;)V

    .line 281
    iput-object p1, p0, Landroidx/compose/foundation/FocusableNode;->focusedInteraction:Landroidx/compose/foundation/interaction/FocusInteraction$Focus;

    .line 283
    :cond_11a
    new-instance p1, Landroidx/compose/foundation/interaction/FocusInteraction$Focus;

    .line 285
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 288
    invoke-virtual {p0, v0, p1}, Landroidx/compose/foundation/FocusableNode;->emitWithFallback(Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;Landroidx/compose/foundation/interaction/Interaction;)V

    .line 291
    iput-object p1, p0, Landroidx/compose/foundation/FocusableNode;->focusedInteraction:Landroidx/compose/foundation/interaction/FocusInteraction$Focus;

    .line 293
    goto :goto_131

    .line 294
    :cond_125
    if-eqz v1, :cond_131

    .line 296
    new-instance p2, Landroidx/compose/foundation/interaction/FocusInteraction$Unfocus;

    .line 298
    invoke-direct {p2, v1}, Landroidx/compose/foundation/interaction/FocusInteraction$Unfocus;-><init>(Landroidx/compose/foundation/interaction/FocusInteraction$Focus;)V

    .line 301
    invoke-virtual {p0, v0, p2}, Landroidx/compose/foundation/FocusableNode;->emitWithFallback(Landroidx/compose/foundation/interaction/MutableInteractionSourceImpl;Landroidx/compose/foundation/interaction/Interaction;)V

    .line 304
    iput-object p1, p0, Landroidx/compose/foundation/FocusableNode;->focusedInteraction:Landroidx/compose/foundation/interaction/FocusInteraction$Focus;

    .line 306
    :cond_131
    :goto_131
    return-object v2

    .line 307
    :pswitch_data_132
    .packed-switch 0x0
        :pswitch_99  #00000000
        :pswitch_6f  #00000001
        :pswitch_5d  #00000002
        :pswitch_45  #00000003
        :pswitch_34  #00000004
        :pswitch_1c  #00000005
    .end packed-switch
.end method
