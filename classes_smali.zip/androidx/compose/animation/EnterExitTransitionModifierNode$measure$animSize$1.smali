.class public final Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;
.super Lkotlin/jvm/internal/Lambda;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic $target:J

.field public final synthetic this$0:Landroidx/compose/animation/EnterExitTransitionModifierNode;


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/EnterExitTransitionModifierNode;JI)V
    .registers 5

    .line 1
    iput p4, p0, Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;->$r8$classId:I

    .line 3
    iput-object p1, p0, Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;->this$0:Landroidx/compose/animation/EnterExitTransitionModifierNode;

    .line 5
    iput-wide p2, p0, Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;->$target:J

    .line 7
    const/4 p1, 0x1

    .line 8
    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    .line 11
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 13

    .line 1
    iget v0, p0, Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;->$r8$classId:I

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    const/4 v3, 0x1

    .line 6
    iget-object v4, p0, Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;->this$0:Landroidx/compose/animation/EnterExitTransitionModifierNode;

    .line 8
    packed-switch v0, :pswitch_data_ba

    .line 11
    check-cast p1, Landroidx/compose/animation/EnterExitState;

    .line 13
    iget-object v0, v4, Landroidx/compose/animation/EnterExitTransitionModifierNode;->currentAlignment:Landroidx/compose/ui/Alignment;

    .line 15
    if-nez v0, :cond_11

    .line 17
    goto :goto_6a

    .line 18
    :cond_11
    invoke-virtual {v4}, Landroidx/compose/animation/EnterExitTransitionModifierNode;->getAlignment()Landroidx/compose/ui/Alignment;

    .line 21
    move-result-object v0

    .line 22
    if-nez v0, :cond_18

    .line 24
    goto :goto_6a

    .line 25
    :cond_18
    iget-object v0, v4, Landroidx/compose/animation/EnterExitTransitionModifierNode;->currentAlignment:Landroidx/compose/ui/Alignment;

    .line 27
    invoke-virtual {v4}, Landroidx/compose/animation/EnterExitTransitionModifierNode;->getAlignment()Landroidx/compose/ui/Alignment;

    .line 30
    move-result-object v5

    .line 31
    invoke-static {v0, v5}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 34
    move-result v0

    .line 35
    if-eqz v0, :cond_25

    .line 37
    goto :goto_6a

    .line 38
    :cond_25
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 41
    move-result p1

    .line 42
    if-eqz p1, :cond_6a

    .line 44
    if-eq p1, v3, :cond_6a

    .line 46
    if-ne p1, v2, :cond_66

    .line 48
    iget-object p1, v4, Landroidx/compose/animation/EnterExitTransitionModifierNode;->exit:Landroidx/compose/animation/ExitTransitionImpl;

    .line 50
    iget-object p1, p1, Landroidx/compose/animation/ExitTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 52
    iget-object p1, p1, Landroidx/compose/animation/TransitionData;->changeSize:Landroidx/compose/animation/ChangeSize;

    .line 54
    if-eqz p1, :cond_6a

    .line 56
    iget-object p1, p1, Landroidx/compose/animation/ChangeSize;->size:Lkotlin/jvm/functions/Function1;

    .line 58
    new-instance v0, Landroidx/compose/ui/unit/IntSize;

    .line 60
    iget-wide v6, p0, Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;->$target:J

    .line 62
    invoke-direct {v0, v6, v7}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 65
    invoke-interface {p1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 68
    move-result-object p0

    .line 69
    check-cast p0, Landroidx/compose/ui/unit/IntSize;

    .line 71
    iget-wide v8, p0, Landroidx/compose/ui/unit/IntSize;->packedValue:J

    .line 73
    invoke-virtual {v4}, Landroidx/compose/animation/EnterExitTransitionModifierNode;->getAlignment()Landroidx/compose/ui/Alignment;

    .line 76
    move-result-object p0

    .line 77
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 80
    move-object v5, p0

    .line 81
    check-cast v5, Landroidx/compose/ui/BiasAlignment;

    .line 83
    sget-object v10, Landroidx/compose/ui/unit/LayoutDirection;->Ltr:Landroidx/compose/ui/unit/LayoutDirection;

    .line 85
    invoke-virtual/range {v5 .. v10}, Landroidx/compose/ui/BiasAlignment;->align-KFBX0sM(JJLandroidx/compose/ui/unit/LayoutDirection;)J

    .line 88
    move-result-wide p0

    .line 89
    iget-object v5, v4, Landroidx/compose/animation/EnterExitTransitionModifierNode;->currentAlignment:Landroidx/compose/ui/Alignment;

    .line 91
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 94
    invoke-interface/range {v5 .. v10}, Landroidx/compose/ui/Alignment;->align-KFBX0sM(JJLandroidx/compose/ui/unit/LayoutDirection;)J

    .line 97
    move-result-wide v0

    .line 98
    invoke-static {p0, p1, v0, v1}, Landroidx/compose/ui/unit/IntOffset;->minus-qkQi6aY(JJ)J

    .line 101
    move-result-wide p0

    .line 102
    goto :goto_6c

    .line 103
    :cond_66
    invoke-static {}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m()V

    .line 106
    goto :goto_71

    .line 107
    :cond_6a
    :goto_6a
    const-wide/16 p0, 0x0

    .line 109
    :goto_6c
    new-instance v1, Landroidx/compose/ui/unit/IntOffset;

    .line 111
    invoke-direct {v1, p0, p1}, Landroidx/compose/ui/unit/IntOffset;-><init>(J)V

    .line 114
    :goto_71
    return-object v1

    .line 115
    :pswitch_72  #0x0
    check-cast p1, Landroidx/compose/animation/EnterExitState;

    .line 117
    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    .line 120
    move-result p1

    .line 121
    iget-wide v5, p0, Landroidx/compose/animation/EnterExitTransitionModifierNode$measure$animSize$1;->$target:J

    .line 123
    if-eqz p1, :cond_9c

    .line 125
    if-eq p1, v3, :cond_b3

    .line 127
    if-ne p1, v2, :cond_98

    .line 129
    iget-object p0, v4, Landroidx/compose/animation/EnterExitTransitionModifierNode;->exit:Landroidx/compose/animation/ExitTransitionImpl;

    .line 131
    iget-object p0, p0, Landroidx/compose/animation/ExitTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 133
    iget-object p0, p0, Landroidx/compose/animation/TransitionData;->changeSize:Landroidx/compose/animation/ChangeSize;

    .line 135
    if-eqz p0, :cond_b3

    .line 137
    iget-object p0, p0, Landroidx/compose/animation/ChangeSize;->size:Lkotlin/jvm/functions/Function1;

    .line 139
    new-instance p1, Landroidx/compose/ui/unit/IntSize;

    .line 141
    invoke-direct {p1, v5, v6}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 144
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 147
    move-result-object p0

    .line 148
    check-cast p0, Landroidx/compose/ui/unit/IntSize;

    .line 150
    iget-wide v5, p0, Landroidx/compose/ui/unit/IntSize;->packedValue:J

    .line 152
    goto :goto_b3

    .line 153
    :cond_98
    invoke-static {}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m()V

    .line 156
    goto :goto_b8

    .line 157
    :cond_9c
    iget-object p0, v4, Landroidx/compose/animation/EnterExitTransitionModifierNode;->enter:Landroidx/compose/animation/EnterTransitionImpl;

    .line 159
    iget-object p0, p0, Landroidx/compose/animation/EnterTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 161
    iget-object p0, p0, Landroidx/compose/animation/TransitionData;->changeSize:Landroidx/compose/animation/ChangeSize;

    .line 163
    if-eqz p0, :cond_b3

    .line 165
    iget-object p0, p0, Landroidx/compose/animation/ChangeSize;->size:Lkotlin/jvm/functions/Function1;

    .line 167
    new-instance p1, Landroidx/compose/ui/unit/IntSize;

    .line 169
    invoke-direct {p1, v5, v6}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 172
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 175
    move-result-object p0

    .line 176
    check-cast p0, Landroidx/compose/ui/unit/IntSize;

    .line 178
    iget-wide v5, p0, Landroidx/compose/ui/unit/IntSize;->packedValue:J

    .line 180
    :cond_b3
    :goto_b3
    new-instance v1, Landroidx/compose/ui/unit/IntSize;

    .line 182
    invoke-direct {v1, v5, v6}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 185
    :goto_b8
    return-object v1

    nop

    .line 187
    :pswitch_data_ba
    .packed-switch 0x0
        :pswitch_72  #00000000
    .end packed-switch
.end method
