.class public abstract Landroidx/compose/animation/Scale;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# direct methods
.method public static final AnimatedContent(Landroidx/compose/animation/core/Transition;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Alignment;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V
    .registers 28

    .line 1
    move-object/from16 v1, p0

    .line 3
    move-object/from16 v7, p1

    .line 5
    move-object/from16 v3, p2

    .line 7
    move-object/from16 v8, p3

    .line 9
    move-object/from16 v9, p4

    .line 11
    move-object/from16 v10, p6

    .line 13
    move/from16 v11, p7

    .line 15
    const v0, 0x1e804e2f

    .line 18
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 21
    and-int/lit8 v0, v11, 0x6

    .line 23
    const/4 v2, 0x4

    .line 24
    if-nez v0, :cond_24

    .line 26
    invoke-virtual {v10, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 29
    move-result v0

    .line 30
    if-eqz v0, :cond_21

    .line 32
    move v0, v2

    .line 33
    goto :goto_22

    .line 34
    :cond_21
    const/4 v0, 0x2

    .line 35
    :goto_22
    or-int/2addr v0, v11

    .line 36
    goto :goto_25

    .line 37
    :cond_24
    move v0, v11

    .line 38
    :goto_25
    and-int/lit8 v4, v11, 0x30

    .line 40
    if-nez v4, :cond_35

    .line 42
    invoke-virtual {v10, v7}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 45
    move-result v4

    .line 46
    if-eqz v4, :cond_32

    .line 48
    const/16 v4, 0x20

    .line 50
    goto :goto_34

    .line 51
    :cond_32
    const/16 v4, 0x10

    .line 53
    :goto_34
    or-int/2addr v0, v4

    .line 54
    :cond_35
    and-int/lit16 v4, v11, 0x180

    .line 56
    if-nez v4, :cond_45

    .line 58
    invoke-virtual {v10, v3}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 61
    move-result v4

    .line 62
    if-eqz v4, :cond_42

    .line 64
    const/16 v4, 0x100

    .line 66
    goto :goto_44

    .line 67
    :cond_42
    const/16 v4, 0x80

    .line 69
    :goto_44
    or-int/2addr v0, v4

    .line 70
    :cond_45
    and-int/lit16 v4, v11, 0xc00

    .line 72
    if-nez v4, :cond_55

    .line 74
    invoke-virtual {v10, v8}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 77
    move-result v4

    .line 78
    if-eqz v4, :cond_52

    .line 80
    const/16 v4, 0x800

    .line 82
    goto :goto_54

    .line 83
    :cond_52
    const/16 v4, 0x400

    .line 85
    :goto_54
    or-int/2addr v0, v4

    .line 86
    :cond_55
    and-int/lit16 v4, v11, 0x6000

    .line 88
    if-nez v4, :cond_65

    .line 90
    invoke-virtual {v10, v9}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 93
    move-result v4

    .line 94
    if-eqz v4, :cond_62

    .line 96
    const/16 v4, 0x4000

    .line 98
    goto :goto_64

    .line 99
    :cond_62
    const/16 v4, 0x2000

    .line 101
    :goto_64
    or-int/2addr v0, v4

    .line 102
    :cond_65
    const/high16 v4, 0x30000

    .line 104
    and-int/2addr v4, v11

    .line 105
    move-object/from16 v6, p5

    .line 107
    if-nez v4, :cond_78

    .line 109
    invoke-virtual {v10, v6}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 112
    move-result v4

    .line 113
    if-eqz v4, :cond_75

    .line 115
    const/high16 v4, 0x20000

    .line 117
    goto :goto_77

    .line 118
    :cond_75
    const/high16 v4, 0x10000

    .line 120
    :goto_77
    or-int/2addr v0, v4

    .line 121
    :cond_78
    const v4, 0x12493

    .line 124
    and-int/2addr v4, v0

    .line 125
    const v5, 0x12492

    .line 128
    if-eq v4, v5, :cond_83

    .line 130
    const/4 v4, 0x1

    .line 131
    goto :goto_84

    .line 132
    :cond_83
    const/4 v4, 0x0

    .line 133
    :goto_84
    and-int/lit8 v5, v0, 0x1

    .line 135
    invoke-virtual {v10, v5, v4}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 138
    move-result v4

    .line 139
    if-eqz v4, :cond_36c

    .line 141
    sget-object v4, Landroidx/compose/ui/platform/CompositionLocalsKt;->LocalLayoutDirection:Landroidx/compose/runtime/StaticProvidableCompositionLocal;

    .line 143
    invoke-virtual {v10, v4}, Landroidx/compose/runtime/GapComposer;->consume(Landroidx/compose/runtime/ProvidableCompositionLocal;)Ljava/lang/Object;

    .line 146
    move-result-object v4

    .line 147
    check-cast v4, Landroidx/compose/ui/unit/LayoutDirection;

    .line 149
    and-int/lit8 v0, v0, 0xe

    .line 151
    if-ne v0, v2, :cond_9a

    .line 153
    const/4 v4, 0x1

    .line 154
    goto :goto_9b

    .line 155
    :cond_9a
    const/4 v4, 0x0

    .line 156
    :goto_9b
    invoke-virtual {v10}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 159
    move-result-object v5

    .line 160
    sget-object v14, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 162
    if-nez v4, :cond_a5

    .line 164
    if-ne v5, v14, :cond_ad

    .line 166
    :cond_a5
    new-instance v5, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;

    .line 168
    invoke-direct {v5, v1, v8}, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;-><init>(Landroidx/compose/animation/core/Transition;Landroidx/compose/ui/Alignment;)V

    .line 171
    invoke-virtual {v10, v5}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 174
    :cond_ad
    move-object v4, v5

    .line 175
    check-cast v4, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;

    .line 177
    if-ne v0, v2, :cond_b4

    .line 179
    const/4 v5, 0x1

    .line 180
    goto :goto_b5

    .line 181
    :cond_b4
    const/4 v5, 0x0

    .line 182
    :goto_b5
    invoke-virtual {v10}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 185
    move-result-object v15

    .line 186
    if-nez v5, :cond_bd

    .line 188
    if-ne v15, v14, :cond_d6

    .line 190
    :cond_bd
    iget-object v5, v1, Landroidx/compose/animation/core/Transition;->transitionState:Landroidx/compose/animation/core/TransitionState;

    .line 192
    invoke-virtual {v5}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 195
    move-result-object v5

    .line 196
    filled-new-array {v5}, [Ljava/lang/Object;

    .line 199
    move-result-object v5

    .line 200
    new-instance v15, Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 202
    invoke-direct {v15}, Landroidx/compose/runtime/snapshots/SnapshotStateList;-><init>()V

    .line 205
    invoke-static {v5}, Lkotlin/collections/ArraysKt;->toList([Ljava/lang/Object;)Ljava/util/List;

    .line 208
    move-result-object v5

    .line 209
    invoke-virtual {v15, v5}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->addAll(Ljava/util/Collection;)Z

    .line 212
    invoke-virtual {v10, v15}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 215
    :cond_d6
    move-object v5, v15

    .line 216
    check-cast v5, Landroidx/compose/runtime/snapshots/SnapshotStateList;

    .line 218
    if-ne v0, v2, :cond_dd

    .line 220
    const/4 v0, 0x1

    .line 221
    goto :goto_de

    .line 222
    :cond_dd
    const/4 v0, 0x0

    .line 223
    :goto_de
    invoke-virtual {v10}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 226
    move-result-object v2

    .line 227
    if-nez v0, :cond_e6

    .line 229
    if-ne v2, v14, :cond_f0

    .line 231
    :cond_e6
    sget-object v0, Landroidx/collection/ScatterMapKt;->EmptyGroup:[J

    .line 233
    new-instance v2, Landroidx/collection/MutableScatterMap;

    .line 235
    invoke-direct {v2}, Landroidx/collection/MutableScatterMap;-><init>()V

    .line 238
    invoke-virtual {v10, v2}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 241
    :cond_f0
    move-object v15, v2

    .line 242
    check-cast v15, Landroidx/collection/MutableScatterMap;

    .line 244
    iget-object v0, v1, Landroidx/compose/animation/core/Transition;->transitionState:Landroidx/compose/animation/core/TransitionState;

    .line 246
    iget-object v2, v1, Landroidx/compose/animation/core/Transition;->targetState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 248
    invoke-virtual {v0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 251
    move-result-object v13

    .line 252
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->contains(Ljava/lang/Object;)Z

    .line 255
    move-result v13

    .line 256
    if-nez v13, :cond_10b

    .line 258
    invoke-virtual {v5}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 261
    invoke-virtual {v0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 264
    move-result-object v13

    .line 265
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->add(Ljava/lang/Object;)Z

    .line 268
    :cond_10b
    invoke-virtual {v0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 271
    move-result-object v13

    .line 272
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 275
    move-result-object v12

    .line 276
    invoke-static {v13, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 279
    move-result v12

    .line 280
    if-eqz v12, :cond_14d

    .line 282
    invoke-virtual {v5}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    .line 285
    move-result v12

    .line 286
    const/4 v13, 0x1

    .line 287
    if-ne v12, v13, :cond_12f

    .line 289
    const/4 v12, 0x0

    .line 290
    invoke-virtual {v5, v12}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->get(I)Ljava/lang/Object;

    .line 293
    move-result-object v13

    .line 294
    invoke-virtual {v0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 297
    move-result-object v12

    .line 298
    invoke-static {v13, v12}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 301
    move-result v12

    .line 302
    if-nez v12, :cond_139

    .line 304
    :cond_12f
    invoke-virtual {v5}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->clear()V

    .line 307
    invoke-virtual {v0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 310
    move-result-object v12

    .line 311
    invoke-virtual {v5, v12}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->add(Ljava/lang/Object;)Z

    .line 314
    :cond_139
    iget v12, v15, Landroidx/collection/MutableScatterMap;->_size:I

    .line 316
    const/4 v13, 0x1

    .line 317
    if-ne v12, v13, :cond_148

    .line 319
    invoke-virtual {v0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 322
    move-result-object v12

    .line 323
    invoke-virtual {v15, v12}, Landroidx/collection/MutableScatterMap;->containsKey(Ljava/lang/Object;)Z

    .line 326
    move-result v12

    .line 327
    if-eqz v12, :cond_14b

    .line 329
    :cond_148
    invoke-virtual {v15}, Landroidx/collection/MutableScatterMap;->clear()V

    .line 332
    :cond_14b
    iput-object v8, v4, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;->contentAlignment:Landroidx/compose/ui/Alignment;

    .line 334
    :cond_14d
    invoke-virtual {v0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 337
    move-result-object v12

    .line 338
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 341
    move-result-object v13

    .line 342
    invoke-static {v12, v13}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 345
    move-result v12

    .line 346
    if-nez v12, :cond_1a9

    .line 348
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 351
    move-result-object v12

    .line 352
    invoke-virtual {v5, v12}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->contains(Ljava/lang/Object;)Z

    .line 355
    move-result v12

    .line 356
    if-nez v12, :cond_1a9

    .line 358
    invoke-virtual {v5}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->listIterator()Ljava/util/ListIterator;

    .line 361
    move-result-object v12

    .line 362
    const/4 v13, 0x0

    .line 363
    :goto_16a
    move-object/from16 v16, v12

    .line 365
    check-cast v16, Lkotlin/collections/builders/ListBuilder$Itr;

    .line 367
    invoke-virtual/range {v16 .. v16}, Lkotlin/collections/builders/ListBuilder$Itr;->hasNext()Z

    .line 370
    move-result v17

    .line 371
    move-object/from16 v18, v0

    .line 373
    if-eqz v17, :cond_195

    .line 375
    invoke-virtual/range {v16 .. v16}, Lkotlin/collections/builders/ListBuilder$Itr;->next()Ljava/lang/Object;

    .line 378
    move-result-object v0

    .line 379
    invoke-interface {v9, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 382
    move-result-object v0

    .line 383
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 386
    move-result-object v1

    .line 387
    invoke-interface {v9, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 390
    move-result-object v1

    .line 391
    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 394
    move-result v0

    .line 395
    if-eqz v0, :cond_18e

    .line 397
    :goto_18c
    const/4 v0, -0x1

    .line 398
    goto :goto_197

    .line 399
    :cond_18e
    add-int/lit8 v13, v13, 0x1

    .line 401
    move-object/from16 v1, p0

    .line 403
    move-object/from16 v0, v18

    .line 405
    goto :goto_16a

    .line 406
    :cond_195
    const/4 v13, -0x1

    .line 407
    goto :goto_18c

    .line 408
    :goto_197
    if-ne v13, v0, :cond_1a1

    .line 410
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 413
    move-result-object v0

    .line 414
    invoke-virtual {v5, v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->add(Ljava/lang/Object;)Z

    .line 417
    goto :goto_1ab

    .line 418
    :cond_1a1
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 421
    move-result-object v0

    .line 422
    invoke-virtual {v5, v13, v0}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    .line 425
    goto :goto_1ab

    .line 426
    :cond_1a9
    move-object/from16 v18, v0

    .line 428
    :goto_1ab
    invoke-virtual {v2}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 431
    move-result-object v0

    .line 432
    invoke-virtual {v15, v0}, Landroidx/collection/MutableScatterMap;->containsKey(Ljava/lang/Object;)Z

    .line 435
    move-result v0

    .line 436
    if-eqz v0, :cond_1cd

    .line 438
    invoke-virtual/range {v18 .. v18}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 441
    move-result-object v0

    .line 442
    invoke-virtual {v15, v0}, Landroidx/collection/MutableScatterMap;->containsKey(Ljava/lang/Object;)Z

    .line 445
    move-result v0

    .line 446
    if-nez v0, :cond_1c0

    .line 448
    goto :goto_1cd

    .line 449
    :cond_1c0
    const v0, 0x72cb6333

    .line 452
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 455
    const/4 v12, 0x0

    .line 456
    invoke-virtual {v10, v12}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 459
    move-object v6, v3

    .line 460
    move-object v0, v4

    .line 461
    goto :goto_201

    .line 462
    :cond_1cd
    :goto_1cd
    const v0, 0x75350ad1

    .line 465
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 468
    invoke-virtual {v15}, Landroidx/collection/MutableScatterMap;->clear()V

    .line 471
    invoke-virtual {v5}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    .line 474
    move-result v12

    .line 475
    const/4 v13, 0x0

    .line 476
    :goto_1db
    if-ge v13, v12, :cond_1fb

    .line 478
    invoke-virtual {v5, v13}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->get(I)Ljava/lang/Object;

    .line 481
    move-result-object v2

    .line 482
    new-instance v0, Landroidx/compose/animation/AnimatedContentKt$AnimatedContent$6$1;

    .line 484
    move-object/from16 v1, p0

    .line 486
    invoke-direct/range {v0 .. v6}, Landroidx/compose/animation/AnimatedContentKt$AnimatedContent$6$1;-><init>(Landroidx/compose/animation/core/Transition;Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;Landroidx/compose/runtime/snapshots/SnapshotStateList;Landroidx/compose/runtime/internal/ComposableLambdaImpl;)V

    .line 489
    move-object v1, v0

    .line 490
    move-object v6, v3

    .line 491
    move-object v0, v4

    .line 492
    const v3, -0x16ceaa7

    .line 495
    invoke-static {v3, v1, v10}, Landroidx/compose/runtime/internal/Expect_jvmKt;->rememberComposableLambda(ILkotlin/Function;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 498
    move-result-object v1

    .line 499
    invoke-virtual {v15, v2, v1}, Landroidx/collection/MutableScatterMap;->set(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 502
    add-int/lit8 v13, v13, 0x1

    .line 504
    move-object v3, v6

    .line 505
    move-object/from16 v6, p5

    .line 507
    goto :goto_1db

    .line 508
    :cond_1fb
    move-object v6, v3

    .line 509
    move-object v0, v4

    .line 510
    const/4 v1, 0x0

    .line 511
    invoke-virtual {v10, v1}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 514
    :goto_201
    invoke-virtual/range {p0 .. p0}, Landroidx/compose/animation/core/Transition;->getSegment()Landroidx/compose/animation/core/Transition$Segment;

    .line 517
    move-result-object v1

    .line 518
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 521
    move-result v2

    .line 522
    invoke-virtual {v10, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 525
    move-result v1

    .line 526
    or-int/2addr v1, v2

    .line 527
    invoke-virtual {v10}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 530
    move-result-object v2

    .line 531
    if-nez v1, :cond_216

    .line 533
    if-ne v2, v14, :cond_220

    .line 535
    :cond_216
    invoke-interface {v6, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 538
    move-result-object v1

    .line 539
    move-object v2, v1

    .line 540
    check-cast v2, Landroidx/compose/animation/ContentTransform;

    .line 542
    invoke-virtual {v10, v2}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 545
    :cond_220
    check-cast v2, Landroidx/compose/animation/ContentTransform;

    .line 547
    iget-object v1, v0, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;->transition:Landroidx/compose/animation/core/Transition;

    .line 549
    invoke-virtual {v10, v0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 552
    move-result v3

    .line 553
    invoke-virtual {v10}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 556
    move-result-object v4

    .line 557
    if-nez v3, :cond_230

    .line 559
    if-ne v4, v14, :cond_239

    .line 561
    :cond_230
    sget-object v3, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 563
    invoke-static {v3}, Landroidx/compose/runtime/Updater;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 566
    move-result-object v4

    .line 567
    invoke-virtual {v10, v4}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 570
    :cond_239
    check-cast v4, Landroidx/compose/runtime/MutableState;

    .line 572
    iget-object v2, v2, Landroidx/compose/animation/ContentTransform;->sizeTransform:Landroidx/compose/animation/SizeTransformImpl;

    .line 574
    invoke-static {v2, v10}, Landroidx/compose/runtime/Updater;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/runtime/MutableState;

    .line 577
    move-result-object v12

    .line 578
    iget-object v2, v1, Landroidx/compose/animation/core/Transition;->transitionState:Landroidx/compose/animation/core/TransitionState;

    .line 580
    invoke-virtual {v2}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 583
    move-result-object v2

    .line 584
    iget-object v1, v1, Landroidx/compose/animation/core/Transition;->targetState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 586
    invoke-virtual {v1}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 589
    move-result-object v1

    .line 590
    invoke-static {v2, v1}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 593
    move-result v1

    .line 594
    if-eqz v1, :cond_259

    .line 596
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 598
    invoke-interface {v4, v1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 601
    goto :goto_264

    .line 602
    :cond_259
    invoke-interface {v12}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 605
    move-result-object v1

    .line 606
    if-eqz v1, :cond_264

    .line 608
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 610
    invoke-interface {v4, v1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 613
    :cond_264
    :goto_264
    invoke-interface {v4}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 616
    move-result-object v1

    .line 617
    check-cast v1, Ljava/lang/Boolean;

    .line 619
    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 622
    move-result v1

    .line 623
    sget-object v13, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 625
    const/4 v2, 0x0

    .line 626
    if-eqz v1, :cond_2b0

    .line 628
    const v1, 0x50a652f9

    .line 631
    invoke-virtual {v10, v1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 634
    move-object v4, v0

    .line 635
    iget-object v0, v4, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;->transition:Landroidx/compose/animation/core/Transition;

    .line 637
    sget-object v1, Landroidx/compose/animation/core/ArcSplineKt;->IntSizeToVector:Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 639
    move-object v3, v4

    .line 640
    const/4 v4, 0x0

    .line 641
    move-object/from16 v16, v5

    .line 643
    const/4 v5, 0x2

    .line 644
    move-object/from16 v17, v2

    .line 646
    const/4 v2, 0x0

    .line 647
    move-object/from16 v19, v10

    .line 649
    move-object v10, v3

    .line 650
    move-object/from16 v3, v19

    .line 652
    invoke-static/range {v0 .. v5}, Landroidx/compose/animation/core/TransitionKt;->createDeferredAnimation(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;II)Landroidx/compose/animation/core/Transition$DeferredAnimation;

    .line 655
    move-result-object v2

    .line 656
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 659
    move-result v0

    .line 660
    invoke-virtual {v3}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 663
    move-result-object v1

    .line 664
    if-nez v0, :cond_29b

    .line 666
    if-ne v1, v14, :cond_2a8

    .line 668
    :cond_29b
    invoke-interface {v12}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 671
    move-result-object v0

    .line 672
    check-cast v0, Landroidx/compose/animation/SizeTransformImpl;

    .line 674
    invoke-static {v13}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 677
    move-result-object v1

    .line 678
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 681
    :cond_2a8
    move-object v13, v1

    .line 682
    check-cast v13, Landroidx/compose/ui/Modifier;

    .line 684
    const/4 v1, 0x0

    .line 685
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 688
    goto :goto_2bf

    .line 689
    :cond_2b0
    move-object/from16 v16, v5

    .line 691
    move-object v3, v10

    .line 692
    const/4 v1, 0x0

    .line 693
    move-object v10, v0

    .line 694
    const v0, 0x50aa6233

    .line 697
    invoke-virtual {v3, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 700
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 703
    const/4 v2, 0x0

    .line 704
    :goto_2bf
    new-instance v0, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl$SizeModifierElement;

    .line 706
    invoke-direct {v0, v2, v12, v10}, Landroidx/compose/animation/AnimatedContentTransitionScopeImpl$SizeModifierElement;-><init>(Landroidx/compose/animation/core/Transition$DeferredAnimation;Landroidx/compose/runtime/MutableState;Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;)V

    .line 709
    invoke-interface {v13, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 712
    move-result-object v0

    .line 713
    invoke-interface {v7, v0}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 716
    move-result-object v0

    .line 717
    invoke-virtual {v3}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 720
    move-result-object v1

    .line 721
    if-ne v1, v14, :cond_2da

    .line 723
    new-instance v1, Landroidx/compose/animation/AnimatedContentMeasurePolicy;

    .line 725
    invoke-direct {v1, v10}, Landroidx/compose/animation/AnimatedContentMeasurePolicy;-><init>(Landroidx/compose/animation/AnimatedContentTransitionScopeImpl;)V

    .line 728
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 731
    :cond_2da
    check-cast v1, Landroidx/compose/animation/AnimatedContentMeasurePolicy;

    .line 733
    iget-wide v4, v3, Landroidx/compose/runtime/GapComposer;->compositeKeyHashCode:J

    .line 735
    invoke-static {v4, v5}, Ljava/lang/Long;->hashCode(J)I

    .line 738
    move-result v2

    .line 739
    invoke-virtual {v3}, Landroidx/compose/runtime/GapComposer;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 742
    move-result-object v4

    .line 743
    invoke-static {v3, v0}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/GapComposer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 746
    move-result-object v0

    .line 747
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 749
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 752
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 754
    invoke-virtual {v3}, Landroidx/compose/runtime/GapComposer;->startReusableNode()V

    .line 757
    iget-boolean v10, v3, Landroidx/compose/runtime/GapComposer;->inserting:Z

    .line 759
    if-eqz v10, :cond_2fc

    .line 761
    invoke-virtual {v3, v5}, Landroidx/compose/runtime/GapComposer;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 764
    goto :goto_2ff

    .line 765
    :cond_2fc
    invoke-virtual {v3}, Landroidx/compose/runtime/GapComposer;->useNode()V

    .line 768
    :goto_2ff
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 770
    invoke-static {v3, v1, v5}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 773
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 775
    invoke-static {v3, v4, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 778
    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 781
    move-result-object v1

    .line 782
    sget-object v2, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 784
    invoke-static {v3, v1, v2}, Landroidx/compose/runtime/Updater;->init-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Integer;Lkotlin/jvm/functions/Function2;)V

    .line 787
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->ApplyOnDeactivatedNodeAssertion:Landroidx/compose/ui/node/OwnerSnapshotObserver$onCommitAffectingLayout$1;

    .line 789
    invoke-static {v3, v1}, Landroidx/compose/runtime/Updater;->reconcile-impl(Landroidx/compose/runtime/GapComposer;Lkotlin/jvm/functions/Function1;)V

    .line 792
    sget-object v1, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 794
    invoke-static {v3, v0, v1}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 797
    const v0, -0x334534ba  # -9.793387E7f

    .line 800
    invoke-virtual {v3, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 803
    invoke-virtual/range {v16 .. v16}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->size()I

    .line 806
    move-result v0

    .line 807
    const/4 v12, 0x0

    .line 808
    :goto_327
    if-ge v12, v0, :cond_363

    .line 810
    move-object/from16 v5, v16

    .line 812
    invoke-virtual {v5, v12}, Landroidx/compose/runtime/snapshots/SnapshotStateList;->get(I)Ljava/lang/Object;

    .line 815
    move-result-object v1

    .line 816
    const v2, -0x78c25a0a

    .line 819
    invoke-interface {v9, v1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 822
    move-result-object v4

    .line 823
    const/4 v10, 0x0

    .line 824
    const/4 v13, 0x0

    .line 825
    invoke-virtual {v3, v2, v13, v4, v10}, Landroidx/compose/runtime/GapComposer;->start-AzEfcrM(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 828
    invoke-virtual {v15, v1}, Landroidx/collection/MutableScatterMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 831
    move-result-object v1

    .line 832
    check-cast v1, Lkotlin/jvm/functions/Function2;

    .line 834
    if-nez v1, :cond_34d

    .line 836
    const v1, 0x6077a733

    .line 839
    invoke-virtual {v3, v1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 842
    :goto_349
    invoke-virtual {v3, v13}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 845
    goto :goto_35b

    .line 846
    :cond_34d
    const v2, -0x78c25572

    .line 849
    invoke-virtual {v3, v2}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 852
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 855
    move-result-object v2

    .line 856
    invoke-interface {v1, v3, v2}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 859
    goto :goto_349

    .line 860
    :goto_35b
    invoke-virtual {v3, v13}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 863
    add-int/lit8 v12, v12, 0x1

    .line 865
    move-object/from16 v16, v5

    .line 867
    goto :goto_327

    .line 868
    :cond_363
    const/4 v13, 0x0

    .line 869
    invoke-virtual {v3, v13}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 872
    const/4 v13, 0x1

    .line 873
    invoke-virtual {v3, v13}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 876
    goto :goto_371

    .line 877
    :cond_36c
    move-object v6, v3

    .line 878
    move-object v3, v10

    .line 879
    invoke-virtual {v3}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 882
    :goto_371
    invoke-virtual {v3}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 885
    move-result-object v10

    .line 886
    if-eqz v10, :cond_387

    .line 888
    new-instance v0, Landroidx/compose/animation/AnimatedContentKt$AnimatedContent$9;

    .line 890
    move-object/from16 v1, p0

    .line 892
    move-object v3, v6

    .line 893
    move-object v2, v7

    .line 894
    move-object v4, v8

    .line 895
    move-object v5, v9

    .line 896
    move v7, v11

    .line 897
    move-object/from16 v6, p5

    .line 899
    invoke-direct/range {v0 .. v7}, Landroidx/compose/animation/AnimatedContentKt$AnimatedContent$9;-><init>(Landroidx/compose/animation/core/Transition;Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Alignment;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/internal/ComposableLambdaImpl;I)V

    .line 902
    iput-object v0, v10, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 904
    :cond_387
    return-void
.end method

.method public static final AnimatedEnterExitImpl(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V
    .registers 40

    .line 1
    move-object/from16 v1, p0

    .line 3
    move-object/from16 v2, p1

    .line 5
    move-object/from16 v3, p2

    .line 7
    move-object/from16 v4, p3

    .line 9
    move-object/from16 v5, p4

    .line 11
    move-object/from16 v6, p5

    .line 13
    move-object/from16 v7, p6

    .line 15
    move-object/from16 v11, p7

    .line 17
    move/from16 v0, p8

    .line 19
    const v8, 0x72039c2f

    .line 22
    invoke-virtual {v11, v8}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 25
    and-int/lit8 v8, v0, 0x6

    .line 27
    const/4 v9, 0x4

    .line 28
    if-nez v8, :cond_28

    .line 30
    invoke-virtual {v11, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 33
    move-result v8

    .line 34
    if-eqz v8, :cond_25

    .line 36
    move v8, v9

    .line 37
    goto :goto_26

    .line 38
    :cond_25
    const/4 v8, 0x2

    .line 39
    :goto_26
    or-int/2addr v8, v0

    .line 40
    goto :goto_29

    .line 41
    :cond_28
    move v8, v0

    .line 42
    :goto_29
    and-int/lit8 v10, v0, 0x30

    .line 44
    if-nez v10, :cond_39

    .line 46
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 49
    move-result v10

    .line 50
    if-eqz v10, :cond_36

    .line 52
    const/16 v10, 0x20

    .line 54
    goto :goto_38

    .line 55
    :cond_36
    const/16 v10, 0x10

    .line 57
    :goto_38
    or-int/2addr v8, v10

    .line 58
    :cond_39
    and-int/lit16 v10, v0, 0x180

    .line 60
    if-nez v10, :cond_49

    .line 62
    invoke-virtual {v11, v3}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 65
    move-result v10

    .line 66
    if-eqz v10, :cond_46

    .line 68
    const/16 v10, 0x100

    .line 70
    goto :goto_48

    .line 71
    :cond_46
    const/16 v10, 0x80

    .line 73
    :goto_48
    or-int/2addr v8, v10

    .line 74
    :cond_49
    and-int/lit16 v10, v0, 0xc00

    .line 76
    if-nez v10, :cond_59

    .line 78
    invoke-virtual {v11, v4}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 81
    move-result v10

    .line 82
    if-eqz v10, :cond_56

    .line 84
    const/16 v10, 0x800

    .line 86
    goto :goto_58

    .line 87
    :cond_56
    const/16 v10, 0x400

    .line 89
    :goto_58
    or-int/2addr v8, v10

    .line 90
    :cond_59
    and-int/lit16 v10, v0, 0x6000

    .line 92
    if-nez v10, :cond_69

    .line 94
    invoke-virtual {v11, v5}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 97
    move-result v10

    .line 98
    if-eqz v10, :cond_66

    .line 100
    const/16 v10, 0x4000

    .line 102
    goto :goto_68

    .line 103
    :cond_66
    const/16 v10, 0x2000

    .line 105
    :goto_68
    or-int/2addr v8, v10

    .line 106
    :cond_69
    const/high16 v10, 0x30000

    .line 108
    and-int/2addr v10, v0

    .line 109
    if-nez v10, :cond_7a

    .line 111
    invoke-virtual {v11, v6}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 114
    move-result v10

    .line 115
    if-eqz v10, :cond_77

    .line 117
    const/high16 v10, 0x20000

    .line 119
    goto :goto_79

    .line 120
    :cond_77
    const/high16 v10, 0x10000

    .line 122
    :goto_79
    or-int/2addr v8, v10

    .line 123
    :cond_7a
    const/high16 v10, 0x180000

    .line 125
    or-int/2addr v8, v10

    .line 126
    const/high16 v10, 0xc00000

    .line 128
    and-int/2addr v10, v0

    .line 129
    if-nez v10, :cond_8e

    .line 131
    invoke-virtual {v11, v7}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 134
    move-result v10

    .line 135
    if-eqz v10, :cond_8b

    .line 137
    const/high16 v10, 0x800000

    .line 139
    goto :goto_8d

    .line 140
    :cond_8b
    const/high16 v10, 0x400000

    .line 142
    :goto_8d
    or-int/2addr v8, v10

    .line 143
    :cond_8e
    move v14, v8

    .line 144
    const v8, 0x492493

    .line 147
    and-int/2addr v8, v14

    .line 148
    const v10, 0x492492

    .line 151
    const/4 v12, 0x0

    .line 152
    if-eq v8, v10, :cond_9b

    .line 154
    const/4 v8, 0x1

    .line 155
    goto :goto_9c

    .line 156
    :cond_9b
    move v8, v12

    .line 157
    :goto_9c
    and-int/lit8 v10, v14, 0x1

    .line 159
    invoke-virtual {v11, v10, v8}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 162
    move-result v8

    .line 163
    if-eqz v8, :cond_4ee

    .line 165
    iget-object v8, v1, Landroidx/compose/animation/core/Transition;->targetState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 167
    iget-object v10, v1, Landroidx/compose/animation/core/Transition;->transitionState:Landroidx/compose/animation/core/TransitionState;

    .line 169
    invoke-virtual {v8}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 172
    move-result-object v8

    .line 173
    invoke-interface {v2, v8}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 176
    move-result-object v8

    .line 177
    check-cast v8, Ljava/lang/Boolean;

    .line 179
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 182
    move-result v8

    .line 183
    const v13, -0x103b79ed

    .line 186
    if-nez v8, :cond_e0

    .line 188
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 191
    move-result-object v8

    .line 192
    invoke-interface {v2, v8}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 195
    move-result-object v8

    .line 196
    check-cast v8, Ljava/lang/Boolean;

    .line 198
    invoke-virtual {v8}, Ljava/lang/Boolean;->booleanValue()Z

    .line 201
    move-result v8

    .line 202
    if-nez v8, :cond_e0

    .line 204
    invoke-virtual {v1}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 207
    move-result v8

    .line 208
    if-nez v8, :cond_e0

    .line 210
    invoke-virtual {v1}, Landroidx/compose/animation/core/Transition;->getHasInitialValueAnimations()Z

    .line 213
    move-result v8

    .line 214
    if-eqz v8, :cond_d8

    .line 216
    goto :goto_e0

    .line 217
    :cond_d8
    invoke-virtual {v11, v13}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 220
    invoke-virtual {v11, v12}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 223
    goto/16 :goto_4f1

    .line 225
    :cond_e0
    :goto_e0
    const v8, -0xdda5963

    .line 228
    invoke-virtual {v11, v8}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 231
    and-int/lit8 v8, v14, 0xe

    .line 233
    or-int/lit8 v16, v8, 0x30

    .line 235
    and-int/lit8 v13, v16, 0xe

    .line 237
    xor-int/lit8 v15, v13, 0x6

    .line 239
    if-le v15, v9, :cond_f6

    .line 241
    invoke-virtual {v11, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 244
    move-result v15

    .line 245
    if-nez v15, :cond_fa

    .line 247
    :cond_f6
    and-int/lit8 v15, v16, 0x6

    .line 249
    if-ne v15, v9, :cond_fc

    .line 251
    :cond_fa
    const/4 v15, 0x1

    .line 252
    goto :goto_fd

    .line 253
    :cond_fc
    move v15, v12

    .line 254
    :goto_fd
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 257
    move-result-object v9

    .line 258
    sget-object v12, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 260
    if-nez v15, :cond_107

    .line 262
    if-ne v9, v12, :cond_10e

    .line 264
    :cond_107
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 267
    move-result-object v9

    .line 268
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 271
    :cond_10e
    invoke-virtual {v1}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 274
    move-result v15

    .line 275
    if-eqz v15, :cond_118

    .line 277
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 280
    move-result-object v9

    .line 281
    :cond_118
    const v10, 0x6defb3b0

    .line 284
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 287
    invoke-static {v1, v2, v9, v11}, Landroidx/compose/animation/Scale;->targetEnterExit(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/animation/EnterExitState;

    .line 290
    move-result-object v9

    .line 291
    const/4 v15, 0x0

    .line 292
    invoke-virtual {v11, v15}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 295
    iget-object v15, v1, Landroidx/compose/animation/core/Transition;->targetState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 297
    invoke-virtual {v15}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 300
    move-result-object v15

    .line 301
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 304
    invoke-static {v1, v2, v15, v11}, Landroidx/compose/animation/Scale;->targetEnterExit(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/animation/EnterExitState;

    .line 307
    move-result-object v10

    .line 308
    const/4 v15, 0x0

    .line 309
    invoke-virtual {v11, v15}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 312
    or-int/lit16 v13, v13, 0xc00

    .line 314
    sget-object v15, Landroidx/compose/animation/core/TransitionKt;->SeekableTransitionStateTotalDurationChanged:Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;

    .line 316
    and-int/lit8 v15, v13, 0xe

    .line 318
    xor-int/lit8 v15, v15, 0x6

    .line 320
    const/4 v0, 0x4

    .line 321
    if-le v15, v0, :cond_148

    .line 323
    invoke-virtual {v11, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 326
    move-result v16

    .line 327
    if-nez v16, :cond_14c

    .line 329
    :cond_148
    and-int/lit8 v2, v13, 0x6

    .line 331
    if-ne v2, v0, :cond_14e

    .line 333
    :cond_14c
    const/4 v0, 0x1

    .line 334
    goto :goto_14f

    .line 335
    :cond_14e
    const/4 v0, 0x0

    .line 336
    :goto_14f
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 339
    move-result-object v2

    .line 340
    if-nez v0, :cond_15d

    .line 342
    if-ne v2, v12, :cond_158

    .line 344
    goto :goto_15d

    .line 345
    :cond_158
    move/from16 v20, v13

    .line 347
    move/from16 v21, v14

    .line 349
    goto :goto_176

    .line 350
    :cond_15d
    :goto_15d
    new-instance v2, Landroidx/compose/animation/core/Transition;

    .line 352
    new-instance v0, Landroidx/compose/animation/core/MutableTransitionState;

    .line 354
    invoke-direct {v0, v9}, Landroidx/compose/animation/core/MutableTransitionState;-><init>(Ljava/lang/Object;)V

    .line 357
    move/from16 v20, v13

    .line 359
    iget-object v13, v1, Landroidx/compose/animation/core/Transition;->label:Ljava/lang/String;

    .line 361
    move/from16 v21, v14

    .line 363
    const-string v14, " > EnterExitTransition"

    .line 365
    invoke-virtual {v13, v14}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 368
    move-result-object v13

    .line 369
    invoke-direct {v2, v0, v1, v13}, Landroidx/compose/animation/core/Transition;-><init>(Landroidx/compose/animation/core/TransitionState;Landroidx/compose/animation/core/Transition;Ljava/lang/String;)V

    .line 372
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 375
    :goto_176
    check-cast v2, Landroidx/compose/animation/core/Transition;

    .line 377
    const/4 v0, 0x4

    .line 378
    if-le v15, v0, :cond_181

    .line 380
    invoke-virtual {v11, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 383
    move-result v13

    .line 384
    if-nez v13, :cond_185

    .line 386
    :cond_181
    and-int/lit8 v13, v20, 0x6

    .line 388
    if-ne v13, v0, :cond_187

    .line 390
    :cond_185
    const/4 v0, 0x1

    .line 391
    goto :goto_188

    .line 392
    :cond_187
    const/4 v0, 0x0

    .line 393
    :goto_188
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 396
    move-result v13

    .line 397
    or-int/2addr v0, v13

    .line 398
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 401
    move-result-object v13

    .line 402
    if-nez v0, :cond_195

    .line 404
    if-ne v13, v12, :cond_19e

    .line 406
    :cond_195
    new-instance v13, Landroidx/compose/material3/ScaffoldKt$$ExternalSyntheticLambda3;

    .line 408
    const/4 v0, 0x5

    .line 409
    invoke-direct {v13, v0, v1, v2}, Landroidx/compose/material3/ScaffoldKt$$ExternalSyntheticLambda3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 412
    invoke-virtual {v11, v13}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 415
    :cond_19e
    check-cast v13, Lkotlin/jvm/functions/Function1;

    .line 417
    invoke-static {v2, v13, v11}, Landroidx/compose/runtime/Updater;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;)V

    .line 420
    invoke-virtual {v1}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 423
    move-result v0

    .line 424
    if-eqz v0, :cond_1ad

    .line 426
    invoke-virtual {v2, v9, v10}, Landroidx/compose/animation/core/Transition;->seek(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 429
    goto :goto_1b7

    .line 430
    :cond_1ad
    invoke-virtual {v2, v10}, Landroidx/compose/animation/core/Transition;->updateTarget$animation_core(Ljava/lang/Object;)V

    .line 433
    iget-object v0, v2, Landroidx/compose/animation/core/Transition;->isSeeking$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 435
    sget-object v9, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 437
    invoke-virtual {v0, v9}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->setValue(Ljava/lang/Object;)V

    .line 440
    :goto_1b7
    invoke-static {v6, v11}, Landroidx/compose/runtime/Updater;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/runtime/MutableState;

    .line 443
    move-result-object v0

    .line 444
    iget-object v9, v2, Landroidx/compose/animation/core/Transition;->transitionState:Landroidx/compose/animation/core/TransitionState;

    .line 446
    iget-object v10, v2, Landroidx/compose/animation/core/Transition;->transitionState:Landroidx/compose/animation/core/TransitionState;

    .line 448
    iget-object v13, v2, Landroidx/compose/animation/core/Transition;->targetState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 450
    invoke-virtual {v9}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 453
    move-result-object v9

    .line 454
    invoke-virtual {v13}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 457
    move-result-object v14

    .line 458
    invoke-interface {v6, v9, v14}, Lkotlin/jvm/functions/Function2;->invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 461
    move-result-object v9

    .line 462
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 465
    move-result v14

    .line 466
    invoke-virtual {v11, v0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 469
    move-result v15

    .line 470
    or-int/2addr v14, v15

    .line 471
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 474
    move-result-object v15

    .line 475
    move-object/from16 v20, v13

    .line 477
    const/4 v13, 0x0

    .line 478
    if-nez v14, :cond_1e1

    .line 480
    if-ne v15, v12, :cond_1ea

    .line 482
    :cond_1e1
    new-instance v15, Landroidx/datastore/core/DataStoreImpl$data$1;

    .line 484
    const/4 v14, 0x1

    .line 485
    invoke-direct {v15, v2, v0, v13, v14}, Landroidx/datastore/core/DataStoreImpl$data$1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 488
    invoke-virtual {v11, v15}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 491
    :cond_1ea
    check-cast v15, Lkotlin/jvm/functions/Function2;

    .line 493
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 496
    move-result-object v0

    .line 497
    if-ne v0, v12, :cond_1f9

    .line 499
    invoke-static {v9}, Landroidx/compose/runtime/Updater;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 502
    move-result-object v0

    .line 503
    invoke-virtual {v11, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 506
    :cond_1f9
    check-cast v0, Landroidx/compose/runtime/MutableState;

    .line 508
    invoke-virtual {v11, v15}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 511
    move-result v9

    .line 512
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 515
    move-result-object v14

    .line 516
    if-nez v9, :cond_207

    .line 518
    if-ne v14, v12, :cond_210

    .line 520
    :cond_207
    new-instance v14, Landroidx/compose/runtime/SnapshotStateKt__ProduceStateKt$produceState$1$1;

    .line 522
    const/4 v9, 0x0

    .line 523
    invoke-direct {v14, v15, v0, v13, v9}, Landroidx/compose/runtime/SnapshotStateKt__ProduceStateKt$produceState$1$1;-><init>(Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/MutableState;Lkotlin/coroutines/Continuation;I)V

    .line 526
    invoke-virtual {v11, v14}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 529
    :cond_210
    check-cast v14, Lkotlin/jvm/functions/Function2;

    .line 531
    sget-object v9, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 533
    invoke-static {v11, v9, v14}, Landroidx/compose/runtime/Updater;->LaunchedEffect(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 536
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 539
    move-result-object v9

    .line 540
    sget-object v14, Landroidx/compose/animation/EnterExitState;->PostExit:Landroidx/compose/animation/EnterExitState;

    .line 542
    if-ne v9, v14, :cond_23f

    .line 544
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 547
    move-result-object v9

    .line 548
    if-ne v9, v14, :cond_23f

    .line 550
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 553
    move-result-object v0

    .line 554
    check-cast v0, Ljava/lang/Boolean;

    .line 556
    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 559
    move-result v0

    .line 560
    if-nez v0, :cond_232

    .line 562
    goto :goto_23f

    .line 563
    :cond_232
    const v0, -0x103b79ed

    .line 566
    invoke-virtual {v11, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 569
    const/4 v15, 0x0

    .line 570
    invoke-virtual {v11, v15}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 573
    move v2, v15

    .line 574
    goto/16 :goto_4ea

    .line 576
    :cond_23f
    :goto_23f
    const v0, -0xdcaa1ed

    .line 579
    invoke-virtual {v11, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 582
    const/4 v0, 0x4

    .line 583
    if-ne v8, v0, :cond_24a

    .line 585
    const/4 v0, 0x1

    .line 586
    goto :goto_24b

    .line 587
    :cond_24a
    const/4 v0, 0x0

    .line 588
    :goto_24b
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 591
    move-result-object v8

    .line 592
    if-nez v0, :cond_253

    .line 594
    if-ne v8, v12, :cond_25b

    .line 596
    :cond_253
    new-instance v8, Landroidx/compose/animation/AnimatedVisibilityScopeImpl;

    .line 598
    invoke-direct {v8}, Landroidx/compose/animation/AnimatedVisibilityScopeImpl;-><init>()V

    .line 601
    invoke-virtual {v11, v8}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 604
    :cond_25b
    move-object v0, v8

    .line 605
    check-cast v0, Landroidx/compose/animation/AnimatedVisibilityScopeImpl;

    .line 607
    sget-object v8, Landroidx/compose/animation/EnterExitTransitionKt;->TransformOriginVectorConverter:Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 609
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 612
    move-result-object v8

    .line 613
    if-ne v8, v12, :cond_26b

    .line 615
    sget-object v8, Landroidx/compose/animation/EnterExitTransitionKt$createModifier$1$1;->INSTANCE:Landroidx/compose/animation/EnterExitTransitionKt$createModifier$1$1;

    .line 617
    invoke-virtual {v11, v8}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 620
    :cond_26b
    move-object v14, v8

    .line 621
    check-cast v14, Lkotlin/jvm/functions/Function0;

    .line 623
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 626
    move-result v8

    .line 627
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 630
    move-result-object v9

    .line 631
    if-nez v8, :cond_27a

    .line 633
    if-ne v9, v12, :cond_281

    .line 635
    :cond_27a
    invoke-static {v4}, Landroidx/compose/runtime/Updater;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 638
    move-result-object v9

    .line 639
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 642
    :cond_281
    check-cast v9, Landroidx/compose/runtime/MutableState;

    .line 644
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 647
    move-result-object v8

    .line 648
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 651
    move-result-object v15

    .line 652
    sget-object v13, Landroidx/compose/animation/EnterExitState;->Visible:Landroidx/compose/animation/EnterExitState;

    .line 654
    if-ne v8, v15, :cond_2a5

    .line 656
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 659
    move-result-object v8

    .line 660
    if-ne v8, v13, :cond_2a5

    .line 662
    invoke-virtual {v2}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 665
    move-result v8

    .line 666
    if-eqz v8, :cond_29f

    .line 668
    invoke-interface {v9, v4}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 671
    goto :goto_2b8

    .line 672
    :cond_29f
    sget-object v8, Landroidx/compose/animation/EnterTransitionImpl;->None:Landroidx/compose/animation/EnterTransitionImpl;

    .line 674
    invoke-interface {v9, v8}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 677
    goto :goto_2b8

    .line 678
    :cond_2a5
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 681
    move-result-object v8

    .line 682
    if-ne v8, v13, :cond_2b8

    .line 684
    invoke-interface {v9}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 687
    move-result-object v8

    .line 688
    check-cast v8, Landroidx/compose/animation/EnterTransitionImpl;

    .line 690
    invoke-virtual {v8, v4}, Landroidx/compose/animation/EnterTransitionImpl;->plus(Landroidx/compose/animation/EnterTransitionImpl;)Landroidx/compose/animation/EnterTransitionImpl;

    .line 693
    move-result-object v8

    .line 694
    invoke-interface {v9, v8}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 697
    :cond_2b8
    :goto_2b8
    invoke-interface {v9}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 700
    move-result-object v8

    .line 701
    move-object v15, v8

    .line 702
    check-cast v15, Landroidx/compose/animation/EnterTransitionImpl;

    .line 704
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 707
    move-result v8

    .line 708
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 711
    move-result-object v9

    .line 712
    if-nez v8, :cond_2cb

    .line 714
    if-ne v9, v12, :cond_2d2

    .line 716
    :cond_2cb
    invoke-static {v5}, Landroidx/compose/runtime/Updater;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 719
    move-result-object v9

    .line 720
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 723
    :cond_2d2
    check-cast v9, Landroidx/compose/runtime/MutableState;

    .line 725
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 728
    move-result-object v8

    .line 729
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 732
    move-result-object v1

    .line 733
    if-ne v8, v1, :cond_2f4

    .line 735
    invoke-virtual {v10}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 738
    move-result-object v1

    .line 739
    if-ne v1, v13, :cond_2f4

    .line 741
    invoke-virtual {v2}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 744
    move-result v1

    .line 745
    if-eqz v1, :cond_2ee

    .line 747
    invoke-interface {v9, v5}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 750
    goto :goto_307

    .line 751
    :cond_2ee
    sget-object v1, Landroidx/compose/animation/ExitTransitionImpl;->None:Landroidx/compose/animation/ExitTransitionImpl;

    .line 753
    invoke-interface {v9, v1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 756
    goto :goto_307

    .line 757
    :cond_2f4
    invoke-virtual/range {v20 .. v20}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 760
    move-result-object v1

    .line 761
    if-eq v1, v13, :cond_307

    .line 763
    invoke-interface {v9}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 766
    move-result-object v1

    .line 767
    check-cast v1, Landroidx/compose/animation/ExitTransitionImpl;

    .line 769
    invoke-virtual {v1, v5}, Landroidx/compose/animation/ExitTransitionImpl;->plus(Landroidx/compose/animation/ExitTransitionImpl;)Landroidx/compose/animation/ExitTransitionImpl;

    .line 772
    move-result-object v1

    .line 773
    invoke-interface {v9, v1}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 776
    :cond_307
    :goto_307
    invoke-interface {v9}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 779
    move-result-object v1

    .line 780
    check-cast v1, Landroidx/compose/animation/ExitTransitionImpl;

    .line 782
    iget-object v8, v15, Landroidx/compose/animation/EnterTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 784
    iget-object v9, v1, Landroidx/compose/animation/ExitTransitionImpl;->data:Landroidx/compose/animation/TransitionData;

    .line 786
    iget-object v10, v8, Landroidx/compose/animation/TransitionData;->changeSize:Landroidx/compose/animation/ChangeSize;

    .line 788
    if-nez v10, :cond_31d

    .line 790
    iget-object v10, v9, Landroidx/compose/animation/TransitionData;->changeSize:Landroidx/compose/animation/ChangeSize;

    .line 792
    if-eqz v10, :cond_31a

    .line 794
    goto :goto_31d

    .line 795
    :cond_31a
    const/16 v16, 0x0

    .line 797
    goto :goto_31f

    .line 798
    :cond_31d
    :goto_31d
    const/16 v16, 0x1

    .line 800
    :goto_31f
    const v10, 0x7fb20d0

    .line 803
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 806
    const/4 v10, 0x0

    .line 807
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 810
    if-eqz v16, :cond_359

    .line 812
    const v13, 0x7fc875f

    .line 815
    invoke-virtual {v11, v13}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 818
    move-object v13, v9

    .line 819
    sget-object v9, Landroidx/compose/animation/core/ArcSplineKt;->IntSizeToVector:Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 821
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 824
    move-result-object v10

    .line 825
    if-ne v10, v12, :cond_33f

    .line 827
    const-string v10, "Built-in shrink/expand"

    .line 829
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 832
    :cond_33f
    check-cast v10, Ljava/lang/String;

    .line 834
    move-object/from16 v17, v12

    .line 836
    const/16 v12, 0x180

    .line 838
    move-object/from16 v20, v13

    .line 840
    const/4 v13, 0x0

    .line 841
    move-object v4, v8

    .line 842
    move-object/from16 v6, v17

    .line 844
    move-object/from16 v5, v20

    .line 846
    move-object v8, v2

    .line 847
    const/4 v2, 0x0

    .line 848
    invoke-static/range {v8 .. v13}, Landroidx/compose/animation/core/TransitionKt;->createDeferredAnimation(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;II)Landroidx/compose/animation/core/Transition$DeferredAnimation;

    .line 851
    move-result-object v13

    .line 852
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 855
    move-object/from16 v17, v13

    .line 857
    goto :goto_369

    .line 858
    :cond_359
    move-object v4, v8

    .line 859
    move-object v5, v9

    .line 860
    move-object v6, v12

    .line 861
    move-object v8, v2

    .line 862
    move v2, v10

    .line 863
    const v9, 0x7fe3847

    .line 866
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 869
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 872
    const/16 v17, 0x0

    .line 874
    :goto_369
    if-eqz v16, :cond_38f

    .line 876
    const v9, 0x7ff57e1

    .line 879
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 882
    sget-object v9, Landroidx/compose/animation/core/ArcSplineKt;->IntOffsetToVector:Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 884
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 887
    move-result-object v10

    .line 888
    if-ne v10, v6, :cond_37e

    .line 890
    const-string v10, "Built-in InterruptionHandlingOffset"

    .line 892
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 895
    :cond_37e
    check-cast v10, Ljava/lang/String;

    .line 897
    const/16 v12, 0x180

    .line 899
    const/4 v13, 0x0

    .line 900
    invoke-static/range {v8 .. v13}, Landroidx/compose/animation/core/TransitionKt;->createDeferredAnimation(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;II)Landroidx/compose/animation/core/Transition$DeferredAnimation;

    .line 903
    move-result-object v13

    .line 904
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 907
    move-object/from16 v19, v13

    .line 909
    :goto_38c
    const/16 v18, 0x1

    .line 911
    goto :goto_39b

    .line 912
    :cond_38f
    const v9, 0x801f187

    .line 915
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 918
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 921
    const/16 v19, 0x0

    .line 923
    goto :goto_38c

    .line 924
    :goto_39b
    xor-int/lit8 v9, v16, 0x1

    .line 926
    sget-object v10, Landroidx/compose/ui/graphics/colorspace/ColorSpaces;->SrgbPrimaries:[F

    .line 928
    const v10, 0x80e3b8c

    .line 931
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 934
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 937
    move v10, v9

    .line 938
    sget-object v9, Landroidx/compose/animation/core/ArcSplineKt;->FloatToVector:Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 940
    iget-object v4, v4, Landroidx/compose/animation/TransitionData;->fade:Landroidx/compose/animation/Fade;

    .line 942
    if-nez v4, :cond_3b6

    .line 944
    iget-object v4, v5, Landroidx/compose/animation/TransitionData;->fade:Landroidx/compose/animation/Fade;

    .line 946
    if-eqz v4, :cond_3b4

    .line 948
    goto :goto_3b6

    .line 949
    :cond_3b4
    move v12, v2

    .line 950
    goto :goto_3b7

    .line 951
    :cond_3b6
    :goto_3b6
    const/4 v12, 0x1

    .line 952
    :goto_3b7
    if-eqz v12, :cond_3dc

    .line 954
    const v4, -0x29f458fd

    .line 957
    invoke-virtual {v11, v4}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 960
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 963
    move-result-object v4

    .line 964
    if-ne v4, v6, :cond_3ca

    .line 966
    const-string v4, "Built-in alpha"

    .line 968
    invoke-virtual {v11, v4}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 971
    :cond_3ca
    check-cast v4, Ljava/lang/String;

    .line 973
    const/16 v12, 0x180

    .line 975
    const/4 v13, 0x0

    .line 976
    move/from16 v30, v10

    .line 978
    move-object v10, v4

    .line 979
    move/from16 v4, v30

    .line 981
    invoke-static/range {v8 .. v13}, Landroidx/compose/animation/core/TransitionKt;->createDeferredAnimation(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;II)Landroidx/compose/animation/core/Transition$DeferredAnimation;

    .line 984
    move-result-object v13

    .line 985
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 988
    goto :goto_3e7

    .line 989
    :cond_3dc
    move v4, v10

    .line 990
    const v5, -0x29f1c318

    .line 993
    invoke-virtual {v11, v5}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 996
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 999
    const/4 v13, 0x0

    .line 1000
    :goto_3e7
    const v5, -0x29ee24f8

    .line 1003
    invoke-virtual {v11, v5}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 1006
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 1009
    const v5, -0x29ea5478

    .line 1012
    invoke-virtual {v11, v5}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 1015
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 1018
    invoke-virtual {v11, v13}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 1021
    move-result v5

    .line 1022
    invoke-virtual {v11, v15}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 1025
    move-result v9

    .line 1026
    or-int/2addr v5, v9

    .line 1027
    invoke-virtual {v11, v1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 1030
    move-result v9

    .line 1031
    or-int/2addr v5, v9

    .line 1032
    const/4 v9, 0x0

    .line 1033
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 1036
    move-result v10

    .line 1037
    or-int/2addr v5, v10

    .line 1038
    invoke-virtual {v11, v8}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 1041
    move-result v10

    .line 1042
    or-int/2addr v5, v10

    .line 1043
    invoke-virtual {v11, v9}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 1046
    move-result v10

    .line 1047
    or-int/2addr v5, v10

    .line 1048
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 1051
    move-result-object v10

    .line 1052
    if-nez v5, :cond_425

    .line 1054
    if-ne v10, v6, :cond_420

    .line 1056
    goto :goto_425

    .line 1057
    :cond_420
    move-object/from16 v27, v1

    .line 1059
    move-object/from16 v26, v15

    .line 1061
    goto :goto_43b

    .line 1062
    :cond_425
    :goto_425
    new-instance v22, Landroidx/compose/animation/EnterExitTransitionKt$$ExternalSyntheticLambda0;

    .line 1064
    move-object/from16 v28, v9

    .line 1066
    move-object/from16 v27, v1

    .line 1068
    move-object/from16 v25, v8

    .line 1070
    move-object/from16 v24, v9

    .line 1072
    move-object/from16 v23, v13

    .line 1074
    move-object/from16 v26, v15

    .line 1076
    invoke-direct/range {v22 .. v28}, Landroidx/compose/animation/EnterExitTransitionKt$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/animation/core/Transition$DeferredAnimation;Landroidx/compose/animation/core/Transition$DeferredAnimation;Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Landroidx/compose/animation/core/Transition$DeferredAnimation;)V

    .line 1079
    move-object/from16 v10, v22

    .line 1081
    invoke-virtual {v11, v10}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1084
    :goto_43b
    move-object/from16 v29, v10

    .line 1086
    check-cast v29, Landroidx/compose/animation/EnterExitTransitionKt$$ExternalSyntheticLambda0;

    .line 1088
    invoke-virtual {v11, v4}, Landroidx/compose/runtime/GapComposer;->changed(Z)Z

    .line 1091
    move-result v1

    .line 1092
    invoke-virtual {v11, v14}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 1095
    move-result v5

    .line 1096
    or-int/2addr v1, v5

    .line 1097
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 1100
    move-result-object v5

    .line 1101
    if-nez v1, :cond_450

    .line 1103
    if-ne v5, v6, :cond_458

    .line 1105
    :cond_450
    new-instance v5, Landroidx/compose/animation/EnterExitTransitionKt$createModifier$2$1;

    .line 1107
    invoke-direct {v5, v4, v14}, Landroidx/compose/animation/EnterExitTransitionKt$createModifier$2$1;-><init>(ZLkotlin/jvm/functions/Function0;)V

    .line 1110
    invoke-virtual {v11, v5}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1113
    :cond_458
    check-cast v5, Lkotlin/jvm/functions/Function1;

    .line 1115
    sget-object v1, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 1117
    invoke-static {v1, v5}, Landroidx/compose/ui/graphics/ColorKt;->graphicsLayer(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function1;)Landroidx/compose/ui/Modifier;

    .line 1120
    move-result-object v4

    .line 1121
    new-instance v22, Landroidx/compose/animation/EnterExitTransitionElement;

    .line 1123
    move-object/from16 v23, v8

    .line 1125
    move-object/from16 v28, v14

    .line 1127
    move-object/from16 v24, v17

    .line 1129
    move-object/from16 v25, v19

    .line 1131
    invoke-direct/range {v22 .. v29}, Landroidx/compose/animation/EnterExitTransitionElement;-><init>(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/Transition$DeferredAnimation;Landroidx/compose/animation/core/Transition$DeferredAnimation;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Lkotlin/jvm/functions/Function0;Landroidx/compose/animation/EnterExitTransitionKt$$ExternalSyntheticLambda0;)V

    .line 1134
    move-object/from16 v5, v22

    .line 1136
    invoke-interface {v4, v5}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 1139
    move-result-object v4

    .line 1140
    invoke-interface {v4, v1}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 1143
    move-result-object v4

    .line 1144
    const v5, -0x7169e9

    .line 1147
    invoke-virtual {v11, v5}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 1150
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 1153
    invoke-interface {v4, v1}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 1156
    move-result-object v1

    .line 1157
    invoke-interface {v3, v1}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 1160
    move-result-object v1

    .line 1161
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 1164
    move-result-object v4

    .line 1165
    if-ne v4, v6, :cond_496

    .line 1167
    new-instance v4, Landroidx/compose/animation/AnimatedEnterExitMeasurePolicy;

    .line 1169
    invoke-direct {v4, v0}, Landroidx/compose/animation/AnimatedEnterExitMeasurePolicy;-><init>(Landroidx/compose/animation/AnimatedVisibilityScopeImpl;)V

    .line 1172
    invoke-virtual {v11, v4}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 1175
    :cond_496
    check-cast v4, Landroidx/compose/animation/AnimatedEnterExitMeasurePolicy;

    .line 1177
    iget-wide v5, v11, Landroidx/compose/runtime/GapComposer;->compositeKeyHashCode:J

    .line 1179
    invoke-static {v5, v6}, Ljava/lang/Long;->hashCode(J)I

    .line 1182
    move-result v5

    .line 1183
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->currentCompositionLocalScope()Landroidx/compose/runtime/internal/PersistentCompositionLocalHashMap;

    .line 1186
    move-result-object v6

    .line 1187
    invoke-static {v11, v1}, Landroidx/compose/ui/AbsoluteAlignment;->materializeModifier(Landroidx/compose/runtime/GapComposer;Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 1190
    move-result-object v1

    .line 1191
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode;->Companion:Landroidx/compose/ui/node/ComposeUiNode$Companion;

    .line 1193
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1196
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->Constructor:Landroidx/compose/ui/node/LayoutNode$Companion$Constructor$1;

    .line 1198
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->startReusableNode()V

    .line 1201
    iget-boolean v9, v11, Landroidx/compose/runtime/GapComposer;->inserting:Z

    .line 1203
    if-eqz v9, :cond_4b8

    .line 1205
    invoke-virtual {v11, v8}, Landroidx/compose/runtime/GapComposer;->createNode(Lkotlin/jvm/functions/Function0;)V

    .line 1208
    goto :goto_4bb

    .line 1209
    :cond_4b8
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->useNode()V

    .line 1212
    :goto_4bb
    sget-object v8, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetMeasurePolicy:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 1214
    invoke-static {v11, v4, v8}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1217
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetResolvedCompositionLocals:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 1219
    invoke-static {v11, v6, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1222
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1225
    move-result-object v4

    .line 1226
    sget-object v5, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetCompositeKeyHash:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 1228
    invoke-static {v11, v4, v5}, Landroidx/compose/runtime/Updater;->init-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Integer;Lkotlin/jvm/functions/Function2;)V

    .line 1231
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->ApplyOnDeactivatedNodeAssertion:Landroidx/compose/ui/node/OwnerSnapshotObserver$onCommitAffectingLayout$1;

    .line 1233
    invoke-static {v11, v4}, Landroidx/compose/runtime/Updater;->reconcile-impl(Landroidx/compose/runtime/GapComposer;Lkotlin/jvm/functions/Function1;)V

    .line 1236
    sget-object v4, Landroidx/compose/ui/node/ComposeUiNode$Companion;->SetModifier:Landroidx/compose/ui/node/ComposeUiNode$Companion$SetModifier$1;

    .line 1238
    invoke-static {v11, v1, v4}, Landroidx/compose/runtime/Updater;->set-impl(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 1241
    shr-int/lit8 v1, v21, 0x12

    .line 1243
    and-int/lit8 v1, v1, 0x70

    .line 1245
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 1248
    move-result-object v1

    .line 1249
    invoke-virtual {v7, v0, v11, v1}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;->invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1252
    const/4 v14, 0x1

    .line 1253
    invoke-virtual {v11, v14}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 1256
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 1259
    :goto_4ea
    invoke-virtual {v11, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 1262
    goto :goto_4f1

    .line 1263
    :cond_4ee
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 1266
    :goto_4f1
    invoke-virtual {v11}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 1269
    move-result-object v9

    .line 1270
    if-eqz v9, :cond_50a

    .line 1272
    new-instance v0, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedEnterExitImpl$4;

    .line 1274
    move-object/from16 v1, p0

    .line 1276
    move-object/from16 v2, p1

    .line 1278
    move-object/from16 v4, p3

    .line 1280
    move-object/from16 v5, p4

    .line 1282
    move-object/from16 v6, p5

    .line 1284
    move/from16 v8, p8

    .line 1286
    invoke-direct/range {v0 .. v8}, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedEnterExitImpl$4;-><init>(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/internal/ComposableLambdaImpl;I)V

    .line 1289
    iput-object v0, v9, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 1291
    :cond_50a
    return-void
.end method

.method public static final AnimatedVisibility(Landroidx/compose/foundation/layout/ColumnScopeInstance;ZLandroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Ljava/lang/String;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V
    .registers 33

    .line 1
    move-object/from16 v5, p7

    .line 3
    sget-object v0, Landroidx/compose/ui/Alignment$Companion;->Center:Landroidx/compose/ui/BiasAlignment;

    .line 5
    sget-object v1, Landroidx/compose/ui/Alignment$Companion;->BottomCenter:Landroidx/compose/ui/BiasAlignment;

    .line 7
    sget-object v2, Landroidx/compose/ui/Alignment$Companion;->TopCenter:Landroidx/compose/ui/BiasAlignment;

    .line 9
    sget-object v3, Landroidx/compose/ui/Alignment$Companion;->Bottom:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 11
    const v4, 0x6b47faab

    .line 14
    invoke-virtual {v5, v4}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 17
    and-int/lit8 v4, p8, 0x30

    .line 19
    move/from16 v7, p1

    .line 21
    if-nez v4, :cond_24

    .line 23
    invoke-virtual {v5, v7}, Landroidx/compose/runtime/GapComposer;->changed(Z)Z

    .line 26
    move-result v4

    .line 27
    if-eqz v4, :cond_1f

    .line 29
    const/16 v4, 0x20

    .line 31
    goto :goto_21

    .line 32
    :cond_1f
    const/16 v4, 0x10

    .line 34
    :goto_21
    or-int v4, p8, v4

    .line 36
    goto :goto_26

    .line 37
    :cond_24
    move/from16 v4, p8

    .line 39
    :goto_26
    const v6, 0x36d80

    .line 42
    or-int/2addr v4, v6

    .line 43
    const/high16 v6, 0x180000

    .line 45
    and-int v6, p8, v6

    .line 47
    move-object/from16 v12, p6

    .line 49
    if-nez v6, :cond_3e

    .line 51
    invoke-virtual {v5, v12}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 54
    move-result v6

    .line 55
    if-eqz v6, :cond_3b

    .line 57
    const/high16 v6, 0x100000

    .line 59
    goto :goto_3d

    .line 60
    :cond_3b
    const/high16 v6, 0x80000

    .line 62
    :goto_3d
    or-int/2addr v4, v6

    .line 63
    :cond_3e
    const v6, 0x92491

    .line 66
    and-int/2addr v6, v4

    .line 67
    const v8, 0x92490

    .line 70
    const/4 v9, 0x0

    .line 71
    const/4 v10, 0x1

    .line 72
    if-eq v6, v8, :cond_4b

    .line 74
    move v6, v10

    .line 75
    goto :goto_4c

    .line 76
    :cond_4b
    move v6, v9

    .line 77
    :goto_4c
    and-int/lit8 v8, v4, 0x1

    .line 79
    invoke-virtual {v5, v8, v6}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 82
    move-result v6

    .line 83
    if-eqz v6, :cond_12e

    .line 85
    const/4 v6, 0x0

    .line 86
    const/4 v8, 0x3

    .line 87
    invoke-static {v6, v8}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeIn$default(Landroidx/compose/animation/core/TweenSpec;I)Landroidx/compose/animation/EnterTransitionImpl;

    .line 90
    move-result-object v11

    .line 91
    sget-object v13, Landroidx/compose/animation/core/VisibilityThresholdsKt;->VisibilityThresholdMap:Ljava/util/Map;

    .line 93
    new-instance v13, Landroidx/compose/ui/unit/IntSize;

    .line 95
    const-wide v14, 0x100000001L

    .line 100
    invoke-direct {v13, v14, v15}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 103
    const/4 v14, 0x0

    .line 104
    const/high16 v15, 0x43c80000  # 400.0f

    .line 106
    invoke-static {v14, v15, v13, v10}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FFLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 109
    move-result-object v13

    .line 110
    sget-object v10, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$5:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 112
    sget-object v14, Landroidx/compose/ui/Alignment$Companion;->Top:Landroidx/compose/ui/BiasAlignment$Vertical;

    .line 114
    invoke-static {v3, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 117
    move-result v17

    .line 118
    if-eqz v17, :cond_79

    .line 120
    move-object v15, v2

    .line 121
    goto :goto_82

    .line 122
    :cond_79
    invoke-static {v3, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 125
    move-result v17

    .line 126
    if-eqz v17, :cond_81

    .line 128
    move-object v15, v1

    .line 129
    goto :goto_82

    .line 130
    :cond_81
    move-object v15, v0

    .line 131
    :goto_82
    new-instance v6, Landroidx/compose/animation/EnterExitTransitionKt$expandVertically$2;

    .line 133
    invoke-direct {v6, v10, v9}, Landroidx/compose/animation/EnterExitTransitionKt$expandVertically$2;-><init>(Lkotlin/jvm/functions/Function1;I)V

    .line 136
    new-instance v9, Landroidx/compose/animation/EnterTransitionImpl;

    .line 138
    new-instance v18, Landroidx/compose/animation/TransitionData;

    .line 140
    new-instance v10, Landroidx/compose/animation/ChangeSize;

    .line 142
    invoke-direct {v10, v15, v6, v13}, Landroidx/compose/animation/ChangeSize;-><init>(Landroidx/compose/ui/BiasAlignment;Lkotlin/jvm/functions/Function1;Landroidx/compose/animation/core/SpringSpec;)V

    .line 145
    const/16 v22, 0x0

    .line 147
    const/16 v23, 0x7b

    .line 149
    const/16 v19, 0x0

    .line 151
    const/16 v21, 0x0

    .line 153
    move-object/from16 v20, v10

    .line 155
    invoke-direct/range {v18 .. v23}, Landroidx/compose/animation/TransitionData;-><init>(Landroidx/compose/animation/Fade;Landroidx/compose/animation/ChangeSize;Landroidx/compose/animation/Scale;Ljava/util/LinkedHashMap;I)V

    .line 158
    move-object/from16 v6, v18

    .line 160
    invoke-direct {v9, v6}, Landroidx/compose/animation/EnterTransitionImpl;-><init>(Landroidx/compose/animation/TransitionData;)V

    .line 163
    invoke-virtual {v11, v9}, Landroidx/compose/animation/EnterTransitionImpl;->plus(Landroidx/compose/animation/EnterTransitionImpl;)Landroidx/compose/animation/EnterTransitionImpl;

    .line 166
    move-result-object v6

    .line 167
    const/4 v9, 0x0

    .line 168
    invoke-static {v9, v8}, Landroidx/compose/animation/EnterExitTransitionKt;->fadeOut$default(Landroidx/compose/animation/core/TweenSpec;I)Landroidx/compose/animation/ExitTransitionImpl;

    .line 171
    move-result-object v8

    .line 172
    new-instance v9, Landroidx/compose/ui/unit/IntSize;

    .line 174
    const-wide v10, 0x100000001L

    .line 179
    invoke-direct {v9, v10, v11}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 182
    const/high16 v10, 0x43c80000  # 400.0f

    .line 184
    const/4 v11, 0x0

    .line 185
    const/4 v13, 0x1

    .line 186
    invoke-static {v11, v10, v9, v13}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FFLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 189
    move-result-object v9

    .line 190
    sget-object v10, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$6:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 192
    invoke-static {v3, v14}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 195
    move-result v11

    .line 196
    if-eqz v11, :cond_c7

    .line 198
    move-object v0, v2

    .line 199
    goto :goto_ce

    .line 200
    :cond_c7
    invoke-static {v3, v3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 203
    move-result v2

    .line 204
    if-eqz v2, :cond_ce

    .line 206
    move-object v0, v1

    .line 207
    :cond_ce
    :goto_ce
    new-instance v1, Landroidx/compose/animation/EnterExitTransitionKt$expandVertically$2;

    .line 209
    invoke-direct {v1, v10, v13}, Landroidx/compose/animation/EnterExitTransitionKt$expandVertically$2;-><init>(Lkotlin/jvm/functions/Function1;I)V

    .line 212
    new-instance v2, Landroidx/compose/animation/ExitTransitionImpl;

    .line 214
    new-instance v13, Landroidx/compose/animation/TransitionData;

    .line 216
    new-instance v15, Landroidx/compose/animation/ChangeSize;

    .line 218
    invoke-direct {v15, v0, v1, v9}, Landroidx/compose/animation/ChangeSize;-><init>(Landroidx/compose/ui/BiasAlignment;Lkotlin/jvm/functions/Function1;Landroidx/compose/animation/core/SpringSpec;)V

    .line 221
    const/16 v17, 0x0

    .line 223
    const/16 v18, 0x7b

    .line 225
    const/4 v14, 0x0

    .line 226
    const/16 v16, 0x0

    .line 228
    invoke-direct/range {v13 .. v18}, Landroidx/compose/animation/TransitionData;-><init>(Landroidx/compose/animation/Fade;Landroidx/compose/animation/ChangeSize;Landroidx/compose/animation/Scale;Ljava/util/LinkedHashMap;I)V

    .line 231
    invoke-direct {v2, v13}, Landroidx/compose/animation/ExitTransitionImpl;-><init>(Landroidx/compose/animation/TransitionData;)V

    .line 234
    invoke-virtual {v8, v2}, Landroidx/compose/animation/ExitTransitionImpl;->plus(Landroidx/compose/animation/ExitTransitionImpl;)Landroidx/compose/animation/ExitTransitionImpl;

    .line 237
    move-result-object v3

    .line 238
    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 241
    move-result-object v0

    .line 242
    shr-int/lit8 v1, v4, 0x3

    .line 244
    and-int/lit8 v2, v1, 0xe

    .line 246
    shr-int/lit8 v8, v4, 0xc

    .line 248
    and-int/lit8 v8, v8, 0x70

    .line 250
    or-int/2addr v2, v8

    .line 251
    const-string v8, "AnimatedVisibility"

    .line 253
    invoke-static {v0, v8, v5, v2}, Landroidx/compose/animation/core/TransitionKt;->updateTransition(Ljava/lang/Object;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;I)Landroidx/compose/animation/core/Transition;

    .line 256
    move-result-object v0

    .line 257
    invoke-virtual {v5}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 260
    move-result-object v2

    .line 261
    sget-object v9, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 263
    if-ne v2, v9, :cond_10d

    .line 265
    sget-object v2, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$1:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 267
    invoke-virtual {v5, v2}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 270
    :cond_10d
    check-cast v2, Lkotlin/jvm/functions/Function1;

    .line 272
    and-int/lit16 v9, v4, 0x380

    .line 274
    or-int/lit8 v9, v9, 0x30

    .line 276
    and-int/lit16 v10, v4, 0x1c00

    .line 278
    or-int/2addr v9, v10

    .line 279
    const v10, 0xe000

    .line 282
    and-int/2addr v4, v10

    .line 283
    or-int/2addr v4, v9

    .line 284
    const/high16 v9, 0x70000

    .line 286
    and-int/2addr v1, v9

    .line 287
    or-int/2addr v1, v4

    .line 288
    move-object v4, v6

    .line 289
    move v6, v1

    .line 290
    move-object v1, v2

    .line 291
    move-object v2, v4

    .line 292
    move-object v4, v12

    .line 293
    invoke-static/range {v0 .. v6}, Landroidx/compose/animation/Scale;->AnimatedVisibilityImpl(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V

    .line 296
    sget-object v0, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 298
    move-object v9, v2

    .line 299
    move-object v10, v3

    .line 300
    move-object v11, v8

    .line 301
    move-object v8, v0

    .line 302
    goto :goto_139

    .line 303
    :cond_12e
    invoke-virtual/range {p7 .. p7}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 306
    move-object/from16 v8, p2

    .line 308
    move-object/from16 v9, p3

    .line 310
    move-object/from16 v10, p4

    .line 312
    move-object/from16 v11, p5

    .line 314
    :goto_139
    invoke-virtual/range {p7 .. p7}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 317
    move-result-object v0

    .line 318
    if-eqz v0, :cond_14c

    .line 320
    new-instance v5, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedVisibility$6;

    .line 322
    move-object/from16 v6, p0

    .line 324
    move-object/from16 v12, p6

    .line 326
    move/from16 v13, p8

    .line 328
    invoke-direct/range {v5 .. v13}, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedVisibility$6;-><init>(Landroidx/compose/foundation/layout/ColumnScopeInstance;ZLandroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Ljava/lang/String;Landroidx/compose/runtime/internal/ComposableLambdaImpl;I)V

    .line 331
    iput-object v5, v0, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 333
    :cond_14c
    return-void
.end method

.method public static final AnimatedVisibilityImpl(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p1

    .line 5
    move-object/from16 v7, p5

    .line 7
    move/from16 v9, p6

    .line 9
    const v2, 0x65b46798

    .line 12
    invoke-virtual {v7, v2}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 15
    and-int/lit8 v2, v9, 0x6

    .line 17
    const/4 v3, 0x4

    .line 18
    if-nez v2, :cond_1e

    .line 20
    invoke-virtual {v7, v0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 23
    move-result v2

    .line 24
    if-eqz v2, :cond_1b

    .line 26
    move v2, v3

    .line 27
    goto :goto_1c

    .line 28
    :cond_1b
    const/4 v2, 0x2

    .line 29
    :goto_1c
    or-int/2addr v2, v9

    .line 30
    goto :goto_1f

    .line 31
    :cond_1e
    move v2, v9

    .line 32
    :goto_1f
    and-int/lit8 v4, v9, 0x30

    .line 34
    const/16 v5, 0x20

    .line 36
    if-nez v4, :cond_30

    .line 38
    invoke-virtual {v7, v1}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 41
    move-result v4

    .line 42
    if-eqz v4, :cond_2d

    .line 44
    move v4, v5

    .line 45
    goto :goto_2f

    .line 46
    :cond_2d
    const/16 v4, 0x10

    .line 48
    :goto_2f
    or-int/2addr v2, v4

    .line 49
    :cond_30
    and-int/lit16 v4, v9, 0x180

    .line 51
    sget-object v6, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 53
    if-nez v4, :cond_42

    .line 55
    invoke-virtual {v7, v6}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 58
    move-result v4

    .line 59
    if-eqz v4, :cond_3f

    .line 61
    const/16 v4, 0x100

    .line 63
    goto :goto_41

    .line 64
    :cond_3f
    const/16 v4, 0x80

    .line 66
    :goto_41
    or-int/2addr v2, v4

    .line 67
    :cond_42
    and-int/lit16 v4, v9, 0xc00

    .line 69
    if-nez v4, :cond_55

    .line 71
    move-object/from16 v4, p2

    .line 73
    invoke-virtual {v7, v4}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 76
    move-result v8

    .line 77
    if-eqz v8, :cond_51

    .line 79
    const/16 v8, 0x800

    .line 81
    goto :goto_53

    .line 82
    :cond_51
    const/16 v8, 0x400

    .line 84
    :goto_53
    or-int/2addr v2, v8

    .line 85
    goto :goto_57

    .line 86
    :cond_55
    move-object/from16 v4, p2

    .line 88
    :goto_57
    and-int/lit16 v8, v9, 0x6000

    .line 90
    if-nez v8, :cond_6a

    .line 92
    move-object/from16 v8, p3

    .line 94
    invoke-virtual {v7, v8}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 97
    move-result v10

    .line 98
    if-eqz v10, :cond_66

    .line 100
    const/16 v10, 0x4000

    .line 102
    goto :goto_68

    .line 103
    :cond_66
    const/16 v10, 0x2000

    .line 105
    :goto_68
    or-int/2addr v2, v10

    .line 106
    goto :goto_6c

    .line 107
    :cond_6a
    move-object/from16 v8, p3

    .line 109
    :goto_6c
    const/high16 v10, 0x30000

    .line 111
    and-int v11, v9, v10

    .line 113
    if-nez v11, :cond_81

    .line 115
    move-object/from16 v11, p4

    .line 117
    invoke-virtual {v7, v11}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 120
    move-result v12

    .line 121
    if-eqz v12, :cond_7d

    .line 123
    const/high16 v12, 0x20000

    .line 125
    goto :goto_7f

    .line 126
    :cond_7d
    const/high16 v12, 0x10000

    .line 128
    :goto_7f
    or-int/2addr v2, v12

    .line 129
    goto :goto_83

    .line 130
    :cond_81
    move-object/from16 v11, p4

    .line 132
    :goto_83
    const v12, 0x12493

    .line 135
    and-int/2addr v12, v2

    .line 136
    const v13, 0x12492

    .line 139
    const/4 v14, 0x0

    .line 140
    const/4 v15, 0x1

    .line 141
    if-eq v12, v13, :cond_90

    .line 143
    move v12, v15

    .line 144
    goto :goto_91

    .line 145
    :cond_90
    move v12, v14

    .line 146
    :goto_91
    and-int/lit8 v13, v2, 0x1

    .line 148
    invoke-virtual {v7, v13, v12}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 151
    move-result v12

    .line 152
    if-eqz v12, :cond_e7

    .line 154
    and-int/lit8 v12, v2, 0x70

    .line 156
    if-ne v12, v5, :cond_9f

    .line 158
    move v5, v15

    .line 159
    goto :goto_a0

    .line 160
    :cond_9f
    move v5, v14

    .line 161
    :goto_a0
    and-int/lit8 v13, v2, 0xe

    .line 163
    if-ne v13, v3, :cond_a5

    .line 165
    move v14, v15

    .line 166
    :cond_a5
    or-int v3, v5, v14

    .line 168
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 171
    move-result-object v5

    .line 172
    sget-object v14, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 174
    if-nez v3, :cond_b1

    .line 176
    if-ne v5, v14, :cond_b9

    .line 178
    :cond_b1
    new-instance v5, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedVisibilityImpl$1$1;

    .line 180
    invoke-direct {v5, v1, v0}, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedVisibilityImpl$1$1;-><init>(Lkotlin/jvm/functions/Function1;Landroidx/compose/animation/core/Transition;)V

    .line 183
    invoke-virtual {v7, v5}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 186
    :cond_b9
    check-cast v5, Lkotlin/jvm/functions/Function3;

    .line 188
    invoke-static {v6, v5}, Landroidx/compose/ui/layout/RulerKt;->layout(Landroidx/compose/ui/Modifier;Lkotlin/jvm/functions/Function3;)Landroidx/compose/ui/Modifier;

    .line 191
    move-result-object v3

    .line 192
    invoke-virtual {v7}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 195
    move-result-object v5

    .line 196
    if-ne v5, v14, :cond_ca

    .line 198
    sget-object v5, Landroidx/compose/animation/AnimatedContentKt$SizeTransform$1;->INSTANCE$1:Landroidx/compose/animation/AnimatedContentKt$SizeTransform$1;

    .line 200
    invoke-virtual {v7, v5}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 203
    :cond_ca
    check-cast v5, Lkotlin/jvm/functions/Function2;

    .line 205
    or-int v6, v13, v10

    .line 207
    or-int/2addr v6, v12

    .line 208
    and-int/lit16 v10, v2, 0x1c00

    .line 210
    or-int/2addr v6, v10

    .line 211
    const v10, 0xe000

    .line 214
    and-int/2addr v10, v2

    .line 215
    or-int/2addr v6, v10

    .line 216
    const/high16 v10, 0x1c00000

    .line 218
    shl-int/lit8 v2, v2, 0x6

    .line 220
    and-int/2addr v2, v10

    .line 221
    or-int/2addr v2, v6

    .line 222
    move-object v6, v8

    .line 223
    move v8, v2

    .line 224
    move-object v2, v3

    .line 225
    move-object v3, v4

    .line 226
    move-object v4, v6

    .line 227
    move-object v6, v11

    .line 228
    invoke-static/range {v0 .. v8}, Landroidx/compose/animation/Scale;->AnimatedEnterExitImpl(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Landroidx/compose/ui/Modifier;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/internal/ComposableLambdaImpl;Landroidx/compose/runtime/GapComposer;I)V

    .line 231
    goto :goto_ea

    .line 232
    :cond_e7
    invoke-virtual/range {p5 .. p5}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 235
    :goto_ea
    invoke-virtual/range {p5 .. p5}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 238
    move-result-object v7

    .line 239
    if-eqz v7, :cond_102

    .line 241
    new-instance v0, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedVisibilityImpl$3;

    .line 243
    move-object/from16 v1, p0

    .line 245
    move-object/from16 v2, p1

    .line 247
    move-object/from16 v3, p2

    .line 249
    move-object/from16 v4, p3

    .line 251
    move-object/from16 v5, p4

    .line 253
    move v6, v9

    .line 254
    invoke-direct/range {v0 .. v6}, Landroidx/compose/animation/AnimatedVisibilityKt$AnimatedVisibilityImpl$3;-><init>(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Landroidx/compose/animation/EnterTransitionImpl;Landroidx/compose/animation/ExitTransitionImpl;Landroidx/compose/runtime/internal/ComposableLambdaImpl;I)V

    .line 257
    iput-object v0, v7, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 259
    :cond_102
    return-void
.end method

.method public static animateContentSize$default()Landroidx/compose/ui/Modifier;
    .registers 4

    .line 1
    sget-object v0, Landroidx/compose/animation/core/VisibilityThresholdsKt;->VisibilityThresholdMap:Ljava/util/Map;

    .line 3
    new-instance v0, Landroidx/compose/ui/unit/IntSize;

    .line 5
    const-wide v1, 0x100000001L

    .line 10
    invoke-direct {v0, v1, v2}, Landroidx/compose/ui/unit/IntSize;-><init>(J)V

    .line 13
    const/4 v1, 0x0

    .line 14
    const/high16 v2, 0x43c80000  # 400.0f

    .line 16
    const/4 v3, 0x1

    .line 17
    invoke-static {v1, v2, v0, v3}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FFLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 20
    move-result-object v0

    .line 21
    sget-object v1, Landroidx/compose/ui/Modifier$Companion;->$$INSTANCE:Landroidx/compose/ui/Modifier$Companion;

    .line 23
    invoke-static {v1}, Landroidx/compose/ui/draw/ClipKt;->clipToBounds(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 26
    move-result-object v1

    .line 27
    new-instance v2, Landroidx/compose/animation/SizeAnimationModifierElement;

    .line 29
    invoke-direct {v2, v0}, Landroidx/compose/animation/SizeAnimationModifierElement;-><init>(Landroidx/compose/animation/core/SpringSpec;)V

    .line 32
    invoke-interface {v1, v2}, Landroidx/compose/ui/Modifier;->then(Landroidx/compose/ui/Modifier;)Landroidx/compose/ui/Modifier;

    .line 35
    move-result-object v0

    .line 36
    return-object v0
.end method

.method public static final targetEnterExit(Landroidx/compose/animation/core/Transition;Lkotlin/jvm/functions/Function1;Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/animation/EnterExitState;
    .registers 10

    .line 1
    const/4 v0, 0x0

    .line 2
    const v1, -0x192ea2d9

    .line 5
    const/4 v2, 0x0

    .line 6
    invoke-virtual {p3, v1, v2, p0, v0}, Landroidx/compose/runtime/GapComposer;->start-AzEfcrM(IILjava/lang/Object;Ljava/lang/Object;)V

    .line 9
    invoke-virtual {p0}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 12
    move-result v0

    .line 13
    iget-object p0, p0, Landroidx/compose/animation/core/Transition;->transitionState:Landroidx/compose/animation/core/TransitionState;

    .line 15
    sget-object v1, Landroidx/compose/animation/EnterExitState;->PreEnter:Landroidx/compose/animation/EnterExitState;

    .line 17
    sget-object v3, Landroidx/compose/animation/EnterExitState;->PostExit:Landroidx/compose/animation/EnterExitState;

    .line 19
    sget-object v4, Landroidx/compose/animation/EnterExitState;->Visible:Landroidx/compose/animation/EnterExitState;

    .line 21
    if-eqz v0, :cond_3f

    .line 23
    const v0, -0xca56761

    .line 26
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 29
    invoke-virtual {p3, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 32
    invoke-interface {p1, p2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 35
    move-result-object p2

    .line 36
    check-cast p2, Ljava/lang/Boolean;

    .line 38
    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    .line 41
    move-result p2

    .line 42
    if-eqz p2, :cond_2d

    .line 44
    move-object v1, v4

    .line 45
    goto :goto_8b

    .line 46
    :cond_2d
    invoke-virtual {p0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 49
    move-result-object p0

    .line 50
    invoke-interface {p1, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    move-result-object p0

    .line 54
    check-cast p0, Ljava/lang/Boolean;

    .line 56
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 59
    move-result p0

    .line 60
    if-eqz p0, :cond_8b

    .line 62
    move-object v1, v3

    .line 63
    goto :goto_8b

    .line 64
    :cond_3f
    const v0, -0xca1388c

    .line 67
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 70
    invoke-virtual {p3}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 73
    move-result-object v0

    .line 74
    sget-object v5, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 76
    if-ne v0, v5, :cond_56

    .line 78
    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    .line 80
    invoke-static {v0}, Landroidx/compose/runtime/Updater;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 83
    move-result-object v0

    .line 84
    invoke-virtual {p3, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 87
    :cond_56
    check-cast v0, Landroidx/compose/runtime/MutableState;

    .line 89
    invoke-virtual {p0}, Landroidx/compose/animation/core/TransitionState;->getCurrentState()Ljava/lang/Object;

    .line 92
    move-result-object p0

    .line 93
    invoke-interface {p1, p0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    move-result-object p0

    .line 97
    check-cast p0, Ljava/lang/Boolean;

    .line 99
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 102
    move-result p0

    .line 103
    if-eqz p0, :cond_6d

    .line 105
    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 107
    invoke-interface {v0, p0}, Landroidx/compose/runtime/MutableState;->setValue(Ljava/lang/Object;)V

    .line 110
    :cond_6d
    invoke-interface {p1, p2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 113
    move-result-object p0

    .line 114
    check-cast p0, Ljava/lang/Boolean;

    .line 116
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 119
    move-result p0

    .line 120
    if-eqz p0, :cond_7b

    .line 122
    move-object v1, v4

    .line 123
    goto :goto_88

    .line 124
    :cond_7b
    invoke-interface {v0}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 127
    move-result-object p0

    .line 128
    check-cast p0, Ljava/lang/Boolean;

    .line 130
    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    .line 133
    move-result p0

    .line 134
    if-eqz p0, :cond_88

    .line 136
    move-object v1, v3

    .line 137
    :cond_88
    :goto_88
    invoke-virtual {p3, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 140
    :cond_8b
    :goto_8b
    invoke-virtual {p3, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 143
    return-object v1
.end method
