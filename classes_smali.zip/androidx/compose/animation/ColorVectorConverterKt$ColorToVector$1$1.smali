.class public final Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;
.super Lkotlin/jvm/internal/Lambda;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function1;


# static fields
.field public static final INSTANCE:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

.field public static final INSTANCE$1:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

.field public static final INSTANCE$2:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

.field public static final INSTANCE$3:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

.field public static final INSTANCE$4:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

.field public static final INSTANCE$5:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

.field public static final INSTANCE$6:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

.field public static final INSTANCE$7:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;


# instance fields
.field public final synthetic $r8$classId:I


# direct methods
.method static synthetic constructor <clinit>()V
    .registers 3

    .line 1
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, 0x1

    .line 5
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 8
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$1:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 10
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 12
    const/4 v2, 0x0

    .line 13
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 16
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 18
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 20
    const/4 v2, 0x2

    .line 21
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 24
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$2:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 26
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 28
    const/4 v2, 0x3

    .line 29
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 32
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$3:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 34
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 36
    const/4 v2, 0x4

    .line 37
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 40
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$4:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 42
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 44
    const/4 v2, 0x5

    .line 45
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 48
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$5:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 50
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 52
    const/4 v2, 0x6

    .line 53
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 56
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$6:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 58
    new-instance v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 60
    const/4 v2, 0x7

    .line 61
    invoke-direct {v0, v1, v2}, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;-><init>(II)V

    .line 64
    sput-object v0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->INSTANCE$7:Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;

    .line 66
    return-void
.end method

.method public synthetic constructor <init>(II)V
    .registers 3

    .line 1
    iput p2, p0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->$r8$classId:I

    .line 3
    invoke-direct {p0, p1}, Lkotlin/jvm/internal/Lambda;-><init>(I)V

    .line 6
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 6

    .line 1
    iget p0, p0, Landroidx/compose/animation/ColorVectorConverterKt$ColorToVector$1$1;->$r8$classId:I

    .line 3
    const/4 v0, 0x0

    .line 4
    packed-switch p0, :pswitch_data_7e

    .line 7
    check-cast p1, Landroidx/compose/animation/core/Transition$Segment;

    .line 9
    sget-object p0, Landroidx/compose/animation/EnterExitTransitionKt;->DefaultOffsetAnimationSpec:Landroidx/compose/animation/core/SpringSpec;

    .line 11
    return-object p0

    .line 12
    :pswitch_b  #0x6
    check-cast p1, Ljava/lang/Number;

    .line 14
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 17
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 20
    move-result-object p0

    .line 21
    return-object p0

    .line 22
    :pswitch_15  #0x5
    check-cast p1, Ljava/lang/Number;

    .line 24
    invoke-virtual {p1}, Ljava/lang/Number;->intValue()I

    .line 27
    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 30
    move-result-object p0

    .line 31
    return-object p0

    .line 32
    :pswitch_1f  #0x4
    check-cast p1, Landroidx/compose/animation/core/Transition$Segment;

    .line 34
    const/4 p0, 0x0

    .line 35
    const/4 p1, 0x7

    .line 36
    const/4 v0, 0x0

    .line 37
    invoke-static {v0, v0, p0, p1}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FFLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 40
    move-result-object p0

    .line 41
    return-object p0

    .line 42
    :pswitch_29  #0x3
    check-cast p1, Landroidx/compose/animation/core/AnimationVector2D;

    .line 44
    iget p0, p1, Landroidx/compose/animation/core/AnimationVector2D;->v1:F

    .line 46
    iget p1, p1, Landroidx/compose/animation/core/AnimationVector2D;->v2:F

    .line 48
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/ColorKt;->TransformOrigin(FF)J

    .line 51
    move-result-wide p0

    .line 52
    new-instance v0, Landroidx/compose/ui/graphics/TransformOrigin;

    .line 54
    invoke-direct {v0, p0, p1}, Landroidx/compose/ui/graphics/TransformOrigin;-><init>(J)V

    .line 57
    return-object v0

    .line 58
    :pswitch_39  #0x2
    check-cast p1, Landroidx/compose/ui/graphics/TransformOrigin;

    .line 60
    iget-wide p0, p1, Landroidx/compose/ui/graphics/TransformOrigin;->packedValue:J

    .line 62
    new-instance v0, Landroidx/compose/animation/core/AnimationVector2D;

    .line 64
    const/16 v1, 0x20

    .line 66
    shr-long v1, p0, v1

    .line 68
    long-to-int v1, v1

    .line 69
    invoke-static {v1}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 72
    move-result v1

    .line 73
    const-wide v2, 0xffffffffL

    .line 78
    and-long/2addr p0, v2

    .line 79
    long-to-int p0, p0

    .line 80
    invoke-static {p0}, Ljava/lang/Float;->intBitsToFloat(I)F

    .line 83
    move-result p0

    .line 84
    invoke-direct {v0, v1, p0}, Landroidx/compose/animation/core/AnimationVector2D;-><init>(FF)V

    .line 87
    return-object v0

    .line 88
    :pswitch_57  #0x1
    check-cast p1, Ljava/lang/Boolean;

    .line 90
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 93
    return-object p1

    .line 94
    :pswitch_5d  #0x0
    check-cast p1, Landroidx/compose/ui/graphics/Color;

    .line 96
    iget-wide p0, p1, Landroidx/compose/ui/graphics/Color;->value:J

    .line 98
    sget-object v0, Landroidx/compose/ui/graphics/colorspace/ColorSpaces;->Oklab:Landroidx/compose/ui/graphics/colorspace/Oklab;

    .line 100
    invoke-static {p0, p1, v0}, Landroidx/compose/ui/graphics/Color;->convert-vNxB06k(JLandroidx/compose/ui/graphics/colorspace/ColorSpace;)J

    .line 103
    move-result-wide p0

    .line 104
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getRed-impl(J)F

    .line 107
    move-result v0

    .line 108
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getGreen-impl(J)F

    .line 111
    move-result v1

    .line 112
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getBlue-impl(J)F

    .line 115
    move-result v2

    .line 116
    invoke-static {p0, p1}, Landroidx/compose/ui/graphics/Color;->getAlpha-impl(J)F

    .line 119
    move-result p0

    .line 120
    new-instance p1, Landroidx/compose/animation/core/AnimationVector4D;

    .line 122
    invoke-direct {p1, p0, v0, v1, v2}, Landroidx/compose/animation/core/AnimationVector4D;-><init>(FFFF)V

    .line 125
    return-object p1

    nop

    .line 127
    :pswitch_data_7e
    .packed-switch 0x0
        :pswitch_5d  #00000000
        :pswitch_57  #00000001
        :pswitch_39  #00000002
        :pswitch_29  #00000003
        :pswitch_1f  #00000004
        :pswitch_15  #00000005
        :pswitch_b  #00000006
    .end packed-switch
.end method
