.class public final Landroidx/compose/animation/core/Transition$animateTo$lambda$2$0$$inlined$onDispose$1;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Landroidx/compose/runtime/DisposableEffectResult;


# virtual methods
.method public final dispose()V
    .registers 1

    .line 1
    return-void
.end method
