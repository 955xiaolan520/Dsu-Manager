.class public abstract Landroidx/compose/animation/core/AnimationVector;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# virtual methods
.method public abstract get$animation_core(I)F
.end method

.method public abstract getSize$animation_core()I
.end method

.method public abstract newVector$animation_core()Landroidx/compose/animation/core/AnimationVector;
.end method

.method public abstract reset$animation_core()V
.end method

.method public abstract set$animation_core(IF)V
.end method
