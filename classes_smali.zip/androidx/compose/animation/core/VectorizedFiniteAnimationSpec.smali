.class public interface abstract Landroidx/compose/animation/core/VectorizedFiniteAnimationSpec;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Landroidx/compose/animation/core/VectorizedAnimationSpec;


# virtual methods
.method public isInfinite()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method
