.class public final Landroidx/compose/animation/core/DecayAnimation;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Landroidx/compose/animation/core/Animation;


# instance fields
.field public final animationSpec:Ljava/lang/Object;

.field public final durationNanos:J

.field public final endVelocity:Ljava/lang/Object;

.field public final initialValue:Ljava/lang/Object;

.field public final initialValueVector:Ljava/lang/Object;

.field public final initialVelocityVector:Ljava/lang/Object;

.field public final targetValue:Ljava/lang/Object;

.field public final typeConverter:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroidx/compose/animation/core/DecayAnimationSpecImpl;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationVector;)V
    .registers 26

    .line 1
    move-object/from16 v0, p0

    .line 3
    move-object/from16 v1, p2

    .line 5
    move-object/from16 v2, p3

    .line 7
    move-object/from16 v3, p4

    .line 9
    new-instance v4, Lkotlin/text/MatcherMatchResult;

    .line 11
    move-object/from16 v5, p1

    .line 13
    iget-object v5, v5, Landroidx/compose/animation/core/DecayAnimationSpecImpl;->floatDecaySpec:Landroidx/compose/ui/draw/DrawResult;

    .line 15
    invoke-direct {v4, v5}, Lkotlin/text/MatcherMatchResult;-><init>(Ljava/lang/Object;)V

    .line 18
    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    .line 21
    iput-object v4, v0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 23
    iput-object v1, v0, Landroidx/compose/animation/core/DecayAnimation;->typeConverter:Ljava/lang/Object;

    .line 25
    iput-object v2, v0, Landroidx/compose/animation/core/DecayAnimation;->initialValue:Ljava/lang/Object;

    .line 27
    iget-object v5, v1, Landroidx/compose/animation/core/TwoWayConverterImpl;->convertToVector:Lkotlin/jvm/functions/Function1;

    .line 29
    invoke-interface {v5, v2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    move-result-object v2

    .line 33
    check-cast v2, Landroidx/compose/animation/core/AnimationVector;

    .line 35
    iput-object v2, v0, Landroidx/compose/animation/core/DecayAnimation;->initialValueVector:Ljava/lang/Object;

    .line 37
    invoke-static {v3}, Landroidx/compose/animation/core/ArcSplineKt;->copy(Landroidx/compose/animation/core/AnimationVector;)Landroidx/compose/animation/core/AnimationVector;

    .line 40
    move-result-object v5

    .line 41
    iput-object v5, v0, Landroidx/compose/animation/core/DecayAnimation;->initialVelocityVector:Ljava/lang/Object;

    .line 43
    iget-object v1, v1, Landroidx/compose/animation/core/TwoWayConverterImpl;->convertFromVector:Lkotlin/jvm/functions/Function1;

    .line 45
    iget-object v5, v4, Lkotlin/text/MatcherMatchResult;->groupValues_:Ljava/lang/Object;

    .line 47
    check-cast v5, Landroidx/compose/animation/core/AnimationVector;

    .line 49
    if-nez v5, :cond_38

    .line 51
    invoke-virtual {v2}, Landroidx/compose/animation/core/AnimationVector;->newVector$animation_core()Landroidx/compose/animation/core/AnimationVector;

    .line 54
    move-result-object v5

    .line 55
    iput-object v5, v4, Lkotlin/text/MatcherMatchResult;->groupValues_:Ljava/lang/Object;

    .line 57
    :cond_38
    iget-object v5, v4, Lkotlin/text/MatcherMatchResult;->groupValues_:Ljava/lang/Object;

    .line 59
    check-cast v5, Landroidx/compose/animation/core/AnimationVector;

    .line 61
    const-string v7, "targetVector"

    .line 63
    if-eqz v5, :cond_137

    .line 65
    invoke-virtual {v5}, Landroidx/compose/animation/core/AnimationVector;->getSize$animation_core()I

    .line 68
    move-result v5

    .line 69
    const/4 v9, 0x0

    .line 70
    :goto_45
    iget-object v10, v4, Lkotlin/text/MatcherMatchResult;->groupValues_:Ljava/lang/Object;

    .line 72
    check-cast v10, Landroidx/compose/animation/core/AnimationVector;

    .line 74
    if-ge v9, v5, :cond_90

    .line 76
    if-eqz v10, :cond_8a

    .line 78
    iget-object v13, v4, Lkotlin/text/MatcherMatchResult;->matcher:Ljava/lang/Object;

    .line 80
    check-cast v13, Landroidx/compose/ui/draw/DrawResult;

    .line 82
    invoke-virtual {v2, v9}, Landroidx/compose/animation/core/AnimationVector;->get$animation_core(I)F

    .line 85
    move-result v14

    .line 86
    invoke-virtual {v3, v9}, Landroidx/compose/animation/core/AnimationVector;->get$animation_core(I)F

    .line 89
    move-result v15

    .line 90
    iget-object v13, v13, Landroidx/compose/ui/draw/DrawResult;->block:Ljava/lang/Object;

    .line 92
    check-cast v13, Landroidx/compose/animation/FlingCalculator;

    .line 94
    invoke-virtual {v13, v15}, Landroidx/compose/animation/FlingCalculator;->getSplineDeceleration(F)D

    .line 97
    move-result-wide v16

    .line 98
    const/16 p1, 0x0

    .line 100
    sget v6, Landroidx/compose/animation/FlingCalculatorKt;->DecelerationRate:F

    .line 102
    const-wide/high16 p2, 0x3ff0000000000000L  # 1.0

    .line 104
    float-to-double v11, v6

    .line 105
    sub-double v18, v11, p2

    .line 107
    iget v6, v13, Landroidx/compose/animation/FlingCalculator;->friction:F

    .line 109
    iget v13, v13, Landroidx/compose/animation/FlingCalculator;->magicPhysicalCoefficient:F

    .line 111
    mul-float/2addr v6, v13

    .line 112
    move/from16 v20, v9

    .line 114
    float-to-double v8, v6

    .line 115
    div-double v11, v11, v18

    .line 117
    mul-double v11, v11, v16

    .line 119
    invoke-static {v11, v12}, Ljava/lang/Math;->exp(D)D

    .line 122
    move-result-wide v11

    .line 123
    mul-double/2addr v11, v8

    .line 124
    double-to-float v6, v11

    .line 125
    invoke-static {v15}, Ljava/lang/Math;->signum(F)F

    .line 128
    move-result v8

    .line 129
    mul-float/2addr v8, v6

    .line 130
    add-float/2addr v8, v14

    .line 131
    move/from16 v6, v20

    .line 133
    invoke-virtual {v10, v6, v8}, Landroidx/compose/animation/core/AnimationVector;->set$animation_core(IF)V

    .line 136
    add-int/lit8 v9, v6, 0x1

    .line 138
    goto :goto_45

    .line 139
    :cond_8a
    const/16 p1, 0x0

    .line 141
    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 144
    throw p1

    .line 145
    :cond_90
    const/16 p1, 0x0

    .line 147
    const-wide/high16 p2, 0x3ff0000000000000L  # 1.0

    .line 149
    if-eqz v10, :cond_133

    .line 151
    invoke-interface {v1, v10}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 154
    move-result-object v1

    .line 155
    iput-object v1, v0, Landroidx/compose/animation/core/DecayAnimation;->targetValue:Ljava/lang/Object;

    .line 157
    iget-object v1, v0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 159
    check-cast v1, Lkotlin/text/MatcherMatchResult;

    .line 161
    iget-object v2, v0, Landroidx/compose/animation/core/DecayAnimation;->initialValueVector:Ljava/lang/Object;

    .line 163
    check-cast v2, Landroidx/compose/animation/core/AnimationVector;

    .line 165
    iget-object v4, v1, Lkotlin/text/MatcherMatchResult;->groups:Ljava/lang/Object;

    .line 167
    check-cast v4, Landroidx/compose/animation/core/AnimationVector;

    .line 169
    if-nez v4, :cond_b0

    .line 171
    invoke-virtual {v2}, Landroidx/compose/animation/core/AnimationVector;->newVector$animation_core()Landroidx/compose/animation/core/AnimationVector;

    .line 174
    move-result-object v4

    .line 175
    iput-object v4, v1, Lkotlin/text/MatcherMatchResult;->groups:Ljava/lang/Object;

    .line 177
    :cond_b0
    iget-object v4, v1, Lkotlin/text/MatcherMatchResult;->groups:Ljava/lang/Object;

    .line 179
    check-cast v4, Landroidx/compose/animation/core/AnimationVector;

    .line 181
    if-eqz v4, :cond_12d

    .line 183
    invoke-virtual {v4}, Landroidx/compose/animation/core/AnimationVector;->getSize$animation_core()I

    .line 186
    move-result v4

    .line 187
    const-wide/16 v5, 0x0

    .line 189
    const/4 v7, 0x0

    .line 190
    :goto_bd
    if-ge v7, v4, :cond_ee

    .line 192
    iget-object v8, v1, Lkotlin/text/MatcherMatchResult;->matcher:Ljava/lang/Object;

    .line 194
    check-cast v8, Landroidx/compose/ui/draw/DrawResult;

    .line 196
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 199
    invoke-virtual {v3, v7}, Landroidx/compose/animation/core/AnimationVector;->get$animation_core(I)F

    .line 202
    move-result v9

    .line 203
    iget-object v8, v8, Landroidx/compose/ui/draw/DrawResult;->block:Ljava/lang/Object;

    .line 205
    check-cast v8, Landroidx/compose/animation/FlingCalculator;

    .line 207
    invoke-virtual {v8, v9}, Landroidx/compose/animation/FlingCalculator;->getSplineDeceleration(F)D

    .line 210
    move-result-wide v8

    .line 211
    sget v10, Landroidx/compose/animation/FlingCalculatorKt;->DecelerationRate:F

    .line 213
    float-to-double v10, v10

    .line 214
    sub-double v10, v10, p2

    .line 216
    div-double/2addr v8, v10

    .line 217
    invoke-static {v8, v9}, Ljava/lang/Math;->exp(D)D

    .line 220
    move-result-wide v8

    .line 221
    const-wide v10, 0x408f400000000000L  # 1000.0

    .line 226
    mul-double/2addr v8, v10

    .line 227
    double-to-long v8, v8

    .line 228
    const-wide/32 v10, 0xf4240

    .line 231
    mul-long/2addr v8, v10

    .line 232
    invoke-static {v5, v6, v8, v9}, Ljava/lang/Math;->max(JJ)J

    .line 235
    move-result-wide v5

    .line 236
    add-int/lit8 v7, v7, 0x1

    .line 238
    goto :goto_bd

    .line 239
    :cond_ee
    iput-wide v5, v0, Landroidx/compose/animation/core/DecayAnimation;->durationNanos:J

    .line 241
    iget-object v1, v0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 243
    check-cast v1, Lkotlin/text/MatcherMatchResult;

    .line 245
    iget-object v2, v0, Landroidx/compose/animation/core/DecayAnimation;->initialValueVector:Ljava/lang/Object;

    .line 247
    check-cast v2, Landroidx/compose/animation/core/AnimationVector;

    .line 249
    invoke-virtual {v1, v5, v6, v2, v3}, Lkotlin/text/MatcherMatchResult;->getVelocityFromNanos(JLandroidx/compose/animation/core/AnimationVector;Landroidx/compose/animation/core/AnimationVector;)Landroidx/compose/animation/core/AnimationVector;

    .line 252
    move-result-object v1

    .line 253
    invoke-static {v1}, Landroidx/compose/animation/core/ArcSplineKt;->copy(Landroidx/compose/animation/core/AnimationVector;)Landroidx/compose/animation/core/AnimationVector;

    .line 256
    move-result-object v1

    .line 257
    iput-object v1, v0, Landroidx/compose/animation/core/DecayAnimation;->endVelocity:Ljava/lang/Object;

    .line 259
    invoke-virtual {v1}, Landroidx/compose/animation/core/AnimationVector;->getSize$animation_core()I

    .line 262
    move-result v1

    .line 263
    const/4 v8, 0x0

    .line 264
    :goto_107
    if-ge v8, v1, :cond_12c

    .line 266
    iget-object v2, v0, Landroidx/compose/animation/core/DecayAnimation;->endVelocity:Ljava/lang/Object;

    .line 268
    check-cast v2, Landroidx/compose/animation/core/AnimationVector;

    .line 270
    invoke-virtual {v2, v8}, Landroidx/compose/animation/core/AnimationVector;->get$animation_core(I)F

    .line 273
    move-result v3

    .line 274
    iget-object v4, v0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 276
    check-cast v4, Lkotlin/text/MatcherMatchResult;

    .line 278
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 281
    iget-object v4, v0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 283
    check-cast v4, Lkotlin/text/MatcherMatchResult;

    .line 285
    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 288
    const/4 v4, 0x0

    .line 289
    const/high16 v5, -0x80000000

    .line 291
    invoke-static {v3, v5, v4}, Lrikka/sui/Sui;->coerceIn(FFF)F

    .line 294
    move-result v3

    .line 295
    invoke-virtual {v2, v8, v3}, Landroidx/compose/animation/core/AnimationVector;->set$animation_core(IF)V

    .line 298
    add-int/lit8 v8, v8, 0x1

    .line 300
    goto :goto_107

    .line 301
    :cond_12c
    return-void

    .line 302
    :cond_12d
    const-string v0, "velocityVector"

    .line 304
    invoke-static {v0}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 307
    throw p1

    .line 308
    :cond_133
    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 311
    throw p1

    .line 312
    :cond_137
    const/16 p1, 0x0

    .line 314
    invoke-static {v7}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 317
    throw p1
.end method

.method public constructor <init>(Lyangfentuozi/dsusideloaderplus/core/StorageManager;Landroid/net/Uri;Ljava/lang/String;Lkotlinx/coroutines/Job;Lkotlin/jvm/functions/Function1;)V
    .registers 6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {p5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 318
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 319
    iput-object p1, p0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 320
    iput-object p2, p0, Landroidx/compose/animation/core/DecayAnimation;->typeConverter:Ljava/lang/Object;

    .line 321
    iput-object p4, p0, Landroidx/compose/animation/core/DecayAnimation;->initialValue:Ljava/lang/Object;

    .line 322
    iput-object p5, p0, Landroidx/compose/animation/core/DecayAnimation;->targetValue:Ljava/lang/Object;

    .line 323
    invoke-virtual {p1}, Lyangfentuozi/dsusideloaderplus/core/StorageManager;->getWorkspaceFolder()Landroidx/compose/ui/platform/WeakCache;

    move-result-object p4

    invoke-virtual {p4, p3}, Landroidx/compose/ui/platform/WeakCache;->createFile(Ljava/lang/String;)Landroidx/compose/ui/platform/WeakCache;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 324
    iput-object p3, p0, Landroidx/compose/animation/core/DecayAnimation;->initialValueVector:Ljava/lang/Object;

    .line 325
    invoke-virtual {p3}, Landroidx/compose/ui/platform/WeakCache;->getUri()Landroid/net/Uri;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 326
    iget-object p4, p1, Lyangfentuozi/dsusideloaderplus/core/StorageManager;->appContext:Landroid/content/Context;

    invoke-virtual {p4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p5

    invoke-virtual {p5, p3}, Landroid/content/ContentResolver;->openOutputStream(Landroid/net/Uri;)Ljava/io/OutputStream;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 327
    iput-object p3, p0, Landroidx/compose/animation/core/DecayAnimation;->initialVelocityVector:Ljava/lang/Object;

    .line 328
    invoke-virtual {p4}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p3

    invoke-virtual {p3, p2}, Landroid/content/ContentResolver;->openInputStream(Landroid/net/Uri;)Ljava/io/InputStream;

    move-result-object p3

    invoke-virtual {p3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 329
    iput-object p3, p0, Landroidx/compose/animation/core/DecayAnimation;->endVelocity:Ljava/lang/Object;

    .line 330
    invoke-virtual {p1, p2}, Lyangfentuozi/dsusideloaderplus/core/StorageManager;->getFilesizeFromUri(Landroid/net/Uri;)J

    move-result-wide p1

    iput-wide p1, p0, Landroidx/compose/animation/core/DecayAnimation;->durationNanos:J

    return-void
.end method


# virtual methods
.method public copy(Ljava/io/InputStream;Ljava/io/OutputStream;Lkotlin/jvm/functions/Function1;)V
    .registers 10

    .line 1
    const/16 v0, 0x2000

    .line 3
    new-array v0, v0, [B

    .line 5
    const-wide/16 v1, 0x0

    .line 7
    :goto_6
    invoke-virtual {p1, v0}, Ljava/io/InputStream;->read([B)I

    .line 10
    move-result v3

    .line 11
    const/4 v4, -0x1

    .line 12
    if-eq v4, v3, :cond_26

    .line 14
    iget-object v4, p0, Landroidx/compose/animation/core/DecayAnimation;->initialValue:Ljava/lang/Object;

    .line 16
    check-cast v4, Lkotlinx/coroutines/Job;

    .line 18
    invoke-interface {v4}, Lkotlinx/coroutines/Job;->isCancelled()Z

    .line 21
    move-result v4

    .line 22
    if-nez v4, :cond_26

    .line 24
    const-wide/16 v4, 0x2000

    .line 26
    add-long/2addr v1, v4

    .line 27
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 30
    move-result-object v4

    .line 31
    invoke-interface {p3, v4}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 34
    const/4 v4, 0x0

    .line 35
    invoke-virtual {p2, v0, v4, v3}, Ljava/io/OutputStream;->write([BII)V

    .line 38
    goto :goto_6

    .line 39
    :cond_26
    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    .line 42
    invoke-virtual {p2}, Ljava/io/OutputStream;->flush()V

    .line 45
    invoke-virtual {p2}, Ljava/io/OutputStream;->close()V

    .line 48
    return-void
.end method

.method public getDurationNanos()J
    .registers 3

    .line 1
    iget-wide v0, p0, Landroidx/compose/animation/core/DecayAnimation;->durationNanos:J

    .line 3
    return-wide v0
.end method

.method public getTargetValue()Ljava/lang/Object;
    .registers 1

    .line 1
    iget-object p0, p0, Landroidx/compose/animation/core/DecayAnimation;->targetValue:Ljava/lang/Object;

    .line 3
    return-object p0
.end method

.method public getTypeConverter()Landroidx/compose/animation/core/TwoWayConverterImpl;
    .registers 1

    .line 1
    iget-object p0, p0, Landroidx/compose/animation/core/DecayAnimation;->typeConverter:Ljava/lang/Object;

    .line 3
    check-cast p0, Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 5
    return-object p0
.end method

.method public getValueFromNanos(J)Ljava/lang/Object;
    .registers 21

    .line 1
    move-object/from16 v0, p0

    .line 3
    invoke-interface/range {p0 .. p2}, Landroidx/compose/animation/core/Animation;->isFinishedFromNanos(J)Z

    .line 6
    move-result v1

    .line 7
    if-nez v1, :cond_8d

    .line 9
    iget-object v1, v0, Landroidx/compose/animation/core/DecayAnimation;->typeConverter:Ljava/lang/Object;

    .line 11
    check-cast v1, Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 13
    iget-object v1, v1, Landroidx/compose/animation/core/TwoWayConverterImpl;->convertFromVector:Lkotlin/jvm/functions/Function1;

    .line 15
    iget-object v2, v0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 17
    check-cast v2, Lkotlin/text/MatcherMatchResult;

    .line 19
    iget-object v3, v0, Landroidx/compose/animation/core/DecayAnimation;->initialValueVector:Ljava/lang/Object;

    .line 21
    check-cast v3, Landroidx/compose/animation/core/AnimationVector;

    .line 23
    iget-object v0, v0, Landroidx/compose/animation/core/DecayAnimation;->initialVelocityVector:Ljava/lang/Object;

    .line 25
    check-cast v0, Landroidx/compose/animation/core/AnimationVector;

    .line 27
    iget-object v4, v2, Lkotlin/text/MatcherMatchResult;->input:Ljava/lang/Object;

    .line 29
    check-cast v4, Landroidx/compose/animation/core/AnimationVector;

    .line 31
    if-nez v4, :cond_26

    .line 33
    invoke-virtual {v3}, Landroidx/compose/animation/core/AnimationVector;->newVector$animation_core()Landroidx/compose/animation/core/AnimationVector;

    .line 36
    move-result-object v4

    .line 37
    iput-object v4, v2, Lkotlin/text/MatcherMatchResult;->input:Ljava/lang/Object;

    .line 39
    :cond_26
    iget-object v4, v2, Lkotlin/text/MatcherMatchResult;->input:Ljava/lang/Object;

    .line 41
    check-cast v4, Landroidx/compose/animation/core/AnimationVector;

    .line 43
    const/4 v5, 0x0

    .line 44
    const-string v6, "valueVector"

    .line 46
    if-eqz v4, :cond_89

    .line 48
    invoke-virtual {v4}, Landroidx/compose/animation/core/AnimationVector;->getSize$animation_core()I

    .line 51
    move-result v4

    .line 52
    const/4 v7, 0x0

    .line 53
    :goto_34
    iget-object v8, v2, Lkotlin/text/MatcherMatchResult;->input:Ljava/lang/Object;

    .line 55
    check-cast v8, Landroidx/compose/animation/core/AnimationVector;

    .line 57
    if-ge v7, v4, :cond_7e

    .line 59
    if-eqz v8, :cond_7a

    .line 61
    iget-object v9, v2, Lkotlin/text/MatcherMatchResult;->matcher:Ljava/lang/Object;

    .line 63
    check-cast v9, Landroidx/compose/ui/draw/DrawResult;

    .line 65
    invoke-virtual {v3, v7}, Landroidx/compose/animation/core/AnimationVector;->get$animation_core(I)F

    .line 68
    move-result v10

    .line 69
    invoke-virtual {v0, v7}, Landroidx/compose/animation/core/AnimationVector;->get$animation_core(I)F

    .line 72
    move-result v11

    .line 73
    const-wide/32 v12, 0xf4240

    .line 76
    div-long v12, p1, v12

    .line 78
    iget-object v9, v9, Landroidx/compose/ui/draw/DrawResult;->block:Ljava/lang/Object;

    .line 80
    check-cast v9, Landroidx/compose/animation/FlingCalculator;

    .line 82
    invoke-virtual {v9, v11}, Landroidx/compose/animation/FlingCalculator;->flingInfo(F)Landroidx/compose/animation/FlingCalculator$FlingInfo;

    .line 85
    move-result-object v9

    .line 86
    iget-wide v14, v9, Landroidx/compose/animation/FlingCalculator$FlingInfo;->duration:J

    .line 88
    const-wide/16 v16, 0x0

    .line 90
    cmp-long v11, v14, v16

    .line 92
    if-lez v11, :cond_61

    .line 94
    long-to-float v11, v12

    .line 95
    long-to-float v12, v14

    .line 96
    div-float/2addr v11, v12

    .line 97
    goto :goto_63

    .line 98
    :cond_61
    const/high16 v11, 0x3f800000  # 1.0f

    .line 100
    :goto_63
    iget v12, v9, Landroidx/compose/animation/FlingCalculator$FlingInfo;->distance:F

    .line 102
    iget v9, v9, Landroidx/compose/animation/FlingCalculator$FlingInfo;->initialVelocity:F

    .line 104
    invoke-static {v9}, Ljava/lang/Math;->signum(F)F

    .line 107
    move-result v9

    .line 108
    mul-float/2addr v9, v12

    .line 109
    invoke-static {v11}, Landroidx/compose/animation/AndroidFlingSpline;->flingPosition(F)Landroidx/compose/animation/AndroidFlingSpline$FlingResult;

    .line 112
    move-result-object v11

    .line 113
    iget v11, v11, Landroidx/compose/animation/AndroidFlingSpline$FlingResult;->distanceCoefficient:F

    .line 115
    mul-float/2addr v9, v11

    .line 116
    add-float/2addr v9, v10

    .line 117
    invoke-virtual {v8, v7, v9}, Landroidx/compose/animation/core/AnimationVector;->set$animation_core(IF)V

    .line 120
    add-int/lit8 v7, v7, 0x1

    .line 122
    goto :goto_34

    .line 123
    :cond_7a
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 126
    throw v5

    .line 127
    :cond_7e
    if-eqz v8, :cond_85

    .line 129
    invoke-interface {v1, v8}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 132
    move-result-object v0

    .line 133
    return-object v0

    .line 134
    :cond_85
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 137
    throw v5

    .line 138
    :cond_89
    invoke-static {v6}, Lkotlin/jvm/internal/Intrinsics;->throwUninitializedPropertyAccessException(Ljava/lang/String;)V

    .line 141
    throw v5

    .line 142
    :cond_8d
    iget-object v0, v0, Landroidx/compose/animation/core/DecayAnimation;->targetValue:Ljava/lang/Object;

    .line 144
    return-object v0
.end method

.method public getVelocityVectorFromNanos(J)Landroidx/compose/animation/core/AnimationVector;
    .registers 5

    .line 1
    invoke-interface {p0, p1, p2}, Landroidx/compose/animation/core/Animation;->isFinishedFromNanos(J)Z

    .line 4
    move-result v0

    .line 5
    if-nez v0, :cond_17

    .line 7
    iget-object v0, p0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 9
    check-cast v0, Lkotlin/text/MatcherMatchResult;

    .line 11
    iget-object v1, p0, Landroidx/compose/animation/core/DecayAnimation;->initialValueVector:Ljava/lang/Object;

    .line 13
    check-cast v1, Landroidx/compose/animation/core/AnimationVector;

    .line 15
    iget-object p0, p0, Landroidx/compose/animation/core/DecayAnimation;->initialVelocityVector:Ljava/lang/Object;

    .line 17
    check-cast p0, Landroidx/compose/animation/core/AnimationVector;

    .line 19
    invoke-virtual {v0, p1, p2, v1, p0}, Lkotlin/text/MatcherMatchResult;->getVelocityFromNanos(JLandroidx/compose/animation/core/AnimationVector;Landroidx/compose/animation/core/AnimationVector;)Landroidx/compose/animation/core/AnimationVector;

    .line 22
    move-result-object p0

    .line 23
    return-object p0

    .line 24
    :cond_17
    iget-object p0, p0, Landroidx/compose/animation/core/DecayAnimation;->endVelocity:Ljava/lang/Object;

    .line 26
    check-cast p0, Landroidx/compose/animation/core/AnimationVector;

    .line 28
    return-object p0
.end method

.method public isInfinite()Z
    .registers 1

    .line 1
    const/4 p0, 0x0

    .line 2
    return p0
.end method

.method public unpack()Lkotlin/Pair;
    .registers 7

    .line 1
    iget-object v0, p0, Landroidx/compose/animation/core/DecayAnimation;->initialValueVector:Ljava/lang/Object;

    .line 3
    check-cast v0, Landroidx/compose/ui/platform/WeakCache;

    .line 5
    iget-object v1, p0, Landroidx/compose/animation/core/DecayAnimation;->endVelocity:Ljava/lang/Object;

    .line 7
    check-cast v1, Ljava/io/InputStream;

    .line 9
    iget-object v2, p0, Landroidx/compose/animation/core/DecayAnimation;->animationSpec:Ljava/lang/Object;

    .line 11
    check-cast v2, Lyangfentuozi/dsusideloaderplus/core/StorageManager;

    .line 13
    iget-object v3, p0, Landroidx/compose/animation/core/DecayAnimation;->typeConverter:Ljava/lang/Object;

    .line 15
    check-cast v3, Landroid/net/Uri;

    .line 17
    invoke-virtual {v2, v3}, Lyangfentuozi/dsusideloaderplus/core/StorageManager;->getFilenameFromUri(Landroid/net/Uri;)Ljava/lang/String;

    .line 20
    move-result-object v3

    .line 21
    const-string v4, "xz"

    .line 23
    const/4 v5, 0x0

    .line 24
    invoke-static {v3, v4, v5}, Lkotlin/text/StringsKt__StringsJVMKt;->endsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 27
    move-result v4

    .line 28
    if-eqz v4, :cond_23

    .line 30
    new-instance v3, Lorg/apache/commons/compress/compressors/xz/XZCompressorInputStream;

    .line 32
    invoke-direct {v3, v1}, Lorg/apache/commons/compress/compressors/xz/XZCompressorInputStream;-><init>(Ljava/io/InputStream;)V

    .line 35
    goto :goto_3e

    .line 36
    :cond_23
    const-string v4, "gz"

    .line 38
    invoke-static {v3, v4, v5}, Lkotlin/text/StringsKt__StringsJVMKt;->endsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 41
    move-result v4

    .line 42
    if-eqz v4, :cond_31

    .line 44
    new-instance v3, Lorg/apache/commons/compress/compressors/gzip/GzipCompressorInputStream;

    .line 46
    invoke-direct {v3, v1}, Lorg/apache/commons/compress/compressors/gzip/GzipCompressorInputStream;-><init>(Ljava/io/InputStream;)V

    .line 49
    goto :goto_3e

    .line 50
    :cond_31
    const-string v4, "gzip"

    .line 52
    invoke-static {v3, v4, v5}, Lkotlin/text/StringsKt__StringsJVMKt;->endsWith(Ljava/lang/String;Ljava/lang/String;Z)Z

    .line 55
    move-result v3

    .line 56
    if-eqz v3, :cond_65

    .line 58
    new-instance v3, Lorg/apache/commons/compress/compressors/gzip/GzipCompressorInputStream;

    .line 60
    invoke-direct {v3, v1}, Lorg/apache/commons/compress/compressors/gzip/GzipCompressorInputStream;-><init>(Ljava/io/InputStream;)V

    .line 63
    :goto_3e
    iget-object v1, p0, Landroidx/compose/animation/core/DecayAnimation;->initialVelocityVector:Ljava/lang/Object;

    .line 65
    check-cast v1, Ljava/io/OutputStream;

    .line 67
    new-instance v4, Landroidx/navigation/NavController$$ExternalSyntheticLambda3;

    .line 69
    const/16 v5, 0x8

    .line 71
    invoke-direct {v4, v5, p0, v3}, Landroidx/navigation/NavController$$ExternalSyntheticLambda3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 74
    invoke-virtual {p0, v3, v1, v4}, Landroidx/compose/animation/core/DecayAnimation;->copy(Ljava/io/InputStream;Ljava/io/OutputStream;Lkotlin/jvm/functions/Function1;)V

    .line 77
    invoke-virtual {v0}, Landroidx/compose/ui/platform/WeakCache;->getUri()Landroid/net/Uri;

    .line 80
    move-result-object p0

    .line 81
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 84
    invoke-virtual {v2, p0}, Lyangfentuozi/dsusideloaderplus/core/StorageManager;->getFilesizeFromUri(Landroid/net/Uri;)J

    .line 87
    move-result-wide v1

    .line 88
    new-instance p0, Lkotlin/Pair;

    .line 90
    invoke-virtual {v0}, Landroidx/compose/ui/platform/WeakCache;->getUri()Landroid/net/Uri;

    .line 93
    move-result-object v0

    .line 94
    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    .line 97
    move-result-object v1

    .line 98
    invoke-direct {p0, v0, v1}, Lkotlin/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 101
    return-object p0

    .line 102
    :cond_65
    new-instance p0, Ljava/lang/Exception;

    .line 104
    const-string v0, "File type not supported"

    .line 106
    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    .line 109
    throw p0
.end method
