.class public final synthetic Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic f$0:Ljava/lang/Object;

.field public final synthetic f$1:Ljava/lang/Object;

.field public final synthetic f$2:I


# direct methods
.method public synthetic constructor <init>(IILjava/lang/Object;Ljava/lang/Object;)V
    .registers 5

    .line 1
    iput p2, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->$r8$classId:I

    .line 3
    iput-object p3, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->f$0:Ljava/lang/Object;

    .line 5
    iput-object p4, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->f$1:Ljava/lang/Object;

    .line 7
    iput p1, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->f$2:I

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 12
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 7

    .line 1
    iget v0, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->$r8$classId:I

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    iget v2, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->f$2:I

    .line 7
    iget-object v3, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->f$1:Ljava/lang/Object;

    .line 9
    iget-object p0, p0, Landroidx/compose/animation/core/Transition$$ExternalSyntheticLambda2;->f$0:Ljava/lang/Object;

    .line 11
    packed-switch v0, :pswitch_data_72

    .line 14
    check-cast p0, Ljava/lang/Boolean;

    .line 16
    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 18
    check-cast p1, Landroidx/compose/runtime/GapComposer;

    .line 20
    check-cast p2, Ljava/lang/Integer;

    .line 22
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 25
    or-int/lit8 p2, v2, 0x1

    .line 27
    invoke-static {p2}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 30
    move-result p2

    .line 31
    invoke-static {p0, v3, p1, p2}, Lyangfentuozi/dsusideloaderplus/ui/components/CommonKt;->LaunchedEffectAfterFirst(Ljava/lang/Boolean;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/GapComposer;I)V

    .line 34
    return-object v1

    .line 35
    :pswitch_22  #0x3
    check-cast p0, Landroidx/compose/runtime/internal/ComposableLambdaImpl;

    .line 37
    check-cast p1, Landroidx/compose/runtime/GapComposer;

    .line 39
    check-cast p2, Ljava/lang/Integer;

    .line 41
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 44
    invoke-static {v2}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 47
    move-result p2

    .line 48
    or-int/lit8 p2, p2, 0x1

    .line 50
    invoke-virtual {p0, v3, p1, p2}, Landroidx/compose/runtime/internal/ComposableLambdaImpl;->invoke(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;I)Ljava/lang/Object;

    .line 53
    return-object v1

    .line 54
    :pswitch_35  #0x2
    check-cast p0, [Landroidx/compose/runtime/ProvidedValue;

    .line 56
    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 58
    check-cast p1, Landroidx/compose/runtime/GapComposer;

    .line 60
    check-cast p2, Ljava/lang/Integer;

    .line 62
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 65
    or-int/lit8 p2, v2, 0x1

    .line 67
    invoke-static {p2}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 70
    move-result p2

    .line 71
    invoke-static {p0, v3, p1, p2}, Landroidx/compose/runtime/Updater;->CompositionLocalProvider([Landroidx/compose/runtime/ProvidedValue;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/GapComposer;I)V

    .line 74
    return-object v1

    .line 75
    :pswitch_4a  #0x1
    check-cast p0, Landroidx/compose/runtime/ProvidedValue;

    .line 77
    check-cast v3, Lkotlin/jvm/functions/Function2;

    .line 79
    check-cast p1, Landroidx/compose/runtime/GapComposer;

    .line 81
    check-cast p2, Ljava/lang/Integer;

    .line 83
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 86
    or-int/lit8 p2, v2, 0x1

    .line 88
    invoke-static {p2}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 91
    move-result p2

    .line 92
    invoke-static {p0, v3, p1, p2}, Landroidx/compose/runtime/Updater;->CompositionLocalProvider(Landroidx/compose/runtime/ProvidedValue;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/GapComposer;I)V

    .line 95
    return-object v1

    .line 96
    :pswitch_5f  #0x0
    check-cast p0, Landroidx/compose/animation/core/Transition;

    .line 98
    check-cast p1, Landroidx/compose/runtime/GapComposer;

    .line 100
    check-cast p2, Ljava/lang/Integer;

    .line 102
    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    .line 105
    or-int/lit8 p2, v2, 0x1

    .line 107
    invoke-static {p2}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 110
    move-result p2

    .line 111
    invoke-virtual {p0, v3, p1, p2}, Landroidx/compose/animation/core/Transition;->animateTo$animation_core(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;I)V

    .line 114
    return-object v1

    .line 115
    :pswitch_data_72
    .packed-switch 0x0
        :pswitch_5f  #00000000
        :pswitch_4a  #00000001
        :pswitch_35  #00000002
        :pswitch_22  #00000003
    .end packed-switch
.end method
