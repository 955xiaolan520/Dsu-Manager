.class public abstract Landroidx/compose/animation/core/AnimateAsStateKt;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# static fields
.field public static final defaultAnimation:Landroidx/compose/animation/core/SpringSpec;


# direct methods
.method static constructor <clinit>()V
    .registers 3

    .line 1
    const/4 v0, 0x0

    .line 2
    const/4 v1, 0x7

    .line 3
    const/4 v2, 0x0

    .line 4
    invoke-static {v2, v2, v0, v1}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FFLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 7
    move-result-object v0

    .line 8
    sput-object v0, Landroidx/compose/animation/core/AnimateAsStateKt;->defaultAnimation:Landroidx/compose/animation/core/SpringSpec;

    .line 10
    sget-object v0, Landroidx/compose/animation/core/VisibilityThresholdsKt;->VisibilityThresholdMap:Ljava/util/Map;

    .line 12
    const/high16 v0, 0x3f800000  # 1.0f

    .line 14
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 17
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 20
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 23
    invoke-static {v0}, Ljava/lang/Float;->floatToRawIntBits(F)I

    .line 26
    return-void
.end method

.method public static final animateFloatAsState(FLandroidx/compose/animation/core/SpringSpec;Landroidx/compose/runtime/GapComposer;I)Landroidx/compose/runtime/State;
    .registers 14

    .line 1
    and-int/lit8 p3, p3, 0x2

    .line 3
    sget-object v0, Landroidx/compose/animation/core/AnimateAsStateKt;->defaultAnimation:Landroidx/compose/animation/core/SpringSpec;

    .line 5
    if-eqz p3, :cond_7

    .line 7
    move-object p1, v0

    .line 8
    :cond_7
    const/4 p3, 0x0

    .line 9
    const v1, 0x3c23d70a  # 0.01f

    .line 12
    if-ne p1, v0, :cond_36

    .line 14
    const p1, 0x44316d7f

    .line 17
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 20
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/GapComposer;->changed(F)Z

    .line 23
    move-result p1

    .line 24
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 27
    move-result-object v0

    .line 28
    if-nez p1, :cond_21

    .line 30
    sget-object p1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 32
    if-ne v0, p1, :cond_2e

    .line 34
    :cond_21
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 37
    move-result-object p1

    .line 38
    const/4 v0, 0x0

    .line 39
    const/4 v2, 0x3

    .line 40
    invoke-static {v0, v0, p1, v2}, Landroidx/compose/animation/core/ArcSplineKt;->spring$default(FFLjava/lang/Object;I)Landroidx/compose/animation/core/SpringSpec;

    .line 43
    move-result-object v0

    .line 44
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 47
    :cond_2e
    move-object p1, v0

    .line 48
    check-cast p1, Landroidx/compose/animation/core/SpringSpec;

    .line 50
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 53
    :goto_34
    move-object v4, p1

    .line 54
    goto :goto_40

    .line 55
    :cond_36
    const v0, 0x44331ae5

    .line 58
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 61
    invoke-virtual {p2, p3}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 64
    goto :goto_34

    .line 65
    :goto_40
    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 68
    move-result-object v2

    .line 69
    sget-object v3, Landroidx/compose/animation/core/ArcSplineKt;->FloatToVector:Landroidx/compose/animation/core/TwoWayConverterImpl;

    .line 71
    invoke-static {v1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    .line 74
    move-result-object v5

    .line 75
    const/4 v8, 0x0

    .line 76
    const/4 v9, 0x0

    .line 77
    const-string v6, "FloatAnimation"

    .line 79
    move-object v7, p2

    .line 80
    invoke-static/range {v2 .. v9}, Landroidx/compose/animation/core/AnimateAsStateKt;->animateValueAsState(Ljava/lang/Object;Landroidx/compose/animation/core/TwoWayConverterImpl;Landroidx/compose/animation/core/AnimationSpec;Ljava/lang/Float;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;II)Landroidx/compose/runtime/State;

    .line 83
    move-result-object p0

    .line 84
    return-object p0
.end method

.method public static final animateValueAsState(Ljava/lang/Object;Landroidx/compose/animation/core/TwoWayConverterImpl;Landroidx/compose/animation/core/AnimationSpec;Ljava/lang/Float;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;II)Landroidx/compose/runtime/State;
    .registers 16

    .line 1
    and-int/lit8 p4, p7, 0x8

    .line 3
    const/4 p6, 0x0

    .line 4
    if-eqz p4, :cond_6

    .line 6
    move-object p3, p6

    .line 7
    :cond_6
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 10
    move-result-object p4

    .line 11
    sget-object p7, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 13
    if-ne p4, p7, :cond_15

    .line 15
    invoke-static {p6}, Landroidx/compose/runtime/Updater;->mutableStateOf$default(Ljava/lang/Object;)Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 18
    move-result-object p4

    .line 19
    invoke-virtual {p5, p4}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 22
    :cond_15
    check-cast p4, Landroidx/compose/runtime/MutableState;

    .line 24
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 27
    move-result-object v0

    .line 28
    if-ne v0, p7, :cond_25

    .line 30
    new-instance v0, Landroidx/compose/animation/core/Animatable;

    .line 32
    invoke-direct {v0, p0, p1, p3}, Landroidx/compose/animation/core/Animatable;-><init>(Ljava/lang/Object;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/Object;)V

    .line 35
    invoke-virtual {p5, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 38
    :cond_25
    move-object v3, v0

    .line 39
    check-cast v3, Landroidx/compose/animation/core/Animatable;

    .line 41
    invoke-static {p6, p5}, Landroidx/compose/runtime/Updater;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/runtime/MutableState;

    .line 44
    move-result-object v5

    .line 45
    if-eqz p3, :cond_47

    .line 47
    instance-of p1, p2, Landroidx/compose/animation/core/SpringSpec;

    .line 49
    if-eqz p1, :cond_47

    .line 51
    move-object p1, p2

    .line 52
    check-cast p1, Landroidx/compose/animation/core/SpringSpec;

    .line 54
    iget-object v0, p1, Landroidx/compose/animation/core/SpringSpec;->visibilityThreshold:Ljava/lang/Object;

    .line 56
    invoke-static {v0, p3}, Lkotlin/jvm/internal/Intrinsics;->areEqual(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 59
    move-result v0

    .line 60
    if-nez v0, :cond_47

    .line 62
    iget p2, p1, Landroidx/compose/animation/core/SpringSpec;->dampingRatio:F

    .line 64
    iget p1, p1, Landroidx/compose/animation/core/SpringSpec;->stiffness:F

    .line 66
    new-instance v0, Landroidx/compose/animation/core/SpringSpec;

    .line 68
    invoke-direct {v0, p2, p1, p3}, Landroidx/compose/animation/core/SpringSpec;-><init>(FFLjava/lang/Object;)V

    .line 71
    move-object p2, v0

    .line 72
    :cond_47
    invoke-static {p2, p5}, Landroidx/compose/runtime/Updater;->rememberUpdatedState(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/runtime/MutableState;

    .line 75
    move-result-object v4

    .line 76
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 79
    move-result-object p1

    .line 80
    if-ne p1, p7, :cond_5a

    .line 82
    const/4 p1, -0x1

    .line 83
    const/4 p2, 0x6

    .line 84
    invoke-static {p1, p2, p6}, Lkotlinx/coroutines/channels/ChannelKt;->Channel$default(IILkotlinx/coroutines/channels/BufferOverflow;)Lkotlinx/coroutines/channels/BufferedChannel;

    .line 87
    move-result-object p1

    .line 88
    invoke-virtual {p5, p1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 91
    :cond_5a
    move-object v2, p1

    .line 92
    check-cast v2, Lkotlinx/coroutines/channels/Channel;

    .line 94
    invoke-virtual {p5, v2}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 97
    move-result p1

    .line 98
    invoke-virtual {p5, p0}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 101
    move-result p2

    .line 102
    or-int/2addr p1, p2

    .line 103
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 106
    move-result-object p2

    .line 107
    if-nez p1, :cond_6e

    .line 109
    if-ne p2, p7, :cond_77

    .line 111
    :cond_6e
    new-instance p2, Landroidx/compose/runtime/Recomposer$$ExternalSyntheticLambda6;

    .line 113
    const/4 p1, 0x2

    .line 114
    invoke-direct {p2, p1, v2, p0}, Landroidx/compose/runtime/Recomposer$$ExternalSyntheticLambda6;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 117
    invoke-virtual {p5, p2}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 120
    :cond_77
    check-cast p2, Lkotlin/jvm/functions/Function0;

    .line 122
    invoke-static {p2, p5}, Landroidx/compose/runtime/Updater;->SideEffect(Lkotlin/jvm/functions/Function0;Landroidx/compose/runtime/GapComposer;)V

    .line 125
    invoke-virtual {p5, v2}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 128
    move-result p0

    .line 129
    invoke-virtual {p5, v3}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 132
    move-result p1

    .line 133
    or-int/2addr p0, p1

    .line 134
    invoke-virtual {p5, v4}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 137
    move-result p1

    .line 138
    or-int/2addr p0, p1

    .line 139
    invoke-virtual {p5, v5}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 142
    move-result p1

    .line 143
    or-int/2addr p0, p1

    .line 144
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 147
    move-result-object p1

    .line 148
    if-nez p0, :cond_97

    .line 150
    if-ne p1, p7, :cond_a2

    .line 152
    :cond_97
    new-instance v1, Landroidx/compose/animation/core/MutatorMutex$mutate$2;

    .line 154
    const/4 v6, 0x0

    .line 155
    const/4 v7, 0x1

    .line 156
    invoke-direct/range {v1 .. v7}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 159
    invoke-virtual {p5, v1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 162
    move-object p1, v1

    .line 163
    :cond_a2
    check-cast p1, Lkotlin/jvm/functions/Function2;

    .line 165
    invoke-static {p5, v2, p1}, Landroidx/compose/runtime/Updater;->LaunchedEffect(Landroidx/compose/runtime/GapComposer;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)V

    .line 168
    invoke-interface {p4}, Landroidx/compose/runtime/State;->getValue()Ljava/lang/Object;

    .line 171
    move-result-object p0

    .line 172
    check-cast p0, Landroidx/compose/runtime/State;

    .line 174
    if-nez p0, :cond_b1

    .line 176
    iget-object p0, v3, Landroidx/compose/animation/core/Animatable;->internalState:Landroidx/compose/animation/core/AnimationState;

    .line 178
    :cond_b1
    return-object p0
.end method
