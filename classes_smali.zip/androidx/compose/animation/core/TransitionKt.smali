.class public abstract Landroidx/compose/animation/core/TransitionKt;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# static fields
.field public static final SeekableStateObserver$delegate:Lkotlin/Lazy;

.field public static final SeekableTransitionStateTotalDurationChanged:Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;


# direct methods
.method static constructor <clinit>()V
    .registers 2

    .line 1
    new-instance v0, Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;

    .line 3
    const/4 v1, 0x3

    .line 4
    invoke-direct {v0, v1}, Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;-><init>(I)V

    .line 7
    sput-object v0, Landroidx/compose/animation/core/TransitionKt;->SeekableTransitionStateTotalDurationChanged:Landroidx/compose/foundation/ImageKt$$ExternalSyntheticLambda0;

    .line 9
    new-instance v0, Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda6;

    .line 11
    const/4 v1, 0x5

    .line 12
    invoke-direct {v0, v1}, Landroidx/compose/material3/AppBarKt$$ExternalSyntheticLambda6;-><init>(I)V

    .line 15
    sget-object v1, Lkotlin/LazyThreadSafetyMode;->NONE:Lkotlin/LazyThreadSafetyMode;

    .line 17
    invoke-static {v1, v0}, Lkotlin/ResultKt;->lazy(Lkotlin/LazyThreadSafetyMode;Lkotlin/jvm/functions/Function0;)Lkotlin/Lazy;

    .line 20
    move-result-object v0

    .line 21
    sput-object v0, Landroidx/compose/animation/core/TransitionKt;->SeekableStateObserver$delegate:Lkotlin/Lazy;

    .line 23
    return-void
.end method

.method public static final UpdateInitialAndTargetValues(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/Transition$TransitionAnimationState;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/SpringSpec;Landroidx/compose/runtime/GapComposer;I)V
    .registers 14

    .line 1
    const v0, 0x33ae021d

    .line 4
    invoke-virtual {p5, v0}, Landroidx/compose/runtime/GapComposer;->startRestartGroup(I)Landroidx/compose/runtime/GapComposer;

    .line 7
    and-int/lit8 v0, p6, 0x6

    .line 9
    if-nez v0, :cond_15

    .line 11
    invoke-virtual {p5, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 14
    move-result v0

    .line 15
    if-eqz v0, :cond_12

    .line 17
    const/4 v0, 0x4

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    const/4 v0, 0x2

    .line 20
    :goto_13
    or-int/2addr v0, p6

    .line 21
    goto :goto_16

    .line 22
    :cond_15
    move v0, p6

    .line 23
    :goto_16
    and-int/lit8 v1, p6, 0x30

    .line 25
    if-nez v1, :cond_26

    .line 27
    invoke-virtual {p5, p1}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 30
    move-result v1

    .line 31
    if-eqz v1, :cond_23

    .line 33
    const/16 v1, 0x20

    .line 35
    goto :goto_25

    .line 36
    :cond_23
    const/16 v1, 0x10

    .line 38
    :goto_25
    or-int/2addr v0, v1

    .line 39
    :cond_26
    and-int/lit16 v1, p6, 0x180

    .line 41
    if-nez v1, :cond_3f

    .line 43
    and-int/lit16 v1, p6, 0x200

    .line 45
    if-nez v1, :cond_33

    .line 47
    invoke-virtual {p5, p2}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 50
    move-result v1

    .line 51
    goto :goto_37

    .line 52
    :cond_33
    invoke-virtual {p5, p2}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 55
    move-result v1

    .line 56
    :goto_37
    if-eqz v1, :cond_3c

    .line 58
    const/16 v1, 0x100

    .line 60
    goto :goto_3e

    .line 61
    :cond_3c
    const/16 v1, 0x80

    .line 63
    :goto_3e
    or-int/2addr v0, v1

    .line 64
    :cond_3f
    and-int/lit16 v1, p6, 0xc00

    .line 66
    if-nez v1, :cond_58

    .line 68
    and-int/lit16 v1, p6, 0x1000

    .line 70
    if-nez v1, :cond_4c

    .line 72
    invoke-virtual {p5, p3}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 75
    move-result v1

    .line 76
    goto :goto_50

    .line 77
    :cond_4c
    invoke-virtual {p5, p3}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 80
    move-result v1

    .line 81
    :goto_50
    if-eqz v1, :cond_55

    .line 83
    const/16 v1, 0x800

    .line 85
    goto :goto_57

    .line 86
    :cond_55
    const/16 v1, 0x400

    .line 88
    :goto_57
    or-int/2addr v0, v1

    .line 89
    :cond_58
    and-int/lit16 v1, p6, 0x6000

    .line 91
    if-nez v1, :cond_73

    .line 93
    const v1, 0x8000

    .line 96
    and-int/2addr v1, p6

    .line 97
    if-nez v1, :cond_67

    .line 99
    invoke-virtual {p5, p4}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 102
    move-result v1

    .line 103
    goto :goto_6b

    .line 104
    :cond_67
    invoke-virtual {p5, p4}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 107
    move-result v1

    .line 108
    :goto_6b
    if-eqz v1, :cond_70

    .line 110
    const/16 v1, 0x4000

    .line 112
    goto :goto_72

    .line 113
    :cond_70
    const/16 v1, 0x2000

    .line 115
    :goto_72
    or-int/2addr v0, v1

    .line 116
    :cond_73
    and-int/lit16 v1, v0, 0x2493

    .line 118
    const/16 v2, 0x2492

    .line 120
    const/4 v3, 0x1

    .line 121
    if-eq v1, v2, :cond_7c

    .line 123
    move v1, v3

    .line 124
    goto :goto_7d

    .line 125
    :cond_7c
    const/4 v1, 0x0

    .line 126
    :goto_7d
    and-int/2addr v0, v3

    .line 127
    invoke-virtual {p5, v0, v1}, Landroidx/compose/runtime/GapComposer;->shouldExecute(IZ)Z

    .line 130
    move-result v0

    .line 131
    if-eqz v0, :cond_92

    .line 133
    invoke-virtual {p0}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 136
    move-result v0

    .line 137
    if-eqz v0, :cond_8e

    .line 139
    invoke-virtual {p1, p2, p3, p4}, Landroidx/compose/animation/core/Transition$TransitionAnimationState;->updateInitialAndTargetValue$animation_core(Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/FiniteAnimationSpec;)V

    .line 142
    goto :goto_95

    .line 143
    :cond_8e
    invoke-virtual {p1, p3, p4}, Landroidx/compose/animation/core/Transition$TransitionAnimationState;->updateTargetValue$animation_core(Ljava/lang/Object;Landroidx/compose/animation/core/FiniteAnimationSpec;)V

    .line 146
    goto :goto_95

    .line 147
    :cond_92
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->skipToGroupEnd()V

    .line 150
    :goto_95
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->endRestartGroup()Landroidx/compose/runtime/RecomposeScopeImpl;

    .line 153
    move-result-object p5

    .line 154
    if-eqz p5, :cond_a8

    .line 156
    new-instance v0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;

    .line 158
    move-object v1, p0

    .line 159
    move-object v2, p1

    .line 160
    move-object v3, p2

    .line 161
    move-object v4, p3

    .line 162
    move-object v5, p4

    .line 163
    move v6, p6

    .line 164
    invoke-direct/range {v0 .. v6}, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;-><init>(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/Transition$TransitionAnimationState;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/SpringSpec;I)V

    .line 167
    iput-object v0, p5, Landroidx/compose/runtime/RecomposeScopeImpl;->block:Lkotlin/jvm/functions/Function2;

    .line 169
    :cond_a8
    return-void
.end method

.method public static final createDeferredAnimation(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;II)Landroidx/compose/animation/core/Transition$DeferredAnimation;
    .registers 7

    .line 1
    and-int/lit8 p4, p5, 0x2

    .line 3
    if-eqz p4, :cond_6

    .line 5
    const-string p2, "DeferredAnimation"

    .line 7
    :cond_6
    invoke-virtual {p3, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 10
    move-result p4

    .line 11
    invoke-virtual {p3}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 14
    move-result-object p5

    .line 15
    sget-object v0, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 17
    if-nez p4, :cond_14

    .line 19
    if-ne p5, v0, :cond_1c

    .line 21
    :cond_14
    new-instance p5, Landroidx/compose/animation/core/Transition$DeferredAnimation;

    .line 23
    invoke-direct {p5, p0, p1, p2}, Landroidx/compose/animation/core/Transition$DeferredAnimation;-><init>(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/TwoWayConverterImpl;Ljava/lang/String;)V

    .line 26
    invoke-virtual {p3, p5}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 29
    :cond_1c
    check-cast p5, Landroidx/compose/animation/core/Transition$DeferredAnimation;

    .line 31
    invoke-virtual {p3, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 34
    move-result p1

    .line 35
    invoke-virtual {p3, p5}, Landroidx/compose/runtime/GapComposer;->changedInstance(Ljava/lang/Object;)Z

    .line 38
    move-result p2

    .line 39
    or-int/2addr p1, p2

    .line 40
    invoke-virtual {p3}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 43
    move-result-object p2

    .line 44
    if-nez p1, :cond_2f

    .line 46
    if-ne p2, v0, :cond_38

    .line 48
    :cond_2f
    new-instance p2, Landroidx/compose/material3/ScaffoldKt$$ExternalSyntheticLambda3;

    .line 50
    const/4 p1, 0x6

    .line 51
    invoke-direct {p2, p1, p0, p5}, Landroidx/compose/material3/ScaffoldKt$$ExternalSyntheticLambda3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 54
    invoke-virtual {p3, p2}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 57
    :cond_38
    check-cast p2, Lkotlin/jvm/functions/Function1;

    .line 59
    invoke-static {p5, p2, p3}, Landroidx/compose/runtime/Updater;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;)V

    .line 62
    invoke-virtual {p0}, Landroidx/compose/animation/core/Transition;->isSeeking()Z

    .line 65
    move-result p0

    .line 66
    if-eqz p0, :cond_7c

    .line 68
    iget-object p0, p5, Landroidx/compose/animation/core/Transition$DeferredAnimation;->data$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 70
    invoke-virtual {p0}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 73
    move-result-object p0

    .line 74
    check-cast p0, Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;

    .line 76
    if-eqz p0, :cond_7c

    .line 78
    iget-object p1, p5, Landroidx/compose/animation/core/Transition$DeferredAnimation;->this$0:Landroidx/compose/animation/core/Transition;

    .line 80
    iget-object p2, p0, Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;->animation:Landroidx/compose/animation/core/Transition$TransitionAnimationState;

    .line 82
    iget-object p3, p0, Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;->targetValueByState:Lkotlin/jvm/functions/Function1;

    .line 84
    invoke-virtual {p1}, Landroidx/compose/animation/core/Transition;->getSegment()Landroidx/compose/animation/core/Transition$Segment;

    .line 87
    move-result-object p4

    .line 88
    invoke-interface {p4}, Landroidx/compose/animation/core/Transition$Segment;->getInitialState()Ljava/lang/Object;

    .line 91
    move-result-object p4

    .line 92
    invoke-interface {p3, p4}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 95
    move-result-object p3

    .line 96
    iget-object p4, p0, Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;->targetValueByState:Lkotlin/jvm/functions/Function1;

    .line 98
    invoke-virtual {p1}, Landroidx/compose/animation/core/Transition;->getSegment()Landroidx/compose/animation/core/Transition$Segment;

    .line 101
    move-result-object v0

    .line 102
    invoke-interface {v0}, Landroidx/compose/animation/core/Transition$Segment;->getTargetState()Ljava/lang/Object;

    .line 105
    move-result-object v0

    .line 106
    invoke-interface {p4, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 109
    move-result-object p4

    .line 110
    iget-object p0, p0, Landroidx/compose/animation/core/Transition$DeferredAnimation$DeferredAnimationData;->transitionSpec:Lkotlin/jvm/functions/Function1;

    .line 112
    invoke-virtual {p1}, Landroidx/compose/animation/core/Transition;->getSegment()Landroidx/compose/animation/core/Transition$Segment;

    .line 115
    move-result-object p1

    .line 116
    invoke-interface {p0, p1}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 119
    move-result-object p0

    .line 120
    check-cast p0, Landroidx/compose/animation/core/FiniteAnimationSpec;

    .line 122
    invoke-virtual {p2, p3, p4, p0}, Landroidx/compose/animation/core/Transition$TransitionAnimationState;->updateInitialAndTargetValue$animation_core(Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/FiniteAnimationSpec;)V

    .line 125
    :cond_7c
    return-object p5
.end method

.method public static final createTransitionAnimation(Landroidx/compose/animation/core/Transition;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/SpringSpec;Landroidx/compose/animation/core/TwoWayConverterImpl;Landroidx/compose/runtime/GapComposer;)Landroidx/compose/animation/core/Transition$TransitionAnimationState;
    .registers 16

    .line 1
    invoke-virtual {p5, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 4
    move-result v0

    .line 5
    invoke-virtual {p5}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 8
    move-result-object v1

    .line 9
    sget-object v2, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 11
    if-nez v0, :cond_e

    .line 13
    if-ne v1, v2, :cond_37

    .line 15
    :cond_e
    invoke-static {}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->getCurrentThreadSnapshot()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 18
    move-result-object v1

    .line 19
    if-eqz v1, :cond_1a

    .line 21
    invoke-virtual {v1}, Landroidx/compose/runtime/snapshots/Snapshot;->getReadObserver()Lkotlin/jvm/functions/Function1;

    .line 24
    move-result-object v0

    .line 25
    :goto_18
    move-object v3, v0

    .line 26
    goto :goto_1c

    .line 27
    :cond_1a
    const/4 v0, 0x0

    .line 28
    goto :goto_18

    .line 29
    :goto_1c
    invoke-static {v1}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->makeCurrentNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;)Landroidx/compose/runtime/snapshots/Snapshot;

    .line 32
    move-result-object v4

    .line 33
    :try_start_20
    new-instance v0, Landroidx/compose/animation/core/Transition$TransitionAnimationState;

    .line 35
    iget-object v5, p4, Landroidx/compose/animation/core/TwoWayConverterImpl;->convertToVector:Lkotlin/jvm/functions/Function1;

    .line 37
    invoke-interface {v5, p2}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 40
    move-result-object v5

    .line 41
    check-cast v5, Landroidx/compose/animation/core/AnimationVector;

    .line 43
    invoke-virtual {v5}, Landroidx/compose/animation/core/AnimationVector;->reset$animation_core()V

    .line 46
    invoke-direct {v0, p0, p1, v5, p4}, Landroidx/compose/animation/core/Transition$TransitionAnimationState;-><init>(Landroidx/compose/animation/core/Transition;Ljava/lang/Object;Landroidx/compose/animation/core/AnimationVector;Landroidx/compose/animation/core/TwoWayConverterImpl;)V
    :try_end_30
    .catchall {:try_start_20 .. :try_end_30} :catchall_63

    .line 49
    invoke-static {v1, v4, v3}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->restoreNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;Lkotlin/jvm/functions/Function1;)V

    .line 52
    invoke-virtual {p5, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 55
    move-object v1, v0

    .line 56
    :cond_37
    move-object v4, v1

    .line 57
    check-cast v4, Landroidx/compose/animation/core/Transition$TransitionAnimationState;

    .line 59
    const/4 v9, 0x0

    .line 60
    move-object v3, p0

    .line 61
    move-object v5, p1

    .line 62
    move-object v6, p2

    .line 63
    move-object v7, p3

    .line 64
    move-object v8, p5

    .line 65
    invoke-static/range {v3 .. v9}, Landroidx/compose/animation/core/TransitionKt;->UpdateInitialAndTargetValues(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/Transition$TransitionAnimationState;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/SpringSpec;Landroidx/compose/runtime/GapComposer;I)V

    .line 68
    invoke-virtual {v8, v3}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 71
    move-result p0

    .line 72
    invoke-virtual {v8, v4}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 75
    move-result p1

    .line 76
    or-int/2addr p0, p1

    .line 77
    invoke-virtual {v8}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 80
    move-result-object p1

    .line 81
    if-nez p0, :cond_54

    .line 83
    if-ne p1, v2, :cond_5d

    .line 85
    :cond_54
    new-instance p1, Landroidx/compose/material3/ScaffoldKt$$ExternalSyntheticLambda3;

    .line 87
    const/4 p0, 0x4

    .line 88
    invoke-direct {p1, p0, v3, v4}, Landroidx/compose/material3/ScaffoldKt$$ExternalSyntheticLambda3;-><init>(ILjava/lang/Object;Ljava/lang/Object;)V

    .line 91
    invoke-virtual {v8, p1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 94
    :cond_5d
    check-cast p1, Lkotlin/jvm/functions/Function1;

    .line 96
    invoke-static {v4, p1, v8}, Landroidx/compose/runtime/Updater;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;)V

    .line 99
    return-object v4

    .line 100
    :catchall_63
    move-exception v0

    .line 101
    move-object p0, v0

    .line 102
    invoke-static {v1, v4, v3}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->restoreNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;Lkotlin/jvm/functions/Function1;)V

    .line 105
    throw p0
.end method

.method public static final rememberTransition(Landroidx/compose/animation/core/TransitionState;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;I)Landroidx/compose/animation/core/Transition;
    .registers 13

    .line 1
    and-int/lit8 p3, p3, 0xe

    .line 3
    xor-int/lit8 p3, p3, 0x6

    .line 5
    const/4 v0, 0x1

    .line 6
    const/4 v1, 0x4

    .line 7
    const/4 v2, 0x0

    .line 8
    if-le p3, v1, :cond_12

    .line 10
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 13
    move-result v3

    .line 14
    if-nez v3, :cond_10

    .line 16
    goto :goto_12

    .line 17
    :cond_10
    move v3, v0

    .line 18
    goto :goto_13

    .line 19
    :cond_12
    :goto_12
    move v3, v2

    .line 20
    :goto_13
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 23
    move-result-object v4

    .line 24
    sget-object v5, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 26
    const/4 v6, 0x0

    .line 27
    if-nez v3, :cond_1e

    .line 29
    if-ne v4, v5, :cond_3a

    .line 31
    :cond_1e
    invoke-static {}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->getCurrentThreadSnapshot()Landroidx/compose/runtime/snapshots/Snapshot;

    .line 34
    move-result-object v3

    .line 35
    if-eqz v3, :cond_29

    .line 37
    invoke-virtual {v3}, Landroidx/compose/runtime/snapshots/Snapshot;->getReadObserver()Lkotlin/jvm/functions/Function1;

    .line 40
    move-result-object v4

    .line 41
    goto :goto_2a

    .line 42
    :cond_29
    move-object v4, v6

    .line 43
    :goto_2a
    invoke-static {v3}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->makeCurrentNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;)Landroidx/compose/runtime/snapshots/Snapshot;

    .line 46
    move-result-object v7

    .line 47
    :try_start_2e
    new-instance v8, Landroidx/compose/animation/core/Transition;

    .line 49
    invoke-direct {v8, p0, v6, p1}, Landroidx/compose/animation/core/Transition;-><init>(Landroidx/compose/animation/core/TransitionState;Landroidx/compose/animation/core/Transition;Ljava/lang/String;)V
    :try_end_33
    .catchall {:try_start_2e .. :try_end_33} :catchall_a5

    .line 52
    invoke-static {v3, v7, v4}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->restoreNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;Lkotlin/jvm/functions/Function1;)V

    .line 55
    invoke-virtual {p2, v8}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 58
    move-object v4, v8

    .line 59
    :cond_3a
    check-cast v4, Landroidx/compose/animation/core/Transition;

    .line 61
    instance-of p1, p0, Landroidx/compose/animation/core/SeekableTransitionState;

    .line 63
    if-eqz p1, :cond_7b

    .line 65
    const p1, -0x50eb7237

    .line 68
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 71
    move-object p1, p0

    .line 72
    check-cast p1, Landroidx/compose/animation/core/SeekableTransitionState;

    .line 74
    iget-object v3, p1, Landroidx/compose/animation/core/SeekableTransitionState;->currentState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 76
    invoke-virtual {v3}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 79
    move-result-object v3

    .line 80
    iget-object p1, p1, Landroidx/compose/animation/core/SeekableTransitionState;->targetState$delegate:Landroidx/compose/runtime/ParcelableSnapshotMutableState;

    .line 82
    invoke-virtual {p1}, Landroidx/compose/runtime/ParcelableSnapshotMutableState;->getValue()Ljava/lang/Object;

    .line 85
    move-result-object p1

    .line 86
    if-le p3, v1, :cond_60

    .line 88
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 91
    move-result p3

    .line 92
    if-nez p3, :cond_5e

    .line 94
    goto :goto_60

    .line 95
    :cond_5e
    move p3, v0

    .line 96
    goto :goto_61

    .line 97
    :cond_60
    :goto_60
    move p3, v2

    .line 98
    :goto_61
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 101
    move-result-object v1

    .line 102
    if-nez p3, :cond_69

    .line 104
    if-ne v1, v5, :cond_72

    .line 106
    :cond_69
    new-instance v1, Landroidx/datastore/core/DataStoreImpl$data$1;

    .line 108
    const/4 p3, 0x2

    .line 109
    invoke-direct {v1, p0, v6, p3}, Landroidx/datastore/core/DataStoreImpl$data$1;-><init>(Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 112
    invoke-virtual {p2, v1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 115
    :cond_72
    check-cast v1, Lkotlin/jvm/functions/Function2;

    .line 117
    invoke-static {v3, p1, v1, p2}, Landroidx/compose/runtime/Updater;->LaunchedEffect(Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Landroidx/compose/runtime/GapComposer;)V

    .line 120
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 123
    goto :goto_8b

    .line 124
    :cond_7b
    const p1, -0x50e46740

    .line 127
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->startReplaceGroup(I)V

    .line 130
    invoke-virtual {p0}, Landroidx/compose/animation/core/TransitionState;->getTargetState()Ljava/lang/Object;

    .line 133
    move-result-object p0

    .line 134
    invoke-virtual {v4, p0, p2, v2}, Landroidx/compose/animation/core/Transition;->animateTo$animation_core(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;I)V

    .line 137
    invoke-virtual {p2, v2}, Landroidx/compose/runtime/GapComposer;->end(Z)V

    .line 140
    :goto_8b
    invoke-virtual {p2, v4}, Landroidx/compose/runtime/GapComposer;->changed(Ljava/lang/Object;)Z

    .line 143
    move-result p0

    .line 144
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 147
    move-result-object p1

    .line 148
    if-nez p0, :cond_97

    .line 150
    if-ne p1, v5, :cond_9f

    .line 152
    :cond_97
    new-instance p1, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda0;

    .line 154
    invoke-direct {p1, v4, v0}, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/animation/core/Transition;I)V

    .line 157
    invoke-virtual {p2, p1}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 160
    :cond_9f
    check-cast p1, Lkotlin/jvm/functions/Function1;

    .line 162
    invoke-static {v4, p1, p2}, Landroidx/compose/runtime/Updater;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;)V

    .line 165
    return-object v4

    .line 166
    :catchall_a5
    move-exception p0

    .line 167
    invoke-static {v3, v7, v4}, Landroidx/compose/runtime/snapshots/SnapshotId_jvmKt;->restoreNonObservable(Landroidx/compose/runtime/snapshots/Snapshot;Landroidx/compose/runtime/snapshots/Snapshot;Lkotlin/jvm/functions/Function1;)V

    .line 170
    throw p0
.end method

.method public static final updateTransition(Ljava/lang/Object;Ljava/lang/String;Landroidx/compose/runtime/GapComposer;I)Landroidx/compose/animation/core/Transition;
    .registers 8

    .line 1
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 4
    move-result-object v0

    .line 5
    sget-object v1, Landroidx/compose/runtime/Composer$Companion;->Empty:Landroidx/compose/runtime/NeverEqualPolicy;

    .line 7
    if-ne v0, v1, :cond_16

    .line 9
    new-instance v0, Landroidx/compose/animation/core/Transition;

    .line 11
    new-instance v2, Landroidx/compose/animation/core/MutableTransitionState;

    .line 13
    invoke-direct {v2, p0}, Landroidx/compose/animation/core/MutableTransitionState;-><init>(Ljava/lang/Object;)V

    .line 16
    const/4 v3, 0x0

    .line 17
    invoke-direct {v0, v2, v3, p1}, Landroidx/compose/animation/core/Transition;-><init>(Landroidx/compose/animation/core/TransitionState;Landroidx/compose/animation/core/Transition;Ljava/lang/String;)V

    .line 20
    invoke-virtual {p2, v0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 23
    :cond_16
    check-cast v0, Landroidx/compose/animation/core/Transition;

    .line 25
    and-int/lit8 p1, p3, 0x8

    .line 27
    or-int/lit8 p1, p1, 0x30

    .line 29
    and-int/lit8 p3, p3, 0xe

    .line 31
    or-int/2addr p1, p3

    .line 32
    invoke-virtual {v0, p0, p2, p1}, Landroidx/compose/animation/core/Transition;->animateTo$animation_core(Ljava/lang/Object;Landroidx/compose/runtime/GapComposer;I)V

    .line 35
    invoke-virtual {p2}, Landroidx/compose/runtime/GapComposer;->rememberedValue()Ljava/lang/Object;

    .line 38
    move-result-object p0

    .line 39
    if-ne p0, v1, :cond_31

    .line 41
    new-instance p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda0;

    .line 43
    const/4 p1, 0x0

    .line 44
    invoke-direct {p0, v0, p1}, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda0;-><init>(Landroidx/compose/animation/core/Transition;I)V

    .line 47
    invoke-virtual {p2, p0}, Landroidx/compose/runtime/GapComposer;->updateRememberedValue(Ljava/lang/Object;)V

    .line 50
    :cond_31
    check-cast p0, Lkotlin/jvm/functions/Function1;

    .line 52
    invoke-static {v0, p0, p2}, Landroidx/compose/runtime/Updater;->DisposableEffect(Ljava/lang/Object;Lkotlin/jvm/functions/Function1;Landroidx/compose/runtime/GapComposer;)V

    .line 55
    return-object v0
.end method
