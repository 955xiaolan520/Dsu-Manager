.class public final synthetic Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic f$0:Landroidx/compose/animation/core/Transition;

.field public final synthetic f$1:Landroidx/compose/animation/core/Transition$TransitionAnimationState;

.field public final synthetic f$2:Ljava/lang/Object;

.field public final synthetic f$3:Ljava/lang/Object;

.field public final synthetic f$4:Landroidx/compose/animation/core/SpringSpec;

.field public final synthetic f$5:I


# direct methods
.method public synthetic constructor <init>(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/Transition$TransitionAnimationState;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/SpringSpec;I)V
    .registers 7

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    iput-object p1, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$0:Landroidx/compose/animation/core/Transition;

    .line 6
    iput-object p2, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$1:Landroidx/compose/animation/core/Transition$TransitionAnimationState;

    .line 8
    iput-object p3, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$2:Ljava/lang/Object;

    .line 10
    iput-object p4, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$3:Ljava/lang/Object;

    .line 12
    iput-object p5, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$4:Landroidx/compose/animation/core/SpringSpec;

    .line 14
    iput p6, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$5:I

    .line 16
    return-void
.end method


# virtual methods
.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 10

    .line 1
    move-object v5, p1

    .line 2
    check-cast v5, Landroidx/compose/runtime/GapComposer;

    .line 4
    check-cast p2, Ljava/lang/Integer;

    .line 6
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 9
    iget p1, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$5:I

    .line 11
    or-int/lit8 p1, p1, 0x1

    .line 13
    invoke-static {p1}, Landroidx/compose/runtime/Updater;->updateChangedFlags(I)I

    .line 16
    move-result v6

    .line 17
    iget-object v0, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$0:Landroidx/compose/animation/core/Transition;

    .line 19
    iget-object v1, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$1:Landroidx/compose/animation/core/Transition$TransitionAnimationState;

    .line 21
    iget-object v2, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$2:Ljava/lang/Object;

    .line 23
    iget-object v3, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$3:Ljava/lang/Object;

    .line 25
    iget-object v4, p0, Landroidx/compose/animation/core/TransitionKt$$ExternalSyntheticLambda2;->f$4:Landroidx/compose/animation/core/SpringSpec;

    .line 27
    invoke-static/range {v0 .. v6}, Landroidx/compose/animation/core/TransitionKt;->UpdateInitialAndTargetValues(Landroidx/compose/animation/core/Transition;Landroidx/compose/animation/core/Transition$TransitionAnimationState;Ljava/lang/Object;Ljava/lang/Object;Landroidx/compose/animation/core/SpringSpec;Landroidx/compose/runtime/GapComposer;I)V

    .line 30
    sget-object p0, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 32
    return-object p0
.end method
