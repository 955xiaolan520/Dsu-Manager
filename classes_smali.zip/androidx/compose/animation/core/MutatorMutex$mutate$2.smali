.class public final Landroidx/compose/animation/core/MutatorMutex$mutate$2;
.super Lkotlin/coroutines/jvm/internal/SuspendLambda;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Lkotlin/jvm/functions/Function2;


# instance fields
.field public final synthetic $block:Ljava/lang/Object;

.field public final synthetic $r8$classId:I

.field public synthetic L$0:Ljava/lang/Object;

.field public L$1:Ljava/lang/Object;

.field public L$2:Ljava/lang/Object;

.field public L$3:Ljava/lang/Object;

.field public label:I

.field public final synthetic this$0:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Landroidx/compose/animation/core/MutatorMutex;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V
    .registers 5

    const/4 v0, 0x0

    iput v0, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$r8$classId:I

    .line 16
    iput-object p1, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    iput-object p2, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p3}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    return-void
.end method

.method public synthetic constructor <init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V
    .registers 7

    .line 1
    iput p6, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$r8$classId:I

    .line 3
    iput-object p1, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 5
    iput-object p2, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 7
    iput-object p3, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 9
    iput-object p4, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 11
    const/4 p1, 0x2

    .line 12
    invoke-direct {p0, p1, p5}, Lkotlin/coroutines/jvm/internal/SuspendLambda;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 15
    return-void
.end method


# virtual methods
.method public final create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;
    .registers 14

    .line 1
    iget v0, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$r8$classId:I

    .line 3
    iget-object v1, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 5
    iget-object v2, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 7
    packed-switch v0, :pswitch_data_4a

    .line 10
    new-instance v3, Landroidx/compose/animation/core/MutatorMutex$mutate$2;

    .line 12
    iget-object p1, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 14
    move-object v4, p1

    .line 15
    check-cast v4, Landroidx/lifecycle/LifecycleRegistry;

    .line 17
    iget-object p0, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 19
    move-object v5, p0

    .line 20
    check-cast v5, Landroidx/lifecycle/Lifecycle$State;

    .line 22
    move-object v6, v2

    .line 23
    check-cast v6, Lkotlinx/coroutines/CoroutineScope;

    .line 25
    move-object v7, v1

    .line 26
    check-cast v7, Landroidx/compose/runtime/SnapshotStateKt__SnapshotFlowKt$collectAsState$1$1$2;

    .line 28
    const/4 v9, 0x2

    .line 29
    move-object v8, p2

    .line 30
    invoke-direct/range {v3 .. v9}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 33
    return-object v3

    .line 34
    :pswitch_21  #0x1
    move-object v8, p2

    .line 35
    new-instance v4, Landroidx/compose/animation/core/MutatorMutex$mutate$2;

    .line 37
    iget-object p2, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 39
    move-object v5, p2

    .line 40
    check-cast v5, Lkotlinx/coroutines/channels/Channel;

    .line 42
    iget-object p0, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 44
    move-object v6, p0

    .line 45
    check-cast v6, Landroidx/compose/animation/core/Animatable;

    .line 47
    move-object v7, v2

    .line 48
    check-cast v7, Landroidx/compose/runtime/MutableState;

    .line 50
    check-cast v1, Landroidx/compose/runtime/MutableState;

    .line 52
    const/4 v10, 0x1

    .line 53
    move-object v9, v8

    .line 54
    move-object v8, v1

    .line 55
    invoke-direct/range {v4 .. v10}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 58
    iput-object p1, v4, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 60
    return-object v4

    .line 61
    :pswitch_3c  #0x0
    move-object v8, p2

    .line 62
    new-instance p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;

    .line 64
    check-cast v2, Landroidx/compose/animation/core/MutatorMutex;

    .line 66
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 68
    invoke-direct {p0, v2, v1, v8}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;-><init>(Landroidx/compose/animation/core/MutatorMutex;Lkotlin/jvm/functions/Function1;Lkotlin/coroutines/Continuation;)V

    .line 71
    iput-object p1, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 73
    return-object p0

    nop

    .line 75
    :pswitch_data_4a
    .packed-switch 0x0
        :pswitch_3c  #00000000
        :pswitch_21  #00000001
    .end packed-switch
.end method

.method public final invoke(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .registers 5

    .line 1
    iget v0, p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$r8$classId:I

    .line 3
    sget-object v1, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 5
    check-cast p1, Lkotlinx/coroutines/CoroutineScope;

    .line 7
    check-cast p2, Lkotlin/coroutines/Continuation;

    .line 9
    packed-switch v0, :pswitch_data_2c

    .line 12
    invoke-virtual {p0, p1, p2}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 15
    move-result-object p0

    .line 16
    check-cast p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;

    .line 18
    invoke-virtual {p0, v1}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_16  #0x1
    invoke-virtual {p0, p1, p2}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 26
    move-result-object p0

    .line 27
    check-cast p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;

    .line 29
    invoke-virtual {p0, v1}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 32
    move-result-object p0

    .line 33
    return-object p0

    .line 34
    :pswitch_21  #0x0
    invoke-virtual {p0, p1, p2}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->create(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 37
    move-result-object p0

    .line 38
    check-cast p0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;

    .line 40
    invoke-virtual {p0, v1}, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;

    .line 43
    move-result-object p0

    .line 44
    return-object p0

    .line 45
    :pswitch_data_2c
    .packed-switch 0x0
        :pswitch_21  #00000000
        :pswitch_16  #00000001
    .end packed-switch
.end method

.method public final invokeSuspend(Ljava/lang/Object;)Ljava/lang/Object;
    .registers 23

    .line 1
    move-object/from16 v0, p0

    .line 3
    iget v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$r8$classId:I

    .line 5
    sget-object v2, Lkotlin/Unit;->INSTANCE:Lkotlin/Unit;

    .line 7
    const/4 v3, 0x2

    .line 8
    const/4 v4, 0x3

    .line 9
    iget-object v5, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->$block:Ljava/lang/Object;

    .line 11
    iget-object v6, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->this$0:Ljava/lang/Object;

    .line 13
    const-string v7, "call to \'resume\' before \'invoke\' with coroutine"

    .line 15
    sget-object v8, Lkotlin/coroutines/intrinsics/CoroutineSingletons;->COROUTINE_SUSPENDED:Lkotlin/coroutines/intrinsics/CoroutineSingletons;

    .line 17
    const/4 v9, 0x1

    .line 18
    const/4 v10, 0x0

    .line 19
    packed-switch v1, :pswitch_data_23e

    .line 22
    iget-object v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 24
    check-cast v1, Landroidx/lifecycle/LifecycleRegistry;

    .line 26
    iget v11, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->label:I

    .line 28
    if-eqz v11, :cond_36

    .line 30
    if-ne v11, v9, :cond_30

    .line 32
    iget-object v3, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 34
    check-cast v3, Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 36
    iget-object v0, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 38
    move-object v4, v0

    .line 39
    check-cast v4, Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 41
    :try_start_28
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_2b
    .catchall {:try_start_28 .. :try_end_2b} :catchall_2d

    .line 44
    goto/16 :goto_ba

    .line 46
    :catchall_2d
    move-exception v0

    .line 47
    goto/16 :goto_d0

    .line 49
    :cond_30
    invoke-static {v7}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 52
    move-object v2, v10

    .line 53
    goto/16 :goto_cc

    .line 55
    :cond_36
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 58
    iget-object v7, v1, Landroidx/lifecycle/LifecycleRegistry;->state:Landroidx/lifecycle/Lifecycle$State;

    .line 60
    sget-object v11, Landroidx/lifecycle/Lifecycle$State;->DESTROYED:Landroidx/lifecycle/Lifecycle$State;

    .line 62
    if-ne v7, v11, :cond_41

    .line 64
    goto/16 :goto_cc

    .line 66
    :cond_41
    new-instance v14, Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 68
    invoke-direct {v14}, Ljava/lang/Object;-><init>()V

    .line 71
    new-instance v7, Lkotlin/jvm/internal/Ref$ObjectRef;

    .line 73
    invoke-direct {v7}, Ljava/lang/Object;-><init>()V

    .line 76
    :try_start_4b
    iget-object v11, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 78
    check-cast v11, Landroidx/lifecycle/Lifecycle$State;

    .line 80
    move-object v15, v6

    .line 81
    check-cast v15, Lkotlinx/coroutines/CoroutineScope;

    .line 83
    move-object/from16 v19, v5

    .line 85
    check-cast v19, Landroidx/compose/runtime/SnapshotStateKt__SnapshotFlowKt$collectAsState$1$1$2;

    .line 87
    iput-object v14, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 89
    iput-object v7, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 91
    iput v9, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->label:I

    .line 93
    new-instance v5, Lkotlinx/coroutines/CancellableContinuationImpl;

    .line 95
    invoke-static {v0}, Lkotlin/io/CloseableKt;->intercepted(Lkotlin/coroutines/Continuation;)Lkotlin/coroutines/Continuation;

    .line 98
    move-result-object v0

    .line 99
    invoke-direct {v5, v9, v0}, Lkotlinx/coroutines/CancellableContinuationImpl;-><init>(ILkotlin/coroutines/Continuation;)V

    .line 102
    invoke-virtual {v5}, Lkotlinx/coroutines/CancellableContinuationImpl;->initCancellability()V

    .line 105
    sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->Companion:Landroidx/lifecycle/Lifecycle$Event$Companion;

    .line 107
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 110
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 113
    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    .line 116
    move-result v0

    .line 117
    const/4 v6, 0x4

    .line 118
    if-eq v0, v3, :cond_84

    .line 120
    if-eq v0, v4, :cond_81

    .line 122
    if-eq v0, v6, :cond_7d

    .line 124
    move-object v13, v10

    .line 125
    goto :goto_87

    .line 126
    :cond_7d
    sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_RESUME:Landroidx/lifecycle/Lifecycle$Event;

    .line 128
    :goto_7f
    move-object v13, v0

    .line 129
    goto :goto_87

    .line 130
    :cond_81
    sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_START:Landroidx/lifecycle/Lifecycle$Event;

    .line 132
    goto :goto_7f

    .line 133
    :cond_84
    sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_CREATE:Landroidx/lifecycle/Lifecycle$Event;

    .line 135
    goto :goto_7f

    .line 136
    :goto_87
    invoke-virtual {v11}, Ljava/lang/Enum;->ordinal()I

    .line 139
    move-result v0

    .line 140
    if-eq v0, v3, :cond_9c

    .line 142
    if-eq v0, v4, :cond_99

    .line 144
    if-eq v0, v6, :cond_94

    .line 146
    move-object/from16 v16, v10

    .line 148
    goto :goto_9f

    .line 149
    :cond_94
    sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_PAUSE:Landroidx/lifecycle/Lifecycle$Event;

    .line 151
    :goto_96
    move-object/from16 v16, v0

    .line 153
    goto :goto_9f

    .line 154
    :cond_99
    sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_STOP:Landroidx/lifecycle/Lifecycle$Event;

    .line 156
    goto :goto_96

    .line 157
    :cond_9c
    sget-object v0, Landroidx/lifecycle/Lifecycle$Event;->ON_DESTROY:Landroidx/lifecycle/Lifecycle$Event;

    .line 159
    goto :goto_96

    .line 160
    :goto_9f
    new-instance v18, Lkotlinx/coroutines/sync/MutexImpl;

    .line 162
    invoke-direct/range {v18 .. v18}, Lkotlinx/coroutines/sync/MutexImpl;-><init>()V

    .line 165
    new-instance v12, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;

    .line 167
    move-object/from16 v17, v5

    .line 169
    invoke-direct/range {v12 .. v19}, Landroidx/lifecycle/RepeatOnLifecycleKt$repeatOnLifecycle$3$1$1$1;-><init>(Landroidx/lifecycle/Lifecycle$Event;Lkotlin/jvm/internal/Ref$ObjectRef;Lkotlinx/coroutines/CoroutineScope;Landroidx/lifecycle/Lifecycle$Event;Lkotlinx/coroutines/CancellableContinuationImpl;Lkotlinx/coroutines/sync/MutexImpl;Landroidx/compose/runtime/SnapshotStateKt__SnapshotFlowKt$collectAsState$1$1$2;)V

    .line 172
    iput-object v12, v7, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 174
    invoke-virtual {v1, v12}, Landroidx/lifecycle/LifecycleRegistry;->addObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 177
    invoke-virtual/range {v17 .. v17}, Lkotlinx/coroutines/CancellableContinuationImpl;->getResult()Ljava/lang/Object;

    .line 180
    move-result-object v0
    :try_end_b4
    .catchall {:try_start_4b .. :try_end_b4} :catchall_cd

    .line 181
    if-ne v0, v8, :cond_b8

    .line 183
    move-object v2, v8

    .line 184
    goto :goto_cc

    .line 185
    :cond_b8
    move-object v3, v7

    .line 186
    move-object v4, v14

    .line 187
    :goto_ba
    iget-object v0, v4, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 189
    check-cast v0, Lkotlinx/coroutines/Job;

    .line 191
    if-eqz v0, :cond_c3

    .line 193
    invoke-interface {v0, v10}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 196
    :cond_c3
    iget-object v0, v3, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 198
    check-cast v0, Landroidx/lifecycle/LifecycleEventObserver;

    .line 200
    if-eqz v0, :cond_cc

    .line 202
    invoke-virtual {v1, v0}, Landroidx/lifecycle/LifecycleRegistry;->removeObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 205
    :cond_cc
    :goto_cc
    return-object v2

    .line 206
    :catchall_cd
    move-exception v0

    .line 207
    move-object v3, v7

    .line 208
    move-object v4, v14

    .line 209
    :goto_d0
    iget-object v2, v4, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 211
    check-cast v2, Lkotlinx/coroutines/Job;

    .line 213
    if-eqz v2, :cond_d9

    .line 215
    invoke-interface {v2, v10}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 218
    :cond_d9
    iget-object v2, v3, Lkotlin/jvm/internal/Ref$ObjectRef;->element:Ljava/lang/Object;

    .line 220
    check-cast v2, Landroidx/lifecycle/LifecycleEventObserver;

    .line 222
    if-eqz v2, :cond_e2

    .line 224
    invoke-virtual {v1, v2}, Landroidx/lifecycle/LifecycleRegistry;->removeObserver(Landroidx/lifecycle/LifecycleObserver;)V

    .line 227
    :cond_e2
    throw v0

    .line 228
    :pswitch_e3  #0x1
    iget-object v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 230
    check-cast v1, Lkotlinx/coroutines/channels/Channel;

    .line 232
    iget v3, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->label:I

    .line 234
    if-eqz v3, :cond_100

    .line 236
    if-ne v3, v9, :cond_fb

    .line 238
    iget-object v3, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 240
    check-cast v3, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 242
    iget-object v7, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 244
    check-cast v7, Lkotlinx/coroutines/CoroutineScope;

    .line 246
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 249
    move-object/from16 v11, p1

    .line 251
    goto :goto_11e

    .line 252
    :cond_fb
    invoke-static {v7}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 255
    move-object v2, v10

    .line 256
    goto :goto_153

    .line 257
    :cond_100
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 260
    iget-object v3, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 262
    check-cast v3, Lkotlinx/coroutines/CoroutineScope;

    .line 264
    invoke-interface {v1}, Lkotlinx/coroutines/channels/Channel;->iterator()Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;

    .line 267
    move-result-object v7

    .line 268
    move-object/from16 v20, v7

    .line 270
    move-object v7, v3

    .line 271
    move-object/from16 v3, v20

    .line 273
    :goto_110
    iput-object v7, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 275
    iput-object v3, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 277
    iput v9, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->label:I

    .line 279
    invoke-virtual {v3, v0}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;->hasNext(Lkotlin/coroutines/jvm/internal/ContinuationImpl;)Ljava/lang/Object;

    .line 282
    move-result-object v11

    .line 283
    if-ne v11, v8, :cond_11e

    .line 285
    move-object v2, v8

    .line 286
    goto :goto_153

    .line 287
    :cond_11e
    :goto_11e
    check-cast v11, Ljava/lang/Boolean;

    .line 289
    invoke-virtual {v11}, Ljava/lang/Boolean;->booleanValue()Z

    .line 292
    move-result v11

    .line 293
    if-eqz v11, :cond_153

    .line 295
    invoke-virtual {v3}, Lkotlinx/coroutines/channels/BufferedChannel$BufferedChannelIterator;->next()Ljava/lang/Object;

    .line 298
    move-result-object v11

    .line 299
    invoke-interface {v1}, Lkotlinx/coroutines/channels/Channel;->tryReceive-PtdJZtk()Ljava/lang/Object;

    .line 302
    move-result-object v12

    .line 303
    instance-of v13, v12, Lkotlinx/coroutines/channels/ChannelResult$Failed;

    .line 305
    if-nez v13, :cond_133

    .line 307
    goto :goto_134

    .line 308
    :cond_133
    move-object v12, v10

    .line 309
    :goto_134
    if-nez v12, :cond_138

    .line 311
    move-object v14, v11

    .line 312
    goto :goto_139

    .line 313
    :cond_138
    move-object v14, v12

    .line 314
    :goto_139
    new-instance v13, Landroidx/navigation/compose/NavHostKt$NavHost$29$1;

    .line 316
    iget-object v11, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 318
    move-object v15, v11

    .line 319
    check-cast v15, Landroidx/compose/animation/core/Animatable;

    .line 321
    move-object/from16 v16, v6

    .line 323
    check-cast v16, Landroidx/compose/runtime/MutableState;

    .line 325
    move-object/from16 v17, v5

    .line 327
    check-cast v17, Landroidx/compose/runtime/MutableState;

    .line 329
    const/16 v18, 0x0

    .line 331
    const/16 v19, 0x1

    .line 333
    invoke-direct/range {v13 .. v19}, Landroidx/navigation/compose/NavHostKt$NavHost$29$1;-><init>(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/coroutines/Continuation;I)V

    .line 336
    invoke-static {v7, v10, v13, v4}, Lkotlinx/coroutines/JobKt;->launch$default(Lkotlinx/coroutines/CoroutineScope;Lkotlin/coroutines/CoroutineContext;Lkotlin/jvm/functions/Function2;I)Lkotlinx/coroutines/StandaloneCoroutine;

    .line 339
    goto :goto_110

    .line 340
    :cond_153
    :goto_153
    return-object v2

    .line 341
    :pswitch_154  #0x0
    check-cast v6, Landroidx/compose/animation/core/MutatorMutex;

    .line 343
    iget v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->label:I

    .line 345
    if-eqz v1, :cond_190

    .line 347
    if-eq v1, v9, :cond_17b

    .line 349
    if-ne v1, v3, :cond_175

    .line 351
    iget-object v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 353
    check-cast v1, Landroidx/compose/animation/core/MutatorMutex;

    .line 355
    iget-object v2, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 357
    check-cast v2, Lkotlinx/coroutines/sync/MutexImpl;

    .line 359
    iget-object v0, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 361
    move-object v3, v0

    .line 362
    check-cast v3, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 364
    :try_start_16b
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V
    :try_end_16e
    .catchall {:try_start_16b .. :try_end_16e} :catchall_172

    .line 367
    move-object/from16 v0, p1

    .line 369
    goto/16 :goto_209

    .line 371
    :catchall_172
    move-exception v0

    .line 372
    goto/16 :goto_222

    .line 374
    :cond_175
    invoke-static {v7}, Lkotlin/math/MathKt$$ExternalSyntheticBUOutline0;->m$3(Ljava/lang/String;)V

    .line 377
    move-object v8, v10

    .line 378
    goto/16 :goto_21c

    .line 380
    :cond_17b
    iget-object v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 382
    move-object v6, v1

    .line 383
    check-cast v6, Landroidx/compose/animation/core/MutatorMutex;

    .line 385
    iget-object v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 387
    check-cast v1, Lkotlin/jvm/functions/Function1;

    .line 389
    iget-object v2, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 391
    check-cast v2, Lkotlinx/coroutines/sync/MutexImpl;

    .line 393
    iget-object v4, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 395
    check-cast v4, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 397
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 400
    goto :goto_1f6

    .line 401
    :cond_190
    invoke-static/range {p1 .. p1}, Lkotlin/ResultKt;->throwOnFailure(Ljava/lang/Object;)V

    .line 404
    iget-object v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 406
    check-cast v1, Lkotlinx/coroutines/CoroutineScope;

    .line 408
    new-instance v2, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 410
    invoke-interface {v1}, Lkotlinx/coroutines/CoroutineScope;->getCoroutineContext()Lkotlin/coroutines/CoroutineContext;

    .line 413
    move-result-object v1

    .line 414
    sget-object v4, Lkotlinx/coroutines/Job$Key;->$$INSTANCE:Lkotlinx/coroutines/Job$Key;

    .line 416
    invoke-interface {v1, v4}, Lkotlin/coroutines/CoroutineContext;->get(Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;

    .line 419
    move-result-object v1

    .line 420
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 423
    check-cast v1, Lkotlinx/coroutines/Job;

    .line 425
    invoke-direct {v2, v1}, Landroidx/compose/animation/core/MutatorMutex$Mutator;-><init>(Lkotlinx/coroutines/Job;)V

    .line 428
    iget-object v1, v6, Landroidx/compose/animation/core/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 430
    :goto_1ad
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 433
    move-result-object v4

    .line 434
    check-cast v4, Landroidx/compose/animation/core/MutatorMutex$Mutator;

    .line 436
    if-eqz v4, :cond_1c6

    .line 438
    sget-object v7, Landroidx/compose/animation/core/MutatePriority;->Default:Landroidx/compose/animation/core/MutatePriority;

    .line 440
    invoke-virtual {v7, v7}, Ljava/lang/Enum;->compareTo(Ljava/lang/Enum;)I

    .line 443
    move-result v7

    .line 444
    if-ltz v7, :cond_1be

    .line 446
    goto :goto_1c6

    .line 447
    :cond_1be
    new-instance v0, Ljava/util/concurrent/CancellationException;

    .line 449
    const-string v1, "Current mutation had a higher priority"

    .line 451
    invoke-direct {v0, v1}, Ljava/util/concurrent/CancellationException;-><init>(Ljava/lang/String;)V

    .line 454
    throw v0

    .line 455
    :cond_1c6
    :goto_1c6
    invoke-virtual {v1, v4, v2}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 458
    move-result v7

    .line 459
    if-eqz v7, :cond_236

    .line 461
    if-eqz v4, :cond_1da

    .line 463
    iget-object v1, v4, Landroidx/compose/animation/core/MutatorMutex$Mutator;->job:Lkotlinx/coroutines/Job;

    .line 465
    new-instance v4, Lkotlinx/coroutines/flow/internal/ChildCancelledException;

    .line 467
    const-string v7, "Mutation interrupted"

    .line 469
    invoke-direct {v4, v9, v7}, Lkotlinx/coroutines/flow/internal/ChildCancelledException;-><init>(ILjava/lang/String;)V

    .line 472
    invoke-interface {v1, v4}, Lkotlinx/coroutines/Job;->cancel(Ljava/util/concurrent/CancellationException;)V

    .line 475
    :cond_1da
    iget-object v1, v6, Landroidx/compose/animation/core/MutatorMutex;->mutex:Lkotlinx/coroutines/sync/MutexImpl;

    .line 477
    move-object v4, v5

    .line 478
    check-cast v4, Lkotlin/jvm/functions/Function1;

    .line 480
    iput-object v2, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 482
    iput-object v1, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 484
    iput-object v4, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 486
    iput-object v6, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 488
    iput v9, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->label:I

    .line 490
    invoke-virtual {v1, v0}, Lkotlinx/coroutines/sync/MutexImpl;->lock(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;

    .line 493
    move-result-object v5

    .line 494
    if-ne v5, v8, :cond_1f0

    .line 496
    goto :goto_21c

    .line 497
    :cond_1f0
    move-object/from16 v20, v2

    .line 499
    move-object v2, v1

    .line 500
    move-object v1, v4

    .line 501
    move-object/from16 v4, v20

    .line 503
    :goto_1f6
    :try_start_1f6
    iput-object v4, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$0:Ljava/lang/Object;

    .line 505
    iput-object v2, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$1:Ljava/lang/Object;

    .line 507
    iput-object v6, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$2:Ljava/lang/Object;

    .line 509
    iput-object v10, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->L$3:Ljava/lang/Object;

    .line 511
    iput v3, v0, Landroidx/compose/animation/core/MutatorMutex$mutate$2;->label:I

    .line 513
    invoke-interface {v1, v0}, Lkotlin/jvm/functions/Function1;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    .line 516
    move-result-object v0
    :try_end_204
    .catchall {:try_start_1f6 .. :try_end_204} :catchall_21f

    .line 517
    if-ne v0, v8, :cond_207

    .line 519
    goto :goto_21c

    .line 520
    :cond_207
    move-object v3, v4

    .line 521
    move-object v1, v6

    .line 522
    :goto_209
    :try_start_209
    iget-object v1, v1, Landroidx/compose/animation/core/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 524
    :cond_20b
    invoke-virtual {v1, v3, v10}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 527
    move-result v4

    .line 528
    if-eqz v4, :cond_212

    .line 530
    goto :goto_218

    .line 531
    :cond_212
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 534
    move-result-object v4
    :try_end_216
    .catchall {:try_start_209 .. :try_end_216} :catchall_21d

    .line 535
    if-eq v4, v3, :cond_20b

    .line 537
    :goto_218
    invoke-virtual {v2, v10}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 540
    move-object v8, v0

    .line 541
    :goto_21c
    return-object v8

    .line 542
    :catchall_21d
    move-exception v0

    .line 543
    goto :goto_232

    .line 544
    :catchall_21f
    move-exception v0

    .line 545
    move-object v3, v4

    .line 546
    move-object v1, v6

    .line 547
    :goto_222
    :try_start_222
    iget-object v1, v1, Landroidx/compose/animation/core/MutatorMutex;->currentMutator:Ljava/util/concurrent/atomic/AtomicReference;

    .line 549
    :goto_224
    invoke-virtual {v1, v3, v10}, Ljava/util/concurrent/atomic/AtomicReference;->compareAndSet(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 552
    move-result v4

    .line 553
    if-nez v4, :cond_231

    .line 555
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 558
    move-result-object v4

    .line 559
    if-ne v4, v3, :cond_231

    .line 561
    goto :goto_224

    .line 562
    :cond_231
    throw v0
    :try_end_232
    .catchall {:try_start_222 .. :try_end_232} :catchall_21d

    .line 563
    :goto_232
    invoke-virtual {v2, v10}, Lkotlinx/coroutines/sync/MutexImpl;->unlock(Ljava/lang/Object;)V

    .line 566
    throw v0

    .line 567
    :cond_236
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 570
    move-result-object v7

    .line 571
    if-eq v7, v4, :cond_1c6

    .line 573
    goto/16 :goto_1ad

    .line 575
    :pswitch_data_23e
    .packed-switch 0x0
        :pswitch_154  #00000000
        :pswitch_e3  #00000001
    .end packed-switch
.end method
