.class public final Landroidx/appcompat/widget/SearchView$SearchAutoComplete$1;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic $r8$classId:I

.field public final synthetic this$0:Ljava/lang/Object;


# direct methods
.method public synthetic constructor <init>(ILjava/lang/Object;)V
    .registers 3

    .line 1
    iput p1, p0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete$1;->$r8$classId:I

    .line 3
    iput-object p2, p0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete$1;->this$0:Ljava/lang/Object;

    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 8
    return-void
.end method


# virtual methods
.method public final run()V
    .registers 10

    .line 1
    iget v0, p0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete$1;->$r8$classId:I

    .line 3
    const/4 v1, 0x0

    .line 4
    const/4 v2, 0x2

    .line 5
    iget-object v3, p0, Landroidx/appcompat/widget/SearchView$SearchAutoComplete$1;->this$0:Ljava/lang/Object;

    .line 7
    packed-switch v0, :pswitch_data_56

    .line 10
    check-cast v3, Landroidx/core/view/MenuHostHelper;

    .line 12
    iget-object p0, v3, Landroidx/core/view/MenuHostHelper;->mMenuProviders:Ljava/lang/Object;

    .line 14
    check-cast p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;

    .line 16
    iget v0, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->state:I

    .line 18
    if-ne v0, v2, :cond_18

    .line 20
    if-nez v0, :cond_16

    .line 22
    goto :goto_18

    .line 23
    :cond_16
    iput v1, p0, Lcom/google/android/material/bottomsheet/BottomSheetBehavior;->state:I

    .line 25
    :cond_18
    :goto_18
    return-void

    .line 26
    :pswitch_19  #0x1
    check-cast v3, Landroidx/compose/ui/platform/AndroidComposeView;

    .line 28
    invoke-virtual {v3, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 31
    iget-object v4, v3, Landroidx/compose/ui/platform/AndroidComposeView;->previousMotionEvent:Landroid/view/MotionEvent;

    .line 33
    if-eqz v4, :cond_3d

    .line 35
    invoke-virtual {v4}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 38
    move-result p0

    .line 39
    const/16 v0, 0xa

    .line 41
    if-eq p0, v0, :cond_3d

    .line 43
    const/4 v0, 0x1

    .line 44
    if-eq p0, v0, :cond_3d

    .line 46
    const/4 v0, 0x7

    .line 47
    if-eq p0, v0, :cond_36

    .line 49
    const/16 v1, 0x9

    .line 51
    if-eq p0, v1, :cond_36

    .line 53
    move v5, v2

    .line 54
    goto :goto_37

    .line 55
    :cond_36
    move v5, v0

    .line 56
    :goto_37
    iget-wide v6, v3, Landroidx/compose/ui/platform/AndroidComposeView;->relayoutTime:J

    .line 58
    const/4 v8, 0x0

    .line 59
    invoke-virtual/range {v3 .. v8}, Landroidx/compose/ui/platform/AndroidComposeView;->sendSimulatedEvent(Landroid/view/MotionEvent;IJZ)V

    .line 62
    :cond_3d
    return-void

    .line 63
    :pswitch_3e  #0x0
    check-cast v3, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;

    .line 65
    iget-boolean p0, v3, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->mHasPendingShowSoftInputRequest:Z

    .line 67
    if-eqz p0, :cond_55

    .line 69
    invoke-virtual {v3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 72
    move-result-object p0

    .line 73
    const-string v0, "input_method"

    .line 75
    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 78
    move-result-object p0

    .line 79
    check-cast p0, Landroid/view/inputmethod/InputMethodManager;

    .line 81
    invoke-virtual {p0, v3, v1}, Landroid/view/inputmethod/InputMethodManager;->showSoftInput(Landroid/view/View;I)Z

    .line 84
    iput-boolean v1, v3, Landroidx/appcompat/widget/SearchView$SearchAutoComplete;->mHasPendingShowSoftInputRequest:Z

    .line 86
    :cond_55
    return-void

    .line 87
    :pswitch_data_56
    .packed-switch 0x0
        :pswitch_3e  #00000000
        :pswitch_19  #00000001
    .end packed-switch
.end method
