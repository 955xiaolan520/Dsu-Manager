.class public final Landroidx/appcompat/widget/AppCompatTextView$SuperCallerApi34;
.super Landroidx/compose/ui/platform/WeakCache;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# instance fields
.field public final synthetic this$0:Landroidx/appcompat/widget/AppCompatTextView;


# direct methods
.method public constructor <init>(Landroidx/appcompat/widget/AppCompatTextView;)V
    .registers 2

    .line 1
    iput-object p1, p0, Landroidx/appcompat/widget/AppCompatTextView$SuperCallerApi34;->this$0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 3
    invoke-direct {p0, p1}, Landroidx/compose/ui/platform/WeakCache;-><init>(Landroidx/appcompat/widget/AppCompatTextView;)V

    .line 6
    return-void
.end method


# virtual methods
.method public final setLineHeight(IF)V
    .registers 3

    .line 1
    iget-object p0, p0, Landroidx/appcompat/widget/AppCompatTextView$SuperCallerApi34;->this$0:Landroidx/appcompat/widget/AppCompatTextView;

    .line 3
    invoke-static {p0, p1, p2}, Landroidx/appcompat/widget/AppCompatTextView;->access$1201(Landroidx/appcompat/widget/AppCompatTextView;IF)V

    .line 6
    return-void
.end method
