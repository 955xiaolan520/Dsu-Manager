.class public final Landroidx/arch/core/executor/ArchTaskExecutor;
.super Lkotlin/math/MathKt;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# static fields
.field public static volatile sInstance:Landroidx/arch/core/executor/ArchTaskExecutor;


# instance fields
.field public final mDelegate:Ljava/lang/Object;


# direct methods
.method public constructor <init>(I)V
    .registers 3

    .line 1
    packed-switch p1, :pswitch_data_24

    .line 4
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 7
    new-instance p1, Landroidx/arch/core/executor/ArchTaskExecutor;

    .line 9
    const/4 v0, 0x1

    .line 10
    invoke-direct {p1, v0}, Landroidx/arch/core/executor/ArchTaskExecutor;-><init>(I)V

    .line 13
    iput-object p1, p0, Landroidx/arch/core/executor/ArchTaskExecutor;->mDelegate:Ljava/lang/Object;

    .line 15
    return-void

    .line 16
    :pswitch_f  #0x1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 19
    new-instance p1, Ljava/lang/Object;

    .line 21
    invoke-direct {p1}, Ljava/lang/Object;-><init>()V

    .line 24
    iput-object p1, p0, Landroidx/arch/core/executor/ArchTaskExecutor;->mDelegate:Ljava/lang/Object;

    .line 26
    new-instance p0, Landroidx/arch/core/executor/DefaultTaskExecutor$1;

    .line 28
    invoke-direct {p0}, Landroidx/arch/core/executor/DefaultTaskExecutor$1;-><init>()V

    .line 31
    const/4 p1, 0x4

    .line 32
    invoke-static {p1, p0}, Ljava/util/concurrent/Executors;->newFixedThreadPool(ILjava/util/concurrent/ThreadFactory;)Ljava/util/concurrent/ExecutorService;

    .line 35
    return-void

    nop

    .line 37
    :pswitch_data_24
    .packed-switch 0x1
        :pswitch_f  #00000001
    .end packed-switch
.end method
