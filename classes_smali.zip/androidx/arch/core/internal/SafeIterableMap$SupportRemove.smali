.class public abstract Landroidx/arch/core/internal/SafeIterableMap$SupportRemove;
.super Ljava/lang/Object;
.source "r8-map-id-d1aee01e0d337e6e364d750a30467ee5638285917fdc327d37aafe299a6a9569"


# virtual methods
.method public abstract supportRemove(Landroidx/arch/core/internal/SafeIterableMap$Entry;)V
.end method
